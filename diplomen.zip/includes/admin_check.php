<?php
// Admin authentication check
// This file should be included at the beginning of admin pages

if (!isset($_SESSION)) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit;
}

// Check if user is admin
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    // Redirect to homepage if not admin
    header('Location: homepage.php');
    exit;
}
?>
