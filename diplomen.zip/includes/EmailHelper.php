<?php
class EmailHelper {
    private $config;
    
    public function __construct() {
        $this->config = require __DIR__ . '/../config/mail.php';
    }
    
    public function sendPasswordRecoveryCode($email, $code) {
        $subject = 'Възстановяване на Паролата - Dronche.BG';
        $html = "<h2>Възстановяване на Парола</h2><p>Твоят код: <strong>$code</strong></p>";
        return $this->send($email, $subject, $html);
    }
    
    public function sendOrderConfirmation($email, $name, $order_id, $order_data) {
        $subject = "Потвърждение на Поръчка #$order_id";
        
        // Format order details
        $items_html = '';
        $items = $order_data['items'] ?? [];
        foreach ($items as $item) {
            $item_name = htmlspecialchars($item['name'] ?? 'Unknown');
            $qty = intval($item['quantity'] ?? 1);
            $price = floatval($item['actual_price'] ?? $item['price'] ?? 0);
            $subtotal = $qty * $price;
            $items_html .= "<tr style='border-bottom: 1px solid #ddd;'>";
            $items_html .= "<td style='padding: 8px;'>$item_name</td>";
            $items_html .= "<td style='padding: 8px; text-align: center;'>$qty</td>";
            $items_html .= "<td style='padding: 8px; text-align: right;'>€ " . number_format($price, 2) . "</td>";
            $items_html .= "<td style='padding: 8px; text-align: right;'>€ " . number_format($subtotal, 2) . "</td>";
            $items_html .= "</tr>";
        }
        
        $subtotal = floatval($order_data['subtotal'] ?? 0);
        $delivery = floatval($order_data['delivery_cost'] ?? 0);
        $total = floatval($order_data['total'] ?? 0);
        
        $html = "
        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
            <h2 style='color: #9FC131;'>Потвърждение на Поръчка</h2>
            <p>Здравей $name,</p>
            <p>Благодарим ти за твоята поръчка! Вижте детайлите по-долу:</p>
            
            <h3 style='color: #042940; margin-top: 20px;'>Поръчка #$order_id</h3>
            <p><strong>Номер на поръчка:</strong> #$order_id</p>
            <p><strong>Статус:</strong> " . ($order_data['status'] === 'pending' ? 'В обработка' : 'Чакане на плащане') . "</p>
            
            <h3 style='color: #042940; margin-top: 20px;'>Артикули</h3>
            <table style='width: 100%; border-collapse: collapse; margin: 15px 0;'>
                <thead>
                    <tr style='background-color: #f5f5f5;'>
                        <th style='padding: 10px; text-align: left;'>Продукт</th>
                        <th style='padding: 10px; text-align: center;'>Количество</th>
                        <th style='padding: 10px; text-align: right;'>Цена</th>
                        <th style='padding: 10px; text-align: right;'>Общо</th>
                    </tr>
                </thead>
                <tbody>
                    $items_html
                </tbody>
            </table>
            
            <h3 style='color: #042940; margin-top: 20px;'>Обобщение на плащане</h3>
            <table style='width: 100%; margin: 15px 0;'>
                <tr><td style='padding: 5px;'><strong>Подсумата:</strong></td><td style='text-align: right;'>€ " . number_format($subtotal, 2) . "</td></tr>
                <tr><td style='padding: 5px;'><strong>Доставка:</strong></td><td style='text-align: right;'>€ " . number_format($delivery, 2) . "</td></tr>
                <tr style='background-color: #f5f5f5; font-weight: bold;'>
                    <td style='padding: 10px;'><strong>ОБЩО:</strong></td>
                    <td style='text-align: right; padding: 10px;'>€ " . number_format($total, 2) . "</td>
                </tr>
            </table>
            
            <div style='background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px;'>
                <h3 style='color: #042940; margin-top: 0;'>Информация за доставка</h3>
                <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                <p><strong>Телефон:</strong> " . htmlspecialchars($order_data['phone'] ?? '-') . "</p>
            </div>
            
            <p style='margin-top: 20px; color: #666;'>Ако имаш въпроси, свържи се с нас на https://support/dronche.bg</p>
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
                Dronche.BG | Всички права запазени
            </p>
        </div>";
        
        return $this->send($email, $subject, $html);
    }
    
    public function sendOrderStatusUpdate($email, $name, $order_id, $new_status) {
        $status_bg = [
            'pending' => 'В обработка',
            'paid' => 'Платено',
            'shipped' => 'Изпратено',
            'delivered' => 'Доставено',
            'cancelled' => 'Отменено'
        ];
        
        $status_message = '';
        $status_color = '#042940';
        
        switch ($new_status) {
            case 'paid':
                $status_message = 'Вашето плащане е получено и обработено успешно! Благодарим ви!';
                $status_color = '#4caf50';
                break;
            case 'shipped':
                $status_message = 'Вашата поръчка е изпратена! Можете да следите вашия пакет със следващата информация.';
                $status_color = '#2196f3';
                break;
            case 'delivered':
                $status_message = 'Вашата поръчка е доставена! Надяваме се, че сте доволни с вашата покупка.';
                $status_color = '#4caf50';
                break;
            case 'cancelled':
                $status_message = 'Вашата поръчка е отменена. Ако имате въпроси, контактирайте нас.';
                $status_color = '#f44336';
                break;
            default:
                $status_message = 'Статусът на вашата поръчка е актуализиран.';
        }
        
        $subject = "Актуализация на Статуса на Поръчка #$order_id";
        
        $html = "
        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
            <h2 style='color: #9FC131;'>Актуализация на Поръчка</h2>
            <p>Здравей $name,</p>
            
            <p>Статусът на вашата поръчка е актуализиран:</p>
            
            <div style='background-color: " . (in_array($new_status, ['cancelled']) ? '#ffebee' : '#f5f5f5') . "; padding: 20px; border-radius: 5px; margin-top: 20px; border-left: 4px solid $status_color;'>
                <h3 style='color: $status_color; margin-top: 0;'>
                    Номер на Поръчка: #$order_id
                </h3>
                <p style='font-size: 16px; color: $status_color; font-weight: bold;'>
                    Статус: " . ($status_bg[$new_status] ?? ucfirst($new_status)) . "
                </p>
                <p style='color: #666;'>$status_message</p>
            </div>
            
            <p style='margin-top: 20px;'>
                <a href='https://dronche.bg/profile.php' style='background: #588157; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;'>
                    Вижте Поръчката
                </a>
            </p>
            
            <p style='margin-top: 20px; color: #666; font-size: 14px;'>
                Ако имате въпроси или проблеми, свържете се с нас на dronchebg@gmail.com
            </p>
            
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
                Dronche.BG | Всички права запазени
            </p>
        </div>";
        
        return $this->send($email, $subject, $html);
    }
    
    public function sendContactResponse($email, $name, $message) {
        $subject = 'Потвърждение на съобщението - Dronche.BG';
        $html = "
        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
            <h2 style='color: #9FC131;'>Благодарим ви за съобщението!</h2>
            <p>Здравей $name,</p>
            <p>Получихме вашето съобщение и ще се свържем с вас в скоро време.</p>
            
            <div style='background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px;'>
                <p><strong>Ваше съобщение:</strong></p>
                <p style='color: #666;'>" . nl2br(htmlspecialchars($message)) . "</p>
            </div>
            
            <p style='margin-top: 20px; color: #666;'>Ако имате спешни въпроси, свържете се с нас на:</p>
            <p>📞 +359 884 597 448</p>
            <p>📧 dronchebg@gmail.com</p>
            
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
                Dronche.BG | Всички права запазени
            </p>
        </div>";
        
        return $this->send($email, $subject, $html);
    }
    
    public function sendWelcomeEmail($email, $name) {
        $subject = 'Добре дошли на Dronche.BG!';
        $html = "
        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
            <h2 style='color: #9FC131;'>Добре дошли, $name!</h2>
            <p>Благодарим ви, че се регистрирахте на Dronche.BG</p>
            
            <p>Вашият акаунт е успешно създаден и сте готови да:</p>
            <ul style='color: #666;'>
                <li>Разглеждате нашия каталог с дронове</li>
                <li>Добавяте продукти в кошницата</li>
                <li>Следите вашите поръчки</li>
                <li>Управлявате вашите адреси за доставка</li>
            </ul>
            
            <p style='margin-top: 20px;'>
                <a href='https://dronche.bg/homepage.php' style='background: #588157; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;'>
                    Начало
                </a>
            </p>
            
            <p style='margin-top: 30px; color: #666; font-size: 14px;'>
                Ако имате въпроси, свържете се с нас на dronchebg@gmail.com
            </p>
            
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
                Dronche.BG | Всички права запазени
            </p>
        </div>";
        
        return $this->send($email, $subject, $html);
    }
    
    public function sendPasswordResetConfirmation($email, $name) {
        $subject = 'Паролата ви е успешно променена - Dronche.BG';
        $html = "
        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
            <h2 style='color: #9FC131;'>Парола променена успешно</h2>
            <p>Здравей $name,</p>
            <p>Паролата на вашия акаунт на Dronche.BG е успешно променена.</p>
            
            <div style='background-color: #e8f5e9; padding: 15px; border-radius: 5px; margin-top: 20px; border-left: 4px solid #4caf50;'>
                <p style='color: #2e7d32;'><strong>✓ Вашият акаунт е защитен</strong></p>
                <p style='color: #666;'>Можете да влезете с новата си парола в любо време.</p>
            </div>
            
            <p style='margin-top: 20px; color: #666;'>Ако не сте направили тази промяна, моля контактирайте нас веднага:</p>
            <p>📧 dronchebg@gmail.com</p>
            
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
                Dronche.BG | Всички права запазени
            </p>
        </div>";
        
        return $this->send($email, $subject, $html);
    }
    
    private function send($to, $subject, $html) {
        try {
            $host = $this->config['host'];
            $port = $this->config['port'] ?? 587;
            $user = $this->config['username'];
            $pass = $this->config['password'];
            $from = $this->config['from_email'];
            $name = $this->config['from_name'];
            $encryption = $this->config['encryption'] ?? 'tls';
            
            $this->log("DEBUG: Attempting to send email to $to via $host:$port with $encryption encryption");
            
            // Setup SSL/TLS context
            $context = stream_context_create([
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ]);
            
            // Determine connection type based on port and encryption
            $protocol = ($encryption === 'ssl' || $port == 465) ? 'ssl' : 'tcp';
            
            // Connect to SMTP server
            $smtp = stream_socket_client(
                "$protocol://$host:$port",
                $errno,
                $errstr,
                30,
                STREAM_CLIENT_CONNECT,
                $context
            );
            
            if (!$smtp) {
                $this->log("FAIL: Cannot connect to $protocol://$host:$port - $errstr ($errno)");
                return false;
            }
            
            // Read server response
            $this->readResponse($smtp);
            
            // EHLO
            $this->sendCommand($smtp, "EHLO localhost");
            $this->readResponse($smtp);
            
            // STARTTLS for port 587
            if ($port == 587 && $encryption === 'tls') {
                $this->sendCommand($smtp, "STARTTLS");
                $resp = $this->readResponse($smtp);
                if (strpos($resp, '220') === false) {
                    $this->log("STARTTLS failed: " . trim($resp));
                    fclose($smtp);
                    return false;
                }
                stream_socket_enable_crypto($smtp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                // Send EHLO again after STARTTLS
                $this->sendCommand($smtp, "EHLO localhost");
                $this->readResponse($smtp);
            }
            
            // AUTH LOGIN
            $this->sendCommand($smtp, "AUTH LOGIN");
            $this->readResponse($smtp);
            
            // Send username
            $this->sendCommand($smtp, base64_encode($user));
            $resp = $this->readResponse($smtp);
            if (strpos($resp, '334') === false) {
                $this->log("AUTH FAIL at username: " . trim($resp));
                fclose($smtp);
                return false;
            }
            
            // Send password
            $this->sendCommand($smtp, base64_encode($pass));
            $resp = $this->readResponse($smtp);
            if (strpos($resp, '235') === false && strpos($resp, '2.7.0') === false) {
                $this->log("AUTH FAIL: " . trim($resp));
                fclose($smtp);
                return false;
            }
            
            // MAIL FROM
            $this->sendCommand($smtp, "MAIL FROM: <$from>");
            $this->readResponse($smtp);
            
            // RCPT TO
            $this->sendCommand($smtp, "RCPT TO: <$to>");
            $this->readResponse($smtp);
            
            // DATA
            $this->sendCommand($smtp, "DATA");
            $this->readResponse($smtp);
            
            // Compose message with proper RFC 5322 compliant headers
            $msg = "From: " . $name . " <" . $from . ">\r\n";
            $msg .= "To: <" . $to . ">\r\n";
            $msg .= "Subject: " . $subject . "\r\n";
            $msg .= "Date: " . date('D, d M Y H:i:s O') . "\r\n";
            $msg .= "Message-ID: <" . time() . "-" . md5($to . $from) . "@dronche.bg>\r\n";
            $msg .= "X-Mailer: Dronche.BG Order System\r\n";
            $msg .= "X-Priority: 3\r\n";
            $msg .= "Reply-To: support@dronche.bg\r\n";
            $msg .= "Return-Path: <" . $from . ">\r\n";
            $msg .= "MIME-Version: 1.0\r\n";
            $msg .= "Content-Type: text/html; charset=UTF-8\r\n";
            $msg .= "Content-Transfer-Encoding: 8bit\r\n";
            $msg .= "Bcc: support@dronche.bg\r\n\r\n";
            $msg .= $html . "\r\n";
            
            fwrite($smtp, $msg . "\r\n.\r\n");
            $this->readResponse($smtp);
            
            // QUIT
            $this->sendCommand($smtp, "QUIT");
            fclose($smtp);
            
            $this->log("OK: Sent to $to");
            return true;
            
        } catch (Exception $e) {
            $this->log("ERROR: " . $e->getMessage());
            return false;
        }
    }
    
    private function sendCommand(&$smtp, $cmd) {
        fwrite($smtp, $cmd . "\r\n");
    }
    
    private function readResponse(&$smtp) {
        $response = "";
        while (!feof($smtp)) {
            $line = fgets($smtp, 1024);
            $response .= $line;
            if (strlen($line) > 3 && $line[3] === ' ') {
                break;
            }
        }
        return $response;
    }
    
    public function sendInvoice($email, $subject, $html) {
        return $this->send($email, $subject, $html);
    }
    
    private function log($msg) {
        $dir = __DIR__ . '/../logs';
        @mkdir($dir, 0755, true);
        file_put_contents($dir . '/email-errors.log', "[" . date('Y-m-d H:i:s') . "] $msg\n", FILE_APPEND);
    }
}
?>
