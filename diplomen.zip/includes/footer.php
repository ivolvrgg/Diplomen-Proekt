    <footer class="footer-section">
        <div class="footer-content">
            <div class="footer-cta">
                <div class="single-cta">
                    <i class="fas fa-map-marker-alt"></i>
                    <div class="cta-text">
                        <h4>Намери ни</h4>
                        <span>България, София</span>
                    </div>
                </div>
                <div class="single-cta">
                    <i class="fas fa-phone"></i>
                    <div class="cta-text">
                        <h4>Обади ни се</h4>
                        <span>+359 123 456 789</span>
                    </div>
                </div>
                <div class="single-cta">
                    <i class="far fa-envelope-open"></i>
                    <div class="cta-text">
                        <h4>Напиши ни</h4>
                        <span>info@dronche.bg</span>
                    </div>
                </div>
            </div>
            <div class="footer-social-icon">
                <span>Последвай ни</span>
                <a href="https://www.facebook.com"><i class="fab fa-facebook-f facebook-bg"></i></a>
                <a href="https://www.instagram.com"><i class="fab fa-instagram twitter-bg"></i></a>
                <a href="https://www.youtube.com"><i class="fab fa-youtube google-bg"></i></a>
            </div>
        </div>
        <div class="copyright-area">
            <p>&copy; Dronche.BG | Всички права запазени | <a href="privacy-policy.php" style="color: white; text-decoration: none; margin-left: 10px;">Политика за лични данни</a></p>
        </div>
    </footer>
