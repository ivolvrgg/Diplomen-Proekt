<?php
$page_title = 'Dronche.BG';
$page_css = 'homepage.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
<?php include 'includes/auth_check.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>
    
    <main id="main-content">
        <section class="featured-products">
            <div class="carousel-container">
                <div class="carousel-wrapper">
                    <div class="carousel">
                        <?php
                        // Get top 5 products for carousel
                        $carousel_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 5";
                        $carousel_result = $conn->query($carousel_query);
                        
                        while ($product = $carousel_result->fetch_assoc()) {
                        ?>
                        <div class="slide">
                            <a href="itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                                <img src="<?php echo htmlspecialchars(get_image_url($product['image_1'], $product['name'])); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27500%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27500%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2720%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E'">
                            </a>
                            <a href="itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                                <h2><?php echo number_format($product['price'], 2); ?> €</h2>
                                <p><?php echo htmlspecialchars($product['name']); ?></p>
                            </a>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="carousel-nav">
                        <button class="carousel-btn prev-btn">❮</button>
                        <button class="carousel-btn next-btn">❯</button>
                    </div>
                </div>
                
                <div class="indicators">
                    <?php
                    $carousel_result->data_seek(0);
                    $count = 0;
                    while ($product = $carousel_result->fetch_assoc()) {
                        $active = ($count === 0) ? 'active' : '';
                    ?>
                    <div class="indicator <?php echo $active; ?>"></div>
                    <?php
                        $count++;
                    }
                    ?>
                </div>
            </div>
        </section>
        
        <section class="best-sellers">
            <h2 class="section-title">Бестселъри</h2>
            <div class="bestsellers-container">
                <?php
                // Get best sellers (top products by stock or recent)
                $bestsellers_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 3";
                $bestsellers_result = $conn->query($bestsellers_query);
                
                while ($product = $bestsellers_result->fetch_assoc()) {
                    $image = get_image_url($product['image_1'], $product['name']);
                ?>
                <div class="bestseller-card">
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2716%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E'">
                        <div class="bestseller-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price"><?php echo number_format($product['price'], 2); ?> €</p>
                        </div>
                    </a>
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
        
        <section class="product-categories">
            <h2 class="section-title">Категории</h2>
            <div class="categories-container">
                <?php
                // Get all categories
                $cats_query = "SELECT * FROM categories ORDER BY sort_order ASC";
                $cats_result = $conn->query($cats_query);
                
                while ($cat = $cats_result->fetch_assoc()) {
                    // Get first product image from category for thumbnail
                    $thumb_query = "SELECT image_1 FROM products WHERE category_id = " . intval($cat['id']) . " AND is_active = 1 LIMIT 1";
                    $thumb_result = $conn->query($thumb_query);
                    $thumb_product = $thumb_result->fetch_assoc();
                    $thumb_image = get_image_url($thumb_product['image_1'] ?? '', $cat['name']);
                ?>
                <div class="category-card">
                    <a href="category-products.php?id=<?php echo $cat['id']; ?>" class="category-link">
                        <img src="<?php echo htmlspecialchars($thumb_image); ?>" alt="<?php echo htmlspecialchars($cat['name']); ?>" class="category-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2716%27 fill=%27%23999%27%3E<?php echo htmlspecialchars($cat['name']); ?> %3C/text%3E%3C/svg%3E'">
                        <div class="category-name"><?php echo htmlspecialchars($cat['name']); ?></div>
                    </a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
