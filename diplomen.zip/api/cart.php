<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', '0');  // Don't display errors directly
ini_set('log_errors', '1');       // Log errors instead

// Start session early to ensure proper initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set JSON header first
header('Content-Type: application/json; charset=utf-8');

// Catch any fatal errors and output as JSON
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server Error: ' . $errstr,
        'debug' => [
            'file' => $errfile,
            'line' => $errline,
            'code' => $errno
        ]
    ]);
    exit;
});

// Include database config
include '../config/db.php';

// Initialize cart in session if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if user is logged in
$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

// For guest users, create a unique guest ID based on session
if ($user_id === 0) {
    // Guest user
    if (!isset($_SESSION['guest_id'])) {
        $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
    }
    // Use -1 for guests in the database
    $db_user_id = -1;
    $guest_identifier = $_SESSION['guest_id'];
} else {
    // Logged-in user
    $db_user_id = $user_id;
    $guest_identifier = null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = isset($_POST['action']) ? $_POST['action'] : '';
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Handle JSON POST
        if (!empty($data)) {
            $product_id = intval($data['product_id'] ?? 0);
            $quantity = intval($data['quantity'] ?? 1);
            $action = $data['action'] ?? 'add';
        } else {
            $product_id = intval($_POST['product_id'] ?? 0);
            $quantity = intval($_POST['quantity'] ?? 1);
        }
        
        // Handle guest cart merge when user logs in
        if ($action === 'merge' && $user_id > 0 && !empty($data['items'])) {
            foreach ($data['items'] as $item) {
                $pid = intval($item['product_id']);
                $qty = intval($item['quantity']);
                $uid = $user_id;
                
                // Check if item already exists in their cart
                $check = $conn->query("SELECT id, quantity FROM cart WHERE user_id=$uid AND product_id=$pid");
                if ($check->num_rows > 0) {
                    $row = $check->fetch_assoc();
                    $newQty = $row['quantity'] + $qty;
                    $conn->query("UPDATE cart SET quantity=$newQty WHERE id={$row['id']}");
                } else {
                    $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($uid, $pid, $qty)");
                }
            }
            echo json_encode(['success' => true, 'message' => 'Cart merged successfully']);
            exit;
        }
        
        // Guests cannot add to database - they use localStorage instead
        if ($user_id === 0 && ($action === 'add' || $action === 'update')) {
            echo json_encode(['success' => false, 'guest' => true, 'message' => 'Guest cart uses localStorage']);
            exit;
        }
        
        if ($action === 'add' || $action === 'update') {
            if ($product_id > 0 && $quantity > 0) {
                // Verify product exists and get details
                $result = $conn->query("SELECT id, name, price, image_1, stock FROM products WHERE id = $product_id AND is_active = 1");
                
                if (!$result) {
                    throw new Exception('Database query failed: ' . $conn->error);
                }
                
                if ($result->num_rows > 0) {
                    $product = $result->fetch_assoc();
                    
                    // Check stock
                    if ($product['stock'] < $quantity) {
                        echo json_encode(['success' => false, 'message' => 'Недостатъчно количество на складе']);
                        exit;
                    }
                    
                    // Save to database (for both logged-in and guest users)
                    if ($action === 'update') {
                        // Update quantity to specific value
                        $update_query = "UPDATE cart SET quantity = $quantity WHERE user_id = $db_user_id AND product_id = $product_id";
                        $update_result = $conn->query($update_query);
                        if (!$update_result) {
                            throw new Exception('Failed to update cart: ' . $conn->error);
                        }
                    } else {
                        // Check if product already in cart
                        $check_query = "SELECT id, quantity FROM cart WHERE user_id = $db_user_id AND product_id = $product_id";
                        $check_result = $conn->query($check_query);
                        
                        if (!$check_result) {
                            throw new Exception('Database error: ' . $conn->error);
                        }
                        
                        if ($check_result->num_rows > 0) {
                            // Update quantity
                            $cart_item = $check_result->fetch_assoc();
                            $new_quantity = $cart_item['quantity'] + $quantity;
                            $update_query = "UPDATE cart SET quantity = $new_quantity WHERE id = " . intval($cart_item['id']);
                            $update_result = $conn->query($update_query);
                            if (!$update_result) {
                                throw new Exception('Failed to update cart quantity: ' . $conn->error);
                            }
                        } else {
                            // Insert new item
                            $insert_query = "INSERT INTO cart (user_id, product_id, quantity) VALUES ($db_user_id, $product_id, $quantity)";
                            $insert_result = $conn->query($insert_query);
                            if (!$insert_result) {
                                throw new Exception('Failed to insert into cart: ' . $conn->error);
                            }
                        }
                    }
                    
                    // Also save in session for consistency
                    if ($action === 'update') {
                        $_SESSION['cart'][$product_id] = [
                            'name' => $product['name'],
                            'price' => $product['price'],
                            'image' => $product['image_1'],
                            'quantity' => $quantity
                        ];
                    } else {
                        if (isset($_SESSION['cart'][$product_id])) {
                            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
                        } else {
                            $_SESSION['cart'][$product_id] = [
                                'name' => $product['name'],
                                'price' => $product['price'],
                                'image' => $product['image_1'],
                                'quantity' => $quantity
                            ];
                        }
                    }
                    
                    // Get updated cart count
                    $count_query = "SELECT COUNT(*) as count FROM cart WHERE user_id = $db_user_id";
                    $count_result = $conn->query($count_query);
                    if ($count_result) {
                        $count_row = $count_result->fetch_assoc();
                        $cart_count = $count_row['count'];
                    } else {
                        $cart_count = 0;
                    }
                    
                    echo json_encode(['success' => true, 'message' => 'Продукт добавен в количката', 'cart_count' => $cart_count]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Продуктът не е намерен или е неактивен']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Невалидни данни']);
            }
        } elseif ($action === 'remove') {
            if ($product_id > 0) {
                // Remove from database
                $delete_query = "DELETE FROM cart WHERE user_id = $db_user_id AND product_id = $product_id";
                $conn->query($delete_query);
                
                // Remove from session
                if (isset($_SESSION['cart'][$product_id])) {
                    unset($_SESSION['cart'][$product_id]);
                }
                
                echo json_encode(['success' => true, 'message' => 'Продукт премахнат']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Продуктът не е в количката']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Невалидно действие']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Грешка: ' . $e->getMessage()]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        
        // If no action, return simple cart items list (for badge)
        if (empty($action)) {
            if ($user_id > 0) {
                // Get logged-in user's cart
                $query = "SELECT id, product_id, quantity FROM cart WHERE user_id = $user_id";
                $result = $conn->query($query);
                
                if ($result && $result->num_rows > 0) {
                    $items = [];
                    while ($row = $result->fetch_assoc()) {
                        $items[] = [
                            'id' => intval($row['id']),
                            'product_id' => intval($row['product_id']),
                            'quantity' => intval($row['quantity'])
                        ];
                    }
                    echo json_encode($items);
                } else {
                    echo json_encode([]);
                }
            } else {
                // Guest user - return empty array (guest cart is in localStorage)
                echo json_encode([]);
            }
            exit;
        }
        
        if ($action === 'get') {
            // Load from database for both logged-in and guest users
            $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price, p.image_1 
                          FROM cart c 
                          JOIN products p ON c.product_id = p.id 
                          WHERE c.user_id = $db_user_id";
            $cart_result = $conn->query($cart_query);
            
            if (!$cart_result) {
                throw new Exception('Database query failed: ' . $conn->error);
            }
            
            $cart_data = [];
            $total = 0;
            
            while ($item = $cart_result->fetch_assoc()) {
                $cart_data[$item['product_id']] = [
                    'name' => $item['name'],
                    'price' => floatval($item['price']),
                    'image' => $item['image_1'],
                    'quantity' => intval($item['quantity'])
                ];
                $total += floatval($item['price']) * intval($item['quantity']);
            }
            
            // Update session with database cart
            $_SESSION['cart'] = $cart_data;
            
            echo json_encode(['success' => true, 'cart' => $cart_data, 'total' => $total]);
        } elseif ($action === 'count') {
            $count_query = "SELECT COUNT(*) as count FROM cart WHERE user_id = $db_user_id";
            $count_result = $conn->query($count_query);
            
            if (!$count_result) {
                throw new Exception('Database query failed: ' . $conn->error);
            }
            
            $count_row = $count_result->fetch_assoc();
            $count = $count_row['count'];
            echo json_encode(['success' => true, 'count' => $count]);
        } elseif ($action === 'get_product') {
            // Get product details from database for guest cart rendering
            $product_id = intval($_GET['product_id'] ?? 0);
            if ($product_id > 0) {
                $product_query = "SELECT id, name, price, image_1 FROM products WHERE id = $product_id AND is_active = 1";
                $product_result = $conn->query($product_query);
                
                if ($product_result && $product_result->num_rows > 0) {
                    $product = $product_result->fetch_assoc();
                    echo json_encode([
                        'success' => true,
                        'product' => [
                            'id' => intval($product['id']),
                            'name' => htmlspecialchars($product['name']),
                            'price' => floatval($product['price']),
                            'image_1' => htmlspecialchars($product['image_1'])
                        ]
                    ]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Product not found']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
            }
        } elseif ($action === 'get_products') {
            // Get multiple product details for guest cart
            $data = json_decode(file_get_contents('php://input'), true);
            $items = $data['items'] ?? [];
            
            if (empty($items)) {
                echo json_encode(['success' => false, 'message' => 'No items provided', 'items' => []]);
                exit;
            }
            
            // Extract product IDs and quantities
            $result_items = [];
            $errors = [];
            
            foreach ($items as $item) {
                $product_id = intval($item['product_id'] ?? 0);
                $quantity = intval($item['quantity'] ?? 1);
                
                if ($product_id <= 0) {
                    $errors[] = 'Invalid product ID: ' . json_encode($item);
                    continue;
                }
                
                $product_query = "SELECT id, name, price FROM products WHERE id = " . $product_id . " AND is_active = 1";
                $product_result = $conn->query($product_query);
                
                if (!$product_result) {
                    $errors[] = 'Database error for product ' . $product_id . ': ' . $conn->error;
                    continue;
                }
                
                if ($product_result->num_rows > 0) {
                    $product = $product_result->fetch_assoc();
                    $result_items[] = [
                        'id' => intval($product['id']),
                        'name' => htmlspecialchars($product['name']),
                        'price' => floatval($product['price']),
                        'quantity' => $quantity
                    ];
                } else {
                    $errors[] = 'Product not found or inactive: ' . $product_id;
                }
            }
            
            echo json_encode([
                'success' => !empty($result_items),
                'items' => $result_items,
                'errors' => $errors
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid request']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Грешка: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
