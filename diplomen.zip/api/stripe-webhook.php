<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('log_errors_max_len', 0);

require_once '../config/stripe.php';
require_once '../config/db.php';

// This endpoint should be added to Stripe Dashboard > Webhooks with events:
// - payment_intent.succeeded
// - payment_intent.payment_failed
// - payment_intent.canceled

$endpoint_secret = 'whsec_YOUR_WEBHOOK_SECRET'; // Replace with your Stripe webhook secret

$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, $endpoint_secret
    );
} catch(\UnexpectedValueException $e) {
    // Invalid payload
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    // Invalid signature
    http_response_code(400);
    exit();
}

// Handle the event
switch ($event->type) {
    case 'payment_intent.succeeded':
        $paymentIntent = $event->data->object;
        
        // Update order status
        $stmt = $conn->prepare("UPDATE orders SET 
            stripe_payment_status = 'succeeded',
            status = 'processing',
            updated_at = NOW()
            WHERE payment_intent_id = ?");
        $stmt->bind_param("s", $paymentIntent->id);
        $stmt->execute();
        $stmt->close();
        
        // Log success
        error_log("Payment succeeded for intent: " . $paymentIntent->id);
        break;

    case 'payment_intent.payment_failed':
        $paymentIntent = $event->data->object;
        
        // Update order status
        $stmt = $conn->prepare("UPDATE orders SET 
            stripe_payment_status = 'failed',
            status = 'payment_failed',
            updated_at = NOW()
            WHERE payment_intent_id = ?");
        $stmt->bind_param("s", $paymentIntent->id);
        $stmt->execute();
        $stmt->close();
        
        // Log failure
        error_log("Payment failed for intent: " . $paymentIntent->id);
        break;

    case 'payment_intent.canceled':
        $paymentIntent = $event->data->object;
        
        // Update order status
        $stmt = $conn->prepare("UPDATE orders SET 
            stripe_payment_status = 'canceled',
            status = 'cancelled',
            updated_at = NOW()
            WHERE payment_intent_id = ?");
        $stmt->bind_param("s", $paymentIntent->id);
        $stmt->execute();
        $stmt->close();
        
        // Log cancellation
        error_log("Payment cancelled for intent: " . $paymentIntent->id);
        break;

    default:
        error_log('Received unknown event type ' . $event->type);
}

http_response_code(200);
exit();
?>
