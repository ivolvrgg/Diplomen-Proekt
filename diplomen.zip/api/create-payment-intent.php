<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
header('Content-Type: application/json');

require_once '../config/db.php';
require_once '../config/stripe.php';
require_once '../includes/auth_check.php';

$response = ['success' => false, 'message' => '', 'checkout_url' => null];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }

    $amount = floatval($data['amount'] ?? 0);
    $order_id = intval($data['order_id'] ?? 0);
    $email = trim($data['email'] ?? '');

    if ($amount <= 0) {
        throw new Exception('Invalid amount');
    }

    if ($order_id <= 0) {
        throw new Exception('Invalid order ID');
    }

    // Verify order exists and belongs to user
    $user_id = get_user_id();
    if ($user_id > 0) {
        $order_check = $conn->query("SELECT id, total FROM orders WHERE id = $order_id AND user_id = $user_id");
        if (!$order_check || $order_check->num_rows === 0) {
            throw new Exception('Order not found or does not belong to you');
        }
        $order = $order_check->fetch_assoc();
        
        // Verify amount matches order total
        if (abs(floatval($order['total']) - $amount) > 0.01) {
            throw new Exception('Amount does not match order total');
        }
    }

    // Create Stripe Checkout Session (hosted payment page)
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'eur',
                'product_data' => [
                    'name' => 'Order #' . $order_id,
                ],
                'unit_amount' => intval($amount * 100), // Amount in cents
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/Diplomna_rabota/order-confirmation.php?order_id=' . $order_id . '&session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/Diplomna_rabota/payment.php',
        'customer_email' => $email,
        'metadata' => [
            'order_id' => $order_id,
        ],
    ]);

    // Update order with session ID
    $stmt = $conn->prepare("UPDATE orders SET payment_intent_id = ? WHERE id = ?");
    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("si", $session->id, $order_id);
    if (!$stmt->execute()) {
        throw new Exception('Failed to update order: ' . $conn->error);
    }
    $stmt->close();

    $response['success'] = true;
    $response['checkout_url'] = $session->url;
    $response['message'] = 'Checkout session created successfully';

} catch (\Stripe\Exception\ApiErrorException $e) {
    $response['success'] = false;
    $response['message'] = 'Stripe API Error: ' . $e->getMessage();
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;
?>

