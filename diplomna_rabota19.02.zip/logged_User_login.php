<?php
$page_title = 'Вход - Dronche.BG';
$page_css = 'logged_user_login.css';
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>
    
    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Вход</h1>
                <form class="login-form" id="loginForm">
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароля</label>
                        <input type="password" id="password" name="password" required placeholder="Въведи своя пароля">
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            Помни ме
                        </label>
                        <a href="#" class="forgot-password">Забравена пароля?</a>
                    </div>
                    
                    <button type="submit" class="login-btn">Вход</button>
                </form>
                
                <div class="signup-link">
                    Нямаш акаунт? <a href="logged_user_register.php">Регистрирай се тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Clear previous errors
            document.getElementById('emailError').textContent = '';
            document.getElementById('passwordError').textContent = '';
            
            // Submit to server
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            
            fetch('api/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    // Show error
                    const errorMsg = data.message || 'Възникна грешка';
                    if (errorMsg.includes('email')) {
                        document.getElementById('emailError').textContent = errorMsg;
                    } else if (errorMsg.includes('пароля')) {
                        document.getElementById('passwordError').textContent = errorMsg;
                    } else {
                        alert(errorMsg);
                    }
                }
            })
            .catch(err => {
                alert('Възникна грешка при вход');
                console.error(err);
            });
        });
    </script>
</body>
</html>
