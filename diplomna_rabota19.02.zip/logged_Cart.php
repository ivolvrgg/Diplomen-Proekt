<?php
session_start();
$page_title = 'Количка - Dronche.BG';
$page_css = 'cart.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>

    <main id="main-content" class="cart-container">
        <div class="container">
            <h1 class="section-title">Количка</h1>
            
            <div class="cart-content">
                <div class="cart-items" id="cart-items">
                    <?php
                    $subtotal = 0;
                    $cart_count = 0;
                    
                    // Get user ID from session (logged-in users only)
                    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                    
                    // Load cart from database for logged-in user
                    $cart_query = "SELECT c.product_id, c.quantity, c.id as cart_id, p.name, p.price, p.image_1 
                                  FROM cart c 
                                  JOIN products p ON c.product_id = p.id 
                                  WHERE c.user_id = $user_id";
                    $cart_result = $conn->query($cart_query);
                    
                    if ($cart_result && $cart_result->num_rows > 0) {
                        while ($item = $cart_result->fetch_assoc()) {
                            $item_total = $item['price'] * $item['quantity'];
                            $subtotal += $item_total;
                            $cart_count++;
                            $product_id = $item['product_id'];
                    ?>
                    <div class="cart-item" data-product-id="<?php echo htmlspecialchars($product_id); ?>">
                        <img src="<?php echo htmlspecialchars($item['image_1']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="cart-item-image">
                        <div class="cart-item-details">
                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                            <div class="cart-item-price"><?php echo number_format($item['price'], 2); ?> €</div>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="cart-qty-minus" data-product-id="<?php echo htmlspecialchars($product_id); ?>">-</button>
                            <span class="quantity-value"><?php echo intval($item['quantity']); ?></span>
                            <button class="cart-qty-plus" data-product-id="<?php echo htmlspecialchars($product_id); ?>">+</button>
                        </div>
                        <button class="remove-btn" data-product-id="<?php echo htmlspecialchars($product_id); ?>">Премахни</button>
                    </div>
                    <?php
                        }
                    } else {
                        echo '<p style="padding: 20px;">Вашата количка е празна. <a href="logged_Catalog.php">Продължете към пазаруването</a></p>';
                    }
                    ?>
                </div>
                
                <div class="cart-summary">
                    <h2>Приключване на поръчката</h2>
                    <div class="summary-row">
                        <span>Общо</span>
                        <span id="subtotal"><?php echo number_format($subtotal, 2); ?> €</span>
                    </div>
                    <div class="summary-row">
                        <span>Доставка</span>
                        <span id="shipping">6.00 €</span>
                    </div>
                    <div class="summary-row">
                        <span>ДДС (20%)</span>
                        <span id="vat"><?php echo number_format(($subtotal * 0.20), 2); ?> €</span>
                    </div>
                    <div class="summary-row total">
                        <span>Общо</span>
                        <span id="total"><?php echo number_format(($subtotal * 1.20) + 6, 2); ?> €</span>
                    </div>
                    <button class="checkout-btn" <?php echo empty($_SESSION['cart']) ? 'disabled' : ''; ?>>
                        <a href="logged_Payment.php" class="checkout-link" <?php echo empty($_SESSION['cart']) ? 'onclick="return false;"' : ''; ?>>Продължете към плащане</a>
                    </button>
                    <a href="logged_Catalog.php" class="continue-shopping">Продължете към пазаруването</a>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    
    <script>
        // Update cart totals
        function updateCartTotals() {
            let subtotal = 0;
            document.querySelectorAll('.cart-item').forEach(item => {
                const priceText = item.querySelector('.cart-item-price').textContent.trim();
                // Extract number from formatted price (remove € and whitespace, replace comma with dot)
                const price = parseFloat(priceText.replace(/[€\s,]/g, '').replace(',', '.'));
                const quantity = parseInt(item.querySelector('.quantity-value').textContent);
                subtotal += price * quantity;
            });
            
            const shipping = 6.00;
            const vat = subtotal * 0.20;
            const total = (subtotal * 1.20) + shipping;
            
            document.getElementById('subtotal').textContent = subtotal.toFixed(2) + ' €';
            document.getElementById('vat').textContent = vat.toFixed(2) + ' €';
            document.getElementById('total').textContent = total.toFixed(2) + ' €';
        }
        
        // Update quantity in database
        function updateQuantity(productId, newQuantity) {
            if (newQuantity <= 0) return;
            
            fetch('api/cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    product_id: productId, 
                    quantity: newQuantity,
                    action: 'update' 
                })
            })
            .then(r => r.json())
            .then(data => {
                if (!data.success) {
                    console.error(data.message);
                    location.reload();
                }
            })
            .catch(err => console.error('Error updating quantity:', err));
        }
        
        // Remove item
        document.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                fetch('api/cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ product_id: productId, action: 'remove' })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`[data-product-id="${productId}"]`).remove();
                        updateCartTotals();
                        if (document.querySelectorAll('.cart-item').length === 0) {
                            document.getElementById('cart-items').innerHTML = '<p style="padding: 20px;">Вашата количка е празна. <a href="logged_Catalog.php">Продължете към пазаруването</a></p>';
                        }
                    }
                });
            });
        });
        
        // Quantity buttons for cart
        document.querySelectorAll('.cart-qty-plus').forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                const quantityEl = this.parentElement.querySelector('.quantity-value');
                const newQty = parseInt(quantityEl.textContent) + 1;
                quantityEl.textContent = newQty;
                updateQuantity(productId, newQty);
                updateCartTotals();
            });
        });
        
        document.querySelectorAll('.cart-qty-minus').forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                const quantityEl = this.parentElement.querySelector('.quantity-value');
                let newQty = parseInt(quantityEl.textContent) - 1;
                if (newQty < 1) newQty = 1;
                if (newQty === parseInt(quantityEl.textContent)) return; // No change
                quantityEl.textContent = newQty;
                updateQuantity(productId, newQty);
                updateCartTotals();
            });
        });
    </script>
</body>
</html>
