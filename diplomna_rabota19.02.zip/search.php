<?php
$page_title = 'Резултати от търсене - Dronche.BG';
$page_css = 'category-products.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <section class="category-header">
            <div class="container">
                <h1 class="category-title">Резултати от търсене</h1>
            </div>
        </section>

        <section class="category-products">
            <div class="container">
                <?php
                $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
                
                if (!empty($search_query)) {
                    $search_term = '%' . ($conn->real_escape_string($search_query)) . '%';
                    
                    $query = "SELECT * FROM products 
                             WHERE (name LIKE '$search_term' OR description LIKE '$search_term') 
                             AND is_active = 1 
                             ORDER BY name ASC";
                    $result = $conn->query($query);
                    
                    if ($result && $result->num_rows > 0) {
                        echo "<p style='margin-bottom: 20px;'>Търсене за: <strong>" . htmlspecialchars($search_query) . "</strong> - Намерени <strong>" . $result->num_rows . "</strong> продукт(и)</p>";
                        echo "<div class='products-grid'>";
                        
                        while ($product = $result->fetch_assoc()) {
                            $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                ?>
                    <div class="product-card">
                        <div class="product-image-wrapper">
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                            <div class="product-overlay">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="view-details-btn">Детайли</a>
                            </div>
                        </div>
                        
                        <div class="product-info">
                            <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-price"><?php echo number_format($product['price'], 2); ?> €</p>
                            <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                            </p>
                        </div>
                        
                        <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                    </div>
                <?php
                        }
                        echo "</div>";
                    } else {
                        echo "<p>Няма намерени продукти за \"" . htmlspecialchars($search_query) . "\". Опитайте да търсите с други ключови думи.</p>";
                    }
                } else {
                    echo "<p>Моля, въведете термин за търсене.</p>";
                }
                ?>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
