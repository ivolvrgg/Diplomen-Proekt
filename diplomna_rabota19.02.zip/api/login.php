<?php
session_start();
header('Content-Type: application/json');
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validation
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email и пароля са задължителни']);
        exit;
    }
    
    // Get user from database
    $emailEscaped = $conn->real_escape_string($email);
    $query = "SELECT id, fullname, password_hash, is_active FROM users WHERE email = '$emailEscaped'";
    $result = $conn->query($query);
    
    if (!$result || $result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Неправилен email или пароля']);
        exit;
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        echo json_encode(['success' => false, 'message' => 'Неправилен email или пароля']);
        exit;
    }
    
    // Check if user is active
    if (!$user['is_active']) {
        echo json_encode(['success' => false, 'message' => 'Вашия акаунт е деактивиран']);
        exit;
    }
    
    // Set session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $email;
    $_SESSION['user_name'] = $user['fullname'];
    
    echo json_encode(['success' => true, 'message' => 'Влизате успешно!', 'redirect' => 'homepage.php']);
} else {
    echo json_encode(['success' => false, 'message' => 'Невалиден метод на заявка']);
}
?>
