<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['address_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Адрес ID е задължителен']);
    exit;
}

$user_id = $_SESSION['user_id'];
$address_id = $data['address_id'];

try {
    // Verify address belongs to user
    $result = $conn->query("SELECT user_id FROM addresses WHERE id = '$address_id'");
    $addr = $result->fetch_assoc();
    
    if (!$addr || $addr['user_id'] != $user_id) {
        throw new Exception('Адресът не принадлежи на твоя профил');
    }

    $sql = "DELETE FROM addresses WHERE id = '$address_id' AND user_id = '$user_id'";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Адресът е изтрит успешно']);
    } else {
        throw new Exception('Грешка при изтриване на адреса');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
