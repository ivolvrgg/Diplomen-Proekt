<?php
session_start();
header('Content-Type: application/json');
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm-password'] ?? '';
    
    // Validation
    $errors = [];
    
    if (empty($fullname)) {
        $errors[] = 'Пълното име е задължително';
    } elseif (strlen($fullname) < 3) {
        $errors[] = 'Пълното име трябва да е поне 3 символа';
    }
    
    if (empty($email)) {
        $errors[] = 'Email адреса е задължителен';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Невалиден email адрес';
    }
    
    if (empty($password)) {
        $errors[] = 'Паролата е задължителна';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Паролата трябва да е поне 6 символа';
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = 'Паролите не съвпадат';
    }
    
    if (!empty($errors)) {
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }
    
    // Check if email already exists
    $checkEmail = $conn->query("SELECT id FROM users WHERE email = '" . $conn->real_escape_string($email) . "'");
    if ($checkEmail && $checkEmail->num_rows > 0) {
        echo json_encode(['success' => false, 'errors' => ['Този email адрес вече е регистриран']]);
        exit;
    }
    
    // Hash password
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    
    // Insert user
    $fullnameEscaped = $conn->real_escape_string($fullname);
    $emailEscaped = $conn->real_escape_string($email);
    
    $insertQuery = "INSERT INTO users (fullname, email, password_hash, is_active) 
                   VALUES ('$fullnameEscaped', '$emailEscaped', '$passwordHash', 1)";
    
    if ($conn->query($insertQuery)) {
        $userId = $conn->insert_id;
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_name'] = $fullname;
        
        echo json_encode(['success' => true, 'message' => 'Регистрацията беше успешна!', 'redirect' => 'logged_Homepage.php']);
    } else {
        echo json_encode(['success' => false, 'errors' => ['Възникна грешка при регистрацията. Опитайте отново.']]);
    }
} else {
    echo json_encode(['success' => false, 'errors' => ['Невалиден метод на заявка']]);
}
?>
