<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['old_password']) || empty($data['new_password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Паролите са задължителни']);
    exit;
}

$user_id = $_SESSION['user_id'];
$oldPassword = $data['old_password'];
$newPassword = $data['new_password'];

try {
    // Get user's current password hash
    $result = $conn->query("SELECT password_hash FROM users WHERE id = '$user_id'");
    $user = $result->fetch_assoc();
    
    if (!$user) {
        throw new Exception('Потребителят не е намерен');
    }

    // Verify old password
    if (!password_verify($oldPassword, $user['password_hash'])) {
        throw new Exception('Текущата парола е неправилна');
    }

    // Hash new password
    $newHash = password_hash($newPassword, PASSWORD_BCRYPT);

    // Update password
    $sql = "UPDATE users SET password_hash = '$newHash' WHERE id = '$user_id'";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Паролата е променена успешно']);
    } else {
        throw new Exception('Грешка при промяна на паролата');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
