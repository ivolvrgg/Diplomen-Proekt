<?php
session_start();
header('Content-Type: application/json');
include '../config/db.php';

// Initialize cart in session if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if user is logged in
$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

// For guest users, create a unique guest ID based on session
if ($user_id === 0) {
    if (!isset($_SESSION['guest_id'])) {
        $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
    }
    // Use a negative ID for guests in the database
    $db_user_id = -1;
    $guest_identifier = $_SESSION['guest_id'];
} else {
    $db_user_id = $user_id;
    $guest_identifier = null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Handle JSON POST
    if (!empty($data)) {
        $product_id = intval($data['product_id'] ?? 0);
        $quantity = intval($data['quantity'] ?? 1);
        $action = $data['action'] ?? 'add';
    } else {
        $product_id = intval($_POST['product_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 1);
    }
    
    if ($action === 'add' || $action === 'update') {
        if ($product_id > 0 && $quantity > 0) {
            // Verify product exists and get details
            $result = $conn->query("SELECT id, name, price, image_1, stock FROM products WHERE id = $product_id AND is_active = 1");
            
            if (!$result) {
                echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
                exit;
            }
            
            if ($result->num_rows > 0) {
                $product = $result->fetch_assoc();
                
                // Check stock
                if ($product['stock'] < $quantity) {
                    echo json_encode(['success' => false, 'message' => 'Недостатъчно количество на складе']);
                    exit;
                }
                
                // Save to database (for both logged-in and guest users)
                if ($action === 'update') {
                    // Update quantity to specific value
                    $update_result = $conn->query("UPDATE cart SET quantity = $quantity WHERE user_id = $db_user_id AND product_id = $product_id");
                    if (!$update_result) {
                        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
                        exit;
                    }
                } else {
                    // Check if product already in cart
                    $check_query = "SELECT id, quantity FROM cart WHERE user_id = $db_user_id AND product_id = $product_id";
                    $check_result = $conn->query($check_query);
                    
                    if (!$check_result) {
                        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
                        exit;
                    }
                    
                    if ($check_result->num_rows > 0) {
                        // Update quantity
                        $cart_item = $check_result->fetch_assoc();
                        $new_quantity = $cart_item['quantity'] + $quantity;
                        $update_result = $conn->query("UPDATE cart SET quantity = $new_quantity WHERE id = " . $cart_item['id']);
                        if (!$update_result) {
                            echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
                            exit;
                        }
                    } else {
                        // Insert new item
                        $insert_result = $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($db_user_id, $product_id, $quantity)");
                        if (!$insert_result) {
                            echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
                            exit;
                        }
                    }
                }
                
                // Also save in session for consistency
                if ($action === 'update') {
                    $_SESSION['cart'][$product_id] = [
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'image' => $product['image_1'],
                        'quantity' => $quantity
                    ];
                } else {
                    if (isset($_SESSION['cart'][$product_id])) {
                        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
                    } else {
                        $_SESSION['cart'][$product_id] = [
                            'name' => $product['name'],
                            'price' => $product['price'],
                            'image' => $product['image_1'],
                            'quantity' => $quantity
                        ];
                    }
                }
                
                // Get updated cart count
                $count_result = $conn->query("SELECT COUNT(*) as count FROM cart WHERE user_id = $db_user_id");
                if ($count_result) {
                    $count_row = $count_result->fetch_assoc();
                    $cart_count = $count_row['count'];
                } else {
                    $cart_count = 0;
                }
                
                echo json_encode(['success' => true, 'message' => 'Продукт добавен в количката', 'cart_count' => $cart_count]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Продуктът не е намерен или е неактивен']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Невалидни данни']);
        }
    } elseif ($action === 'remove') {
        if ($product_id > 0) {
            // Remove from database
            $conn->query("DELETE FROM cart WHERE user_id = $db_user_id AND product_id = $product_id");
            
            // Remove from session
            if (isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
            }
            
            echo json_encode(['success' => true, 'message' => 'Продукт премахнат']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Продуктът не е в количката']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Невалидно действие']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    
    if ($action === 'get') {
        // Load from database for both logged-in and guest users
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price, p.image_1 
                      FROM cart c 
                      JOIN products p ON c.product_id = p.id 
                      WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);
        $cart_data = [];
        $total = 0;
        
        while ($item = $cart_result->fetch_assoc()) {
            $cart_data[$item['product_id']] = [
                'name' => $item['name'],
                'price' => floatval($item['price']),
                'image' => $item['image_1'],
                'quantity' => intval($item['quantity'])
            ];
            $total += floatval($item['price']) * intval($item['quantity']);
        }
        
        // Update session with database cart
        $_SESSION['cart'] = $cart_data;
        
        echo json_encode(['success' => true, 'cart' => $cart_data, 'total' => $total]);
    } elseif ($action === 'count') {
        $count_result = $conn->query("SELECT COUNT(*) as count FROM cart WHERE user_id = $db_user_id");
        $count_row = $count_result->fetch_assoc();
        $count = $count_row['count'];
        echo json_encode(['success' => true, 'count' => $count]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
