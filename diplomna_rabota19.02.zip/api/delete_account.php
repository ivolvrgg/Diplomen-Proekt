<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$user_id = $_SESSION['user_id'];

try {
    // Start transaction to delete user and related data
    $conn->begin_transaction();

    // Delete user's orders and order items
    $ordersResult = $conn->query("SELECT id FROM orders WHERE user_id = '$user_id'");
    if ($ordersResult && $ordersResult->num_rows > 0) {
        while ($order = $ordersResult->fetch_assoc()) {
            $conn->query("DELETE FROM order_items WHERE order_id = {$order['id']}");
        }
        $conn->query("DELETE FROM orders WHERE user_id = '$user_id'");
    }

    // Delete user's addresses
    $conn->query("DELETE FROM addresses WHERE user_id = '$user_id'");

    // Delete user
    $conn->query("DELETE FROM users WHERE id = '$user_id'");

    // Commit transaction
    $conn->commit();

    // Logout the user
    session_destroy();

    echo json_encode(['success' => true, 'message' => 'Профилът е изтрит успешно']);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Грешка при изтриване на профила: ' . $e->getMessage()]);
}

$conn->close();
?>
