<?php
$page_title = 'Dronche.BG - Каталог';
$page_css = 'logged_Catalog.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>

    <main id="main-content">
        <?php
        $categories_query = "SELECT * FROM categories ORDER BY sort_order ASC";
        $categories_result = $conn->query($categories_query);
        
        if ($categories_result && $categories_result->num_rows > 0) {
            while ($category = $categories_result->fetch_assoc()) {
                // Use prepared statement for products query
                $products_query = "SELECT * FROM products WHERE category_id = ? AND is_active = 1 LIMIT 8";
                $products_stmt = $conn->prepare($products_query);
                
                if ($products_stmt) {
                    $products_stmt->bind_param("i", $category['id']);
                    $products_stmt->execute();
                    $products_result = $products_stmt->get_result();
                    $product_count = $products_result->num_rows;
                    
                    if ($product_count > 0) {
            ?>
            <section class="product-categories">
                <h2 class="section-title"><?php echo htmlspecialchars($category['name']); ?></h2>
                <div class="bestsellers-container">
                    <?php
                    while ($product = $products_result->fetch_assoc()) {
                        $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                    ?>
                    <div class="bestseller-card">
                        <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image">
                            <div class="bestseller-info">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="price"><?php echo number_format($product['price'], 2); ?> €</p>
                            </div>
                        </a>
                        <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </section>
            <?php
                    }
                    $products_stmt->close();
                }
            }
        }
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
