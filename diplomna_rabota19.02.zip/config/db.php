<?php
// Database configuration file for reusable connections

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'dron_db';

try {
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}
?>
