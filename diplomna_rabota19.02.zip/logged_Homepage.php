<?php
$page_title = 'Dronche.BG';
$page_css = 'homepage.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>
    
    <main id="main-content">
        <section class="featured-products">
            <div class="carousel-container">
                <div class="carousel-wrapper">
                    <div class="carousel">
                        <?php
                        // Get top 5 products for carousel
                        $carousel_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 5";
                        $carousel_result = $conn->query($carousel_query);
                        
                        while ($product = $carousel_result->fetch_assoc()) {
                        ?>
                        <div class="slide">
                            <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                                <img src="<?php echo htmlspecialchars($product['image_1']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            </a>
                            <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                                <h2><?php echo number_format($product['price'], 2); ?> €</h2>
                                <p><?php echo htmlspecialchars($product['name']); ?></p>
                            </a>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="carousel-nav">
                        <button class="carousel-btn prev-btn">❮</button>
                        <button class="carousel-btn next-btn">❯</button>
                    </div>
                </div>
                
                <div class="indicators">
                    <div class="indicator active"></div>
                    <div class="indicator"></div>
                    <div class="indicator"></div>
                </div>
            </div>
        </section>
        
        <section class="best-sellers">
            <h2 class="section-title">Бестселъри</h2>
            <div class="bestsellers-container">
                <?php
                $bestsellers_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 3";
                $bestsellers_result = $conn->query($bestsellers_query);
                
                while ($product = $bestsellers_result->fetch_assoc()) {
                    $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                ?>
                <div class="bestseller-card">
                    <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image">
                        <div class="bestseller-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price"><?php echo number_format($product['price'], 2); ?> €</p>
                            <p class="description"><?php echo htmlspecialchars(substr($product['description'] ?? '', 0, 60)); ?></p>
                        </div>
                    </a>
                    <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
        
        <section class="product-categories">
            <h2 class="section-title">Категории</h2>
            <div class="categories-container">
                <div class="category-card">
                    <a href="category-products.php?id=1" class="category-link">
                        <img src="https://images.unsplash.com/photo-1516268335757-f0ec2afb6172?w=400" alt="ДРОНОВЕ" class="category-image">
                        <div class="category-name">ДРОНОВЕ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="category-products.php?id=2" class="category-link">
                        <img src="https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400" alt="RC САМОЛЕТИ" class="category-image">
                        <div class="category-name">RC САМОЛЕТИ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="category-products.php?id=3" class="category-link">
                        <img src="https://images.unsplash.com/photo-1559163238-94ce64fbea90?w=400" alt="RC ЛОДКИ" class="category-image">
                        <div class="category-name">RC ЛОДКИ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="category-products.php?id=4" class="category-link">
                        <img src="https://images.unsplash.com/photo-1581235720704-06d3acfcb36f?w=400" alt="RC КОЛИ" class="category-image">
                        <div class="category-name">RC КОЛИ</div>
                    </a>
                </div>

                <div class="category-card">
                    <a href="category-products.php?id=5" class="category-link">
                        <img src="https://images.unsplash.com/photo-1579481516173-29c5c2e417c9?w=400" alt="БАТЕРИИ" class="category-image">
                        <div class="category-name">БАТЕРИИ</div>
                    </a>
                </div>

                <div class="category-card">
                    <a href="category-products.php?id=6" class="category-link">
                        <img src="https://images.unsplash.com/photo-1598933247716-3eea7e4e13ba?w=400" alt="ДЖОЙСТИЦИ" class="category-image">
                        <div class="category-name">ДЖОЙСТИЦИ</div>
                    </a>
                </div>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
