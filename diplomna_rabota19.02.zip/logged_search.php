<?php
$page_title = 'Резултати от търсене - Dronche.BG';
$page_css = 'logged_Catalog.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>

    <main id="main-content">
        <?php
        $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
        
        if (!empty($search_query)) {
            $search_term = '%' . ($conn->real_escape_string($search_query)) . '%';
            
            $query = "SELECT * FROM products 
                     WHERE (name LIKE '$search_term' OR description LIKE '$search_term') 
                     AND is_active = 1 
                     ORDER BY name ASC";
            $result = $conn->query($query);
            
            if ($result && $result->num_rows > 0) {
        ?>
            <section class="product-categories">
                <h2 class="section-title">Резултати за: <?php echo htmlspecialchars($search_query); ?> (<?php echo $result->num_rows; ?> намерени)</h2>
                <div class="bestsellers-container">
                    <?php
                    while ($product = $result->fetch_assoc()) {
                        $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                    ?>
                    <div class="bestseller-card">
                        <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image">
                            <div class="bestseller-info">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="price"><?php echo number_format($product['price'], 2); ?> €</p>
                            </div>
                        </a>
                        <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </section>
        <?php
            } else {
                echo "<p style='padding: 20px;'>Няма намерени продукти за \"" . htmlspecialchars($search_query) . "\". Опитайте да търсите с други ключови думи.</p>";
            }
        } else {
            echo "<p style='padding: 20px;'>Моля, въведете термин за търсене.</p>";
        }
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
