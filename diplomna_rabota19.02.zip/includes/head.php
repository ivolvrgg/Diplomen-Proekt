<?php
if (!isset($page_title)) {
    $page_title = 'Dronche.BG';
}
if (!isset($page_css)) {
    $page_css = '';
}
?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo htmlspecialchars($page_title); ?>
    </title>

    <!-- Global site CSS (provides nav/footer and base styles) -->
    <link rel="stylesheet" href="homepage.css">

    <?php if (!empty($page_css)): ?>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($page_css); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <a href="#main-content" class="skip-link">Skip to main content</a>
