# Card Payment Implementation Guide

## Overview

The Stripe card payment flow has been implemented to properly create orders after payment is confirmed. Previously, after successful Stripe payment, no order was created in the database. This has now been fixed with a new order handler endpoint.

## How It Works

### Previous Flow (BROKEN)
```
payment.php 
→ api/create-payment-intent.php 
→ Stripe Checkout
→ order-confirmation.php?session_id=XXX 
→ ❌ NO ORDER IN DATABASE
```

### New Flow (FIXED)
```
payment.php 
→ api/create-payment-intent.php 
→ Stripe Checkout
→ api/stripe-order-handler.php (NEW)
  - Verifies payment was successful
  - Creates order in database
  - Sends confirmation email
→ order-confirmation.php?order_id=123
→ ✓ ORDER CREATED AND VISIBLE IN PROFILE
```

## New Components

### 1. `api/stripe-order-handler.php`

**Purpose:** Handles post-payment order creation

**Triggered by:** Stripe success_url redirect after successful payment

**Process:**
1. Receives `session_id` from Stripe
2. Calls Stripe API to retrieve and verify payment
3. Extracts order metadata from Stripe session:
   - User ID, email, phone
   - Delivery method, cost, office
4. Creates order in database:
   - Inserts main order record
   - Inserts order items (from cart)
   - Clears cart for logged-in users
   - Uses transactions with proper commit()
5. Sends confirmation email
6. Redirects to order-confirmation.php with order_id

**Error Handling:**
- If payment not completed: redirects to payment.php with error
- If order creation fails: rolls back transaction
- Extensive error logging to PHP error log

### 2. Updated `api/create-payment-intent.php`

**Change:**
- `success_url` now points to `api/stripe-order-handler.php`
- All necessary metadata still passed to Stripe session

**Metadata Stored in Stripe:**
```php
[
    'user_id' => 'guest' or user_id,
    'email' => customer email,
    'phone' => customer phone,
    'delivery_method' => 'courier' or 'econt',
    'delivery_method_id' => database ID,
    'delivery_office_id' => office ID (if ECONT),
    'delivery_cost' => cost as string
]
```

## Payment Methods Supported

### 1. COD (Cash on Delivery)
- ✓ User fills form with payment_method='cod'
- ✓ Submits to api/orders.php
- ✓ Order created immediately
- ✓ Available on payment.php

### 2. Card (Stripe)
- ✓ User fills form with payment_method='card'
- ✓ Submits to api/create-payment-intent.php
- ✓ Gets Stripe checkout URL
- ✓ Redirects to Stripe payment page
- ✓ After payment → stripe-order-handler.php creates order
- ✓ Redirects to confirmation page
- ✓ Order visible in user profile

## Invoice Options

### For COD Orders
- ✓ Invoice checkbox available on payment.php
- ✓ If checked: invoice generated and emailed after order created
- ✓ Invoice stored in uploads/invoices/
- ✓ Invoice record saved in database

### For Card (Stripe) Orders
- Currently: No invoice option
- Can be added later by:
  1. Passing invoice_requested in Stripe metadata
  2. Handling in stripe-order-handler.php
  3. Generating invoice after order creation

## Delivery Methods

Both payment methods work with both delivery methods:

### Courier (Delivery to Address)
- User enters address on payment.php
- Works with COD ✓
- Works with Card ✓

### ECONT (Office Pickup)
- User selects office via ECONT iframe
- Office ID passed to handler
- Works with COD ✓
- Works with Card ✓

## Testing Steps

### Test 1: Verify Implementation Files
```bash
# Check handler file exists
cd /path/to/diplomna_rabota
ls -la api/stripe-order-handler.php

# Run setup test
php test-stripe-flow.php
```

### Test 2: Make a COD Test Order (Existing, Should Still Work)
1. Go to payment.php
2. Fill form with:
   - Payment method: "Плащане при доставка" (COD)
   - Delivery: "Куриер до адрес" (Courier)
   - Email: your@email.com
   - Phone: +359888123456
3. Submit
4. Check:
   - ✓ Order appears in profile immediately
   - ✓ Order number displayed
   - ✓ Confirmation email received

### Test 3: Make a Card Payment Test Order
**NOTE:** Requires Stripe account in test mode

1. Go to payment.php
2. Fill form with:
   - Payment method: "Платежна карта" (Card)
   - Delivery: "Куриер до адрес" (Courier)
   - Email: your@email.com
   - Phone: +359888123456
   - Cart: Add items to cart first
3. Click "Pay Now"
4. Stripe checkout page opens
5. Use test card: `4242 4242 4242 4242`
6. Expiry: `12/25`, CVC: `123`
7. Enter email/name (any test data)
8. Complete payment
9. Check:
   - ✓ Redirected to order-confirmation.php
   - ✓ Order number displayed
   - ✓ Order appears in profile
   - ✓ Confirmation email received
   - ✓ Order visible in database

### Test 4: Card Payment with ECONT Delivery
Same as Test 3 but:
- Select "Офис на eсонт" delivery
- Select office from ECONT iframe
- Order should include office_id

## Database Changes (Already Done)

**orders table:**
- Added columns (already migrated):
  - `delivery_method_id` INT
  - `delivery_office_id` INT NULL
  - `invoice_requested` TINYINT(1)
  - `payment_method` VARCHAR

**delivery_methods table:**
- Verified correct IDs:
  - ID 1: Courier
  - ID 3: ECONT (was incorrectly 2)

**invoices table:**
- Already created, ready for invoice records

## Error Handling

### Common Issues

**Issue: "Payment not completed"**
- Payment was cancelled or not authorized
- Solution: Try payment again with correct card details

**Issue: Order created but shows error**
- Check error log: `/var/log/apache2/error.log`
- Handler logs all steps for debugging

**Issue: Order not appearing in profile**
- Check order visibility permissions
- Verify user_id saved correctly in orders table
- Check order-confirmation.php displays correct order_id

**Issue: No confirmation email**
- Verify EmailHelper.php can send emails
- Check SMTP credentials in EmailHelper.php
- Check spam folder
- Test with: `php test-email-system.php`

## Monitoring

**Check System Status:**
```bash
# View recent orders
php check-recent-orders.php

# Check specific order
php check-order-XX.php replace XX with order_id

# Verify Stripe config
php verify-stripe-setup.php

# View error log
tail -f /var/log/apache2/error.log
```

## Security Notes

1. ✓ Stripe session verified on backend
2. ✓ Metadata validated from Stripe (not from URL)
3. ✓ Payment status checked before creating order
4. ✓ Database transactions used (all-or-nothing)
5. ✓ User authentication preserved
6. ✓ Email validation performed

## Rollback/Troubleshooting

If issues occur:

1. **Discard last payment:**
   - Manual database cleanup: `DELETE FROM orders WHERE id > XX`

2. **Reset cart:**
   - For guest: Clear localStorage in browser
   - For logged-in: `DELETE FROM cart WHERE user_id = XX`

3. **Check payment status:**
   - Go to Stripe Dashboard
   - View transactions
   - Confirm payment status

4. **Restore previous version:**
   - The old flow still accessible at:
   - Git revert if needed
   - Original files backed up

## Next Steps (Optional Enhancements)

1. Add invoice option to Stripe checkout
2. Add order status webhook to sync with Stripe
3. Add refund handling
4. Add recurring billing support
5. Add payment retry logic

## Support

For issues:
1. Check error_log output
2. Verify Stripe API key validity
3. Check database connections
4. Verify file permissions
5. Review test files: test-stripe-flow.php, test-complete-order.php
