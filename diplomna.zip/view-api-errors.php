<?php
// View recent PHP error log entries

$error_log_path = 'C:/xampp/apache/logs/error.log';

if (!file_exists($error_log_path)) {
    echo "Error log not found at: " . $error_log_path;
    exit;
}

echo "<h1>Recent API Errors (Last 50 lines)</h1>";
echo "<pre style='background: #f5f5f5; padding: 10px; max-height: 600px; overflow-y: auto;'>";

$lines = file($error_log_path);
$recent = array_slice($lines, -50);

foreach ($recent as $line) {
    // Highlight Orders API lines
    if (strpos($line, 'Orders API:') !== false) {
        echo '<span style="background: yellow; color: black;">' . htmlspecialchars($line) . '</span>';
    } elseif (strpos($line, 'ERROR') !== false || strpos($line, 'error') !== false) {
        echo '<span style="color: red;">' . htmlspecialchars($line) . '</span>';
    } else {
        echo htmlspecialchars($line);
    }
}

echo "</pre>";
?>
