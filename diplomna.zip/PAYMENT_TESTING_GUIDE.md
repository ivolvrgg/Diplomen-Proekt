# Payment Form Testing Guide

## System Overview
This document explains how the payment form works and how to test it properly.

## How the Checkout Process Works

### 1. Guest Cart Management
- Products are added to cart and stored in browser's localStorage as `guest_cart`
- Each cart item has: `product_id`, `quantity`, `name`, `price`
- When you reach payment page, the form loads this cart automatically

### 2. Delivery Method Options

#### Courier (До адрес)
- Requires: City, Street, Block, Entrance, Apartment
- Delivery Fee: 3.00 €
- Server stores order but not address details yet

#### ECONT (Office Selection)
- Requires: Select office from ECONT iframe
- The iframe loads from: `https://delivery.econt.com/customer_info.php`
- When you select an office, the iframe sends back data
- System generates office code from city name using mapping:
  - София → VN1
  - Варна → VA1
  - Плевен → PL1
  - Пловдив → PD1
  - Бургас → BU1
  - Русе → RU1
  - Стара Загора → SZ1

### 3. Required Contact Information
- **Email**: Must be valid email (rejected: @example.com, @test.com)
- **Phone**: Must have at least 10 digits

### 4. Payment Methods
- **Card Payment**: Creates payment intent, redirects to Stripe
- **Cash on Delivery (COD)**: Creates order directly, no payment processing

---

## Step-by-Step Testing Instructions

### Step 1: Add a Product to Cart
1. Go to any product page (e.g., hover over catalog or search for product)
2. Enter quantity and click "Add to Cart"
3. You should see cart badge update

### Step 2: Go to Checkout
1. Click "Checkout" or cart badge
2. You'll be redirected to `/payment.php`

### Step 3: Verify Cart is Loaded
- Open browser Developer Tools (F12)
- Go to Console tab
- Type: `JSON.parse(localStorage.getItem('guest_cart'))`
- You should see your cart items with product_id, quantity, name, price

### Step 4: Select Delivery Method - OPTION A (ECONT)
1. Select "econt" radio button
2. Wait for iframe to load (you'll see form titled "ECONT Office Selection")
3. In console, watch for messages like: "🔊 [ALL MESSAGES]" to see incoming data
4. Select an ECONT office from the form
5. After selection, console should show: "✓ Set econt_office_code: VN1" (or your city code)

### Step 5: Select Delivery Method - OPTION B (Courier)
1. Select "До адрес" radio button
2. Fill in all address fields:
   - Град (City)
   - Улица (Street)
   - Блок (Block)
   - Вход (Entrance)
   - Апартамент (Apartment)

### Step 6: Enter Contact Information
1. Phone: Enter valid phone (e.g., +359 888 123456)
2. Email: Enter valid email (e.g., your.email@gmail.com)

### Step 7: Select Payment Method
1. Choose either "Плащане с карта" (Card) or "Наложен платеж" (Cash on Delivery)

### Step 8: Submit Form
1. Click "Завърши поръчка" button
2. Watch console for messages:
   - If ECONT: You should see console logs showing the submitted data
   - Console will log: "📋 Form data to submit: {..."
3. Wait for response

---

## Common Issues and Solutions

### Issue: "Вашата количка е празна" (Empty Cart)
**Solution**: 
1. Add products to cart first from product page
2. Refresh the payment page
3. Check localStorage: `JSON.parse(localStorage.getItem('guest_cart'))` should not be empty

### Issue: "Моля, изберете ECONT офис" (Please Select ECONT Office)
**Solution**:
1. Make sure ECONT iframe loaded (should see form inside iframe)
2. Click inside iframe and select an office
3. Check console for messages showing the office code was set

### Issue: "Имейл е задължителен" or "Телефон е задължителен"
**Solution**: Fill in both fields before submitting

### Issue: Email rejected
**Solution**: Make sure email doesn't contain @example.com or @test.com - use real email like gmail.com

### Issue: ECONT Iframe Won't Load
**Solution**:
1. Check if ECONT_SHOP_ID is configured in payment.php (line 193)
2. Check browser console for CORS errors
3. Visit https://delivery.econt.com/ directly to verify site is accessible

---

## Debugging Console Logs

### Important Console Outputs

1. **Form Submission Start**:
   ```
   Form submission started
   ```

2. **Cart Loaded**:
   ```
   ✓ Guest cart loaded: [{product_id: 1, quantity: 1, ...}]
   ```

3. **Form Data Prepared**:
   ```
   📋 Form data to submit: {payment_method: "cod", delivery_method: "econt", ...}
   ```

4. **ECONT Messages**:
   ```
   🔊 [ALL MESSAGES] {origin: "https://delivery.econt.com", data: {...}}
   ```

5. **Office Code Set**:
   ```
   ✓ Set econt_office_code: VN1
   ```

6. **API Response**:
   ```
   Response status: 200
   Raw response: {"success": true, "message": "Order created successfully", ...}
   ✓ Order response: {...}
   ```

7. **Order Created**:
   ```
   Поръчката е успешно създадена! Ще получите потвърждение по имейл.
   ```

---

## API Response Examples

### Success Response (COD)
```json
{
  "success": true,
  "message": "Order created successfully",
  "order_id": 42,
  "total": 102.99,
  "redirect_url": "/Diplomna_rabota/homepage.php"
}
```

### Error Response Examples
```json
{
  "success": false,
  "message": "Вашата количка е празна",
  "order_id": null
}
```

```json
{
  "success": false,
  "message": "Моля, използвайте реален имейл адрес. @example.com и @test.com не са валидни.",
  "order_id": null
}
```

---

## Technical Details

### API Endpoint: `/api/orders.php`
- **Method**: POST
- **Content-Type**: application/json
- **Required Fields in JSON Body**:
  - `payment_method`: "card" or "cod"
  - `delivery_method`: "courier", "speedy", or "econt"
  - `email`: Valid email address
  - `phone`: Phone number with at least 10 digits
  - `cart`: Array of cart items (for guests)

**For ECONT Delivery, add**:
  - `delivery_office_id` or `econt_office_code`: Office code (e.g., "VN1")

**For Courier Delivery, add**:
  - `city`: City name
  - `street`: Street name
  - `block`: Block number (optional)
  - `entrance`: Entrance (optional)
  - `apartment`: Apartment number (optional)

---

## Testing Checklist

- [ ] Product added to cart and badge shows count
- [ ] Payment page loads and cart displays
- [ ] ECONT iframe loads when ECONT selected
- [ ] Office selection sends data to form
- [ ] Form validation shows error for empty fields
- [ ] Form validation shows error for test emails
- [ ] COD submission shows success message
- [ ] Order confirmation email received
- [ ] User redirected to homepage after COD success
- [ ] Card payment shows Stripe checkout (if configured)
