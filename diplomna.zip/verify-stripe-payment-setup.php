<?php
/**
 * Stripe Card Payment Implementation - Configuration Verification
 */

require_once 'config/db.php';
require_once 'config/stripe.php';

echo "<style>
    body { font-family: monospace; padding: 20px; background: #f5f5f5; }
    .section { background: white; padding: 15px; margin: 15px 0; border-radius: 5px; border-left: 4px solid #ddd; }
    .success { border-left-color: #28a745; color: #28a745; font-weight: bold; }
    .error { border-left-color: #dc3545; color: #dc3545; font-weight: bold; }
    .warning { border-left-color: #ffc107; color: #ff9800; font-weight: bold; }
    .info { border-left-color: #17a2b8; color: #17a2b8; }
    code { background: #f8f9fa; padding: 2px 5px; border-radius: 3px; }
    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
    table td { padding: 8px; border: 1px solid #ddd; }
    table tr:nth-child(odd) { background: #f9f9f9; }
</style>";

echo "<h1>🔍 Stripe Payment Implementation - Verification Report</h1>";

$checks = [
    'success' => 0,
    'error' => 0,
    'warning' => 0
];

// Check 1: Handler file exists
echo "<div class='section info'>";
echo "<strong>✓ Check 1: Handler File</strong><br>";
$handler_path = __DIR__ . '/api/stripe-order-handler.php';
if (file_exists($handler_path)) {
    echo "<span class='success'>✓ SUCCESS:</span> stripe-order-handler.php exists<br>";
    echo "  Location: <code>api/stripe-order-handler.php</code><br>";
    echo "  Size: " . round(filesize($handler_path) / 1024, 2) . " KB<br>";
    $checks['success']++;
} else {
    echo "<span class='error'>✗ ERROR:</span> Handler file not found!<br>";
    $checks['error']++;
}
echo "</div>";

// Check 2: create-payment-intent.php configuration
echo "<div class='section info'>";
echo "<strong>✓ Check 2: Payment Intent Configuration</strong><br>";
$create_intent_path = __DIR__ . '/api/create-payment-intent.php';
if (file_exists($create_intent_path)) {
    $content = file_get_contents($create_intent_path);
    if (strpos($content, 'stripe-order-handler.php') !== false) {
        echo "<span class='success'>✓ SUCCESS:</span> Redirect URL configured correctly<br>";
        echo "  Success URL points to: <code>api/stripe-order-handler.php</code><br>";
        $checks['success']++;
    } else {
        echo "<span class='error'>✗ ERROR:</span> Redirect URL NOT configured!<br>";
        echo "  Expected: <code>stripe-order-handler.php</code><br>";
        $checks['error']++;
    }
} else {
    echo "<span class='error'>✗ ERROR:</span> create-payment-intent.php not found!<br>";
    $checks['error']++;
}
echo "</div>";

// Check 3: Stripe API configuration
echo "<div class='section info'>";
echo "<strong>✓ Check 3: Stripe API Configuration</strong><br>";
try {
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    echo "<span class='success'>✓ SUCCESS:</span> Stripe API initialized<br>";
    echo "  API Key: " . substr(STRIPE_SECRET_KEY, 0, 10) . "...<br>";
    $checks['success']++;
} catch (Exception $e) {
    echo "<span class='error'>✗ ERROR:</span> Stripe API configuration failed<br>";
    echo "  Details: " . $e->getMessage() . "<br>";
    $checks['error']++;
}
echo "</div>";

// Check 4: Database tables
echo "<div class='section info'>";
echo "<strong>✓ Check 4: Database Tables</strong><br>";

$tables_to_check = [
    'orders' => ['user_id', 'payment_method', 'delivery_method_id', 'invoice_requested', 'status'],
    'order_items' => ['order_id', 'product_id', 'quantity', 'unit_price'],
    'delivery_methods' => ['id', 'name', 'cost', 'is_active'],
    'invoices' => ['order_id', 'invoice_number', 'file_path', 'status'],
    'cart' => ['user_id', 'product_id', 'quantity']
];

$table_results = [];
foreach ($tables_to_check as $table => $columns) {
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "<span class='success'>✓</span> Table <code>$table</code> exists<br>";
        
        // Check columns
        $col_result = $conn->query("DESCRIBE $table");
        $db_columns = [];
        while ($col = $col_result->fetch_assoc()) {
            $db_columns[] = $col['Field'];
        }
        
        $missing = array_diff($columns, $db_columns);
        if (empty($missing)) {
            echo "  &nbsp;&nbsp;✓ All required columns present<br>";
            $checks['success']++;
        } else {
            echo "  &nbsp;&nbsp;⚠ Missing columns: " . implode(', ', $missing) . "<br>";
            $checks['warning']++;
        }
    } else {
        echo "<span class='error'>✗ Table <code>$table</code> NOT found</span><br>";
        $checks['error']++;
    }
}
echo "</div>";

// Check 5: Delivery methods configuration
echo "<div class='section info'>";
echo "<strong>✓ Check 5: Delivery Methods</strong><br>";
$delivery_result = $conn->query("SELECT id, name, cost, is_active FROM delivery_methods WHERE is_active = 1");
if ($delivery_result) {
    $required_methods = ['courier', 'econt'];
    $found_methods = [];
    
    echo "<table>";
    echo "<tr><td><strong>ID</strong></td><td><strong>Name</strong></td><td><strong>Cost</strong></td><td><strong>Active</strong></td></tr>";
    
    while ($method = $delivery_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $method['id'] . "</td>";
        echo "<td>" . htmlspecialchars($method['name']) . "</td>";
        echo "<td>€" . number_format($method['cost'], 2) . "</td>";
        echo "<td>" . ($method['is_active'] ? '✓' : '✗') . "</td>";
        echo "</tr>";
        $found_methods[$method['id']] = true;
    }
    echo "</table>";
    
    // Specifically check for ECONT with ID 3 (was bug with ID 2)
    $econt_check = $conn->query("SELECT id FROM delivery_methods WHERE name LIKE '%econt%' AND is_active = 1");
    if ($econt_check && $econt_check->num_rows > 0) {
        $econt = $econt_check->fetch_assoc();
        if ($econt['id'] == 3) {
            echo "<span class='success'>✓ SUCCESS:</span> ECONT correctly mapped to ID 3<br>";
            $checks['success']++;
        } elseif ($econt['id'] == 2) {
            echo "<span class='error'>✗ ERROR:</span> ECONT still mapped to ID 2 (should be 3)<br>";
            $checks['error']++;
        }
    }
} else {
    echo "<span class='error'>✗ ERROR:</span> Could not query delivery methods<br>";
    $checks['error']++;
}
echo "</div>";

// Check 6: Payment.php configuration
echo "<div class='section info'>";
echo "<strong>✓ Check 6: Payment Form Configuration</strong><br>";
$payment_path = __DIR__ . '/payment.php';
if (file_exists($payment_path)) {
    $payment_content = file_get_contents($payment_path);
    
    // Check for invoice checkbox
    if (strpos($payment_content, 'invoice') !== false && strpos($payment_content, 'invoice_requested') !== false) {
        echo "<span class='success'>✓</span> Invoice checkbox implemented<br>";
        $checks['success']++;
    } else {
        echo "<span class='warning'>⚠</span> Invoice checkbox not found<br>";
        $checks['warning']++;
    }
    
    // Check for delivery method selection
    if (strpos($payment_content, 'delivery_method') !== false) {
        echo "<span class='success'>✓</span> Delivery method selection implemented<br>";
        $checks['success']++;
    }
    
    // Check for card payment option
    if (strpos($payment_content, 'card') !== false || strpos($payment_content, 'Stripe') !== false) {
        echo "<span class='success'>✓</span> Card payment option available<br>";
        $checks['success']++;
    } else {
        echo "<span class='error'>✗</span> Card payment option missing<br>";
        $checks['error']++;
    }
} else {
    echo "<span class='error'>✗ ERROR:</span> payment.php not found<br>";
    $checks['error']++;
}
echo "</div>";

// Check 7: Email system
echo "<div class='section info'>";
echo "<strong>✓ Check 7: Email System</strong><br>";
$email_helper_path = __DIR__ . '/includes/EmailHelper.php';
if (file_exists($email_helper_path)) {
    $email_content = file_get_contents($email_helper_path);
    if (strpos($email_content, 'sendOrderConfirmation') !== false) {
        echo "<span class='success'>✓</span> sendOrderConfirmation() method exists<br>";
        $checks['success']++;
    }
    if (strpos($email_content, 'sendInvoice') !== false) {
        echo "<span class='success'>✓</span> sendInvoice() method exists<br>";
        $checks['success']++;
    }
} else {
    echo "<span class='error'>✗ ERROR:</span> EmailHelper.php not found<br>";
    $checks['error']++;
}
echo "</div>";

// Check 8: Database transactions in api/orders.php
echo "<div class='section info'>";
echo "<strong>✓ Check 8: Transaction Handling</strong><br>";
$orders_api = __DIR__ . '/api/orders.php';
if (file_exists($orders_api)) {
    $orders_content = file_get_contents($orders_api);
    
    $has_begin = strpos($orders_content, 'begin_transaction') !== false;
    $has_commit = strpos($orders_content, '$conn->commit()') !== false;
    $has_rollback = strpos($orders_content, 'rollback') !== false;
    
    if ($has_begin) {
        echo "<span class='success'>✓</span> Transaction BEGIN found<br>";
        $checks['success']++;
    } else {
        echo "<span class='warning'>⚠</span> Transaction BEGIN not found<br>";
        $checks['warning']++;
    }
    
    if ($has_commit) {
        echo "<span class='success'>✓</span> Transaction COMMIT found (critical fix applied)<br>";
        $checks['success']++;
    } else {
        echo "<span class='error'>✗ ERROR:</span> Transaction COMMIT not found (bug still present!)<br>";
        $checks['error']++;
    }
    
    if ($has_rollback) {
        echo "<span class='success'>✓</span> Transaction ROLLBACK found<br>";
        $checks['success']++;
    }
} else {
    echo "<span class='error'>✗ ERROR:</span> api/orders.php not found<br>";
    $checks['error']++;
}
echo "</div>";

// Check 9: Recent orders count
echo "<div class='section info'>";
echo "<strong>✓ Check 9: System Status</strong><br>";
$order_count = $conn->query("SELECT COUNT(*) as count FROM orders");
$order_data = $order_count->fetch_assoc();
echo "Total orders in system: <strong>" . $order_data['count'] . "</strong><br>";

$recent_orders = $conn->query("
    SELECT id, user_id, payment_method, status, created_at 
    FROM orders 
    ORDER BY id DESC 
    LIMIT 5
");
echo "<br><strong>Last 5 orders:</strong><br>";
echo "<table>";
echo "<tr><td><strong>Order ID</strong></td><td><strong>User</strong></td><td><strong>Payment</strong></td><td><strong>Status</strong></td><td><strong>Date</strong></td></tr>";
while ($order = $recent_orders->fetch_assoc()) {
    $user = $order['user_id'] ? 'User #' . $order['user_id'] : 'Guest';
    echo "<tr>";
    echo "<td>#{$order['id']}</td>";
    echo "<td>{$user}</td>";
    echo "<td>{$order['payment_method']}</td>";
    echo "<td>{$order['status']}</td>";
    echo "<td>" . $order['created_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";
$checks['success']++;
echo "</div>";

// Summary
echo "<div class='section' style='border-left-color: #333; background: #f0f0f0;'>";
echo "<h2>📊 Verification Summary</h2>";
echo "<table>";
echo "<tr><td><span class='success'>✓ Success Checks</span></td><td><strong style='color: green; font-size: 18px;'>" . $checks['success'] . "</strong></td></tr>";
echo "<tr><td><span class='error'>✗ Error Checks</span></td><td><strong style='color: red; font-size: 18px;'>" . $checks['error'] . "</strong></td></tr>";
echo "<tr><td><span class='warning'>⚠ Warning Checks</span></td><td><strong style='color: orange; font-size: 18px;'>" . $checks['warning'] . "</strong></td></tr>";
echo "</table>";

if ($checks['error'] == 0) {
    echo "<br><h3 style='color: green;'>✓ All checks passed! System is ready for card payment testing.</h3>";
} else {
    echo "<br><h3 style='color: red;'>✗ " . $checks['error'] . " error(s) found. Please fix before testing.</h3>";
}
echo "</div>";

echo "<div class='section info'>";
echo "<strong>🧪 Next Steps:</strong><br>";
echo "1. Run: <code>php verify-stripe-setup.php</code> to check Stripe configuration<br>";
echo "2. Make a COD test order to verify system works<br>";
echo "3. Make a Stripe test payment using test card: <code>4242 4242 4242 4242</code><br>";
echo "4. Check that order appears in profile after payment<br>";
echo "5. Verify confirmation email is received<br>";
echo "6. Check that order is visible in database<br>";
echo "</div>";
?>
