# Invoice Feature Implementation

## Overview
I've added the ability for users to request and receive invoices on the payment page. When users check the "I want to receive an invoice" checkbox during checkout, they will automatically receive a professionally formatted invoice via email.

## What Was Added

### 1. **Database Changes**
- Created `invoices` table to store invoice records
- Added `invoice_requested` column to `orders` table

**Run this to apply database changes:**
```bash
php run-invoice-migration.php
```

### 2. **Front-End Changes** (payment.php)
- Added invoice checkbox in "Допълнителни опции" section
- Checkbox allows users to opt-in for invoice delivery
- Invoice checkbox value is sent with form submission

### 3. **Back-End Changes**

#### a) **API - Invoice Generation** (`api/invoice.php`)
- New endpoint to generate invoices in HTML format
- Generates professional invoice with:
  - Company branding (Dronche.BG)
  - Invoice number (format: INV-YYYY-XXXXXX)
  - Order details and items
  - Customer information
  - Delivery method
  - Total calculations
- Stores invoices in `uploads/invoices/` directory
- Database records for invoice tracking

#### b) **Order Processing** (`api/orders.php`)
- Reads `invoice_requested` flag from payment form
- After order creation, automatically generates invoice if requested
- Saves invoice HTML file
- Records invoice in database
- Sends invoice via email

#### c) **Email Helper** (`includes/EmailHelper.php`)
- New `sendInvoice()` method
- Sends professional email with invoice information
- Includes invoice number and generation date

## How It Works

1. **User Checkout Flow:**
   - User fills out payment form
   - Checks "Искам да получа фактура по имейл" (I want to receive an invoice)
   - Submits order

2. **Invoice Generation:**
   - Order is created in database
   - Invoice HTML is generated with order details
   - Invoice file saved to `uploads/invoices/INV-YYYY-XXXXXX.html`
   - Invoice record stored in `invoices` table

3. **Email Delivery:**
   - User receives order confirmation email
   - User also receives separate invoice email with:
     - Invoice number
     - Generation date
     - Link to download from profile

## File Structure

```
📁 uploads/invoices/          # Where invoices are stored
📄 api/invoice.php            # Invoice generation API
📄 payment.php                # Updated with invoice checkbox
📄 api/orders.php             # Updated with invoice generation logic
📄 includes/EmailHelper.php   # Updated with sendInvoice method
📄 sql/migration_add_invoices.sql  # Database migration SQL
📄 run-invoice-migration.php  # Migration runner script
```

## Database Schema

### invoices Table
```sql
- id: Primary key
- order_id: Foreign key to orders
- user_id: Foreign key to users
- invoice_number: Unique invoice identifier (format: INV-YYYY-XXXXXX)
- file_path: Path to stored HTML invoice
- status: generated | sent | downloaded
- created_at: When invoice was generated
- sent_at: When invoice was sent
- downloaded_at: When user downloaded invoice
```

### orders Table (New Column)
```sql
- invoice_requested: Boolean flag (0 or 1)
```

## Invoice Features

✓ Professional HTML format with company branding
✓ Automatic numbering system
✓ Complete order details (products, quantities, prices)
✓ Delivery method information
✓ Customer contact information
✓ Subtotal, delivery cost, and total calculations
✓ Automatically sent via email
✓ Stored for future retrieval

## Future Enhancements

1. **PDF Generation:** Add mPDF or TCPDF library to convert HTML invoices to PDF
2. **Invoice Management:** Add invoice download section in user profile
3. **Advanced Features:**
   - Invoice number counter per year
   - VAT/Tax information
   - Company tax ID and registration details
   - QR code for invoice verification
   - Multiple language support

## Testing

1. Run the migration: `php run-invoice-migration.php`
2. Go to payment page
3. Fill out order form
4. Check the "I want to receive an invoice" checkbox
5. Complete the order
6. Check user email for invoice notification
7. Invoice HTML will be available in `uploads/invoices/`

## Notes

- Invoices are generated in HTML format for security and simplicity
- They can be printed directly from browser or converted to PDF
- Each invoice has a unique number combining year and order ID
- Invoice records help track which orders requested invoices
- System logs all invoice generation in application logs
