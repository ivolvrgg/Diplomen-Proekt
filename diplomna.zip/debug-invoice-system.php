<?php
/**
 * Invoice System Debug & Testing
 * Tests every step of the invoice generation flow
 */

require_once 'config/db.php';
require_once 'includes/EmailHelper.php';

echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .container { max-width: 1000px; margin: 0 auto; }
    .section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #588157; }
    .success { color: #28a745; font-weight: bold; }
    .error { color: #c41e3a; font-weight: bold; }
    .info { color: #17a2b8; }
    .warning { color: #ff9800; }
    code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; font-family: monospace; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    table td { padding: 10px; border: 1px solid #ddd; }
    table tr:nth-child(odd) { background: #f9f9f9; }
    .log { background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 12px; font-family: monospace; }
    .btn-test { display: inline-block; padding: 10px 20px; background: #588157; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; margin: 5px; font-weight: bold; }
    .btn-test:hover { background: #3d5a38; }
</style>";

echo "<div class='container'>";
echo "<h1>🔧 Invoice System Debug & Testing</h1>";

// Check 1: Database table structure
echo "<div class='section'>";
echo "<h2>✓ Step 1: Database Schema Verification</h2>";

$result = $conn->query("DESCRIBE invoices");
echo "<p>Invoices table columns:</p>";
echo "<table>";
echo "<tr><td><strong>Field</strong></td><td><strong>Type</strong></td><td><strong>Null</strong></td><td><strong>Key</strong></td><td><strong>Default</strong></td></tr>";
$columns = [];
while ($col = $result->fetch_assoc()) {
    $columns[] = $col['Field'];
    echo "<tr>";
    echo "<td><code>" . htmlspecialchars($col['Field']) . "</code></td>";
    echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
    echo "<td>" . ($col['Null'] === 'YES' ? 'YES' : 'NO') . "</td>";
    echo "<td>" . ($col['Key'] ? $col['Key'] : '-') . "</td>";
    echo "<td>" . ($col['Default'] ? htmlspecialchars($col['Default']) : '-') . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check for viewed_at column
if (in_array('viewed_at', $columns)) {
    echo "<p class='success'>✓ Column 'viewed_at' exists</p>";
} else {
    echo "<p class='warning'>⚠️ Column 'viewed_at' MISSING (safe to ignore, optional for tracking)</p>";
}

// Check for downloaded_at column
if (in_array('downloaded_at', $columns)) {
    echo "<p class='success'>✓ Column 'downloaded_at' exists</p>";
} else {
    echo "<p class='warning'>⚠️ Column 'downloaded_at' MISSING (safe to ignore, optional for tracking)</p>";
}
echo "</div>";

// Check 2: Recent orders with invoice_requested flag
echo "<div class='section'>";
echo "<h2>✓ Step 2: Orders Analysis</h2>";

$all_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
echo "<p>Total orders in database: <strong>" . $all_orders . "</strong></p>";

$invoice_requested_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE invoice_requested = 1")->fetch_assoc()['count'];
echo "<p>Orders with invoice_requested=1: <strong>" . $invoice_requested_orders . "</strong></p>";

// Get recent orders to analyze
$recent_orders = $conn->query("
    SELECT id, email, payment_method, invoice_requested, created_at 
    FROM orders 
    ORDER BY id DESC 
    LIMIT 10
");

echo "<p>Recent 10 orders:</p>";
echo "<table>";
echo "<tr><td><strong>Order ID</strong></td><td><strong>Email</strong></td><td><strong>Payment</strong></td><td><strong>Invoice?</strong></td><td><strong>Created</strong></td><td><strong>Has Invoice Record</strong></td></tr>";
while ($order = $recent_orders->fetch_assoc()) {
    $has_invoice = $conn->query("SELECT id FROM invoices WHERE order_id = " . $order['id'])->num_rows > 0;
    $has_file = false;
    
    if ($has_invoice) {
        $inv_file = $conn->query("SELECT file_path FROM invoices WHERE order_id = " . $order['id'])->fetch_assoc();
        $has_file = file_exists($inv_file['file_path']);
    }
    
    echo "<tr>";
    echo "<td>#" . $order['id'] . "</td>";
    echo "<td>" . htmlspecialchars(substr($order['email'], 0, 20)) . "...</td>";
    echo "<td>" . $order['payment_method'] . "</td>";
    echo "<td>";
    if ($order['invoice_requested']) {
        echo "<span style='color: #28a745; font-weight: bold;'>YES (1)</span>";
    } else {
        echo "NO (0)";
    }
    echo "</td>";
    echo "<td>" . date('m/d H:i', strtotime($order['created_at'])) . "</td>";
    echo "<td>";
    if ($has_invoice && $has_file) {
        echo "<span class='success'>✓ YES</span>";
    } elseif ($has_invoice && !$has_file) {
        echo "<span class='warning'>✓ DB Record, but file missing</span>";
    } else {
        echo $order['invoice_requested'] ? "<span class='error'>✗ MISSING!</span>" : "-";
    }
    echo "</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// Check 3: File system status
echo "<div class='section'>";
echo "<h2>✓ Step 3: Invoice File Storage</h2>";

$invoice_dir = __DIR__ . '/uploads/invoices';
if (is_dir($invoice_dir)) {
    echo "<p class='success'>✓ Directory exists: <code>uploads/invoices/</code></p>";
    
    $files = glob($invoice_dir . '/*');
    echo "<p>Files stored: <strong>" . count($files) . "</strong></p>";
    
    if (count($files) > 0) {
        echo "<table>";
        echo "<tr><td><strong>Filename</strong></td><td><strong>Size</strong></td><td><strong>Age</strong></td></tr>";
        
        usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
        foreach (array_slice($files, 0, 5) as $file) {
            $age_seconds = time() - filemtime($file);
            $age_str = '';
            if ($age_seconds < 60) {
                $age_str = $age_seconds . 's ago';
            } elseif ($age_seconds < 3600) {
                $age_str = round($age_seconds / 60) . 'm ago';
            } else {
                $age_str = round($age_seconds / 3600) . 'h ago';
            }
            
            echo "<tr>";
            echo "<td><code>" . basename($file) . "</code></td>";
            echo "<td>" . round(filesize($file) / 1024, 2) . " KB</td>";
            echo "<td>" . $age_str . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='warning'>⚠️ No invoice files found (will be created when orders are placed with invoice checkbox)</p>";
    }
} else {
    echo "<p class='error'>✗ Directory does NOT exist!</p>";
    echo "<p>Creating directory...</p>";
    if (mkdir($invoice_dir, 0755, true)) {
        echo "<p class='success'>✓ Directory created successfully</p>";
    } else {
        echo "<p class='error'>✗ Failed to create directory</p>";
    }
}
echo "</div>";

// Check 4: Email configuration
echo "<div class='section'>";
echo "<h2>✓ Step 4: Email System</h2>";

$mail_config_path = __DIR__ . '/config/mail.php';
if (file_exists($mail_config_path)) {
    $mail_config = require $mail_config_path;
    echo "<p class='success'>✓ Mail config exists</p>";
    echo "<table>";
    echo "<tr><td><strong>Host</strong></td><td><code>" . htmlspecialchars($mail_config['host'] ?? 'NOT SET') . "</code></td></tr>";
    echo "<tr><td><strong>Port</strong></td><td><code>" . ($mail_config['port'] ?? 587) . "</code></td></tr>";
    echo "<tr><td><strong>Username</strong></td><td><code>" . (isset($mail_config['username']) ? substr($mail_config['username'], 0, 10) . '...' : 'NOT SET') . "</code></td></tr>";
    echo "<tr><td><strong>Password</strong></td><td><code>" . (isset($mail_config['password']) ? '***..' : 'NOT SET') . "</code></td></tr>";
    echo "</table>";
    
    // Test email sending
    echo "<p><strong>Test Email Function:</strong></p>";
    try {
        $emailer = new EmailHelper();
        echo "<p class='success'>✓ EmailHelper class loaded successfully</p>";
        
        // Check if methods exist
        if (method_exists($emailer, 'sendInvoice')) {
            echo "<p class='success'>✓ sendInvoice() method exists</p>";
        } else {
            echo "<p class='error'>✗ sendInvoice() method NOT FOUND</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>✗ Error loading EmailHelper: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
} else {
    echo "<p class='error'>✗ Mail config file not found at <code>config/mail.php</code></p>";
}
echo "</div>";

// Check 5: Invoice generation function
echo "<div class='section'>";
echo "<h2>✓ Step 5: Invoice Generation Function</h2>";

$orders_api = file_get_contents(__DIR__ . '/api/orders.php');
if (strpos($orders_api, 'function buildInvoiceHTML') !== false) {
    echo "<p class='success'>✓ buildInvoiceHTML() function defined</p>";
} else {
    echo "<p class='error'>✗ buildInvoiceHTML() function NOT FOUND</p>";
}

if (strpos($orders_api, '$invoice_requested') !== false) {
    echo "<p class='success'>✓ \$invoice_requested variable used</p>";
} else {
    echo "<p class='error'>✗ \$invoice_requested variable NOT FOUND</p>";
}

if (strpos($orders_api, 'sendInvoice') !== false) {
    echo "<p class='success'>✓ sendInvoice() method called</p>";
} else {
    echo "<p class='error'>✗ sendInvoice() NOT called in orders.php</p>";
}
echo "</div>";

// Check 6: Error logs
echo "<div class='section'>";
echo "<h2>✓ Step 6: Recent Error Logs</h2>";

$log_file = __DIR__ . '/logs/php_errors.log';
if (file_exists($log_file)) {
    echo "<p>File: <code>" . htmlspecialchars($log_file) . "</code></p>";
    
    // Read last 20 lines
    $lines = file($log_file);
    $recent_lines = array_slice($lines, -20);
    
    // Filter for invoice-related logs
    $invoice_logs = array_filter($recent_lines, fn($line) => stripos($line, 'invoice') !== false || stripos($line, 'sendInvoice') !== false);
    
    if (count($invoice_logs) > 0) {
        echo "<p><strong>Invoice-related logs:</strong></p>";
        echo "<div class='log'>";
        foreach (array_slice($invoice_logs, -10) as $log_line) {
            echo htmlspecialchars($log_line);
        }
        echo "</div>";
    } else {
        echo "<p class='info'>ℹ️ No invoice logs found in error log</p>";
    }
} else {
    echo "<p class='warning'>⚠️ PHP error log not found or not configured</p>";
}
echo "</div>";

// Check 7: Test manual invoice generation
echo "<div class='section'>";
echo "<h2>✓ Step 7: Manual Invoice Test</h2>";

// Find an order that should have had an invoice
$test_order = $conn->query("SELECT id, email FROM orders WHERE invoice_requested = 1 ORDER BY id DESC LIMIT 1")->fetch_assoc();

if ($test_order) {
    echo "<p>Found order #" . $test_order['id'] . " with invoice_requested=1</p>";
    echo "<p>Testing invoice generation for this order:</p>";
    
    // Check if invoice exists
    $existing_invoice = $conn->query("SELECT id, invoice_number, file_path FROM invoices WHERE order_id = " . $test_order['id'])->fetch_assoc();
    
    if ($existing_invoice) {
        echo "<p class='success'>✓ Invoice record exists:</p>";
        echo "<table>";
        echo "<tr><td>Invoice #</td><td><code>" . htmlspecialchars($existing_invoice['invoice_number']) . "</code></td></tr>";
        echo "<tr><td>File Path</td><td><code>" . htmlspecialchars($existing_invoice['file_path']) . "</code></td></tr>";
        echo "<tr><td>File Exists</td><td>" . (file_exists($existing_invoice['file_path']) ? '<span class="success">✓ YES</span>' : '<span class="error">✗ NO</span>') . "</td></tr>";
        echo "</table>";
        
        if (file_exists($existing_invoice['file_path'])) {
            echo "<p><a href='api/view-invoice.php?invoice_id=" . $existing_invoice['id'] . "' class='btn-test' target='_blank'>👁️ View Invoice</a></p>";
        }
    } else {
        echo "<p class='error'>✗ No invoice record found for order #" . $test_order['id'] . "</p>";
        echo "<p class='warning'>⚠️ This indicates the invoice was never generated, even though invoice_requested=1</p>";
    }
} else {
    echo "<p class='warning'>⚠️ No orders with invoice_requested=1 found for testing</p>";
}
echo "</div>";

// Summary
echo "<div class='section' style='border-left-color: #17a2b8; background: #f8f9fa;'>";
echo "<h2>📋 Summary & Next Steps</h2>";

echo "<p><strong>To debug missing invoices:</strong></p>";
echo "<ol>";
echo "<li>Place a NEW order with the invoice checkbox <strong>CHECKED</strong></li>";
echo "<li>Check the 'Recent orders' table above - it should show invoice_requested=1</li>";
echo "<li>Refresh this page and look for your new order in the table</li>";
echo "<li>Check if 'Has Invoice Record' shows ✓ YES</li>";
echo "<li>If it shows ✗ MISSING, the invoice generation failed</li>";
echo "</ol>";

echo "<p><strong>If invoices are missing, check:</strong></p>";
echo "<ul>";
echo "<li>✓ Checkbox is actually CHECKED on payment form</li>";
echo "<li>✓ Order was created (check database)</li>";
echo "<li>✓ uploads/invoices/ directory is writable</li>";
echo "<li>✓ Email was sent (check spam folder)</li>";
echo "<li>✓ PHP error log for invoice generation errors</li>";
echo "</ul>";
echo "</div>";

echo "</div>";
?>
