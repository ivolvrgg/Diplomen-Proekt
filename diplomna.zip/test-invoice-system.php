<?php
/**
 * Invoice System Test & Verification
 */

require_once 'config/db.php';

echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .container { max-width: 900px; margin: 0 auto; }
    .section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #588157; }
    .success { color: #28a745; font-weight: bold; }
    .error { color: #c41e3a; font-weight: bold; }
    .info { color: #17a2b8; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    table td { padding: 10px; border: 1px solid #ddd; }
    table tr:nth-child(odd) { background: #f9f9f9; }
    code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; }
    .btn { display: inline-block; padding: 8px 15px; background: #588157; color: white; text-decoration: none; border-radius: 4px; margin-top: 10px; }
</style>";

echo "<div class='container'>";
echo "<h1>📄 Invoice System - Verification & Status</h1>";

// Check 1: invoices table exists
echo "<div class='section'>";
echo "<h2>✓ Check 1: Database Table</h2>";
$result = $conn->query("SHOW TABLES LIKE 'invoices'");
if ($result && $result->num_rows > 0) {
    echo "<p class='success'>✓ invoices table exists</p>";
    
    // Check columns
    $cols = $conn->query("DESCRIBE invoices");
    echo "<p>Columns:</p>";
    echo "<table>";
    echo "<tr><td><strong>Field</strong></td><td><strong>Type</strong></td><td><strong>Null</strong></td></tr>";
    while ($col = $cols->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
        echo "<td>" . ($col['Null'] === 'YES' ? 'YES' : 'NO') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p class='error'>✗ invoices table does not exist</p>";
}
echo "</div>";

// Check 2: Invoice files on disk
echo "<div class='section'>";
echo "<h2>✓ Check 2: Invoice Files</h2>";
$invoice_dir = __DIR__ . '/uploads/invoices';
if (is_dir($invoice_dir)) {
    echo "<p class='success'>✓ Invoice directory exists: <code>uploads/invoices/</code></p>";
    
    $files = glob($invoice_dir . '/*');
    echo "<p>Files stored: <strong>" . count($files) . "</strong></p>";
    
    if (count($files) > 0) {
        echo "<p>Recent files:</p>";
        usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
        echo "<table>";
        echo "<tr><td><strong>Filename</strong></td><td><strong>Size</strong></td><td><strong>Modified</strong></td></tr>";
        foreach (array_slice($files, 0, 5) as $file) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars(basename($file)) . "</td>";
            echo "<td>" . round(filesize($file) / 1024, 2) . " KB</td>";
            echo "<td>" . date('d.m.Y H:i', filemtime($file)) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='info'>ℹ️ No invoice files yet (will be created when orders are placed with invoice checkbox)</p>";
    }
} else {
    echo "<p class='error'>✗ Invoice directory does not exist</p>";
}
echo "</div>";

// Check 3: Database invoices records
echo "<div class='section'>";
echo "<h2>✓ Check 3: Invoice Records</h2>";
$invoice_count = $conn->query("SELECT COUNT(*) as count FROM invoices")->fetch_assoc()['count'];
echo "<p>Total invoices in database: <strong>" . $invoice_count . "</strong></p>";

if ($invoice_count > 0) {
    $recent_invoices = $conn->query("
        SELECT 
            inv.id, inv.invoice_number, inv.order_id, inv.status, 
            inv.created_at, o.user_id, o.email
        FROM invoices inv
        JOIN orders o ON inv.order_id = o.id
        ORDER BY inv.created_at DESC
        LIMIT 10
    ");
    
    echo "<p>Recent invoices:</p>";
    echo "<table>";
    echo "<tr>";
    echo "<td><strong>Invoice ID</strong></td>";
    echo "<td><strong>Invoice #</strong></td>";
    echo "<td><strong>Order ID</strong></td>";
    echo "<td><strong>Status</strong></td>";
    echo "<td><strong>Email</strong></td>";
    echo "<td><strong>Created</strong></td>";
    echo "<td><strong>Action</strong></td>";
    echo "</tr>";
    
    while ($inv = $recent_invoices->fetch_assoc()) {
        echo "<tr>";
        echo "<td>#" . $inv['id'] . "</td>";
        echo "<td>" . htmlspecialchars($inv['invoice_number']) . "</td>";
        echo "<td>#" . $inv['order_id'] . "</td>";
        echo "<td>" . htmlspecialchars($inv['status']) . "</td>";
        echo "<td>" . htmlspecialchars($inv['email']) . "</td>";
        echo "<td>" . date('d.m.Y H:i', strtotime($inv['created_at'])) . "</td>";
        echo "<td><a href='api/view-invoice.php?invoice_id=" . $inv['id'] . "' target='_blank' class='btn' style='margin: 0; padding: 4px 8px; font-size: 12px;'>👁️ View</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p class='info'>ℹ️ No invoices yet. Place an order with invoice checkbox selected to generate one.</p>";
}
echo "</div>";

// Check 4: Email configuration
echo "<div class='section'>";
echo "<h2>✓ Check 4: Email Functions</h2>";
$email_helper = __DIR__ . '/includes/EmailHelper.php';
if (file_exists($email_helper)) {
    $content = file_get_contents($email_helper);
    
    if (strpos($content, 'sendInvoice') !== false) {
        echo "<p class='success'>✓ sendInvoice() method exists in EmailHelper</p>";
    }
    
    if (strpos($content, 'sendOrderConfirmation') !== false) {
        echo "<p class='success'>✓ sendOrderConfirmation() method exists</p>";
    }
} else {
    echo "<p class='error'>✗ EmailHelper.php not found</p>";
}
echo "</div>";

// Check 5: Invoice viewer endpoint
echo "<div class='section'>";
echo "<h2>✓ Check 5: Invoice Endpoints</h2>";
$viewer_path = __DIR__ . '/api/view-invoice.php';
if (file_exists($viewer_path)) {
    echo "<p class='success'>✓ Invoice viewer endpoint: <code>api/view-invoice.php</code></p>";
} else {
    echo "<p class='error'>✗ Invoice viewer endpoint not found</p>";
}

$old_api = __DIR__ . '/api/invoice.php';
if (file_exists($old_api)) {
    echo "<p class='info'>ℹ️ Old invoice API: <code>api/invoice.php</code> (deprecated but still exists)</p>";
}
echo "</div>";

// Check 6: Orders with invoice_requested flag
echo "<div class='section'>";
echo "<h2>✓ Check 6: Orders Requesting Invoices</h2>";
$invoice_requested_count = $conn->query("SELECT COUNT(*) as count FROM orders WHERE invoice_requested = 1")->fetch_assoc()['count'];
echo "<p>Orders with invoice_requested=1: <strong>" . $invoice_requested_count . "</strong></p>";

if ($invoice_requested_count > 0) {
    $orders = $conn->query("
        SELECT id, email, invoice_requested, created_at
        FROM orders
        WHERE invoice_requested = 1
        ORDER BY id DESC
        LIMIT 5
    ");
    
    echo "<p>Recent orders requesting invoices:</p>";
    echo "<table>";
    echo "<tr><td><strong>Order ID</strong></td><td><strong>Email</strong></td><td><strong>Requested</strong></td><td><strong>Date</strong></td></tr>";
    while ($order = $orders->fetch_assoc()) {
        $has_invoice = $conn->query("SELECT id FROM invoices WHERE order_id = " . $order['id'])->num_rows > 0;
        echo "<tr>";
        echo "<td>#" . $order['id'] . " " . ($has_invoice ? "<span class='success'>✓</span>" : "<span class='error'>✗</span>") . "</td>";
        echo "<td>" . htmlspecialchars($order['email']) . "</td>";
        echo "<td>" . ($order['invoice_requested'] ? "Yes" : "No") . "</td>";
        echo "<td>" . date('d.m.Y H:i', strtotime($order['created_at'])) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// Instructions
echo "<div class='section' style='border-left-color: #9FC131;'>";
echo "<h2>📚 How to Test Invoice System</h2>";
echo "<ol>";
echo "<li><strong>Place a COD Order:</strong> Go to checkout and select 'Cash on Delivery' as payment method</li>";
echo "<li><strong>Check Invoice Checkbox:</strong> Check the 'I want to receive an invoice' checkbox</li>";
echo "<li><strong>Complete Order:</strong> Fill in delivery details and submit</li>";
echo "<li><strong>Check Email:</strong> You should receive a confirmation email with a link to the invoice</li>";
echo "<li><strong>View Invoice:</strong> Click the invoice number in your profile (" . (is_dir($invoice_dir) ? '✓ ready' : '✗ not ready') . ")</li>";
echo "<li><strong>Print/Download:</strong> Click 'Print / Save as PDF' button to save as PDF to your computer</li>";
echo "</ol>";
echo "</div>";

// System Status Summary
echo "<div class='section' style='border-left-color: #17a2b8; background: #f8f9fa;'>";
echo "<h2>🔍 System Status Summary</h2>";

$checks = [
    'invoices table' => is_dir($invoice_dir) ? 'OK' : 'MISSING',
    'invoice directory' => is_dir($invoice_dir) ? 'OK' : 'MISSING',
    'invoice files' => (is_dir($invoice_dir) && count(glob($invoice_dir . '/*')) > 0) ? 'OK' : 'WAITING',
    'email helper' => file_exists($email_helper) && strpos(file_get_contents($email_helper), 'sendInvoice') !== false ? 'OK' : 'ERROR',
    'viewer endpoint' => file_exists($viewer_path) ? 'OK' : 'MISSING'
];

$overall_status = 'READY';
foreach ($checks as $check => $status) {
    $icon = ($status === 'OK') ? '✓' : (($status === 'WAITING') ? '⏳' : '✗');
    echo "<p>$icon <strong>" . ucfirst($check) . ":</strong> <code>" . $status . "</code></p>";
    if ($status === 'ERROR' || $status === 'MISSING') {
        $overall_status = 'ERROR';
    }
}

if ($overall_status === 'READY') {
    echo "<h3 style='color: #28a745;'>✓ Invoice system is READY for use</h3>";
} elseif ($overall_status === 'ERROR') {
    echo "<h3 style='color: #c41e3a;'>✗ Invoice system has ERRORS</h3>";
} else {
    echo "<h3 style='color: #ff9800;'>⏳ Invoice system is waiting for first order</h3>";
}
echo "</div>";

echo "</div>";
?>
