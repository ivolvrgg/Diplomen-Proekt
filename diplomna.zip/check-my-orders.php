<?php
// Check orders for logged-in user

include 'config/db.php';
include 'includes/auth_check.php';

echo "<h1>Check Your Orders</h1>";

$user_id = get_user_id();
echo "<p>Your user_id: " . ($user_id ?: 'NOT LOGGED IN') . "</p>";

if ($user_id === 0) {
    echo "<p style='color: red;'>Not logged in!</p>";
    exit;
}

// Find user by email in session
$user_email = $_SESSION['user_email'] ?? 'Unknown';
echo "<p>Email: $user_email</p>";

// Check all orders for this user
$orders = $conn->query("SELECT id, user_id, email, total, payment_method, status, invoice_requested, created_at FROM orders WHERE user_id = $user_id ORDER BY id DESC");

echo "<h2>Orders for this user:</h2>";

if ($orders && $orders->num_rows > 0) {
    echo "<p style='color: green;'>✓ Found " . $orders->num_rows . " orders</p>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Order ID</th><th>User ID</th><th>Email</th><th>Total</th><th>Payment</th><th>Status</th><th>Invoice</th><th>Created</th></tr>";
    while ($order = $orders->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $order['id'] . "</td>";
        echo "<td>" . $order['user_id'] . "</td>";
        echo "<td>" . $order['email'] . "</td>";
        echo "<td>" . $order['total'] . "</td>";
        echo "<td>" . $order['payment_method'] . "</td>";
        echo "<td>" . $order['status'] . "</td>";
        echo "<td>" . ($order['invoice_requested'] ? '✓ YES' : '✗ NO') . "</td>";
        echo "<td>" . $order['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>✗ No orders found for this user!</p>";
}

// Also check TOTAL orders in the entire orders table
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders");
$total = $total_orders->fetch_assoc();
echo "<h2>Database Status:</h2>";
echo "<p>Total orders in database: " . $total['count'] . "</p>";

// Check last 5 orders (any user)
echo "<h2>Last 5 orders (any user):</h2>";
$last_five = $conn->query("SELECT id, user_id, email, total, created_at FROM orders ORDER BY id DESC LIMIT 5");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Order ID</th><th>User ID</th><th>Email</th><th>Total</th><th>Created</th></tr>";
while ($order = $last_five->fetch_assoc()) {
    $user_or_guest = $order['user_id'] ? 'User #' . $order['user_id'] : 'GUEST (NULL)';
    echo "<tr>";
    echo "<td>" . $order['id'] . "</td>";
    echo "<td>" . $user_or_guest . "</td>";
    echo "<td>" . $order['email'] . "</td>";
    echo "<td>" . $order['total'] . "</td>";
    echo "<td>" . $order['created_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();
?>
