<?php
// Test making an actual order via HTTP POST to api/orders.php

echo "<h1>Testing HTTP POST to api/orders.php</h1>";

// Prepare the order data (what payment.php sends)
$order_data = [
    'payment_method' => 'cod',
    'delivery_method' => 'courier',
    'email' => 'httptest@test.bg',
    'phone' => '0895123456',
    'invoice_requested' => 1,
    'city' => 'Sofia',
    'street' => 'Test Street',
    'block' => '5',
    'entrance' => 'B',
    'apartment' => '12',
    'cart' => [
        [
            'product_id' => 1,
            'quantity' => 2
        ]
    ]
];

echo "<h2>Request Data:</h2>";
echo "<pre>";
print_r($order_data);
echo "</pre>";

// Create the HTTP context
$options = [
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/json',
        'content' => json_encode($order_data),
        'timeout' => 10
    ]
];

$context = stream_context_create($options);

echo "<h2>Making HTTP POST request to api/orders.php...</h2>";

// Make the request
$response = @file_get_contents('http://localhost/Diplomna_rabota/api/orders.php', false, $context);

if ($response === false) {
    echo "<strong style='color: red;'>✗ Request failed!</strong><br>";
    echo "Error: " . error_get_last()['message'] . "<br>";
} else {
    echo "<h2>Response:</h2>";
    echo "<pre>";
    echo htmlspecialchars($response);
    echo "</pre>";
    
    // Try parsing as JSON
    $result = json_decode($response, true);
    if ($result) {
        echo "<h2>Parsed Result:</h2>";
        if ($result['success']) {
            echo "<p style='color: green;'><strong>✓ Order Created!</strong></p>";
            echo "<p>Order ID: " . $result['order_id'] . "</p>";
        } else {
            echo "<p style='color: red;'><strong>✗ Error:</strong> " . $result['message'] . "</p>";
        }
    }
}
?>
