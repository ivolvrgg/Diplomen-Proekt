<?php
require_once __DIR__ . '/../vendor/autoload.php';

// Load environment variables or set directly
// For testing: use sk_test_ and pk_test_ keys from your Stripe dashboard
// For production: use sk_live_ and pk_live_ keys

// You can set these in a .env file or directly here:
$stripe_secret_key = getenv('STRIPE_SECRET_KEY');

// If not in environment, use live key
if (!$stripe_secret_key) {
    $stripe_secret_key = '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';
}

\Stripe\Stripe::setApiKey($stripe_secret_key);
?>
