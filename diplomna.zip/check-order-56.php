<?php
// Check order 56 details

include 'config/db.php';
include 'includes/auth_check.php';

$user_id = get_user_id();

echo "<h1>Check Order #56</h1>";
echo "<p>Your current user_id: " . $user_id . "</p>";

// Get order 56
$order = $conn->query("SELECT id, user_id, email, total, payment_method, status, created_at FROM orders WHERE id = 56");

if ($order && $order->num_rows > 0) {
    $row = $order->fetch_assoc();
    echo "<h2>Order #56 Details:</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><td>Order ID:</td><td>" . $row['id'] . "</td></tr>";
    echo "<tr><td>User ID:</td><td>" . ($row['user_id'] ?: 'NULL (Guest)') . "</td></tr>";
    echo "<tr><td>Email:</td><td>" . $row['email'] . "</td></tr>";
    echo "<tr><td>Total:</td><td>" . $row['total'] . "</td></tr>";
    echo "<tr><td>Payment:</td><td>" . $row['payment_method'] . "</td></tr>";
    echo "<tr><td>Status:</td><td>" . $row['status'] . "</td></tr>";
    echo "<tr><td>Created:</td><td>" . $row['created_at'] . "</td></tr>";
    echo "</table>";
    
    if ($row['user_id'] != $user_id) {
        echo "<p style='color: red;'><strong>✗ PROBLEM:</strong> Order was saved with user_id=" . ($row['user_id'] ?: 'NULL') . " but you are logged in as user_id=" . $user_id . "</p>";
        echo "<p>That's why it's not showing in your profile!</p>";
    } else {
        echo "<p style='color: green;'><strong>✓ Order user_id matches your user_id</strong></p>";
    }
} else {
    echo "<p style='color: red;'>Order #56 not found in database!</p>";
}

$conn->close();
?>
