<?php
require_once 'config/db.php';

$success = false;
$message = '';

try {
    // Check if google_id column already exists
    $result = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");
    
    if ($result && $result->num_rows > 0) {
        $message = "✓ google_id column already exists!";
        $success = true;
    } else {
        // Add the google_id column
        $alter_query = "ALTER TABLE users ADD COLUMN google_id VARCHAR(255) DEFAULT NULL UNIQUE";
        
        if ($conn->query($alter_query)) {
            $message = "✓ Successfully added google_id column to users table!";
            $success = true;
        } else {
            $message = "✗ Error adding google_id column: " . $conn->error;
            $success = false;
        }
    }
} catch (Exception $e) {
    $message = "✗ Error: " . $e->getMessage();
    $success = false;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Google OAuth Migration</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; }
        .success { color: green; font-size: 18px; padding: 20px; background-color: #f0f0f0; border-radius: 5px; }
        .error { color: red; font-size: 18px; padding: 20px; background-color: #f0f0f0; border-radius: 5px; }
        pre { background-color: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Google OAuth Migration</h1>
        <div class="<?php echo $success ? 'success' : 'error'; ?>">
            <?php echo $message; ?>
        </div>
        
        <h2>Status:</h2>
        <p>
            <?php if ($success): ?>
                Google OAuth column setup is complete!
                <br><br>
                <strong>You can now:</strong>
                <ul>
                    <li>Go to the <a href="user_login.php">Login Page</a></li>
                    <li>Click "Вход с Google" button</li>
                    <li>Sign in with your Google account</li>
                </ul>
            <?php else: ?>
                There was an issue setting up the Google OAuth column.
                <br><br>
                <strong>Please make sure:</strong>
                <ul>
                    <li>The database connection is working</li>
                    <li>The users table exists</li>
                    <li>You have permissions to modify the table</li>
                </ul>
            <?php endif; ?>
        </p>
    </div>
</body>
</html>
