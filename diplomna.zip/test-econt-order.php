<?php
// Complete order debug - test the full flow

session_start();

include 'config/db.php';
include 'includes/auth_check.php';

$user_id = get_user_id();

echo "<h1>Complete ECONT Order Test</h1>";
echo "<p>Your user_id: " . $user_id . "</p>";

// Step 1: Check delivery methods
echo "<h2>Step 1: Verify delivery methods in DB</h2>";
$dm = $conn->query("SELECT * FROM delivery_methods ORDER BY id");
while ($row = $dm->fetch_assoc()) {
    echo "ID " . $row['id'] . ": " . htmlspecialchars($row['name']) . " - Cost: " . $row['cost'] . " - Active: " . ($row['is_active'] ? 'YES' : 'NO') . "<br>";
}

// Step 2: Check products exist
echo "<h2>Step 2: Check products</h2>";
$prod = $conn->query("SELECT COUNT(*) as count FROM products WHERE id >= 1");
$p = $prod->fetch_assoc();
echo "<p>Products available: " . $p['count'] . "</p>";

// Step 3: Simulate ECONT order submission
echo "<h2>Step 3: Simulate ECONT order creation</h2>";

$order_data = [
    'payment_method' => 'cod',
    'delivery_method' => 'econt',
    'email' => $user_id ? ('user' . $user_id . '@test.com') : 'guest@test.com',
    'phone' => '0895999888',
    'invoice_requested' => 0,
    'delivery_office_id' => '9014',
    'econt_selected_address' => '9014 - Варна Битоля, 9000',
    'econt_customer_id' => '60ccdebacd9945a06cdc6d00130ac1',
    'cart' => [
        ['product_id' => 1, 'quantity' => 1]
    ]
];

echo "<p>Simulating order with:</p>";
echo "<pre>";
print_r($order_data);
echo "</pre>";

// Make the HTTP request
$options = [
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/json',
        'content' => json_encode($order_data),
        'timeout' => 10
    ]
];

$context = stream_context_create($options);
$response = @file_get_contents('http://localhost/Diplomna_rabota/api/orders.php', false, $context);

if ($response === false) {
    echo "<p style='color: red;'>✗ HTTP Request failed</p>";
} else {
    $result = json_decode($response, true);
    echo "<h2>API Response:</h2>";
    echo "<pre>";
    print_r($result);
    echo "</pre>";
    
    if ($result && $result['success']) {
        echo "<p style='color: green;'><strong>✓ Order created successfully!</strong></p>";
        echo "<p>Order ID: " . $result['order_id'] . "</p>";
    } else {
        echo "<p style='color: red;'><strong>✗ Order failed</strong></p>";
        if ($result && isset($result['message'])) {
            echo "<p>Error: " . htmlspecialchars($result['message']) . "</p>";
        }
    }
}

$conn->close();
?>
