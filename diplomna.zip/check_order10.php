<?php
require 'config/db.php';

// Check order 10 prices
$result = $conn->query("SELECT order_id, unit_price FROM order_items WHERE order_id = 10");
echo "Current prices for order 10:\n";
while($row = $result->fetch_assoc()) {
    echo "Order " . $row['order_id'] . " - Price: " . $row['unit_price'] . "\n";
}

// Update to 10.32
$update = $conn->query("UPDATE order_items SET unit_price = 10.32 WHERE order_id = 10 AND unit_price = 10.00");
echo "\nUpdated order 10 price to 10.32\n";

// Verify
$check = $conn->query("SELECT unit_price FROM order_items WHERE order_id = 10")->fetch_assoc();
echo "New price: " . $check['unit_price'] . "\n";

$conn->close();
?>
