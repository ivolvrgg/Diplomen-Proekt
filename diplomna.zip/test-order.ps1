$body = @{
    email = "testuser@gmail.com"
    phone = "0888123456"
    payment_method = "cod"
    delivery_method = "econt"
    delivery_office_id = "VN1"
    cart = @(
        @{product_id = 1; quantity = 1},
        @{product_id = 2; quantity = 1}
    )
} | ConvertTo-Json

Write-Host "===== Testing Complete Order Submission =====" -ForegroundColor Cyan
Write-Host "`nTest Configuration:
  Email: testuser@gmail.com
  Phone: 0888123456
  Payment: COD (Наложен платеж)
  Delivery: ECONT office VN1
  Cart: 2 items (product ID 1 qty 1, product ID 2 qty 1)
" -ForegroundColor Yellow

Write-Host "Sending order to API...`n" -ForegroundColor Cyan

$response = Invoke-WebRequest -Uri "http://localhost/Diplomna_rabota/api/orders.php" `
    -Method POST `
    -Headers @{"Content-Type"="application/json"} `
    -Body $body `
    -UseBasicParsing `
    -ErrorAction Continue

Write-Host "Response Status Code: $($response.StatusCode)`n" -ForegroundColor Green

$json = $response.Content | ConvertFrom-Json

if ($json.success) {
    Write-Host "SUCCESS: ORDER CREATED!" -ForegroundColor Green
    Write-Host "`nOrder Details:" -ForegroundColor Yellow
    Write-Host "  Order ID: $($json.order_id)"
    Write-Host "  Total: $($json.total)" 
    Write-Host "  Message: $($json.message)"
    Write-Host "  Redirect: $($json.redirect_url)"
} else {
    Write-Host "FAILED: ORDER ERROR!" -ForegroundColor Red
    Write-Host "`nError: $($json.message)" -ForegroundColor Yellow
}

Write-Host "`n`nFull Response:" -ForegroundColor Cyan
Write-Host ($json | ConvertTo-Json) -ForegroundColor White
