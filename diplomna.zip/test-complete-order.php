<?php
// Complete order submission test
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');
ob_start();

session_start();

// Simulate guest session
$_SESSION['guest_id'] = 'test_guest_' . time();

// Test case 1: Valid COD order with ECONT
$_POST = [
    'email' => 'testuser@gmail.com',
    'phone' => '0888123456',
    'payment_method' => 'cod',
    'delivery_method' => 'econt',
    'delivery_office_id' => 'VN1',
    'econt_office_code' => 'VN1',
    'cart' => json_encode([
        ['product_id' => 1, 'quantity' => 1],
        ['product_id' => 2, 'quantity' => 1]
    ])
];

// Prepare the data as JSON for the API
$json_input = json_encode([
    'email' => 'testuser@gmail.com',
    'phone' => '0888123456',
    'payment_method' => 'cod',
    'delivery_method' => 'econt',
    'delivery_office_id' => 'VN1',
    'cart' => [
        ['product_id' => 1, 'quantity' => 1],
        ['product_id' => 2, 'quantity' => 1]
    ]
]);

// Mock the php://input stream
$GLOBALS['_JSON_INPUT'] = $json_input;

// Create a mock file_get_contents
if (!function_exists('file_get_contents_original')) {
    $GLOBALS['_FILE_GET_CONTENTS_CALLED'] = false;
}

echo "=== Testing Complete Order Submission ===\n\n";
echo "Test Data:\n";
echo "Email: testuser@gmail.com\n";
echo "Phone: 0888123456\n";
echo "Payment: COD (Наложен платеж)\n";
echo "Delivery: ECONT with office VN1\n";
echo "Cart: 2 items\n\n";
echo "Executing order submission...\n\n";

ob_clean();

// Simulate the POST request
$_SERVER['REQUEST_METHOD'] = 'POST';

// Include orders API
include 'api/orders.php';
?>
