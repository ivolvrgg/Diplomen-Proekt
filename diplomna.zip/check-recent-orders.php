<?php
// Check orders with detailed timestamps

include 'config/db.php';
include 'includes/auth_check.php';

$user_id = get_user_id();

echo "<h1>Your Recent Orders (detailed)</h1>";
echo "<p>User ID: " . $user_id . "</p>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";

if ($user_id === 0) {
    echo "<p style='color: red;'>Not logged in!</p>";
    exit;
}

// Get orders from the last 10 minutes
$ten_min_ago = date('Y-m-d H:i:s', time() - 600);

$recent = $conn->query("
    SELECT id, user_id, email, total, payment_method, status, invoice_requested, created_at, updated_at 
    FROM orders 
    WHERE user_id = $user_id AND created_at > '$ten_min_ago'
    ORDER BY created_at DESC
");

echo "<h2>Orders created in last 10 minutes:</h2>";
if ($recent && $recent->num_rows > 0) {
    echo "<p style='color: green;'>✓ Found " . $recent->num_rows . " recent orders</p>";
    while ($order = $recent->fetch_assoc()) {
        echo "<div style='border: 1px solid green; padding: 10px; margin: 10px 0;'>";
        echo "<strong>Order #" . $order['id'] . "</strong><br>";
        echo "Created: " . $order['created_at'] . "<br>";
        echo "Total: " . $order['total'] . " €<br>";
        echo "Payment: " . $order['payment_method'] . "<br>";
        echo "Invoice: " . ($order['invoice_requested'] ? 'YES ✓' : 'NO ✗') . "<br>";
        echo "</div>";
    }
} else {
    echo "<p style='color: red;'>✗ No orders in last 10 minutes</p>";
}

// Show your last 3 orders overall
echo "<h2>Your last 3 orders (all time):</h2>";
$last3 = $conn->query("SELECT id, total, created_at FROM orders WHERE user_id = $user_id ORDER BY id DESC LIMIT 3");
while ($order = $last3->fetch_assoc()) {
    echo "<p>Order #" . $order['id'] . " - €" . $order['total'] . " - " . $order['created_at'] . "</p>";
}

$conn->close();
?>
