<?php
require 'config/db.php';

// Add address columns to users table if they don't exist
$columns_to_add = [
    'street' => "ALTER TABLE users ADD COLUMN street VARCHAR(255) DEFAULT NULL",
    'block' => "ALTER TABLE users ADD COLUMN block VARCHAR(50) DEFAULT NULL",
    'entrance' => "ALTER TABLE users ADD COLUMN entrance VARCHAR(50) DEFAULT NULL",
    'apartment' => "ALTER TABLE users ADD COLUMN apartment VARCHAR(50) DEFAULT NULL",
];

foreach ($columns_to_add as $col_name => $query) {
    // Check if column exists
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col_name'");
    if ($check && $check->num_rows === 0) {
        if ($conn->query($query)) {
            echo "Added column: $col_name\n";
        } else {
            echo "Error adding $col_name: " . $conn->error . "\n";
        }
    } else {
        echo "Column $col_name already exists\n";
    }
}

echo "\nEnsuring google_id column exists...\n";
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");
if ($check && $check->num_rows === 0) {
    if ($conn->query("ALTER TABLE users ADD COLUMN google_id VARCHAR(255) UNIQUE DEFAULT NULL")) {
        echo "Added google_id column\n";
    } else {
        echo "Error adding google_id: " . $conn->error . "\n";
    }
} else {
    echo "google_id column already exists\n";
}

echo "\nDone!\n";
?>
