<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'includes/econt-service.php';

echo "Testing ECONT Service with correct credentials:\n";
echo "Email: dronchebg@gmail.com\n";
echo "Password: Test1234\n\n";

$econt = new EcontService();
echo "EcontService initialized.\n\n";

echo "Fetching offices...\n";
$result = $econt->getOffices();

echo "Result:\n";
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n\n";

if ($result['success']) {
    echo "✓ API call successful!\n";
    echo "Found " . count($result['offices']) . " offices.\n";
    if (!empty($result['offices'])) {
        echo "\nFirst office:\n";
        echo json_encode($result['offices'][0], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    echo "✗ API call failed: " . $result['error'] . "\n";
}
