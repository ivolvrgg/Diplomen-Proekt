<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Address Loading</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .box { border: 1px solid #ccc; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        code { background: #f5f5f5; padding: 2px 6px; border-radius: 3px; }
    </style>
</head>
<body>
    <h1>🔍 Address Loading Debug</h1>
    
    <div class="box">
        <h2>Session Info</h2>
        <p><strong>User ID:</strong> <?php echo $_SESSION['user_id'] ?? 'NOT SET'; ?></p>
        <p><strong>User Email:</strong> <?php echo $_SESSION['user_email'] ?? 'NOT SET'; ?></p>
    </div>

    <div class="box">
        <h2>📋 API Test</h2>
        <button onclick="testAPI()">Test get_user_profile.php</button>
        <p><small>This should return your profile data including default address</small></p>
        <pre id="api-result" style="background: #f5f5f5; padding: 10px; margin-top: 10px; max-height: 300px; overflow: auto;"></pre>
    </div>

    <div class="box">
        <h2>🏠 Payment Page Test</h2>
        <p><strong>Step 1:</strong> Go add an address on your <a href="profile.php" target="_blank">profile page</a></p>
        <p><strong>Step 2:</strong> Then test the payment page:</p>
        <button onclick="testPaymentPage()">Check Payment Page</button>
        <button onclick="openPaymentPage()" style="margin-left: 10px; background: #588157; color: white; padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer;">Open Payment Page</button>
        <pre id="payment-result" style="background: #f5f5f5; padding: 10px; margin-top: 10px; max-height: 300px; overflow: auto;"></pre>
    </div>

    <script>
        function testAPI() {
            const result = document.getElementById('api-result');
            result.textContent = 'Loading...';
            
            fetch('api/get_user_profile.php')
                .then(r => r.json())
                .then(data => {
                    result.textContent = JSON.stringify(data, null, 2);
                    if (data.success) {
                        result.parentElement.parentElement.classList.add('success');
                    } else {
                        result.parentElement.parentElement.classList.add('error');
                    }
                })
                .catch(err => {
                    result.textContent = 'ERROR: ' + err.message;
                    result.parentElement.parentElement.classList.add('error');
                });
        }

        function testPaymentPage() {
            const result = document.getElementById('payment-result');
            result.textContent = 'Checking payment page DOM...';
            
            fetch('payment.php')
                .then(r => r.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    
                    const cityInput = doc.getElementById('city-input');
                    const streetInput = doc.getElementById('street-input');
                    const blockInput = doc.getElementById('block-input');
                    const entranceInput = doc.getElementById('entrance-input');
                    const apartmentInput = doc.getElementById('apartment-input');
                    
                    const checks = [
                        { name: 'city-input', element: cityInput },
                        { name: 'street-input', element: streetInput },
                        { name: 'block-input', element: blockInput },
                        { name: 'entrance-input', element: entranceInput },
                        { name: 'apartment-input', element: apartmentInput }
                    ];
                    
                    let output = 'Address fields found on payment.php:\n\n';
                    checks.forEach(check => {
                        output += (check.element ? '✓' : '✗') + ' ' + check.name + '\n';
                    });
                    
                    result.textContent = output;
                    result.parentElement.parentElement.classList.add('success');
                })
                .catch(err => {
                    result.textContent = 'ERROR: ' + err.message;
                    result.parentElement.parentElement.classList.add('error');
                });
        }

        function openPaymentPage() {
            window.open('payment.php', '_blank');
        }

        // Auto-test on load
        window.addEventListener('load', function() {
            testAPI();
        });
    </script>
</body>
</html>
