<?php
require 'config/db.php';

$result = $conn->query("UPDATE order_items SET unit_price = 10.32 WHERE order_id = 60 AND unit_price = 10.00");

if($result) {
    echo "Successfully updated order 60 price to 10.32\n";
    
    // Verify the update
    $check = $conn->query("SELECT unit_price FROM order_items WHERE order_id = 60")->fetch_assoc();
    echo "New price in database: " . $check['unit_price'] . "\n";
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
?>
