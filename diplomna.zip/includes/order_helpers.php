<?php
/**
 * Order Delivery Date Helpers
 * This file provides helper functions for calculating and displaying expected delivery dates
 */

/**
 * Generate URL-friendly slug from product name
 * 
 * @param string $name The product name
 * @return string URL-friendly slug
 */
function generate_product_slug($name) {
    // Convert to lowercase
    $slug = strtolower($name);
    
    // Replace spaces with hyphens
    $slug = preg_replace('/\s+/', '-', $slug);
    
    // Remove special characters, keeping only alphanumeric and hyphens
    $slug = preg_replace('/[^a-z0-9\-]/', '', $slug);
    
    // Remove consecutive hyphens
    $slug = preg_replace('/-+/', '-', $slug);
    
    // Remove leading/trailing hyphens
    $slug = trim($slug, '-');
    
    return $slug;
}

/**
 * Calculate expected arrival dates based on delivery method
 * 
 * @param int $delivery_method_id The delivery method ID
 * @param DateTime|null $from_date The date to calculate from (defaults to today)
 * @return array ['start' => DateTime, 'end' => DateTime, 'start_formatted' => string, 'end_formatted' => string]
 */
function calculate_expected_arrival_dates($delivery_method_id, $from_date = null) {
    if (!$from_date) {
        $from_date = new DateTime('NOW');
    }
    
    // Define delivery times for each method: [min_days, max_days]
    $delivery_times = [
        1 => [3, 5],  // Courier
        2 => [2, 4],  // Speedy
        3 => [2, 3]   // Econt
    ];
    
    $delivery_method_id = intval($delivery_method_id);
    
    if (!isset($delivery_times[$delivery_method_id])) {
        // Default to 3-5 days if method not found
        $min_days = 3;
        $max_days = 5;
    } else {
        [$min_days, $max_days] = $delivery_times[$delivery_method_id];
    }
    
    $arrival_start = clone $from_date;
    $arrival_start->add(new DateInterval('P' . $min_days . 'D'));
    
    $arrival_end = clone $from_date;
    $arrival_end->add(new DateInterval('P' . $max_days . 'D'));
    
    return [
        'start' => $arrival_start,
        'end' => $arrival_end,
        'start_formatted' => $arrival_start->format('d.m.Y'),
        'end_formatted' => $arrival_end->format('d.m.Y'),
        'start_long' => $arrival_start->format('d F Y'),
        'end_long' => $arrival_end->format('d F Y')
    ];
}

/**
 * Get human-readable status text for order status
 * 
 * @param string $status The order status code
 * @return string Human-readable status text in Bulgarian
 */
function get_order_status_text($status) {
    return match($status) {
        'pending' => 'Очакваща плащане',
        'paid' => 'Платена',
        'processing' => 'В обработка',
        'shipped' => 'Изпратена',
        'delivered' => 'Доставена',
        'cancelled' => 'Отменена',
        default => ucfirst(htmlspecialchars($status))
    };
}

/**
 * Get CSS class for order status
 * 
 * @param string $status The order status code
 * @return string CSS class name
 */
function get_order_status_class($status) {
    return match($status) {
        'pending' => 'status-pending',
        'paid' => 'status-paid',
        'processing' => 'status-processing',
        'shipped' => 'status-shipped',
        'delivered' => 'status-delivered',
        'cancelled' => 'status-cancelled',
        default => 'status-unknown'
    };
}

/**
 * Format order status with styling HTML
 * 
 * @param string $status The order status code
 * @return string Formatted HTML string
 */
function format_order_status_badge($status) {
    $text = get_order_status_text($status);
    $class = get_order_status_class($status);
    return '<span class="order-status ' . htmlspecialchars($class) . '">' . htmlspecialchars($text) . '</span>';
}
?>
