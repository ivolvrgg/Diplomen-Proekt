<?php
include 'includes/auth_check.php';

echo "<h1>Session Diagnostics</h1>";
echo "<p><strong>Current Time:</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><strong>Session Status:</strong> " . (session_status() === PHP_SESSION_ACTIVE ? 'ACTIVE' : 'INACTIVE') . "</p>";
echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
echo "<h2>$_SESSION contents:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>is_logged_in() result:</h2>";
echo "<p>" . (is_logged_in() ? "✓ TRUE - User is logged in" : "✗ FALSE - User is NOT logged in") . "</p>";

echo "<h2>Session Variables:</h2>";
echo "<ul>";
echo "<li>user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') . "</li>";
echo "<li>user_email: " . ($_SESSION['user_email'] ?? 'NOT SET') . "</li>";
echo "<li>user_name: " . ($_SESSION['user_name'] ?? 'NOT SET') . "</li>";
echo "<li>is_admin: " . ($_SESSION['is_admin'] ?? 'NOT SET') . "</li>";
echo "</ul>";

echo "<h2>Recommended Actions:</h2>";
if (!is_logged_in()) {
    echo "<p style='color: red;'><strong>You are not logged in!</strong></p>";
    echo "<p><a href='user_login.php'>Go to login page</a></p>";
} else {
    echo "<p style='color: green;'><strong>You are logged in!</strong></p>";
    echo "<p><a href='profile.php'>Go to profile page</a></p>";
}

// Check if session file exists
$session_file = session_save_path() . '/sess_' . session_id();
echo "<h2>Session File Info:</h2>";
echo "<p>Session save path: " . session_save_path() . "</p>";
echo "<p>Session file path: " . $session_file . "</p>";
if (file_exists($session_file)) {
    echo "<p style='color: green;'>✓ Session file EXISTS</p>";
    echo "<p>File size: " . filesize($session_file) . " bytes</p>";
    echo "<p>Last modified: " . date('Y-m-d H:i:s', filemtime($session_file)) . "</p>";
} else {
    echo "<p style='color: red;'>✗ Session file NOT FOUND</p>";
}
?>
