<?php
require 'config/db.php';

$order_id = 63;

// Check the actual unit_price in database
$result = $conn->query("SELECT unit_price FROM order_items WHERE order_id = $order_id");
echo "Unit prices for order $order_id:\n";
while($row = $result->fetch_assoc()) {
    echo "Price in DB: " . $row['unit_price'] . "\n";
    echo "As float: " . floatval($row['unit_price']) . "\n";
}

$conn->close();
?>
