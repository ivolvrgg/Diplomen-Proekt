#!/usr/bin/powershell
# Direct MySQL migration for address columns using Windows

$xamppPath = "C:\xampp"
$mysqlPath = "$xamppPath\mysql\bin\mysql.exe"
$mysqlUser = "root"
$mysqlPort = "3307"
$dbName = "dron_db"

# Check if MySQL exists
if (!(Test-Path $mysqlPath)) {
    Write-Error "MySQL not found at $mysqlPath"
    exit 1
}

# SQL commands to add address columns
$sqlCommands = @(
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS street VARCHAR(255) DEFAULT NULL;",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS block VARCHAR(50) DEFAULT NULL;",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS entrance VARCHAR(50) DEFAULT NULL;",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS apartment VARCHAR(50) DEFAULT NULL;",
    "SELECT 'Address columns added successfully' as status;"
)

# Run each command
foreach ($sql in $sqlCommands) {
    Write-Host "Running: $sql"
    & $mysqlPath -u $mysqlUser -P $mysqlPort -e $sql $dbName
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Command failed: $sql"
    }
}

Write-Host "Migration completed!"
