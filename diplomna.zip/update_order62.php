<?php
require 'config/db.php';

// Find the order ID from invoice number - assuming it's 62
$order_id = 62;

// Check current price
$result = $conn->query("SELECT unit_price FROM order_items WHERE order_id = $order_id");
echo "Current prices for order $order_id:\n";
while($row = $result->fetch_assoc()) {
    echo "Price: " . $row['unit_price'] . "\n";
}

// Update all 10.00 prices to 10.32
$update = $conn->query("UPDATE order_items SET unit_price = 10.32 WHERE order_id = $order_id AND unit_price = 10.00");
echo "\nUpdated order $order_id prices: 10.00 -> 10.32\n";

// Verify
$check = $conn->query("SELECT unit_price FROM order_items WHERE order_id = $order_id");
echo "\nNew prices:\n";
while($row = $check->fetch_assoc()) {
    echo "Price: " . $row['unit_price'] . "\n";
}

$conn->close();
?>
