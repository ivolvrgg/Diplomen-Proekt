<?php
// Load .env manually
foreach (file('.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
    if (strpos($line, '#') === 0 || strpos($line, '=') === false) continue;
   list($key, $val) = explode('=', $line, 2);
    putenv(trim($key) . '=' . trim($val));
}

$username = getenv('ECONT_USERNAME');
$password = getenv('ECONT_PASSWORD');

echo "Testing Econt API with Query Parameters\n";
echo "=======================================\n";

// Try with query params instead of auth header
$urls = [
    'https://api.econt.com/v1/offices?username=' . urlencode($username) . '&password=' . urlencode($password),
    'https://api.econt.com/offices?username=' . urlencode($username) . '&password=' . urlencode($password),
    'https://api.econt.com/rest/offices?username=' . urlencode($username) . '&password=' . urlencode($password),
];

foreach ($urls as $url) {
    echo "\nTesting: " . substr($url, 0, 50) . "...\n";
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 3,
        CURLOPT_FAILONERROR => false
    ]);
    
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP $code\n";
    if ($code == 200 && !empty($response)) {
        echo "Response: " . substr($response, 0, 300) . "\n";
        
        $data = json_decode($response, true);
        if ($data && is_array($data)) {
            echo "Valid JSON response!\n";
        }
    }
}

// Also try localhost endpoint
echo "\n\nTesting localhost endpoints\n";
echo "============================\n";

$endpoints = [
    'http://localhost/Diplomna_rabota/api/econt-offices.php',
];

foreach ($endpoints as $url) {
    echo "Testing: $url\n";
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5,
        CURLOPT_FAILONERROR => false
    ]);
    
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP $code\n";
    if (!empty($response)) {
        $data = json_decode($response, true);
        if ($data) {
            echo "Success: " . ($data['success'] ? 'YES' : 'NO') . "\n";
            if (isset($data['count'])) echo "Count: " . $data['count'] . "\n";
            if (isset($data['error'])) echo "Error: " . $data['error'] . "\n";
        }
    }
}
?>
