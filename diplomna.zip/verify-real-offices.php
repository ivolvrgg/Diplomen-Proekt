<?php
require_once 'config/db.php';

// Load .env
foreach (file('.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
    if (strpos($line, '#') === 0 || strpos($line, '=') === false) continue;
    list($key, $val) = explode('=', $line, 2);
    putenv(trim($key) . '=' . trim($val));
}

$username = getenv('ECONT_USERNAME');
$password = getenv('ECONT_PASSWORD');

// Get a random Econt office from database
$result = $conn->query("SELECT id, label, city, street FROM delivery_offices WHERE delivery_method_id = 3 LIMIT 1");
$office = $result->fetch_assoc();

echo "Testing Shipment Creation with Real Econt Office\n";
echo "================================================\n\n";

echo "Using office: {$office['label']}\n";
echo "Office in database: YES (Real Econt data)\n\n";

// Try to create a shipment with this office
$shipment_json = json_encode([
    'label' => [
        'senderClient' => [
            'name' => 'Test Store',
            'phones' => ['+359 888 123 456']
        ],
        'senderAddress' => [
            'city' => [
                'country' => ['code3' => 'BGR'],
                'name' => 'Sofia'
            ],
            'street' => 'Test Street',
            'num' => '1'
        ],
        'receiverClient' => [
            'name' => 'Test Customer',
            'phones' => ['+359 888 654 321']
        ],
        'receiverAddress' => [
            'city' => [
                'country' => ['code3' => 'BGR'],
                'name' => $office['city']
            ],
            'street' => $office['street'],
            'poiId' => intval($office['id'])  // Use office ID from database
        ],
        'packCount' => 1,
        'shipmentType' => 'PACK',
        'weight' => 1,
        'shipmentDescription' => 'Test shipment'
    ],
    'mode' => 'validate'  // Just validate, don't create
]);

echo "Sending test shipment request to Econt API...\n";
echo "Office ID used: " . $office['id'] . "\n\n";

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://api.econt.com/v1/labels',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $shipment_json,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode("$username:$password")
    ],
    CURLOPT_FAILONERROR => false
]);

$response = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Response Code: $code\n";

if ($code == 200) {
    echo "\n✓ SUCCESS! The office ID is VALID in Econt system\n";
    echo "This confirms the offices in your database ARE real Econt offices\n";
    
    $data = json_decode($response, true);
    echo "\nEcont API Response:\n";
    echo json_encode($data, JSON_PRETTY_PRINT) . "\n";
} else {
    echo "\nResponse: " . substr($response, 0, 500) . "\n";
}
?>
