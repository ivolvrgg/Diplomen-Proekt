<?php
require_once 'includes/econt-service.php';
$econt = new EcontService();
$result = $econt->getOffices();
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
