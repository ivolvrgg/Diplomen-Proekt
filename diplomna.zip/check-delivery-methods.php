<?php
// Check delivery methods in database

include 'config/db.php';

echo "<h1>Delivery Methods in Database</h1>";

$result = $conn->query("SELECT * FROM delivery_methods");

if (!$result) {
    echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
} else {
    echo "<p>Found " . $result->num_rows . " delivery methods</p>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Cost</th><th>Active</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $active = $row['is_active'] ? '✓ Yes' : '✗ No';
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . $row['cost'] . "</td>";
        echo "<td>" . $active . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Also check if ID 2 (ECONT) exists and is active
echo "<h2>Specific check for ECONT (id=2):</h2>";
$check = $conn->query("SELECT * FROM delivery_methods WHERE id = 2 AND is_active = 1");
if ($check && $check->num_rows > 0) {
    echo "<p style='color: green;'>✓ ECONT exists and is ACTIVE</p>";
    $row = $check->fetch_assoc();
    print_r($row);
} else {
    echo "<p style='color: red;'>✗ ECONT is missing or NOT ACTIVE</p>";
    // Check if it exists at all
    $exists = $conn->query("SELECT * FROM delivery_methods WHERE id = 2");
    if ($exists && $exists->num_rows > 0) {
        echo "<p>It exists but:</p>";
        $row = $exists->fetch_assoc();
        echo "<pre>";
        print_r($row);
        echo "</pre>";
    }
}

$conn->close();
?>
