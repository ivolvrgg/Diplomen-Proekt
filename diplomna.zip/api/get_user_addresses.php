<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once '../config/db.php';
require_once '../includes/auth_check.php';

$response = ['success' => false, 'addresses' => []];

try {
    // Check if user is logged in
    $user_id = get_user_id();
    
    if ($user_id === 0) {
        // Guest user
        $response['success'] = false;
        $response['message'] = 'Not authenticated';
        echo json_encode($response);
        exit;
    }

    // Fetch user's addresses
    $stmt = $conn->prepare("SELECT id, city, street, block, entrance, apartment, is_default FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id ASC");
    
    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }
    
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $addresses = [];
    while ($row = $result->fetch_assoc()) {
        $addresses[] = [
            'id' => $row['id'],
            'city' => $row['city'],
            'street' => $row['street'],
            'block' => $row['block'],
            'entrance' => $row['entrance'],
            'apartment' => $row['apartment'],
            'is_default' => (bool)$row['is_default']
        ];
    }
    
    $stmt->close();
    
    $response['success'] = true;
    $response['addresses'] = $addresses;
    
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;
?>
