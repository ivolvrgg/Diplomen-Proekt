<?php
/**
 * Stripe Order Handler
 * Called after successful Stripe payment
 * Creates the order and redirects to confirmation page
 */

require_once 'config/db.php';
require_once 'config/stripe.php';
require_once 'includes/auth_check.php';

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

try {
    // Get Stripe session ID from success URL
    $session_id = trim($_GET['session_id'] ?? '');
    if (empty($session_id)) {
        throw new Exception('No session ID provided');
    }

    error_log("Stripe Order Handler: Processing session $session_id");

    // Retrieve the session from Stripe to verify payment
    $session = \Stripe\Checkout\Session::retrieve($session_id, [
        'expand' => ['payment_intent'],
    ]);

    error_log("Stripe session status: " . $session->payment_status);

    // Verify payment was successful
    if ($session->payment_status !== 'paid') {
        throw new Exception('Payment not completed. Status: ' . $session->payment_status);
    }

    // Get order data from session metadata
    $metadata = $session->metadata;
    $user_id = ($metadata->user_id === 'guest') ? null : intval($metadata->user_id);
    $db_user_id = $user_id;
    $email = $metadata->email;
    $phone = $metadata->phone;
    $delivery_method = $metadata->delivery_method;
    $delivery_method_id = intval($metadata->delivery_method_id);
    $delivery_office_id = intval($metadata->delivery_office_id ?? 0);
    $delivery_cost = floatval($metadata->delivery_cost);

    error_log("Creating order for user_id=$db_user_id, email=$email, delivery=$delivery_method");

    // Get cart items
    $cart_items = [];
    $subtotal = 0;

    if ($db_user_id !== null) {
        // Logged-in user
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price, p.sale_price, p.discount_percent 
                       FROM cart c 
                       JOIN products p ON c.product_id = p.id 
                       WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);

        if (!$cart_result || $cart_result->num_rows === 0) {
            throw new Exception('Cart is empty');
        }

        while ($item = $cart_result->fetch_assoc()) {
            $display_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price'];
            $item_total = $display_price * $item['quantity'];
            $subtotal += $item_total;
            $cart_items[] = $item;
        }
    } else {
        // For guest orders from Stripe, we need to retrieve cart from session (won't work without it)
        // This is a limitation - guest carts are in localStorage, not available on this page
        throw new Exception('Guest checkout with Stripe not fully implemented. Please use logged-in account.');
    }

    // Calculate totals
    $vat = 0;
    $total = $subtotal + $delivery_cost;
    $order_status = 'pending';
    $payment_method = 'card';
    $econt_office_code = '';
    $econt_selected_address = '';

    error_log("Starting transaction for order creation");

    // Start transaction
    $conn->begin_transaction();

    try {
        // Insert order
        $insert_order = $conn->prepare("
            INSERT INTO orders (
                user_id, status, subtotal, delivery_cost, vat, total, 
                payment_method, delivery_method_id, delivery_office_id, 
                email, phone, econt_office_code, econt_selected_address, 
                invoice_requested, created_at, updated_at
            ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");

        if (!$insert_order) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }

        $user_id_param = $db_user_id;
        $invoice_requested_int = 0; // Stripe orders don't request invoices
        
        $insert_order->bind_param("isddddsiissssi", $user_id_param, $order_status, $subtotal, 
            $delivery_cost, $vat, $total, $payment_method, $delivery_method_id, $delivery_office_id, 
            $email, $phone, $econt_office_code, $econt_selected_address, $invoice_requested_int);

        if (!$insert_order->execute()) {
            throw new Exception('Failed to create order: ' . $conn->error);
        }

        $order_id = $conn->insert_id;
        error_log("Stripe Order: Created order #$order_id");

        // Insert order items
        $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
        if (!$item_stmt) {
            throw new Exception('Item prepare failed: ' . $conn->error);
        }

        foreach ($cart_items as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $display_price = floatval((!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price']);

            $item_stmt->bind_param("iiid", $order_id, $product_id, $quantity, $display_price);
            if (!$item_stmt->execute()) {
                throw new Exception('Failed to insert order item: ' . $conn->error);
            }
        }
        $item_stmt->close();
        $insert_order->close();

        // Clear cart for logged-in users
        if ($db_user_id !== null) {
            $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $clear_stmt->bind_param("i", $db_user_id);
            $clear_stmt->execute();
            $clear_stmt->close();
        }

        // Commit transaction
        if (!$conn->commit()) {
            throw new Exception('Failed to commit transaction: ' . $conn->error);
        }

        error_log("Stripe Order: Transaction committed for order #$order_id");

        // Send confirmation email
        require_once 'includes/EmailHelper.php';
        try {
            $emailer = new EmailHelper();
            $order_data = [
                'order_id' => $order_id,
                'email' => $email,
                'phone' => $phone,
                'total' => $total,
                'delivery_cost' => $delivery_cost,
                'payment_method' => 'card'
            ];
            $emailer->sendOrderConfirmation($email, 'Customer', $order_id, $order_data);
            error_log("Stripe Order: Confirmation email sent for order #$order_id");
        } catch (Exception $e) {
            error_log("Stripe Order: Failed to send email: " . $e->getMessage());
        }

        // Redirect to confirmation page
        error_log("Stripe Order: Redirecting to confirmation for order #$order_id");
        header('Location: /Diplomna_rabota/order-confirmation.php?order_id=' . $order_id);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Stripe Order Handler Error: " . $e->getMessage());
    // Redirect to payment page with error
    header('Location: /Diplomna_rabota/payment.php?error=' . urlencode($e->getMessage()));
    exit;
}
?>
