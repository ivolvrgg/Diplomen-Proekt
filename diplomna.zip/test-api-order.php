<?php
// Test script to simulate an order creation request

session_start();
$_SESSION['user_id'] = 69;

header('Content-Type: application/json; charset=utf-8');

// Simulate the API call
$test_data = [
    'email' => 'test@example.com',
    'phone' => '0895123456',
    'payment_method' => 'cod',
    'delivery_method' => 'courier',
    'subtotal' => 50.00,
    'delivery_cost' => 3.00,
    'vat' => 12.65,
    'total' => 65.00,
    'invoice_requested' => 1,
    'cart_items' => [
        ['product_id' => 1, 'quantity' => 1, 'name' => 'Test Product', 'price' => 50.00]
    ]
];

echo "<h1>Testing Order Creation API</h1>";
echo "<h2>Test Data:</h2>";
echo "<pre>";
print_r($test_data);
echo "</pre>";

// Try to create a request
$_POST = $test_data;
file_put_contents('php://stderr', "Starting order test...\n");

// Get the actual response from the API
$_SERVER['REQUEST_METHOD'] = 'POST';

ob_start();
include 'api/orders.php';
$output = ob_get_clean();

echo "<h2>API Response:</h2>";
echo "<pre>" . htmlspecialchars($output) . "</pre>";

// Also check the error log for any PHP errors
echo "<h2>Recent PHP Errors (check apache error log):</h2>";
$error_log_path = 'C:/xampp/apache/logs/error.log';
if (file_exists($error_log_path)) {
    $lines = file($error_log_path);
    $recent = array_slice($lines, -20);
    echo "<pre>";
    foreach ($recent as $line) {
        if (strpos($line, '2026-04-01') !== false) {
            echo htmlspecialchars($line);
        }
    }
    echo "</pre>";
} else {
    echo "Error log not found at: " . $error_log_path;
}
?>
