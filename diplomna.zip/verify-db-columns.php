<?php
header('Content-Type: text/plain');
require 'config/db.php';

// Try to add columns one by one with error handling
$columns = [
    'street' => 'VARCHAR(255)',
    'block' => 'VARCHAR(50)',
    'entrance' => 'VARCHAR(50)',
    'apartment' => 'VARCHAR(50)'
];

foreach ($columns as $col => $type) {
    // Check if column exists
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col'");
    
    if ($check && $check->num_rows === 0) {
        $query = "ALTER TABLE users ADD COLUMN $col $type DEFAULT NULL";
        if ($conn->query($query)) {
            echo "✓ Added column: $col\n";
        } else {
            echo "✗ Error adding $col: " . $conn->error . "\n";
        }
    } else {
        echo "✓ Column $col already exists\n";
    }
}

// Check google_id column
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");
if ($check && $check->num_rows === 0) {
    $query = "ALTER TABLE users ADD COLUMN google_id VARCHAR(255) UNIQUE DEFAULT NULL";
    if ($conn->query($query)) {
        echo "✓ Added column: google_id\n";
    } else {
        echo "✗ Error adding google_id: " . $conn->error . "\n";
    }
} else {
    echo "✓ Column google_id already exists\n";
}

// Verify all columns now exist
echo "\n=== Final Check ===\n";
$result = $conn->query('DESCRIBE users');
$cols = [];
while ($row = $result->fetch_assoc()) {
    $cols[] = $row['Field'];
}
echo "Users table columns: " . implode(', ', $cols) . "\n";
?>
