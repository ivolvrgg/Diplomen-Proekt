<?php
require_once 'config/db.php';

echo "<h2>Database Column Verification</h2>";

// Check if google_id column exists
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");

if ($result && $result->num_rows > 0) {
    echo "<p style='color: green;'><strong>✓ google_id column EXISTS</strong></p>";
    $column = $result->fetch_assoc();
    echo "<pre>";
    print_r($column);
    echo "</pre>";
} else {
    echo "<p style='color: red;'><strong>✗ google_id column NOT FOUND</strong></p>";
    
    // Show all columns
    echo "<h3>Current users table columns:</h3>";
    $all_columns = $conn->query("SHOW COLUMNS FROM users");
    if ($all_columns) {
        while ($col = $all_columns->fetch_assoc()) {
            echo "- " . $col['Field'] . " (" . $col['Type'] . ")" . ($col['Null'] === 'NO' ? ' NOT NULL' : '') . "<br>";
        }
    }
    
    echo "<h3>To fix this, run:</h3>";
    echo "<pre>ALTER TABLE users ADD COLUMN google_id VARCHAR(255) DEFAULT NULL UNIQUE;</pre>";
}

// Test a simple query
echo "<h3>Test Query Result:</h3>";
$test = $conn->query("SELECT id, email, google_id FROM users LIMIT 1");
if ($test) {
    echo "<p style='color: green;'>Query executed successfully</p>";
} else {
    echo "<p style='color: red;'>Query failed: " . $conn->error . "</p>";
}
?>
