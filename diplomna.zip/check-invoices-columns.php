<?php
require_once 'config/db.php';

echo "Checking invoices table structure:\n";
$result = $conn->query('DESCRIBE invoices');
while($row = $result->fetch_assoc()) {
    echo $row['Field'] . ' - ' . $row['Type'] . "\n";
}
?>
