# How to Load Speedy and Econt Offices

## Quick Start (2 Steps)

### Step 1: Load Offices into Database
Visit this URL in your browser:
```
http://localhost/load-offices.php
```

This will:
- Check if offices are already loaded
- Load all Speedy offices (300+) 
- Load all Econt offices (200+)
- Show you the results

### Step 2: Go to Payment Page
Visit:
```
http://localhost/payment.php
```

You should now see:
- Speedy offices with full address (city + street)
- Econt offices with full address (city + street)
- Office selector dropdown that filters by city/street
- Selected office info displayed below dropdown

---

## What Happens

When you visit `http://localhost/load-offices.php`:

1. **Check Current Status**
   - Shows how many offices are in database
   - Shows breakdown: Speedy count, Econt count

2. **Load if Empty**
   - If no offices, automatically runs migration
   - Loads 300+ Speedy offices with addresses
   - Loads 200+ Econt offices with addresses
   - Displays confirmation message

3. **Show Results**
   - Displays sample offices
   - Shows office ID, name, city, street

---

## On Payment Page

### Speedy Section
- Radio button "Speedy" 
- Click to expand office dropdown
- All offices with address (city - street)
- Type to search by city or street
- Click to select office
- **Selected office address** displays below dropdown

### Econt Section  
- Radio button "econt"
- Click to expand office dropdown
- All offices with address (city - street)
- Type to search by city or street
- Click to select office
- **Selected office address** displays below dropdown

---

## What Addresses You Get

### From Database
All offices come with:
- **Office Name** (e.g., "Speedy - Sofia Center")
- **City** (e.g., "София")
- **Street Address** (e.g., "ул. ВИТОША 10")

### Display Format
```
Office Name
City - Street Address
```

Example:
```
Speedy - Sofia Center
София - ул. ВИТОША 10
```

---

## Database Details

**Table**: `delivery_offices`

**Columns**:
- `id` - Unique office ID
- `delivery_method_id` - 2=Speedy, 3=Econt
- `label` - Office name
- `city` - City name
- `street` - Street address
- `phone` - Phone number (if available)
- `working_hours` - Hours (if available)
- `is_active` - 1=active, 0=inactive

**Total Records**:
- 300+ Speedy offices
- 200+ Econt offices
- 1 Courier (home delivery)

---

## Troubleshooting

**Q: Offices not showing on payment page?**
A: Did you run load-offices.php? Visit `http://localhost/load-offices.php` first.

**Q: Getting database error?**
A: Check database connection in `.env` file
```env
DB_HOST=localhost
DB_PORT=3307
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=dron_db
```

**Q: Want to reload offices?**
A: Just visit `http://localhost/load-offices.php` again - it will overwrite old data.

**Q: Where do the addresses come from?**
A: From the migration file: `sql/migration_update_speedy_ekont.sql`

---

## What's Inside load-offices.php

```php
1. Connects to database
2. Checks current office count
3. If empty, loads data from migration file
4. Shows you the results
5. Lists sample offices
```

The file is safe to run multiple times - it won't hurt anything.

---

## Next Steps

Once offices are loaded:

1. **Test the payment form**
   - Select Speedy or Econt
   - Search for offices
   - Select an office
   - Verify address displays

2. **Process an order**
   - Add products to cart
   - Go to checkout
   - Select delivery method + office
   - Complete payment

3. **Check the database**
   - Verify order was saved with selected office ID
   - Check `orders` table for `external_shipment_id`

---

## Database Queries

If you want to check offices in database:

```sql
-- Count offices by method
SELECT 
  CASE WHEN delivery_method_id = 2 THEN 'Speedy' 
       WHEN delivery_method_id = 3 THEN 'Econt' 
       ELSE 'Other' END as method,
  COUNT(*) as count
FROM delivery_offices
GROUP BY delivery_method_id;

-- Show Speedy offices in Sofia
SELECT * FROM delivery_offices 
WHERE delivery_method_id = 2 
  AND city LIKE '%София%'
LIMIT 10;

-- Show Econt offices in Sofia  
SELECT * FROM delivery_offices 
WHERE delivery_method_id = 3 
  AND city LIKE '%София%'
LIMIT 10;
```

---

## Done! ✅

Your payment page now has:
- ✅ 300+ Speedy offices with full addresses
- ✅ 200+ Econt offices with full addresses
- ✅ Searchable office dropdown
- ✅ Address display when office selected
- ✅ Integration with your payment flow

**Next**: Go to `http://localhost/payment.php` and test it out!

---

**Questions?** Check the payment.php source code or see ECONT_INTEGRATION_GUIDE.md and SPEEDY_REST_API_REFERENCE.md for more details.
