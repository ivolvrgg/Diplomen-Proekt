<?php
/**
 * Load Speedy and Econt Offices into Database
 * Run this once to populate all office addresses
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/db.php';

echo "<h2>Checking Office Database</h2>";

// Check current counts
$result = $conn->query("SELECT count(*) as total FROM delivery_offices");
$total = $result->fetch_assoc()['total'];
echo "<p>Total offices in database: <strong>$total</strong></p>";

$speedy_count = $conn->query("SELECT count(*) as total FROM delivery_offices WHERE delivery_method_id = 2")->fetch_assoc()['total'];
echo "<p>Speedy offices: <strong>$speedy_count</strong></p>";

$econt_count = $conn->query("SELECT count(*) as total FROM delivery_offices WHERE delivery_method_id = 3")->fetch_assoc()['total'];
echo "<p>Econt offices: <strong>$econt_count</strong></p>";

// Always run migration to ensure fresh data
echo "<h3>Loading offices from migration file...</h3>";

// Read and execute migration file
$migration_file = __DIR__ . '/sql/migration_update_speedy_ekont.sql';

if (file_exists($migration_file)) {
    // Disable foreign key checks to allow deletion
    $conn->query("SET FOREIGN_KEY_CHECKS=0");
    
    $sql = file_get_contents($migration_file);
    
    // Remove SQL comments completely (lines starting with --)
    $lines = explode("\n", $sql);
    $cleaned_lines = array();
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        // Skip empty lines and comment lines
        if (!empty($trimmed) && !preg_match('/^--/', $trimmed)) {
            $cleaned_lines[] = $line;
        }
    }
    
    $cleaned_sql = implode("\n", $cleaned_lines);
    
    // Split by semicolon and execute each statement
    $statements = array_filter(array_map('trim', explode(';', $cleaned_sql)), function($s) {
        return !empty($s);
    });
    
    $executed = 0;
    $errors = 0;
    
    foreach ($statements as $statement) {
        $trimmed = trim($statement);
        if (!empty($trimmed)) {
            if ($conn->query($trimmed)) {
                $executed++;
            } else {
                $errors++;
                echo "<p>❌ Error: " . $conn->error . "</p>";
            }
        }
    }
    
    // Re-enable foreign key checks
    $conn->query("SET FOREIGN_KEY_CHECKS=1");
    
    // Check again
    $speedy_count = $conn->query("SELECT count(*) as total FROM delivery_offices WHERE delivery_method_id = 2")->fetch_assoc()['total'];
    $econt_count = $conn->query("SELECT count(*) as total FROM delivery_offices WHERE delivery_method_id = 3")->fetch_assoc()['total'];
    
    echo "<h3>✅ Migration Complete!</h3>";
    echo "<p><strong>$executed</strong> SQL statements executed successfully</p>";
    if ($errors > 0) {
        echo "<p><strong>$errors</strong> errors encountered</p>";
    }
    echo "<p>Speedy offices loaded: <strong>$speedy_count</strong></p>";
    echo "<p>Econt offices loaded: <strong>$econt_count</strong></p>";
} else {
    echo "<p>❌ Migration file not found: $migration_file</p>";
}

// Show sample offices
echo "<h3>Sample Offices</h3>";
$sample = $conn->query("SELECT * FROM delivery_offices LIMIT 10");
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Method</th><th>Label</th><th>City</th><th>Street</th></tr>";
while ($row = $sample->fetch_assoc()) {
    $method = ($row['delivery_method_id'] == 2) ? 'Speedy' : (($row['delivery_method_id'] == 3) ? 'Econt' : 'Courier');
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $method . "</td>";
    echo "<td>" . htmlspecialchars($row['label']) . "</td>";
    echo "<td>" . htmlspecialchars($row['city']) . "</td>";
    echo "<td>" . htmlspecialchars($row['street']) . "</td>";
    echo "</tr>";
}
echo "</table>";

?>
