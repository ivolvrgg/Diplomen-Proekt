<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit;
    }

    $query = "SELECT id, user_id, email, phone, product_id, order_id, title, description, category, status, priority, response, created_at FROM complaints";
    
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $status = $conn->real_escape_string($_GET['status']);
        $query .= " WHERE status = '" . $status . "'";
    }
    
    $query .= " ORDER BY created_at DESC";
    
    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception('Query failed: ' . $conn->error);
    }
    
    $complaints = [];
    while ($row = $result->fetch_assoc()) {
        $complaints[] = $row;
    }
    
    echo json_encode(['success' => true, 'complaints' => $complaints]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
