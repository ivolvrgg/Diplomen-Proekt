<?php
header('Content-Type: application/json');
include '../config/db.php';

$response = array();

// Get all banners ordered by sort_order
$query = "SELECT * FROM banners ORDER BY sort_order ASC";
$result = $conn->query($query);

if ($result) {
    $banners = array();
    while ($banner = $result->fetch_assoc()) {
        $banners[] = $banner;
    }
    $response['success'] = true;
    $response['data'] = $banners;
} else {
    $response['success'] = false;
    $response['error'] = $conn->error;
}

echo json_encode($response);
$conn->close();
?>
