<?php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
ob_clean();
header('Content-Type: application/json; charset=utf-8');
include '../config/db.php';
include '../includes/auth_check.php';

// Initialize response
$response = ['success' => false, 'message' => '', 'order_id' => null];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Get request data
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }

    // Get user info
    $user_id = get_user_id();
    if ($user_id === 0) {
        // Guest user - use NULL for database
        $db_user_id = null;
        if (!isset($_SESSION['guest_id'])) {
            $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
        }
    } else {
        $db_user_id = $user_id;
    }

    // Validate required fields
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $payment_method = trim($data['payment_method'] ?? '');
    $delivery_method = trim($data['delivery_method'] ?? '');

    if (empty($email)) {
        throw new Exception('Имейл адресът е задължителен');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Неправилен формат на имейл адреса. Пример: example@gmail.com');
    }
    
    // Additional check for common test emails
    if (strpos($email, '@example.com') !== false || strpos($email, '@test.com') !== false) {
        throw new Exception('Моля, използвайте реален имейл адрес. @example.com и @test.com не са валидни.');
    }

    if (empty($phone)) {
        throw new Exception('Телефонният номер е задължителен');
    }

    // Basic phone validation (at least 10 digits)
    $phoneDigits = preg_replace('/\D/', '', $phone);
    if (strlen($phoneDigits) < 10) {
        throw new Exception('Неправилен телефонен номер. Моля, въведете валиден номер.');
    }

    if (!in_array($payment_method, ['card', 'cod'])) {
        throw new Exception('Неправилен начин на плащане');
    }

    if (!in_array($delivery_method, ['courier', 'speedy', 'econt'])) {
        throw new Exception('Неправилен начин на доставка');
    }

    // Get cart items
    $cart_items = [];
    $subtotal = 0;
    
    if ($db_user_id !== null) {
        // Logged-in user - get from database
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price, p.sale_price, p.discount_percent 
                       FROM cart c 
                       JOIN products p ON c.product_id = p.id 
                       WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);

        if (!$cart_result || $cart_result->num_rows === 0) {
            throw new Exception('Вашата количка е празна');
        }

        while ($item = $cart_result->fetch_assoc()) {
            // Use sale price if available, otherwise use regular price
            $actual_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price'];
            $item_total = $actual_price * $item['quantity'];
            $subtotal += $item_total;
            $item['actual_price'] = $actual_price;
            $cart_items[] = $item;
        }
    } else {
        // Guest user - get from request data
        $cart_data = $data['cart'] ?? [];
        if (empty($cart_data)) {
            throw new Exception('Вашата количка е празна');
        }

        // Validate and fetch product data for each item
        foreach ($cart_data as $item) {
            $product_id = intval($item['product_id'] ?? 0);
            $quantity = intval($item['quantity'] ?? 0);

            if ($product_id <= 0 || $quantity <= 0) {
                throw new Exception('Неправилен артикул в количката');
            }

            // Get product details
            $product_query = "SELECT id, name, price, sale_price, discount_percent FROM products WHERE id = $product_id";
            $product_result = $conn->query($product_query);

            if (!$product_result || $product_result->num_rows === 0) {
                throw new Exception('Продуктът не съществува');
            }

            $product = $product_result->fetch_assoc();
            // Use sale price if available, otherwise use regular price
            $actual_price = (!empty($product['sale_price']) && $product['sale_price'] > 0) ? $product['sale_price'] : $product['price'];
            $item_total = $actual_price * $quantity;
            $subtotal += $item_total;
            
            $cart_items[] = [
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'actual_price' => $actual_price
            ];
        }
    }

    // Map delivery method slug to database ID
    $delivery_mapping = [
        'courier' => 1,
        'speedy' => 2,
        'econt' => 3
    ];

    if (!isset($delivery_mapping[$delivery_method])) {
        throw new Exception('Неправилен начин на доставка');
    }

    $delivery_method_id = $delivery_mapping[$delivery_method];
    
    // FETCH delivery cost from database to ensure it matches the latest value
    $cost_stmt = $conn->prepare("SELECT cost FROM delivery_methods WHERE id = ? AND is_active = 1");
    $cost_stmt->bind_param("i", $delivery_method_id);
    $cost_stmt->execute();
    $cost_result = $cost_stmt->get_result();
    
    if ($cost_result->num_rows === 0) {
        throw new Exception('Неправилен начин на доставка');
    }
    
    $cost_row = $cost_result->fetch_assoc();
    $delivery_cost = floatval($cost_row['cost']);
    $cost_stmt->close();

    // Calculate order totals
    $vat = 0;
    $total = $subtotal + $delivery_cost;

    // Handle delivery address for courier method
    $shipping_address_id = null;
    $delivery_office_id = null;

    if ($delivery_method === 'courier') {
        // For courier, get address from request
        $city = trim($data['city'] ?? '');
        $street = trim($data['street'] ?? '');
        $block = trim($data['block'] ?? '');
        $entrance = trim($data['entrance'] ?? '');
        $apartment = trim($data['apartment'] ?? '');

        if (empty($city) || empty($street)) {
            throw new Exception('Адресът е задължителен за куриерска доставка');
        }

        // For guests or to store inline, we'll save delivery info in the order
        // The system should be updated to store address details directly in orders table
        // For now, we'll use null but the frontend should validate addresses are entered
    } else {
        // For office delivery, get office ID
        $delivery_office_id = intval($data['delivery_office_id'] ?? 0);
        if ($delivery_office_id <= 0) {
            throw new Exception('Офисът на доставка е задължителен');
        }

        // Verify office exists
        $office_check = $conn->query("SELECT id FROM delivery_offices WHERE id = $delivery_office_id AND is_active = 1");
        if (!$office_check || $office_check->num_rows === 0) {
            throw new Exception('Неправилен офис на доставка');
        }
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Set order status based on payment method
        // Card payment: pending_payment (waiting for payment)
        // Cash on delivery: pending (order confirmed, payment on delivery)
        $order_status = ($payment_method === 'card') ? 'pending_payment' : 'pending';
        
        // Insert order using prepared statement
        $insert_order = $conn->prepare("INSERT INTO orders (user_id, status, subtotal, delivery_cost, vat, total, payment_method, delivery_method_id, delivery_office_id, email, phone, created_at, updated_at) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        
        if (!$insert_order) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        $insert_order->bind_param("isdddssisss", $db_user_id, $order_status, $subtotal, $delivery_cost, $vat, $total, $payment_method, $delivery_method_id, $delivery_office_id, $email, $phone);
        
        if (!$insert_order->execute()) {
            throw new Exception('Failed to create order: ' . $conn->error);
        }
        $insert_order->close();

        $order_id = $conn->insert_id;

        // Insert order items
        $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
        
        if (!$item_stmt) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        error_log("DEBUG: Processing " . count($cart_items) . " cart items for order $order_id");
        
        foreach ($cart_items as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $unit_price = floatval($item['actual_price']);
            
            error_log("DEBUG: Item {$item['name']}: price=" . $item['price'] . ", sale_price=" . ($item['sale_price'] ?? 'NULL') . ", actual_price=" . $item['actual_price'] . ", using unit_price=$unit_price");

            $item_stmt->bind_param("iidi", $order_id, $product_id, $quantity, $unit_price);

            if (!$item_stmt->execute()) {
                throw new Exception('Failed to add order item: ' . $conn->error);
            }

            // Update product stock using prepared statement
            $stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
            if (!$stock_stmt) {
                throw new Exception('Prepare failed: ' . $conn->error);
            }
            $stock_stmt->bind_param("ii", $quantity, $product_id);
            if (!$stock_stmt->execute()) {
                throw new Exception('Failed to update stock: ' . $conn->error);
            }
            $stock_stmt->close();
        }
        $item_stmt->close();

        // Clear cart using prepared statement
        $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_stmt->bind_param("i", $db_user_id);
        if (!$clear_stmt->execute()) {
            throw new Exception('Failed to clear cart: ' . $conn->error);
        }
        $clear_stmt->close();

        // Clear session cart
        $_SESSION['cart'] = [];

        // Commit transaction
        $conn->commit();

        // Send order confirmation email
        try {
            require_once '../includes/EmailHelper.php';
            $emailer = new EmailHelper();
            
            // Get user name for email
            $user_name = $data['guest_name'] ?? 'Customer';
            if ($user_id !== 0) {
                // For logged-in users, get their full name from database
                $name_query = $conn->query("SELECT fullname FROM users WHERE id = $user_id");
                if ($name_query && $name_query->num_rows > 0) {
                    $user_data = $name_query->fetch_assoc();
                    $user_name = $user_data['fullname'];
                }
            }
            
            // Prepare order data for email
            $email_order_data = [
                'items' => $cart_items,
                'subtotal' => $subtotal,
                'vat' => $vat,
                'delivery_cost' => $delivery_cost,
                'total' => $total,
                'status' => $order_status,
                'phone' => $phone
            ];
            
            // Send and verify email was sent
            $email_sent = $emailer->sendOrderConfirmation($email, $user_name, $order_id, $email_order_data);
            if (!$email_sent) {
                error_log("WARNING: Order confirmation email failed for order #$order_id to $email");
            } else {
                error_log("INFO: Order confirmation email sent successfully for order #$order_id to $email");
            }
        } catch (Exception $e) {
            // Log email error but don't fail the order
            error_log('Failed to send order confirmation email for order #' . $order_id . ': ' . $e->getMessage());
        }

        $response['success'] = true;
        $response['message'] = 'Order created successfully';
        $response['order_id'] = $order_id;
        $response['total'] = $total;
        // Redirect to homepage for guests, profile for logged-in users
        $response['redirect_url'] = ($user_id === 0) ? '/Diplomna_rabota/homepage.php' : '/Diplomna_rabota/profile.php?tab=orders';

    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

ob_clean();
echo json_encode($response);
exit;
?>
