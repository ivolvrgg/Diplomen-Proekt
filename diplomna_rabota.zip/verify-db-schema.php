<?php
try {
    $pdo = new PDO('mysql:host=127.0.0.1;port=3307;dbname=dron_db', 'root', '', ['charset' => 'utf8mb4']);
    
    echo "<h2>Database Schema Verification</h2>";
    
    // Check users table structure
    $result = $pdo->query('DESCRIBE users');
    $columns = $result->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Users Table Columns:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    
    $has_google_id = false;
    $password_nullable = false;
    
    foreach ($columns as $col) {
        $null_status = $col['Null'] === 'YES' ? 'YES' : 'NO';
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
        echo "<td>" . $null_status . "</td>";
        echo "<td>" . htmlspecialchars($col['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
        
        if ($col['Field'] === 'google_id') {
            $has_google_id = true;
        }
        if ($col['Field'] === 'password_hash' && $col['Null'] === 'YES') {
            $password_nullable = true;
        }
    }
    
    echo "</table>";
    
    echo "<h3>Migration Status:</h3>";
    echo "<ul>";
    echo "<li>google_id column exists: " . ($has_google_id ? "✅ YES" : "❌ NO") . "</li>";
    echo "<li>password_hash is nullable: " . ($password_nullable ? "✅ YES" : "❌ NO") . "</li>";
    echo "</ul>";
    
    // Count existing Google logins
    echo "<h3>Current Data:</h3>";
    $count = $pdo->query("SELECT COUNT(*) as total FROM users")->fetch()['total'];
    echo "<p>Total users: " . $count . "</p>";
    
    if ($has_google_id) {
        $google_users = $pdo->query("SELECT COUNT(*) as total FROM users WHERE google_id IS NOT NULL")->fetch()['total'];
        echo "<p>Users with Google ID: " . $google_users . "</p>";
    }
    
} catch (Exception $e) {
    echo "<h2>Error</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
