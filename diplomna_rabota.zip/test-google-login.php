<?php
session_start();
require 'config/db.php';
require 'config/google.php';

echo "<h1>Google Login Test</h1>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";

// Check database
echo "<h2>Database Check</h2>";
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");
if ($result && $result->num_rows > 0) {
    echo "✓ google_id column exists<br>";
} else {
    echo "✗ google_id column MISSING<br>";
}

// Check config
echo "<h2>Google Config Check</h2>";
echo "Client ID: " . (strlen(GOOGLE_CLIENT_ID) > 0 ? "✓ Set" : "✗ Missing") . "<br>";
echo "Client Secret: " . (strlen(GOOGLE_CLIENT_SECRET) > 0 ? "✓ Set" : "✗ Missing") . "<br>";
echo "Redirect URI: " . GOOGLE_REDIRECT_URI . "<br>";

// Test auth URL
echo "<h2>Auth URL Test</h2>";
require 'includes/google_auth.php';
$auth_url = getGoogleAuthUrl();
echo "Generated URL length: " . strlen($auth_url) . " chars<br>";
echo "<a href='$auth_url' class='button'>Click to Test Google Login</a><br><br>";

// Check logs
echo "<h2>Recent Logs</h2>";
if (file_exists('logs/google-oauth.log')) {
    $lines = array_slice(file('logs/google-oauth.log'), -10);
    echo "<pre>";
    foreach ($lines as $line) {
        echo htmlspecialchars($line);
    }
    echo "</pre>";
} else {
    echo "No log file yet<br>";
}

?>
