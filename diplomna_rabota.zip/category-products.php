<?php
$page_css = 'css/category-products.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <?php
        // Check if this is a sales filter request
        $show_sales_only = isset($_GET['sale']) && $_GET['sale'] == 1;
        $discount_filter = isset($_GET['discount']) ? intval($_GET['discount']) : 0;
        
        // Get category ID from URL (single or multiple)
        $category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $category_ids = [];
        
        // Handle multiple category IDs
        if (isset($_GET['ids']) && !empty($_GET['ids'])) {
            $ids_input = $_GET['ids'];
            $category_ids = array_map('intval', array_filter(array_map('trim', explode(',', $ids_input))));
        } elseif ($category_id > 0) {
            $category_ids = [$category_id];
        }
        
        $valid_view = false;
        $category = null;
        
        if ($show_sales_only && $discount_filter > 0) {
            // Sales view
            $page_title = 'Продукти на Намаление - Dronche.BG';
            $valid_view = true;
        } elseif (!empty($category_ids)) {
            // Get category details - if single category
            if (count($category_ids) === 1) {
                $cat_query = "SELECT * FROM categories WHERE id = ?";
                $cat_stmt = $conn->prepare($cat_query);
                
                if ($cat_stmt) {
                    $cat_id = $category_ids[0];
                    $cat_stmt->bind_param("i", $cat_id);
                    $cat_stmt->execute();
                    $cat_result = $cat_stmt->get_result();
                    
                    if ($cat_result && $cat_result->num_rows > 0) {
                        $category = $cat_result->fetch_assoc();
                        $page_title = $category['name'] . ' - Dronche.BG';
                        $valid_view = true;
                    }
                    if (isset($cat_stmt)) $cat_stmt->close();
                }
            } else {
                // Multiple categories
                $page_title = 'Продукти - Dronche.BG';
                $valid_view = true;
            }
        }
        
        if ($valid_view):
        ?>
        
        <section class="category-header">
            <div class="container">
                <?php if ($show_sales_only && $discount_filter > 0): ?>
                    <h1 class="category-title">Продукти на Намаление</h1>
                <?php elseif (count($category_ids) === 1 && $category): ?>
                    <h1 class="category-title"><?php echo htmlspecialchars($category['name']); ?></h1>
                <?php else: ?>
                    <h1 class="category-title">Продукти</h1>
                <?php endif; ?>
            </div>
        </section>

        <section class="category-products">
            <div class="container">
                <div class="products-wrapper">
                    <!-- Filter Sidebar -->
                    <aside class="filters-sidebar">
                        <div class="filter-header">
                            <h3>Филтри</h3>
                            <button class="filter-toggle-mobile" id="filterToggleMobile">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>

                        <!-- Price Range Filter -->
                        <div class="filter-group">
                            <h4>Цена</h4>
                            <div class="price-filter">
                                <input type="range" min="0" max="5000" value="5000" class="price-slider" id="priceSlider">
                                <div class="price-display">
                                    <span>0 €</span> - <span id="priceValue">5000</span> €
                                </div>
                            </div>
                        </div>

                        <!-- Stock Filter -->
                        <div class="filter-group">
                            <h4>Наличност</h4>
                            <label class="filter-checkbox">
                                <input type="checkbox" value="inStock" class="stock-filter">
                                <span>Само на склад</span>
                            </label>
                        </div>

                        <!-- Sort Filter -->
                        <div class="filter-group">
                            <h4>Сортиране</h4>
                            <select id="sortSelect" class="sort-select">
                                <option value="name-asc">Име (А-Я)</option>
                                <option value="name-desc">Име (Я-А)</option>
                                <option value="price-asc">Цена (ниска-висока)</option>
                                <option value="price-desc">Цена (висока-ниска)</option>
                            </select>
                        </div>

                        <button class="filter-reset" id="resetFilters">Изчисти филтрите</button>
                    </aside>

                    <!-- Products Grid -->
                    <div class="products-section">
                        <div class="products-grid" id="productsGrid">
                    <?php
                    if ($show_sales_only && $discount_filter > 0) {
                        // Sales view - get all products on sale with specified discount
                        $products_query = "SELECT id, name, price, sale_price, image_1, stock FROM products 
                                         WHERE is_active = 1 
                                         AND sale_price > 0
                                         AND sale_price < price
                                         ORDER BY name ASC";
                        
                        $products_result = $conn->query($products_query);
                        
                        if ($products_result && $products_result->num_rows > 0) {
                            $filtered_products = array();
                            
                            while ($product = $products_result->fetch_assoc()) {
                                $discount_percent = round(((($product['price'] - $product['sale_price']) / $product['price']) * 100));
                                
                                if ($discount_percent <= $discount_filter) {
                                    $product['discount_percent'] = $discount_percent;
                                    $filtered_products[] = $product;
                                }
                            }
                            
                            if (count($filtered_products) > 0) {
                                foreach ($filtered_products as $product) {
                                    $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                        ?>
                        <div class="product-card" data-price="<?php echo ($product['sale_price'] && $product['sale_price'] > 0) ? $product['sale_price'] : $product['price']; ?>" data-stock="<?php echo $product['stock']; ?>" data-name="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="product-image-wrapper">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>">
                                    <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                                </a>
                            </div>
                            <div class="product-info">
                                <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">
                                    <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                        <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                        <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                    <?php } else { ?>
                                        <?php echo number_format($product['price'], 2); ?> €
                                    <?php } ?>
                                </p>
                                <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                    <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                                </p>
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                            </div>
                        </div>
                        <?php
                                }
                            } else {
                                echo "<p style='grid-column: 1/-1; text-align: center; padding: 40px 20px;'>Няма продукти на намаление до " . htmlspecialchars($discount_filter) . "%</p>";
                            }
                        } else {
                            echo "<p style='grid-column: 1/-1; text-align: center; padding: 40px 20px;'>Няма продукти на намаление</p>";
                        }
                    } else {
                        // Category view
                        if (count($category_ids) === 1) {
                            // Single category
                            $products_query = "SELECT * FROM products WHERE category_id = ? AND is_active = 1 ORDER BY name ASC";
                            $products_stmt = $conn->prepare($products_query);
                            
                            if ($products_stmt) {
                                $cat_id = $category_ids[0];
                                $products_stmt->bind_param("i", $cat_id);
                                $products_stmt->execute();
                                $products_result = $products_stmt->get_result();
                                
                                if ($products_result && $products_result->num_rows > 0) {
                                    while ($product = $products_result->fetch_assoc()) {
                                        $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                        ?>
                        <div class="product-card" data-price="<?php echo ($product['sale_price'] && $product['sale_price'] > 0) ? $product['sale_price'] : $product['price']; ?>" data-stock="<?php echo $product['stock']; ?>" data-name="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="product-image-wrapper">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>">
                                    <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                                </a>
                            </div>
                            <div class="product-info">
                                <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">
                                    <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                        <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                        <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                    <?php } else { ?>
                                        <?php echo number_format($product['price'], 2); ?> €
                                    <?php } ?>
                                </p>
                                <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                    <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                                </p>
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                            </div>
                        </div>
                        <?php
                                    }
                                } else {
                                    echo '<div class="empty-state"><p>Няма продукти в тази категория.</p></div>';
                                }
                                $products_stmt->close();
                            }
                        } else {
                            // Multiple categories - use IN clause
                            $ids_placeholder = implode(',', array_fill(0, count($category_ids), '?'));
                            $products_query = "SELECT * FROM products WHERE category_id IN ($ids_placeholder) AND is_active = 1 ORDER BY name ASC";
                            $products_stmt = $conn->prepare($products_query);
                            
                            if ($products_stmt) {
                                $types = str_repeat('i', count($category_ids));
                                $products_stmt->bind_param($types, ...$category_ids);
                                $products_stmt->execute();
                                $products_result = $products_stmt->get_result();
                                
                                if ($products_result && $products_result->num_rows > 0) {
                                    while ($product = $products_result->fetch_assoc()) {
                                        $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                        ?>
                        <div class="product-card" data-price="<?php echo ($product['sale_price'] && $product['sale_price'] > 0) ? $product['sale_price'] : $product['price']; ?>" data-stock="<?php echo $product['stock']; ?>" data-name="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="product-image-wrapper">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>">
                                    <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                                </a>
                            </div>
                            <div class="product-info">
                                <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">
                                    <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                        <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                        <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                    <?php } else { ?>
                                        <?php echo number_format($product['price'], 2); ?> €
                                    <?php } ?>
                                </p>
                                <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                    <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                                </p>
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                            </div>
                        </div>
                        <?php
                                    }
                                } else {
                                    echo '<div class="empty-state"><p>Няма продукти в избраните категории.</p></div>';
                                }
                                $products_stmt->close();
                            }
                        }
                    }
                    ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
        else:
            echo '<div class="container"><p>Невалидна страница или категория не намерена.</p></div>';
        endif;
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
    <script src="filters.js"></script>
</body>
</html>