<?php
/**
 * Fetch REAL Econt Offices from API
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/db.php';

// Load env variables
$econt_username = getenv('ECONT_USERNAME');
$econt_password = getenv('ECONT_PASSWORD');
$econt_client_id = getenv('ECONT_CLIENT_SYSTEM_ID');

echo "<h2>Fetching Real Econt Offices from API</h2>";
echo "<p>Username: " . htmlspecialchars($econt_username) . "</p>";
echo "<p>Client ID: " . htmlspecialchars($econt_client_id) . "</p>";

// Disable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS=0");

// Clear old Econt offices
$conn->query("DELETE FROM delivery_offices WHERE delivery_method_id = 3");

echo "<p>✓ Cleared old Econt offices</p>";

// ============ ECONT API ============
echo "<h3>Fetching from Econt API...</h3>";

$auth = base64_encode($econt_username . ':' . $econt_password);

// Try multiple Econt endpoints
$endpoints = [
    'https://api.econt.com/v1/offices',
    'https://api.econt.com/offices',
    'https://econt.com/api/v1/offices'
];

$econt_response = false;
$endpoint_used = '';

foreach ($endpoints as $url) {
    echo "<p>Trying: " . htmlspecialchars($url) . "</p>";
    
    $options = [
        'http' => [
            'method' => 'GET',
            'header' => "Authorization: Basic " . $auth . "\r\nContent-Type: application/json\r\n",
            'timeout' => 10
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ];
    
    $context = stream_context_create($options);
    
    try {
        $response = @file_get_contents($url, false, $context);
        
        if ($response !== false) {
            $econt_response = $response;
            $endpoint_used = $url;
            echo "<p style='color:green'>✓ Connected to: " . htmlspecialchars($url) . "</p>";
            break;
        }
    } catch (Exception $e) {
        // Continue to next endpoint
    }
}

if ($econt_response === false) {
    echo "<p style='color:red'>❌ Could not connect to any Econt API endpoint.</p>";
    echo "<p style='color:orange'><strong>Possible issues:</strong></p>";
    echo "<ul>";
    echo "<li>API credentials are incorrect</li>";
    echo "<li>Your account doesn't have API access enabled</li>";
    echo "<li>Contact Econt support: support@econt.com</li>";
    echo "</ul>";
} else {
    echo "<p>Response received (length: " . strlen($econt_response) . " bytes)</p>";
    
    $econt_data = json_decode($econt_response, true);
    
    if ($econt_data === null) {
        echo "<p style='color:red'>❌ Invalid JSON response from API</p>";
        echo "<pre style='background:#f0f0f0; padding:10px; max-height:200px; overflow:auto;'>";
        echo htmlspecialchars(substr($econt_response, 0, 500));
        echo "</pre>";
    } else {
        echo "<p>✓ Valid JSON response received</p>";
        
        // Try different data structures
        $offices = [];
        
        if (isset($econt_data['offices']) && is_array($econt_data['offices'])) {
            $offices = $econt_data['offices'];
            echo "<p>Found data in 'offices' key</p>";
        } elseif (isset($econt_data['data']) && is_array($econt_data['data'])) {
            $offices = $econt_data['data'];
            echo "<p>Found data in 'data' key</p>";
        } elseif (is_array($econt_data) && count($econt_data) > 0 && isset($econt_data[0]['address'])) {
            $offices = $econt_data;
            echo "<p>Found data as array of offices</p>";
        } else {
            echo "<p style='color:orange'>⚠️ Could not find offices in response</p>";
            echo "<pre style='background:#f0f0f0; padding:10px; max-height:200px; overflow:auto;'>";
            echo htmlspecialchars(json_encode($econt_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            echo "</pre>";
        }
        
        if (count($offices) > 0) {
            echo "<p>Processing " . count($offices) . " offices...</p>";
            
            $success_count = 0;
            $error_count = 0;
            
            foreach ($offices as $office) {
                // Handle different possible field names
                $name = $office['name'] 
                    ?? $office['Name'] 
                    ?? $office['officeName'] 
                    ?? $office['label'] 
                    ?? 'Econt Office';
                
                $city = $office['city'] 
                    ?? $office['City'] 
                    ?? $office['cityName'] 
                    ?? 'Unknown';
                
                $address = $office['address'] 
                    ?? $office['Address'] 
                    ?? $office['street'] 
                    ?? '';
                
                // Clean up data
                $label = 'Econt - ' . trim($name);
                $city = trim($city);
                $street = trim($address);
                
                // Only insert if we have at least city and street
                if (!empty($city) && !empty($street)) {
                    $sql = "INSERT INTO delivery_offices (delivery_method_id, label, city, street, is_active) 
                            VALUES (3, ?, ?, ?, 1)";
                    
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("sss", $label, $city, $street);
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                        $stmt->close();
                    }
                }
            }
            
            echo "<p style='color:green'>✅ Successfully inserted: <strong>$success_count</strong> offices</p>";
            if ($error_count > 0) {
                echo "<p style='color:orange'>⚠️ Failed inserts: <strong>$error_count</strong></p>";
            }
        }
    }
}

// Re-enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS=1");

// Show final count
$econt_count = $conn->query("SELECT COUNT(*) as c FROM delivery_offices WHERE delivery_method_id = 3")->fetch_assoc()['c'];

echo "<h3 style='margin-top: 2rem;'>Final Result</h3>";
echo "<p><strong>Econt offices in database:</strong> $econt_count</p>";

if ($econt_count > 0) {
    echo "<h3>Sample Offices</h3>";
    $sample = $conn->query("SELECT * FROM delivery_offices WHERE delivery_method_id = 3 LIMIT 10");
    echo "<table border='1' cellpadding='10' style='width:100%;'>";
    echo "<tr><th>ID</th><th>Label</th><th>City</th><th>Street</th></tr>";
    while ($row = $sample->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['label']) . "</td>";
        echo "<td>" . htmlspecialchars($row['city']) . "</td>";
        echo "<td>" . htmlspecialchars($row['street']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

echo "<hr>";
echo "<p style='margin-top: 2rem;'><a href='payment.php' style='padding:10px 20px; background:#588157; color:white; text-decoration:none; border-radius:5px;'>Go to Payment Page →</a></p>";
?>
