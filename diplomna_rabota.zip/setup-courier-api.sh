#!/bin/bash
# Speedy & Econt API Integration Setup Script
# Run this to set up the courier integration

echo "==========================================="
echo "Speedy & Econt API Integration Setup"
echo "==========================================="
echo ""

# Check if MySQL is available
if ! command -v mysql &> /dev/null; then
    echo "ERROR: MySQL is not installed or not in PATH"
    exit 1
fi

# Define database credentials
DB_HOST="localhost"
DB_USER="root"
DB_PASS=""
DB_NAME="dron_db"
DB_PORT="3307"

echo "Setting up database..."
echo "- Host: $DB_HOST:$DB_PORT"
echo "- Database: $DB_NAME"
echo ""

# 1. Run migration for delivery setup
echo "[1/3] Running courier setup migration..."
mysql -h $DB_HOST -u $DB_USER -P $DB_PORT $DB_NAME < sql/migration_courier_setup.sql
if [ $? -eq 0 ]; then
    echo "✓ Courier setup migration completed"
else
    echo "✗ Error running courier setup migration"
    exit 1
fi
echo ""

# 2. Run migration for Speedy and Econt offices
echo "[2/3] Loading Speedy and Econt office locations..."
mysql -h $DB_HOST -u $DB_USER -P $DB_PORT $DB_NAME < sql/migration_update_speedy_ekont.sql
if [ $? -eq 0 ]; then
    echo "✓ Office locations loaded successfully"
else
    echo "✗ Error loading office locations"
    exit 1
fi
echo ""

# 3. Check .env file
echo "[3/3] Checking configuration..."
if [ ! -f .env ]; then
    echo "⚠ .env file not found. Creating..."
    cp .env.example .env 2>/dev/null || echo "# Copy your .env settings here" > .env
fi

if grep -q "SPEEDY_USERNAME" .env; then
    echo "✓ Configuration file exists"
else
    echo "⚠ Add your courier credentials to .env:"
    echo "  - SPEEDY_USERNAME"
    echo "  - SPEEDY_PASSWORD"
    echo "  - SPEEDY_CUSTOMER_CODE"
    echo "  - ECONT_USERNAME"
    echo "  - ECONT_PASSWORD"
    echo "  - ECONT_CLIENT_SYSTEM_ID"
fi
echo ""

echo "==========================================="
echo "Setup Complete!"
echo "==========================================="
echo ""
echo "Next steps:"
echo "1. Update .env with your courier credentials"
echo "2. Test APIs:"
echo "   curl 'http://localhost/api/get_delivery_offices.php?method=speedy&city=Sofia'"
echo "3. Check logs in: logs/courier_*.log"
echo ""
