<?php
require_once 'config/db.php';

echo "<!DOCTYPE html>";
echo "<html><head><title>Password Recovery Migration</title></head><body>";
echo "<h2>Running Password Recovery Migration...</h2>";

try {
    // Add password recovery columns to users table
    $queries = [
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_code VARCHAR(255) NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_code_expires DATETIME NULL"
    ];
    
    foreach ($queries as $query) {
        echo "<p>Executing: <code>$query</code></p>";
        if ($conn->query($query) === TRUE) {
            echo "<p style='color: green;'>✓ Success</p>";
        } else {
            if (strpos($conn->error, 'already exists') !== false) {
                echo "<p style='color: orange;'>⚠ Column already exists (skipped)</p>";
            } else {
                echo "<p style='color: red;'>✗ Error: " . $conn->error . "</p>";
                throw new Exception($conn->error);
            }
        }
    }
    
    echo "<h3 style='color: green;'>✓ Password Recovery Database Migration Completed Successfully!</h3>";
    echo "<p>Next steps:</p>";
    echo "<ol>";
    echo "<li>Test password recovery on <a href='user_login.php'>Login Page</a></li>";
    echo "<li>Click 'Забравена парола?' (Forgot Password)</li>";
    echo "<li>Check your email for verification code</li>";
    echo "</ol>";
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>✗ Migration Failed</h3>";
    echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</body></html>";
?>
