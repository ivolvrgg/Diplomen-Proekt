<!DOCTYPE html>
<html>
<head>
    <title>Password Recovery Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { color: #042940; }
        h2 { color: #333; margin-top: 25px; }
        .step {
            background: #f9f9f9;
            padding: 15px;
            border-left: 4px solid #042940;
            margin: 15px 0;
        }
        .code-block {
            background: #333;
            color: #0f0;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            overflow-x: auto;
            margin: 10px 0;
        }
        .success { color: green; }
        .error { color: red; }
        .warning { color: #ff6600; }
        button {
            background: #042940;
            color: #DBF227;
            border: 2px solid #DBF227;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #DBF227;
            color: #042940;
        }
        .note {
            background: #fffbea;
            border: 1px solid #ffe4a8;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Password Recovery System Setup</h1>
        
        <h2>Step 1: Install PHPMailer via Composer</h2>
        <div class="step">
            <p>Run this command in your project directory:</p>
            <div class="code-block">composer install</div>
            <p class="warning">⚠️ If you get SSL certificate errors, you may need to run:</p>
            <div class="code-block">composer install --no-verify-ssl</div>
        </div>
        
        <h2>Step 2: Configure Email Settings</h2>
        <div class="step">
            <p>Edit <code>config/mail.php</code> and add your email credentials.</p>
            
            <h3>Option A: Gmail (Recommended)</h3>
            <ol>
                <li>Go to <a href="https://myaccount.google.com/apppasswords" target="_blank">Google App Passwords</a></li>
                <li>Create an App Password for Mail</li>
                <li>Copy that password and update config/mail.php:</li>
            </ol>
            <div class="code-block">
'username' => 'your-email@gmail.com',<br>
'password' => 'your-app-password-here',<br>
'from_email' => 'your-email@gmail.com',
            </div>
            
            <h3>Option B: SendGrid</h3>
            <div class="code-block">
'host' => 'smtp.sendgrid.net',<br>
'port' => 587,<br>
'username' => 'apikey',<br>
'password' => 'your-sendgrid-api-key',
            </div>
            
            <h3>Option C: Mailtrap (Testing)</h3>
            <div class="code-block">
'host' => 'live.smtp.mailtrap.io',<br>
'port' => 587,<br>
'username' => 'your-mailtrap-username',<br>
'password' => 'your-mailtrap-password',
            </div>
        </div>
        
        <h2>Step 3: Run Database Migration</h2>
        <div class="step">
            <p>Add the password recovery columns to the users table:</p>
            <a href="run-password-recovery-migration.php" style="color: #042940; text-decoration: none;">
                <button>▶️ Run Migration Now</button>
            </a>
        </div>
        
        <h2>Step 4: Test the System</h2>
        <div class="step">
            <ol>
                <li>Go to <a href="user_login.php">Login Page</a></li>
                <li>Click "Забравена парола?" (Forgot Password)</li>
                <li>Enter your email address</li>
                <li>Check your email for the verification code</li>
                <li>Enter the code and your new password</li>
            </ol>
            
            <div class="note">
                <strong>Note:</strong> If you're testing locally with Mailtrap or local mail server, 
                you can see the email in the Mailtrap inbox without receiving it on your actual email.
            </div>
        </div>
        
        <h2>Troubleshooting</h2>
        <div class="step">
            <h3>Email not sending?</h3>
            <ul>
                <li>Check <code>logs/email-errors.log</code> for error messages</li>
                <li>Verify credentials in <code>config/mail.php</code></li>
                <li>If using Gmail, ensure App Password is correct (not regular password)</li>
                <li>Ensure 2FA is enabled on Gmail account</li>
            </ul>
            
            <h3>Composer install fails?</h3>
            <ul>
                <li>Try: <code>composer install --no-verify-ssl</code></li>
                <li>Or use a different PHP version</li>
                <li>Or download PHPMailer manually</li>
            </ul>
        </div>
        
        <h2>Files Created/Modified</h2>
        <div class="step">
            <ul>
                <li>✅ <code>config/mail.php</code> - Email configuration</li>
                <li>✅ <code>includes/EmailHelper.php</code> - Email sending class</li>
                <li>✅ <code>api/password-recovery.php</code> - API for handling recovery</li>
                <li>✅ <code>password-recovery.php</code> - Recovery request page</li>
                <li>✅ <code>password-reset.php</code> - Reset password page</li>
                <li>✅ <code>run-password-recovery-migration.php</code> - Database migration</li>
                <li>✅ <code>user_login.php</code> - Added "Forgot Password" link</li>
                <li>✅ <code>css/user_login.css</code> - Styling for recovery flow</li>
                <li>✅ <code>composer.json</code> - Added PHPMailer dependency</li>
            </ul>
        </div>
    </div>
</body>
</html>
