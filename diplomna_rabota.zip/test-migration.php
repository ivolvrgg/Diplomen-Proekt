<?php
require_once 'config/db.php';

// Run migration
$queries = [
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_code VARCHAR(255) NULL",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_code_expires DATETIME NULL"
];

echo "Running migrations...\n";
foreach ($queries as $q) {
    if ($conn->query($q) === TRUE) {
        echo "✓ $q\n";
    } else {
        echo "✗ ERROR: " . $conn->error . "\n";
    }
}

echo "\nChecking columns:\n";
$result = $conn->query("DESCRIBE users");
while ($row = $result->fetch_assoc()) {
    if (in_array($row['Field'], ['reset_code', 'reset_code_expires'])) {
        echo "✓ " . $row['Field'] . " - " . $row['Type'] . "\n";
    }
}

echo "\nDone!\n";
?>
