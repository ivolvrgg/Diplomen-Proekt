<?php
// Test the OAuth flow step by step
session_start();

echo "<h2>Google OAuth Setup Test</h2>";

try {
    require_once 'config/db.php';
    require_once 'config/google.php';
    
    echo "<h3>1. Configuration Check:</h3>";
    echo "<ul>";
    echo "<li>GOOGLE_CLIENT_ID: " . (defined('GOOGLE_CLIENT_ID') && GOOGLE_CLIENT_ID ? "✅ Set" : "❌ Not set") . "</li>";
    echo "<li>GOOGLE_CLIENT_SECRET: " . (defined('GOOGLE_CLIENT_SECRET') && GOOGLE_CLIENT_SECRET ? "✅ Set" : "❌ Not set") . "</li>";
    echo "<li>GOOGLE_REDIRECT_URI: " . (defined('GOOGLE_REDIRECT_URI') ? "✅ " . htmlspecialchars(GOOGLE_REDIRECT_URI) : "❌ Not set") . "</li>";
    echo "</ul>";
    
    echo "<h3>2. Database Check:</h3>";
    $result = $conn->query('DESCRIBE users');
    
    $has_google_id = false;
    while ($col = $result->fetch_assoc()) {
        if ($col['Field'] === 'google_id') {
            $has_google_id = true;
        }
    }
    
    echo "<p>google_id column exists: " . ($has_google_id ? "✅ YES" : "❌ NO") . "</p>";
    
    if ($has_google_id) {
        echo "<h3>3. File Check:</h3>";
        $files = [
            'google-callback.php' => __DIR__ . '/google-callback.php',
            'includes/google_auth.php' => __DIR__ . '/includes/google_auth.php',
            'user_login.php' => __DIR__ . '/user_login.php',
            'user_register.php' => __DIR__ . '/user_register.php'
        ];
        
        foreach ($files as $name => $path) {
            $exists = file_exists($path);
            echo "<p>$name: " . ($exists ? "✅ Exists" : "❌ Missing") . "</p>";
        }
        
        echo "<h3>4. Login Pages Check:</h3>";
        $login_content = file_get_contents(__DIR__ . '/user_login.php');
        $register_content = file_get_contents(__DIR__ . '/user_register.php');
        
        echo "<p>Login page has Google button: " . (strpos($login_content, 'getGoogleAuthUrl') !== false ? "✅ YES" : "❌ NO") . "</p>";
        echo "<p>Register page has Google button: " . (strpos($register_content, 'getGoogleAuthUrl') !== false ? "✅ YES" : "❌ NO") . "</p>";
        
        echo "<h3>5. Authorization URL:</h3>";
        require_once 'includes/google_auth.php';
        $auth_url = getGoogleAuthUrl();
        echo "<p>Generated URL looks valid: " . (strpos($auth_url, 'https://accounts.google.com') === 0 ? "✅ YES" : "❌ NO") . "</p>";
        
        echo "<h3>✅ SETUP COMPLETE</h3>";
        echo "<p>Everything is configured correctly. You can now test login/registration:</p>";
        echo "<ol>";
        echo "<li>Go to <a href='user_login.php'>Login Page</a></li>";
        echo "<li>Click 'Sign in with Google'</li>";
        echo "<li>Approve access when prompted</li>";
        echo "</ol>";
    } else {
        echo "<h3>❌ Setup Not Complete</h3>";
        echo "<p>The google_id column is missing from the users table.</p>";
        echo "<p>Run the migration: <a href='run-google-migration.php'>run-google-migration.php</a></p>";
    }
    
} catch (Exception $e) {
    echo "<h3>❌ Error</h3>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
?>
