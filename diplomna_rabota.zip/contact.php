<?php
$pageTitle = "Контакти";
include 'includes/head.php';
include 'config/db.php';

$successMessage = '';
$errorMessage = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    // Validate required fields
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $errorMessage = "Моля, попълнете всички задължителни полета.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Моля, въведете валиден имейл адрес.";
    } else {
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $phone, $subject, $message);
        
        if ($stmt->execute()) {
            $successMessage = "Благодарим ви! Вашето съобщение беше изпратено успешно. Ще се свържем с вас скоро.";
            
            // Send confirmation email to user
            try {
                require_once 'includes/EmailHelper.php';
                $emailer = new EmailHelper();
                $emailer->sendContactResponse($email, $name, $message);
            } catch (Exception $e) {
                // Log email error but don't interrupt the success message
                error_log('Contact form confirmation email failed: ' . $e->getMessage());
            }
            
            // Clear form
            $name = $email = $phone = $subject = $message = '';
        } else {
            $errorMessage = "Възникна грешка при изпращането на съобщението. Моля, опитайте отново.";
        }
        $stmt->close();
    }
}
?>
<?php include 'includes/navbar_selector.php'; ?>

<div class="contact-section">
    <div class="contact-hero">
        <h1>Свържете се с нас</h1>
        <p>Ние сме тук за да помогнем</p>
    </div>

    <div class="contact-content">
        <div class="contact-container">
            <div class="contact-info">
                <div class="contact-block">
                    <div class="contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h3>Адрес</h3>
                    <p>България, Варна</p>
                </div>

                <div class="contact-block">
                    <div class="contact-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h3>Телефон</h3>
                    <p><a href="tel:+359884597448">+359 884 597 448</a></p>
                </div>

                <div class="contact-block">
                    <div class="contact-icon">
                        <i class="far fa-envelope"></i>
                    </div>
                    <h3>Email</h3>
                    <p><a href="mailto:dronchebg@gmail.com">dronchebg@gmail.com</a></p>
                </div>

                <div class="contact-block">
                    <div class="contact-icon">
                        <i class="far fa-clock"></i>
                    </div>
                    <h3>Работно време</h3>
                    <p>
                        Пн - Пт: 09:00 - 18:00<br>
                        Сб - Нд: Затворено
                    </p>
                </div>
            </div>

            <div class="contact-form-wrapper">
                <h2>Изпратете ни съобщение</h2>
                
                <?php if ($successMessage): ?>
                <div class="alert alert-success" style="background-color: #d4edda; border-color: #c3e6cb; color: #155724; padding: 12px; border-radius: 4px; margin-bottom: 20px;">
                    <?php echo htmlspecialchars($successMessage); ?>
                </div>
                <?php endif; ?>
                
                <?php if ($errorMessage): ?>
                <div class="alert alert-error" style="background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; padding: 12px; border-radius: 4px; margin-bottom: 20px;">
                    <?php echo htmlspecialchars($errorMessage); ?>
                </div>
                <?php endif; ?>
                
                <form class="contact-form" action="contact.php" method="POST">
                    <div class="form-group">
                        <label for="name">Име *</label>
                        <input type="text" id="name" name="name" required placeholder="Вашето име" value="<?php echo htmlspecialchars($name ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" required placeholder="Вашия email" value="<?php echo htmlspecialchars($email ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" placeholder="Вашия телефон" value="<?php echo htmlspecialchars($phone ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="subject">Тема *</label>
                        <input type="text" id="subject" name="subject" required placeholder="Тема на съобщението" value="<?php echo htmlspecialchars($subject ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="message">Съобщение *</label>
                        <textarea id="message" name="message" required rows="6" placeholder="Вашето съобщение"><?php echo htmlspecialchars($message ?? ''); ?></textarea>
                    </div>

                    <button type="submit" class="contact-btn">Изпрати съобщение</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .contact-section {
        background-color: #f5f5f5;
        padding: 0 0 60px 0;
        min-height: 100vh;
    }

    .contact-hero {
        background-color:#005C53;
        color: white;
        padding: 80px 20px;
        text-align: center;
        margin-bottom: 40px;
    }

    .contact-hero h1 {
        font-size: 48px;
        margin: 0 0 10px 0;
        font-weight: bold;
    }

    .contact-hero p {
        font-size: 20px;
        color: #DBF227;
        margin: 0;
    }

    .contact-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px 60px;
    }

    .contact-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
    }

    .contact-info {
        display: grid;
        grid-template-columns: 1fr;
        gap: 30px;
    }

    .contact-block {
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: transform 0.3s ease;
    }

    .contact-block:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .contact-icon {
        font-size: 40px;
        color: #DBF227;
        margin-bottom: 15px;
    }

    .contact-block h3 {
        color: #344e41;
        margin: 0 0 10px 0;
        font-size: 20px;
    }

    .contact-block p {
        color: #666;
        margin: 0;
        line-height: 1.6;
    }

    .contact-block a {
        color: #DBF227;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .contact-block a:hover {
        color: #344e41;
    }

    .contact-form-wrapper {
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .contact-form-wrapper h2 {
        color: #344e41;
        margin-top: 0;
        margin-bottom: 25px;
        font-size: 28px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        color: #005C53;
        font-weight: 600;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;
        padding: 12px;
        border: 2px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        font-family: inherit;
        transition: border-color 0.3s ease;
    }

    .form-group textarea {
        resize: vertical;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        outline: none;
        border-color: #9fc1315a;
        box-shadow: 0 0 0 3px rgba(219, 242, 39, 0.1);
    }

    .contact-btn {
        background-color: #005C53;
        color: white;
        padding: 12px 30px;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
    }

    .contact-btn:hover {
        background-color: #2a3f37;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    @media (max-width: 768px) {
        .contact-container {
            grid-template-columns: 1fr;
        }

        .contact-hero h1 {
            font-size: 36px;
        }

        .contact-hero p {
            font-size: 16px;
        }

        .contact-info {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 480px) {
        .contact-info {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>
</body>
</html>
