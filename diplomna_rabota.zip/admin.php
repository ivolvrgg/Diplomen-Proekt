<?php
session_start();
include 'includes/admin_check.php';
include 'config/db.php';
?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Административен панел - Управление на продукти</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #344e41;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-size: 28px;
        }
        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background-color: #c0392b;
        }
        .back-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
            margin-right: 10px;
        }
        .back-btn:hover {
            background-color: #2980b9;
        }
        .header-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .welcome {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .section {
            background-color: white;
            padding: 25px;
            border-radius: 5px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #e8e6df;
            border-radius: 4px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        select[multiple] {
            padding: 5px;
            min-height: 150px;
            background-color: white;
            cursor: pointer;
        }
        select[multiple] option {
            padding: 8px 5px;
            margin-bottom: 2px;
        }
        select[multiple] option:checked {
            background: linear-gradient(#3498db, #3498db);
            background-color: #3498db;
            color: white;
        }
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .form-row-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        button.delete-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 6px 10px;
            font-size: 11px;
            margin: 0;
            cursor: pointer;
            border-radius: 3px;
            transition: background-color 0.3s ease;
            white-space: nowrap;
        }
        button.delete-btn:hover {
            background-color: #c0392b;
        }
        button.admin-btn {
            background-color: #f39c12;
            color: white;
            border: none;
            padding: 6px 10px;
            font-size: 11px;
            cursor: pointer;
            border-radius: 3px;
            transition: background-color 0.3s ease;
            white-space: nowrap;
        }
        button.admin-btn:hover {
            background-color: #d68910;
        }
        button.active-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 6px 10px;
            font-size: 11px;
            cursor: pointer;
            border-radius: 3px;
            transition: background-color 0.3s ease;
            white-space: nowrap;
        }
        button.active-btn:hover {
            background-color: #2980b9;
        }
        .products-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .products-table th {
            background-color: #34495e;
            color: white;
            padding: 10px 12px;
            text-align: left;
            font-weight: bold;
            white-space: nowrap;
            font-size: 12px;
        }
        .products-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e8e6df;
            font-size: 13px;
        }
        .products-table tr:hover {
            background-color: #faf8f3;
        }
        .products-table tr:nth-child(even) {
            background-color: #f0f0f0;
        }
        .product-name {
            font-weight: bold;
            color: #2c3e50;
        }
        .product-price {
            color: #27ae60;
            font-weight: bold;
        }
        .product-stock {
            text-align: center;
        }
        .product-stock.low {
            color: #e74c3c;
            font-weight: bold;
        }
        .product-stock.adequate {
            color: #27ae60;
        }
        .action-buttons {
            display: flex !important;
            gap: 4px;
            flex-wrap: nowrap;
        }
        .message {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .message.info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .no-products {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-size: 16px;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: #3498db;
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 2px solid #e8e6df;
        }
        .tab {
            padding: 12px 20px;
            cursor: pointer;
            background-color: transparent;
            border: none;
            font-size: 16px;
            border-bottom: 3px solid transparent;
            color: #7f8c8d;
            transition: all 0.3s;
            margin: 0;
        }
        .tab.active {
            color: #3498db;
            border-bottom-color: #3498db;
        }
        .tab:hover {
            color: #ffffff;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            color: white;
            transition: all 0.3s;
            font-weight: 500;
        }
        .filter-btn:hover {
            opacity: 0.8;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .filter-btn.active {
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            transform: translateY(-3px);
            border: 2px solid #fff;
        }
        .banner-card {
            border: 1px solid #e8e6df;
            border-radius: 5px;
            padding: 12px;
            margin-bottom: 15px;
            background-color: #faf8f3;
            display: grid;
            grid-template-columns: 130px 1fr;
            gap: 15px;
            align-items: start;
        }
        .banner-preview {
            position: relative;
        }
        .banner-preview img {
            width: 130px;
            height: 78px;
            object-fit: cover;
            border-radius: 4px;
        }
        .banner-info {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }
        .banner-details {
            margin-bottom: 10px;
        }
        .banner-details h3 {
            margin: 0 0 8px 0;
            font-size: 14px;
            color: #2c3e50;
        }
        .banner-details p {
            margin: 4px 0;
            font-size: 12px;
            color: #555;
        }
        .banner-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 8px;
        }
        .banner-actions button {
            padding: 6px 12px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .banner-actions .active-btn {
            background-color: #3498db;
            color: white;
        }
        .banner-actions .active-btn:hover {
            background-color: #2980b9;
        }
        .banner-actions .delete-btn {
            background-color: #e74c3c;
            color: white;
        }
        .banner-actions .delete-btn:hover {
            background-color: #c0392b;
        }
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 15px;
                gap: 15px;
            }
            .header h1 {
                font-size: 20px;
            }
            .header-buttons {
                width: 100%;
                justify-content: flex-start;
            }
            .header-buttons button {
                font-size: 12px;
                padding: 8px 12px;
            }
            .section {
                padding: 15px;
                margin-bottom: 20px;
            }
            .section h2 {
                font-size: 18px;
                margin-bottom: 15px;
            }
            .tabs {
                flex-wrap: wrap;
                border-bottom: none;
                gap: 5px;
            }
            .tab {
                padding: 8px 12px;
                font-size: 12px;
                border-bottom: 3px solid transparent;
                border: 1px solid #e8e6df;
                border-radius: 4px;
                margin: 0 2px;
            }
            .tab.active {
                border-bottom: 3px solid #3498db;
                border: 1px solid #3498db;
            }
            .form-group {
                margin-bottom: 12px;
            }
            label {
                font-size: 12px;
            }
            input[type="text"],
            input[type="number"],
            input[type="email"],
            input[type="url"],
            textarea,
            select {
                font-size: 14px;
                padding: 8px;
            }
            .form-row,
            .form-row-3 {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            button {
                padding: 10px 15px;
                font-size: 14px;
                width: 100%;
            }
            button.delete-btn,
            button.admin-btn,
            button.active-btn {
                padding: 6px 8px;
                font-size: 11px;
                width: auto;
            }
            .products-table {
                font-size: 11px;
            }
            .products-table th,
            .products-table td {
                padding: 6px;
            }
            .action-buttons {
                flex-direction: column;
                gap: 2px !important;
            }
            .action-buttons button {
                width: 100%;
                padding: 4px 8px;
                font-size: 10px;
            }
            .banner-card {
                grid-template-columns: 100px 1fr;
                padding: 10px;
                gap: 10px;
            }
            .banner-preview img {
                width: 100px;
                height: 60px;
            }
            .banner-details h3 {
                font-size: 12px;
            }
            .banner-details p {
                font-size: 11px;
            }
            .welcome {
                font-size: 12px;
            }
            .no-products,
            .loading {
                padding: 20px 10px;
                font-size: 14px;
            }
        }
        @media (max-width: 480px) {
            .container {
                padding: 8px;
            }
            .header {
                flex-direction: column;
                padding: 10px;
                gap: 10px;
            }
            .header h1 {
                font-size: 18px;
            }
            .section {
                padding: 10px;
                margin-bottom: 15px;
            }
            .section h2 {
                font-size: 16px;
                margin-bottom: 10px;
            }
            .tab {
                padding: 6px 10px;
                font-size: 11px;
                margin: 2px 1px;
            }
            .banner-card {
                grid-template-columns: 80px 1fr;
                padding: 8px;
                gap: 8px;
            }
            .banner-preview img {
                width: 80px;
                height: 48px;
            }
            .banner-details h3 {
                font-size: 11px;
            }
            .banner-details p {
                font-size: 10px;
            }
            .products-table {
                font-size: 10px;
            }
            .products-table th,
            .products-table td {
                padding: 4px;
            }
            button {
                padding: 8px 12px;
                font-size: 12px;
            }
            input[type="text"],
            input[type="number"],
            input[type="email"],
            input[type="url"],
            textarea,
            select {
                font-size: 13px;
                padding: 6px;
            }
            .welcome {
                font-size: 11px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Административен панел</h1>
                <div class="welcome">Добре дошли, <?php echo htmlspecialchars($_SESSION['user_name']); ?> (<?php echo htmlspecialchars($_SESSION['user_email']); ?>)</div>
            </div>
            <div class="header-buttons">
                <button class="back-btn" onclick="window.location.href='homepage.php'">← Към уебсайта</button>
                <button class="logout-btn" onclick="logout()">Изход</button>
            </div>
        </div>
        <div id="message-container"></div>
        <!-- Табове -->
        <div class="tabs">
            <button class="tab active" onclick="switchTab('add-product')">Добавяне на продукт</button>
            <button class="tab" onclick="switchTab('manage-products')">Управление на продукти</button>
            <button class="tab" onclick="switchTab('manage-orders')">Управление на поръчки</button>
            <button class="tab" onclick="switchTab('manage-users')">Управление на потребители</button>
            <button class="tab" onclick="switchTab('manage-banners')">Управление на банери</button>
            <button class="tab" onclick="switchTab('manage-complaints');loadComplaints()">Преглед на оплаквания</button>
            <button class="tab" onclick="switchTab('manage-contacts');loadContacts()">Преглед на съобщения</button>
        </div>
        <!-- Таб: Добавяне на продукт -->
        <div id="add-product" class="tab-content active">
            <div class="section">
                <h2>Добавяне на нов продукт</h2>
                <form id="add-product-form" onsubmit="submitAddProduct(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="category_id">Категория *</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Избор на категория</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="product_name">Наименование на продукта *</label>
                            <input type="text" id="product_name" name="name" required placeholder="Въведете наименование на продукта">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="product_description">Описание</label>
                        <textarea id="product_description" name="description" placeholder="Въведете описание на продукта"></textarea>
                    </div>
                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="product_price">Цена (€) *</label>
                            <input type="number" id="product_price" name="price" step="0.01" min="0.01" required placeholder="0.00">
                        </div>
                        <div class="form-group">
                            <label for="product_stock">Наличност *</label>
                            <input type="number" id="product_stock" name="stock" min="0" required placeholder="0">
                        </div>
                    </div>
                    <h3 style="margin-top: 20px; margin-bottom: 15px; color: #2c3e50;">Изображения на продукта</h3>
                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="image_1">URL на изображение 1</label>
                            <input type="url" id="image_1" name="image_1" placeholder="https://example.com/image1.jpg">
                        </div>
                        <div class="form-group">
                            <label for="image_2">URL на изображение 2</label>
                            <input type="url" id="image_2" name="image_2" placeholder="https://example.com/image2.jpg">
                        </div>
                        <div class="form-group">
                            <label for="image_3">URL на изображение 3</label>
                            <input type="url" id="image_3" name="image_3" placeholder="https://example.com/image3.jpg">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="image_4">URL на изображение 4</label>
                            <input type="url" id="image_4" name="image_4" placeholder="https://example.com/image4.jpg">
                        </div>
                        <div class="form-group">
                            <label for="video_url">URL на видео</label>
                            <input type="url" id="video_url" name="video_url" placeholder="https://example.com/video.mp4">
                        </div>
                    </div>
                    <button type="submit" style="width: 100%; margin-top: 20px;">Добавяне на продукт</button>
                </form>
            </div>
        </div>
        <!-- Таб: Управление на продукти -->
        <div id="manage-products" class="tab-content">
            <div class="section">
                <h2>Управление на съществуващи продукти</h2>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                    <input type="text" id="product-search" placeholder="Търси по наименование..." style="flex: 1; min-width: 200px; padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onkeyup="filterProducts()">
                    <select id="product-category-filter" style="padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onchange="filterProducts()">
                        <option value="">Всички категории</option>
                    </select>
                    <button onclick="resetProductFilters()" style="background-color: #95a5a6; padding: 10px 20px;">Изчистване</button>
                </div>
                <div id="edit-product-form-container" style="display:none; margin-bottom: 30px; padding: 20px; background-color: #faf8f3; border: 2px solid #3498db; border-radius: 5px;">
                    <h3 style="margin-top: 0;">Редактиране на продукт</h3>
                    <form id="edit-product-form" onsubmit="submitEditProduct(event)">
                        <input type="hidden" id="edit_product_id" name="product_id">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="edit_category_id">Категория *</label>
                                <select id="edit_category_id" name="category_id" required>
                                    <option value="">Избор на категория</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_product_name">Наименование на продукта *</label>
                                <input type="text" id="edit_product_name" name="name" required placeholder="Въведете наименование на продукта">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="edit_product_description">Описание</label>
                            <textarea id="edit_product_description" name="description" placeholder="Въведете описание на продукта"></textarea>
                        </div>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label for="edit_product_price">Цена (€) *</label>
                                <input type="number" id="edit_product_price" name="price" step="0.01" min="0.01" required placeholder="0.00">
                            </div>
                            <div class="form-group">
                                <label for="edit_product_stock">Наличност *</label>
                                <input type="number" id="edit_product_stock" name="stock" min="0" required placeholder="0">
                            </div>
                        </div>
                        <h3 style="margin-top: 20px; margin-bottom: 15px; color: #2c3e50;">Изображения на продукта</h3>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label for="edit_image_1">URL на изображение 1</label>
                                <input type="url" id="edit_image_1" name="image_1" placeholder="https://example.com/image1.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_image_2">URL на изображение 2</label>
                                <input type="url" id="edit_image_2" name="image_2" placeholder="https://example.com/image2.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_image_3">URL на изображение 3</label>
                                <input type="url" id="edit_image_3" name="image_3" placeholder="https://example.com/image3.jpg">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="edit_image_4">URL на изображение 4</label>
                                <input type="url" id="edit_image_4" name="image_4" placeholder="https://example.com/image4.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_video_url">URL на видео</label>
                                <input type="url" id="edit_video_url" name="video_url" placeholder="https://example.com/video.mp4">
                            </div>
                        </div>
                        <h3 style="margin-top: 20px; margin-bottom: 15px; color: #2c3e50;">Управление на намаление</h3>
                        <div id="sale-management-section">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="edit_discount_percent">Процент намаление (%)</label>
                                    <input type="number" id="edit_discount_percent" name="discount_percent" min="1" max="99" placeholder="Напр: 20">
                                </div>
                                <div class="form-group">
                                    <label for="edit_sale_price">ИЛИ Цена с намаление (€)</label>
                                    <input type="number" id="edit_sale_price" name="sale_price" step="0.01" min="0.01" placeholder="Напр: 25.99">
                                </div>
                            </div>
                            <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                                <button type="button" onclick="applySaleFromForm()" style="background-color: #e74c3c; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Приложи намаление</button>
                                <button type="button" id="removeSaleBtn" onclick="removeSaleFromEdit()" style="background-color: #95a5a6; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; display: none;">Премахни намаление</button>
                            </div>
                            <div id="current-sale-info" style="padding: 10px; background-color: #ecf0f1; border-radius: 4px; display: none; margin-bottom: 15px;">
                                <p style="margin: 0; color: #2c3e50;"><strong>Текущо намаление:</strong> <span id="current-sale-text"></span></p>
                            </div>
                        </div>
                        <button type="submit" style="width: 100%; margin-top: 20px;">Запазване на промените</button>
                        <button type="button" onclick="cancelEditProduct()" style="width: 100%; margin-top: 10px; background-color: #95a5a6;">Отказ</button>
                    </form>
                </div>
                <div id="products-container" class="loading">Зареждане на продуктите...</div>
            </div>
        </div>
        <!-- Таб: Управление на потребители -->
        <div id="manage-users" class="tab-content">
            <div class="section">
                <h2>Управление на потребители</h2>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                    <input type="text" id="user-search" placeholder="Търси по име или имейл..." style="flex: 1; min-width: 200px; padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onkeyup="filterUsers()">
                    <select id="user-admin-filter" style="padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onchange="filterUsers()">
                        <option value="">Всички</option>
                        <option value="admin">Администратори</option>
                        <option value="user">Потребители</option>
                    </select>
                    <select id="user-active-filter" style="padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onchange="filterUsers()">
                        <option value="">Всички статуси</option>
                        <option value="active">Активни</option>
                        <option value="inactive">Неактивни</option>
                    </select>
                    <button onclick="resetUserFilters()" style="background-color: #95a5a6; padding: 10px 20px;">Изчистване</button>
                </div>
                <div id="users-container" class="loading">Зареждане на потребителите...</div>
            </div>
        </div>
        <!-- Таб: Управление на поръчки -->
        <div id="manage-orders" class="tab-content">
            <div class="section">
                <h2>Управление на поръчки</h2>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                    <input type="text" id="order-search" placeholder="Търси по име или имейл..." style="flex: 1; min-width: 200px; padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onkeyup="filterOrders()">
                    <select id="order-status-filter" style="padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" onchange="filterOrders()">
                        <option value="">Всички статуси</option>
                        <option value="pending">Изчакваща</option>
                        <option value="paid">Платена</option>
                        <option value="shipped">Изпратена</option>
                        <option value="delivered">Доставена</option>
                        <option value="cancelled">Отказана</option>
                    </select>
                    <button onclick="resetOrderFilters()" style="background-color: #95a5a6; padding: 10px 20px;">Изчистване</button>
                </div>
                <div id="orders-container" class="loading">Зареждане на поръчките...</div>
            </div>
        </div>
        <!-- Таб: Управление на банери -->
        <div id="manage-banners" class="tab-content">
            <div class="section">
                <h2>Добавяне на нов банер</h2>
                <form id="add-banner-form" enctype="multipart/form-data" onsubmit="submitAddBanner(event)">
                    <div class="form-group">
                        <label for="banner_image">Изображение на банера * (JPG, PNG, GIF, WebP - макс 5MB)</label>
                        <label for="image_input" class="file-input-label">Избор на файл</label>
                        <input type="file" id="image_input" name="image" accept="image/*" required onchange="updateFileName()">
                        <span class="file-name" id="file-name">Избран файл: няма</span>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="banner_link_type">Насочи към *</label>
                            <select id="banner_link_type" name="link_type" required onchange="updateLinkOptions()">
                                <option value="">Избор</option>
                                <option value="sales">Продажби (намаления)</option>
                                <option value="category">Категория</option>
                                <option value="custom">Персонализиран URL</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="banner_link_value" id="link-label">Избор *</label>
                            <select id="banner_category_select" name="link_value" multiple style="display: none; min-height: 120px;">
                                <option value="">Избор на категория</option>
                            </select>
                            <small id="multi-select-hint" style="display: none; color: #666; margin-top: 5px;">Задръжте Ctrl (или Cmd на Mac) и кликнете, за да изберете няколко категории</small>
                            <input type="text" id="banner_custom_url" name="link_value" placeholder="https://example.com" style="display: none;">
                        </div>
                    </div>

                    <div id="sale-percent-group" class="form-group" style="display: none;">
                        <label for="banner_sale_percent">Процент намаление (%)</label>
                        <input type="number" id="banner_sale_percent" name="sale_percent" min="1" max="100" placeholder="Напр: 20">
                        <small style="display: block; margin-top: 5px; color: #666;">Ще показва само продукти с намаление поне до този процент</small>
                    </div>

                    <button type="submit" style="width: 100%; margin-top: 20px;">Добавяне на банер</button>
                </form>
            </div>

            <div class="section">
                <h2>Съществуващи банери</h2>
                <div id="banners-container" class="loading">Зареждане на банерите...</div>
            </div>
        </div>
        <!-- Таб: Управление на оплаквания -->
        <div id="manage-complaints" class="tab-content">
            <div class="section">
                <h2>Оплаквания на потребителите</h2>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;" id="complaints-filters">
                    <button onclick="filterComplaints('all')" class="filter-btn active" data-filter="all" style="background-color: #3498db;">Всички</button>
                    <button onclick="filterComplaints('new')" class="filter-btn" data-filter="new" style="background-color: #f39c12;">Нови</button>
                    <button onclick="filterComplaints('in_progress')" class="filter-btn" data-filter="in_progress" style="background-color: #3498db;">В процес на разглеждане</button>
                    <button onclick="filterComplaints('resolved')" class="filter-btn" data-filter="resolved" style="background-color: #27ae60;">Разрешени</button>
                    <button onclick="filterComplaints('closed')" class="filter-btn" data-filter="closed" style="background-color: #95a5a6;">Закрити</button>
                </div>
                <div id="complaints-container" class="loading">Зареждане на оплакванията...</div>
            </div>
        </div>
        <!-- Таб: Управление на съобщения -->
        <div id="manage-contacts" class="tab-content">
            <div class="section">
                <h2>Съобщения от контактната форма</h2>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;" id="contacts-filters">
                    <button onclick="filterContacts('all')" class="filter-btn active" data-filter="all" style="background-color: #3498db;">Всички</button>
                    <button onclick="filterContacts('new')" class="filter-btn" data-filter="new" style="background-color: #f39c12;">Нови</button>
                    <button onclick="filterContacts('read')" class="filter-btn" data-filter="read" style="background-color: #3498db;">Прочетени</button>
                    <button onclick="filterContacts('replied')" class="filter-btn" data-filter="replied" style="background-color: #27ae60;">С отговор</button>
                </div>
                <div id="contacts-container" class="loading">Зареждане на съобщенията...</div>
            </div>
        </div>
    </div>
    <script>
        let currentPage = 1;
        const productsPerPage = 50;
        
        // Store original data for filtering
        let allProducts = [];
        let allOrders = [];
        let allUsers = [];
        
        // Инициализация
        document.addEventListener('DOMContentLoaded', function() {
            loadCategories();
            loadProducts();
            loadUsers();
            loadOrders();
            loadBanners();
            
            // Set up banner file input change handler
            const fileInput = document.getElementById('image_input');
            if (fileInput) {
                fileInput.addEventListener('change', updateFileName);
            }
        });
        function showMessage(message, type = 'info') {
            const container = document.getElementById('message-container');
            const messageEl = document.createElement('div');
            messageEl.className = `message ${type}`;
            messageEl.textContent = message;
            container.innerHTML = '';
            container.appendChild(messageEl);
            
            // Автоматично скриване след 5 секунди
            setTimeout(() => {
                messageEl.style.display = 'none';
            }, 5000);
        }
        function switchTab(tabName) {
            // Скриване на всички табове
            document.querySelectorAll('.tab-content').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(el => {
                el.classList.remove('active');
            });
            // Показване на избрания таб
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }
        function loadCategories() {
            fetch('api/get_categories.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Store categories for use in banner form
                        allCategories = data.categories;
                        
                        const select = document.getElementById('category_id');
                        const editSelect = document.getElementById('edit_category_id');
                        const bannerSelect = document.getElementById('banner_category_select');
                        
                        data.categories.forEach(category => {
                            const option1 = document.createElement('option');
                            option1.value = category.id;
                            option1.textContent = category.name;
                            select.appendChild(option1);
                            
                            const option2 = document.createElement('option');
                            option2.value = category.id;
                            option2.textContent = category.name;
                            editSelect.appendChild(option2);
                            
                            if (bannerSelect) {
                                const option3 = document.createElement('option');
                                option3.value = category.id;
                                option3.textContent = category.name;
                                bannerSelect.appendChild(option3);
                            }
                        });
                    } else {
                        showMessage('Грешка при зареждане на категориите: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                });
        }
        function loadProducts() {
            const container = document.getElementById('products-container');
            container.innerHTML = '<div class="loading">Зареждане на продуктите...</div>';
            fetch('api/get_products_admin.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.products.length === 0) {
                            container.innerHTML = '<div class="no-products">Няма намерени продукти. Добавете първия си продукт чрез таба „Добавяне на продукт".</div>';
                            return;
                        }
                        let html = '<table class="products-table"><thead><tr><th>№</th><th>Наименование</th><th>Категория</th><th>Цена</th><th>Наличност</th><th>Създаден на</th><th>Действия</th></tr></thead><tbody>';
                        
                        allProducts = data.products;
                        
                        // Populate category filter
                        const categoryFilter = document.getElementById('product-category-filter');
                        const categories = [...new Set(data.products.map(p => p.category_name))];
                        categories.forEach(cat => {
                            if (cat) {
                                const option = document.createElement('option');
                                option.value = cat;
                                option.textContent = cat;
                                categoryFilter.appendChild(option);
                            }
                        });
                        
                        data.products.forEach(product => {
                            const stockClass = product.stock < 5 ? 'low' : 'adequate';
                            const createdDate = new Date(product.created_at).toLocaleDateString();
                            let priceDisplay = `${parseFloat(product.price).toFixed(2)} €`;
                            if (product.sale_price && product.sale_price > 0) {
                                priceDisplay = `<span style="text-decoration: line-through; color: #999;">${parseFloat(product.price).toFixed(2)} €</span> <span style="color: #e74c3c; font-weight: bold;">${parseFloat(product.sale_price).toFixed(2)} €</span>`;
                            }
                            
                            html += `<tr>
                                <td>${product.id}</td>
                                <td class="product-name">${htmlEscape(product.name)}</td>
                                <td>${htmlEscape(product.category_name || 'Няма')}</td>
                                <td class="product-price">${priceDisplay}</td>
                                <td class="product-stock ${stockClass}">${product.stock}</td>
                                <td>${createdDate}</td>
                                <td class="action-buttons">
                                    <button onclick="editProduct(${product.id}, ${htmlEscape(JSON.stringify(product)).replace(/'/g, "&apos;")})" style="background-color: #27ae60; margin-right: 5px;">Редактиране</button>
                                    <button class="delete-btn" onclick="deleteProduct(${product.id}, '${htmlEscape(product.name).replace(/'/g, "\\'")}')">Изтриване</button>
                                </td>
                            </tr>`;
                        });
                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Грешка при зареждане на продуктите: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Грешка при зареждане на продуктите</div>';
                });
        }
        function submitAddProduct(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('add-product-form'));
            
            fetch('api/add_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Продуктът е добавен успешно!', 'success');
                    document.getElementById('add-product-form').reset();
                    loadProducts();
                    // Превключване към таба за управление на продукти
                    setTimeout(() => {
                        document.getElementById('manage-products').classList.add('active');
                        document.getElementById('add-product').classList.remove('active');
                        document.querySelectorAll('.tab')[1].classList.add('active');
                        document.querySelectorAll('.tab')[0].classList.remove('active');
                    }, 1000);
                } else {
                    showMessage('Грешка: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        function deleteProduct(productId, productName) {
            if (confirm(`Сигурни ли сте, че искате да изтриете „${productName}"? Това действие е необратимо.`)) {
                const formData = new FormData();
                formData.append('product_id', productId);
                fetch('api/delete_product.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Продуктът е изтрит успешно!', 'success');
                        loadProducts();
                    } else {
                        showMessage('Грешка: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }
        function loadOrders() {
            const container = document.getElementById('orders-container');
            container.innerHTML = '<div class="loading">Зареждане на поръчките...</div>';
            fetch('api/get_orders.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.orders.length === 0) {
                            container.innerHTML = '<div class="no-products">Няма намерени поръчки.</div>';
                            return;
                        }
                        let html = '<table class="products-table"><thead><tr><th>№</th><th>Клиент</th><th>Имейл</th><th>Артикули</th><th>Сума</th><th>Доставка</th><th>Статус</th><th>Плащане</th><th>Създадена на</th><th>Действия</th></tr></thead><tbody>';
                        
                        allOrders = data.orders;
                        
                        const statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
                        const statusLabels = {
                            'pending': 'Изчакваща',
                            'paid': 'Платена',
                            'shipped': 'Изпратена',
                            'delivered': 'Доставена',
                            'cancelled': 'Отказана'
                        };
                        const statusColors = {
                            'pending': '#f39c12',
                            'paid': '#27ae60',
                            'shipped': '#3498db',
                            'delivered': '#16a085',
                            'cancelled': '#e74c3c'
                        };
                        data.orders.forEach(order => {
                            const createdDate = new Date(order.created_at).toLocaleDateString();
                            const totalAmount = parseFloat(order.total).toFixed(2);
                            const itemCount = order.items.length;
                            const statusColor = statusColors[order.status] || '#95a5a6';
                            
                            // Информация за доставка
                            let deliveryInfo = order.delivery_method || 'Неизвестна';
                            if (order.delivery_method === 'Courier' && order.shipping_address) {
                                // For home delivery, show the shipping address
                                deliveryInfo += '<br/><small style="font-size: 11px;">' + htmlEscape(order.shipping_address) + '</small>';
                            } else if (order.delivery_office) {
                                // For office delivery, show office name and street
                                deliveryInfo += '<br/><small>' + htmlEscape(order.delivery_office) + '</small>';
                                if (order.delivery_street) {
                                    deliveryInfo += '<br/><small style="font-size: 10px; color: #7f8c8d;">' + htmlEscape(order.delivery_street) + '</small>';
                                }
                            }
                            
                            let statusSelect = '<select onchange="updateOrderStatus(' + order.id + ', this.value)" style="padding: 5px; border: 1px solid #e8e6df; border-radius: 3px;">';
                            statuses.forEach(st => {
                                statusSelect += '<option value="' + st + '" ' + (st === order.status ? 'selected' : '') + '>' + (statusLabels[st] || st) + '</option>';
                            });
                            statusSelect += '</select>';
                            html += `<tr>
                                <td>${order.id}</td>
                                <td>${htmlEscape(order.fullname || 'Неизвестен')}</td>
                                <td>${htmlEscape(order.email)}</td>
                                <td>${itemCount} бр.</td>
                                <td style="color: #27ae60; font-weight: bold;">${totalAmount} €</td>
                                <td>${deliveryInfo}</td>
                                <td>${statusSelect}</td>
                                <td>${order.payment_method === 'card' ? 'Карта' : 'Наложен платеж'}</td>
                                <td>${createdDate}</td>
                                <td class="action-buttons">
                                    <button onclick="viewOrderDetails(${order.id}, ${htmlEscape(JSON.stringify(order)).replace(/'/g, "&apos;")})" style="background-color: #3498db; padding: 8px 12px; font-size: 12px;">Детайли</button>
                                </td>
                            </tr>`;
                        });
                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Грешка при зареждане на поръчките: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Грешка при зареждане на поръчките</div>';
                });
        }
        function updateOrderStatus(orderId, newStatus) {
            const statusLabels = {
                'pending': 'Изчакваща',
                'paid': 'Платена',
                'shipped': 'Изпратена',
                'delivered': 'Доставена',
                'cancelled': 'Отказана'
            };
            const label = statusLabels[newStatus] || newStatus;
            if (confirm('Промяна на статуса на поръчка №' + orderId + ' на „' + label + '"?')) {
                const formData = new FormData();
                formData.append('order_id', orderId);
                formData.append('status', newStatus);
                fetch('api/update_order_status.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Статусът на поръчката е обновен успешно!', 'success');
                        loadOrders();
                    } else {
                        showMessage('Грешка: ' + data.message, 'error');
                        loadOrders();
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                    loadOrders();
                });
            } else {
                loadOrders();
            }
        }
        function viewOrderDetails(orderId, orderData) {
            const order = typeof orderData === 'string' ? JSON.parse(orderData) : orderData;
            const statusLabels = {
                'pending': 'Изчакваща',
                'paid': 'Платена',
                'shipped': 'Изпратена',
                'delivered': 'Доставена',
                'cancelled': 'Отказана'
            };
            
            let detailsHTML = 'Поръчка №' + order.id + '\n\n';
            detailsHTML += 'Клиент: ' + (order.fullname || 'Неизвестен') + '\n';
            detailsHTML += 'Имейл: ' + order.email + '\n';
            detailsHTML += 'Телефон: ' + (order.phone || 'Няма') + '\n';
            detailsHTML += 'Град: ' + (order.city || 'Няма') + '\n';
            detailsHTML += 'Статус: ' + (statusLabels[order.status] || order.status) + '\n';
            detailsHTML += 'Начин на плащане: ' + (order.payment_method === 'card' ? 'Карта' : 'Наложен платеж') + '\n';
            detailsHTML += 'Дата на поръчката: ' + new Date(order.created_at).toLocaleString() + '\n\n';
            
            detailsHTML += 'Артикули:\n';
            order.items.forEach(item => {
                detailsHTML += '- ' + item.name + ' — Брой: ' + item.quantity + ' × ' + parseFloat(item.unit_price).toFixed(2) + ' €\n';
            });
            
            detailsHTML += '\nЦенообразуване:\n';
            detailsHTML += 'Подтотал: ' + parseFloat(order.subtotal).toFixed(2) + ' €\n';
            detailsHTML += 'Доставка: ' + parseFloat(order.delivery_cost).toFixed(2) + ' €\n';
            detailsHTML += 'Общо: ' + parseFloat(order.total).toFixed(2) + ' €';
            
            alert(detailsHTML);
        }
        function logout() {
            if (confirm('Сигурни ли сте, че искате да излезете?')) {
                window.location.href = 'api/logout.php';
            }
        }
        function htmlEscape(str) {
            return str
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }
        function editProduct(productId, productData) {
            const product = typeof productData === 'string' ? JSON.parse(productData) : productData;
            
            document.getElementById('edit_product_id').value = product.id;
            document.getElementById('edit_category_id').value = product.category_id;
            document.getElementById('edit_product_name').value = product.name;
            document.getElementById('edit_product_description').value = product.description || '';
            document.getElementById('edit_product_price').value = product.price;
            document.getElementById('edit_product_stock').value = product.stock;
            document.getElementById('edit_image_1').value = product.image_1 || '';
            document.getElementById('edit_image_2').value = product.image_2 || '';
            document.getElementById('edit_image_3').value = product.image_3 || '';
            document.getElementById('edit_image_4').value = product.image_4 || '';
            document.getElementById('edit_video_url').value = product.video_url || '';
            
            // Update sale information
            document.getElementById('edit_discount_percent').value = product.discount_percent || '';
            document.getElementById('edit_sale_price').value = product.sale_price || '';
            
            // Show/hide remove sale button
            if (product.discount_percent && product.sale_price) {
                document.getElementById('removeSaleBtn').style.display = 'inline-block';
                document.getElementById('current-sale-info').style.display = 'block';
                document.getElementById('current-sale-text').textContent = `${product.discount_percent}% намаление (Цена: ${parseFloat(product.sale_price).toFixed(2)} €)`;
            } else {
                document.getElementById('removeSaleBtn').style.display = 'none';
                document.getElementById('current-sale-info').style.display = 'none';
            }
            
            document.getElementById('edit-product-form-container').style.display = 'block';
            document.getElementById('edit-product-form-container').scrollIntoView({ behavior: 'smooth' });
        }
        function submitEditProduct(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('edit-product-form'));
            
            fetch('api/update_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Продуктът е обновен успешно!', 'success');
                    cancelEditProduct();
                    loadProducts();
                } else {
                    showMessage('Грешка: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        function cancelEditProduct() {
            document.getElementById('edit-product-form-container').style.display = 'none';
            document.getElementById('edit-product-form').reset();
            document.getElementById('removeSaleBtn').style.display = 'none';
            document.getElementById('current-sale-info').style.display = 'none';
        }
        
        function applySaleFromForm() {
            const productId = document.getElementById('edit_product_id').value;
            const discountPercent = document.getElementById('edit_discount_percent').value;
            const salePrice = document.getElementById('edit_sale_price').value;
            
            if (!productId) {
                showMessage('Моля, перву редактирайте продукт', 'error');
                return;
            }
            
            if (!discountPercent && !salePrice) {
                showMessage('Моля, въведете процент намаление или цена с намаление', 'error');
                return;
            }
            
            const formData = new FormData();
            formData.append('product_id', productId);
            if (discountPercent) {
                formData.append('discount_percent', discountPercent);
            }
            if (salePrice) {
                formData.append('sale_price', salePrice);
            }
            
            fetch('api/add_sale.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Намаление приложено успешно!', 'success');
                    document.getElementById('removeSaleBtn').style.display = 'inline-block';
                    document.getElementById('current-sale-info').style.display = 'block';
                    document.getElementById('current-sale-text').textContent = `${data.discount_percent}% намаление (Цена: ${parseFloat(data.sale_price).toFixed(2)} €)`;
                    document.getElementById('edit_discount_percent').value = data.discount_percent;
                    document.getElementById('edit_sale_price').value = data.sale_price;
                } else {
                    showMessage('Грешка: ' + (data.message || 'Неизвестна грешка'), 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        
        function removeSaleFromEdit() {
            const productId = document.getElementById('edit_product_id').value;
            
            if (!confirm('Сигурни ли сте че искате да премахнете намалението?')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('product_id', productId);
            
            fetch('api/remove_sale.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Намалението е премахнато успешно!', 'success');
                    document.getElementById('removeSaleBtn').style.display = 'none';
                    document.getElementById('current-sale-info').style.display = 'none';
                    document.getElementById('edit_discount_percent').value = '';
                    document.getElementById('edit_sale_price').value = '';
                } else {
                    showMessage('Грешка: ' + (data.message || 'Неизвестна грешка'), 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        
        function loadUsers() {
            const container = document.getElementById('users-container');
            container.innerHTML = '<div class="loading">Зареждане на потребителите...</div>';
            fetch('api/get_users.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.users.length === 0) {
                            container.innerHTML = '<div class="no-products">Няма намерени потребители.</div>';
                            return;
                        }
                        let html = '<table class="products-table"><thead><tr><th>№</th><th>Име</th><th>Имейл</th><th>Телефон</th><th>Град</th><th>Последна доставка</th><th>Администратор</th><th>Активен</th><th>Регистриран на</th><th>Действия</th></tr></thead><tbody>';
                        
                        allUsers = data.users;
                        
                        data.users.forEach(user => {
                            const joinedDate = new Date(user.created_at).toLocaleDateString();
                            const adminBadge = user.is_admin ? '<span style="color: #27ae60; font-weight: bold;">Да</span>' : '<span style="color: #e74c3c;">Не</span>';
                            const activeBadge = user.is_active ? '<span style="color: #27ae60; font-weight: bold;">Да</span>' : '<span style="color: #e74c3c;">Не</span>';
                            
                            let shipmentInfo = '—';
                            if (user.last_delivery_method) {
                                shipmentInfo = user.last_delivery_method;
                                if (user.last_delivery_office) {
                                    shipmentInfo += '<br/><small>' + htmlEscape(user.last_delivery_office) + '</small>';
                                }
                            }
                            
                            html += `<tr>
                                <td>${user.id}</td>
                                <td class="product-name">${htmlEscape(user.fullname)}</td>
                                <td>${htmlEscape(user.email)}</td>
                                <td>${htmlEscape(user.phone || '—')}</td>
                                <td>${htmlEscape(user.city || '—')}</td>
                                <td>${shipmentInfo}</td>
                                <td>${adminBadge}</td>
                                <td>${activeBadge}</td>
                                <td>${joinedDate}</td>
                                <td class="action-buttons">
                                    <button class="admin-btn" onclick="toggleUserAdmin(${user.id}, ${user.is_admin})">${user.is_admin ? 'Отнемане на права' : 'Направи администратор'}</button>
                                    <button class="active-btn" onclick="toggleUserActive(${user.id}, ${user.is_active})">${user.is_active ? 'Деактивиране' : 'Активиране'}</button>
                                    <button class="delete-btn" onclick="deleteUser(${user.id}, '${htmlEscape(user.fullname).replace(/'/g, "\\'")}')">Изтриване</button>
                                </td>
                            </tr>`;
                        });
                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Грешка при зареждане на потребителите: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Грешка при зареждане на потребителите</div>';
                });
        }
        function toggleUserAdmin(userId, currentAdminStatus) {
            if (confirm(`Сигурни ли сте, че искате да ${currentAdminStatus ? 'отнемете' : 'предоставите'} администраторски права?`)) {
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('is_admin', currentAdminStatus ? 0 : 1);
                fetch('api/update_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message, 'success');
                        loadUsers();
                    } else {
                        showMessage('Грешка: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }
        function toggleUserActive(userId, currentActiveStatus) {
            if (confirm(`Сигурни ли сте, че искате да ${currentActiveStatus ? 'деактивирате' : 'активирате'} този потребител?`)) {
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('is_active', currentActiveStatus ? 0 : 1);
                fetch('api/update_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message, 'success');
                        loadUsers();
                    } else {
                        showMessage('Грешка: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }
        function deleteUser(userId, userName) {
            if (confirm(`Сигурни ли сте, че искате да изтриете потребител „${userName}"? Това действие е необратимо и ще премахне всички негови данни.`)) {
                const formData = new FormData();
                formData.append('user_id', userId);
                fetch('api/delete_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Потребителят е изтрит успешно!', 'success');
                        loadUsers();
                    } else {
                        showMessage('Грешка: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }
        let currentComplaintFilter = 'all';
        function loadComplaints() {
            const container = document.getElementById('complaints-container');
            container.className = 'loading';
            container.innerHTML = 'Зареждане на оплакванията...';
            let url = 'api/get_complaints.php';
            if (currentComplaintFilter !== 'all') {
                url += '?status=' + currentComplaintFilter;
            }
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.complaints) {
                        displayComplaints(data.complaints);
                    } else {
                        container.innerHTML = '<div class="no-products">Няма намерени оплаквания</div>';
                    }
                })
                .catch(error => {
                    showMessage('Грешка при зареждане на оплакванията: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Грешка при зареждане на оплакванията</div>';
                });
        }
        function filterComplaints(status) {
            currentComplaintFilter = status;
            // Update active button styling
            const complaintButtons = document.querySelectorAll('#complaints-filters .filter-btn');
            complaintButtons.forEach(btn => {
                if (btn.dataset.filter === status) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
            loadComplaints();
        }
        function displayComplaints(complaints) {
            const container = document.getElementById('complaints-container');
            container.className = '';
            if (complaints.length === 0) {
                container.innerHTML = '<div class="no-products">Няма намерени оплаквания</div>';
                return;
            }
            const priorityLabels = {
                'low': 'Ниски',
                'medium': 'Средни',
                'high': 'Високи',
                'urgent': 'Спешни'
            };
            const statusLabels = {
                'new': 'Ново',
                'in_progress': 'В процес',
                'resolved': 'Разрешено',
                'closed': 'Закрито'
            };
            let html = '<table class="products-table">';
            html += '<thead><tr>';
            html += '<th>№</th>';
            html += '<th>Имейл</th>';
            html += '<th>Телефон</th>';
            html += '<th>Заглавие</th>';
            html += '<th>Категория</th>';
            html += '<th>Приоритет</th>';
            html += '<th>Статус</th>';
            html += '<th>Дата</th>';
            html += '<th>Действия</th>';
            html += '</tr></thead>';
            html += '<tbody>';
            const priorityColor = {
                'low': '#3498db',
                'medium': '#f39c12',
                'high': '#e74c3c',
                'urgent': '#c0392b'
            };
            const statusColor = {
                'new': '#f39c12',
                'in_progress': '#3498db',
                'resolved': '#27ae60',
                'closed': '#95a5a6'
            };
            complaints.forEach(complaint => {
                html += '<tr>';
                html += '<td>#' + complaint.id + '</td>';
                html += '<td>' + (complaint.email || 'Няма') + '</td>';
                html += '<td>' + (complaint.phone || 'Няма') + '</td>';
                html += '<td style="font-weight: bold;">' + complaint.title + '</td>';
                html += '<td>' + complaint.category.replace('_', ' ') + '</td>';
                html += '<td><span style="background-color: ' + (priorityColor[complaint.priority] || '#95a5a6') + '; color: white; padding: 5px 10px; border-radius: 3px; font-size: 12px;">' + (priorityLabels[complaint.priority] || complaint.priority) + '</span></td>';
                html += '<td><span style="background-color: ' + (statusColor[complaint.status] || '#95a5a6') + '; color: white; padding: 5px 10px; border-radius: 3px; font-size: 12px;">' + (statusLabels[complaint.status] || complaint.status) + '</span></td>';
                html += '<td>' + new Date(complaint.created_at).toLocaleDateString() + '</td>';
                html += '<td><button onclick="viewComplaintDetails(' + complaint.id + ')" style="font-size: 12px; padding: 5px 10px;">Преглед</button></td>';
                html += '</tr>';
            });
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        function viewComplaintDetails(complaintId) {
            fetch('api/get_complaint.php?id=' + complaintId)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.complaint) {
                        const complaint = data.complaint;
                        const priorityLabels = { 'low': 'Нисък', 'medium': 'Среден', 'high': 'Висок', 'urgent': 'Спешен' };
                        const statusLabels = { 'new': 'Ново', 'in_progress': 'В процес', 'resolved': 'Разрешено', 'closed': 'Закрито' };
                        let modal = `
                            <div id="complaint-modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000;">
                                <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; max-height: 80vh; overflow-y: auto; box-shadow: 0 5px 20px rgba(0,0,0,0.3);">
                                    <h3 style="margin-bottom: 20px; color: #344e41;">Оплакване №${complaint.id}</h3>
                                    
                                    <p><strong>Имейл:</strong> ${complaint.email || 'Няма'}</p>
                                    <p><strong>Телефон:</strong> ${complaint.phone || 'Няма'}</p>
                                    <p><strong>Заглавие:</strong> ${complaint.title}</p>
                                    <p><strong>Категория:</strong> ${complaint.category.replace('_', ' ')}</p>
                                    <p><strong>Приоритет:</strong> ${priorityLabels[complaint.priority] || complaint.priority}</p>
                                    <p><strong>Статус:</strong> ${statusLabels[complaint.status] || complaint.status}</p>
                                    <p><strong>Подадено на:</strong> ${new Date(complaint.created_at).toLocaleString()}</p>
                                    
                                    <hr style="margin: 20px 0;">
                                    
                                    <h4>Описание:</h4>
                                    <p style="background: #f5f5f5; padding: 15px; border-radius: 5px; white-space: pre-wrap; word-break: break-word;">${htmlEscape(complaint.description)}</p>
                                    
                                    ${complaint.response ? `
                                        <hr style="margin: 20px 0;">
                                        <h4>Отговор на администратора:</h4>
                                        <p style="background: #e8f5e9; padding: 15px; border-radius: 5px; white-space: pre-wrap; word-break: break-word;">${htmlEscape(complaint.response)}</p>
                                    ` : ''}
                                    
                                    <hr style="margin: 20px 0;">
                                    
                                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px;">
                                        <button onclick="updateComplaintStatus(${complaint.id}, 'in_progress')" style="background-color: #3498db;">Отбележи като „В процес"</button>
                                        <button onclick="updateComplaintStatus(${complaint.id}, 'resolved')" style="background-color: #27ae60;">Отбележи като „Разрешено"</button>
                                        <button onclick="updateComplaintStatus(${complaint.id}, 'closed')" style="background-color: #95a5a6;">Закрий</button>
                                    </div>
                                    
                                    <div style="margin-top: 15px;">
                                        <label><strong>Отговор:</strong></label>
                                        <textarea id="complaint-response-${complaint.id}" style="width: 100%; min-height: 80px; padding: 10px; border: 1px solid #e8e6df; border-radius: 4px;" placeholder="Въведете вашия отговор тук...">${complaint.response || ''}</textarea>
                                        <button onclick="submitComplaintResponse(${complaint.id})" style="margin-top: 10px; background-color: #fb8500; width: 100%;">Запазване на отговора</button>
                                    </div>
                                    
                                    <button onclick="closeComplaintModal()" style="margin-top: 15px; width: 100%; background-color: #e74c3c;">Затваряне</button>
                                </div>
                            </div>
                        `;
                        document.body.insertAdjacentHTML('beforeend', modal);
                        document.getElementById('complaint-modal-overlay').addEventListener('click', function(e) {
                            if (e.target === this) {
                                closeComplaintModal();
                            }
                        });
                    }
                })
                .catch(error => {
                    alert('Грешка: ' + error.message);
                });
        }
        function closeComplaintModal() {
            const overlay = document.getElementById('complaint-modal-overlay');
            if (overlay) {
                overlay.remove();
            }
        }
        function updateComplaintStatus(complaintId, status) {
            const formData = new FormData();
            formData.append('id', complaintId);
            formData.append('status', status);
            fetch('api/update_complaint.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Статусът на оплакването е обновен успешно!', 'success');
                    closeComplaintModal();
                    loadComplaints();
                } else {
                    showMessage('Грешка: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        function submitComplaintResponse(complaintId) {
            const response = document.getElementById('complaint-response-' + complaintId).value;
            
            if (!response.trim()) {
                alert('Моля, въведете отговор.');
                return;
            }
            const formData = new FormData();
            formData.append('id', complaintId);
            formData.append('response', response);
            fetch('api/update_complaint.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Отговорът е запазен успешно!', 'success');
                    closeComplaintModal();
                    loadComplaints();
                } else {
                    showMessage('Грешка: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        let currentContactFilter = 'all';
        function loadContacts() {
            const container = document.getElementById('contacts-container');
            container.className = 'loading';
            container.innerHTML = 'Зареждане на съобщенията...';
            let url = 'api/get_contact_messages.php';
            if (currentContactFilter !== 'all') {
                url += '?status=' + currentContactFilter;
            }
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.messages) {
                        displayContacts(data.messages);
                    } else {
                        container.innerHTML = '<div class="no-products">Няма намерени съобщения</div>';
                    }
                })
                .catch(error => {
                    showMessage('Грешка при зареждане на съобщенията: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Грешка при зареждане на съобщенията</div>';
                });
        }
        function filterContacts(status) {
            currentContactFilter = status;
            // Update active button styling
            const contactButtons = document.querySelectorAll('#contacts-filters .filter-btn');
            contactButtons.forEach(btn => {
                if (btn.dataset.filter === status) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
            loadContacts();
        }
        function displayContacts(messages) {
            const container = document.getElementById('contacts-container');
            container.className = '';
            if (messages.length === 0) {
                container.innerHTML = '<div class="no-products">Няма намерени съобщения</div>';
                return;
            }
            const statusLabels = {
                'new': 'Ново',
                'read': 'Прочетено',
                'replied': 'С отговор'
            };
            const statusColor = {
                'new': '#f39c12',
                'read': '#3498db',
                'replied': '#27ae60'
            };
            let html = '<table class="products-table">';
            html += '<thead><tr>';
            html += '<th>№</th>';
            html += '<th>Име</th>';
            html += '<th>Имейл</th>';
            html += '<th>Телефон</th>';
            html += '<th>Тема</th>';
            html += '<th>Статус</th>';
            html += '<th>Дата</th>';
            html += '<th>Действия</th>';
            html += '</tr></thead>';
            html += '<tbody>';
            messages.forEach(message => {
                html += '<tr>';
                html += '<td>#' + message.id + '</td>';
                html += '<td>' + message.name + '</td>';
                html += '<td>' + message.email + '</td>';
                html += '<td>' + (message.phone || '—') + '</td>';
                html += '<td style="font-weight: bold;">' + message.subject + '</td>';
                html += '<td><span style="background-color: ' + (statusColor[message.status] || '#95a5a6') + '; color: white; padding: 5px 10px; border-radius: 3px; font-size: 12px;">' + (statusLabels[message.status] || message.status) + '</span></td>';
                html += '<td>' + new Date(message.created_at).toLocaleDateString() + '</td>';
                html += '<td><button onclick="viewContactDetails(' + message.id + ')" style="font-size: 12px; padding: 5px 10px;">Преглед</button></td>';
                html += '</tr>';
            });
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        function viewContactDetails(contactId) {
            fetch('api/get_contact_message.php?id=' + contactId)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.message) {
                        const message = data.message;
                        const statusLabels = { 'new': 'Ново', 'read': 'Прочетено', 'replied': 'С отговор' };
                        let modal = `
                            <div id="contact-modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000;">
                                <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; max-height: 80vh; overflow-y: auto; box-shadow: 0 5px 20px rgba(0,0,0,0.3);">
                                    <h3 style="margin-bottom: 20px; color: #344e41;">Съобщение №${message.id}</h3>
                                    
                                    <p><strong>Име:</strong> ${message.name}</p>
                                    <p><strong>Имейл:</strong> ${message.email}</p>
                                    <p><strong>Телефон:</strong> ${message.phone || 'Няма'}</p>
                                    <p><strong>Тема:</strong> ${message.subject}</p>
                                    <p><strong>Статус:</strong> ${statusLabels[message.status] || message.status}</p>
                                    <p><strong>Получено на:</strong> ${new Date(message.created_at).toLocaleString()}</p>
                                    
                                    <hr style="margin: 20px 0;">
                                    
                                    <h4>Съобщение:</h4>
                                    <p style="background: #f5f5f5; padding: 15px; border-radius: 5px; white-space: pre-wrap; word-break: break-word;">${htmlEscape(message.message)}</p>
                                    
                                    <hr style="margin: 20px 0;">
                                    
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                        <button onclick="updateContactStatus(${message.id}, 'read')" style="background-color: #3498db;">Отбележи като „Прочетено"</button>
                                        <button onclick="updateContactStatus(${message.id}, 'replied')" style="background-color: #27ae60;">Отбележи като „С отговор"</button>
                                    </div>
                                    
                                    <button onclick="closeContactModal()" style="margin-top: 15px; width: 100%; background-color: #e74c3c;">Затваряне</button>
                                </div>
                            </div>
                        `;
                        document.body.insertAdjacentHTML('beforeend', modal);
                        document.getElementById('contact-modal-overlay').addEventListener('click', function(e) {
                            if (e.target === this) {
                                closeContactModal();
                            }
                        });
                    }
                })
                .catch(error => {
                    alert('Грешка: ' + error.message);
                });
        }
        function closeContactModal() {
            const overlay = document.getElementById('contact-modal-overlay');
            if (overlay) {
                overlay.remove();
            }
        }
        function updateContactStatus(contactId, status) {
            const formData = new FormData();
            formData.append('id', contactId);
            formData.append('status', status);
            fetch('api/update_contact_message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Статусът на съобщението е обновен успешно!', 'success');
                    closeContactModal();
                    loadContacts();
                } else {
                    showMessage('Грешка: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Грешка: ' + error.message, 'error');
            });
        }
        
        // Filter Functions
        function filterProducts() {
            const searchTerm = document.getElementById('product-search').value.toLowerCase();
            const categoryFilter = document.getElementById('product-category-filter').value;
            
            let filtered = allProducts.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchTerm);
                const matchesCategory = categoryFilter === '' || product.category_name === categoryFilter;
                return matchesSearch && matchesCategory;
            });
            
            displayProductsTable(filtered);
        }
        
        function resetProductFilters() {
            document.getElementById('product-search').value = '';
            document.getElementById('product-category-filter').value = '';
            displayProductsTable(allProducts);
        }
        
        function displayProductsTable(products) {
            const container = document.getElementById('products-container');
            if (products.length === 0) {
                container.innerHTML = '<div class="no-products">Няма намерени продукти.</div>';
                return;
            }
            
            let html = '<table class="products-table"><thead><tr><th>№</th><th>Наименование</th><th>Категория</th><th>Цена</th><th>Наличност</th><th>Създаден на</th><th>Действия</th></tr></thead><tbody>';
            
            products.forEach(product => {
                const stockClass = product.stock < 5 ? 'low' : 'adequate';
                const createdDate = new Date(product.created_at).toLocaleDateString();
                
                html += `<tr>
                    <td>${product.id}</td>
                    <td class="product-name">${htmlEscape(product.name)}</td>
                    <td>${htmlEscape(product.category_name || 'Няма')}</td>
                    <td class="product-price">${parseFloat(product.price).toFixed(2)} €</td>
                    <td class="product-stock ${stockClass}">${product.stock}</td>
                    <td>${createdDate}</td>
                    <td class="action-buttons">
                        <button onclick="editProduct(${product.id}, ${htmlEscape(JSON.stringify(product)).replace(/'/g, "&apos;")})" style="background-color: #27ae60; margin-right: 5px;">Редактиране</button>
                        <button class="delete-btn" onclick="deleteProduct(${product.id}, '${htmlEscape(product.name).replace(/'/g, "\\'")}')">Изтриване</button>
                    </td>
                </tr>`;
            });
            
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        
        function filterOrders() {
            const searchTerm = document.getElementById('order-search').value.toLowerCase();
            const statusFilter = document.getElementById('order-status-filter').value;
            
            let filtered = allOrders.filter(order => {
                const matchesSearch = (order.fullname && order.fullname.toLowerCase().includes(searchTerm)) || 
                                    order.email.toLowerCase().includes(searchTerm);
                const matchesStatus = statusFilter === '' || order.status === statusFilter;
                return matchesSearch && matchesStatus;
            });
            
            displayOrdersTable(filtered);
        }
        
        function resetOrderFilters() {
            document.getElementById('order-search').value = '';
            document.getElementById('order-status-filter').value = '';
            displayOrdersTable(allOrders);
        }
        
        function displayOrdersTable(orders) {
            const container = document.getElementById('orders-container');
            if (orders.length === 0) {
                container.innerHTML = '<div class="no-products">Няма намерени поръчки.</div>';
                return;
            }
            
            let html = '<table class="products-table"><thead><tr><th>№</th><th>Клиент</th><th>Имейл</th><th>Артикули</th><th>Сума</th><th>Доставка</th><th>Статус</th><th>Плащане</th><th>Създадена на</th><th>Действия</th></tr></thead><tbody>';
            
            const statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
            const statusLabels = {
                'pending': 'Изчакваща',
                'paid': 'Платена',
                'shipped': 'Изпратена',
                'delivered': 'Доставена',
                'cancelled': 'Отказана'
            };
            
            orders.forEach(order => {
                const createdDate = new Date(order.created_at).toLocaleDateString();
                const totalAmount = parseFloat(order.total).toFixed(2);
                const itemCount = order.items.length;
                
                let deliveryInfo = order.delivery_method || 'Неизвестна';
                if (order.delivery_method === 'Courier' && order.shipping_address) {
                    deliveryInfo += '<br/><small style="font-size: 11px;">' + htmlEscape(order.shipping_address) + '</small>';
                } else if (order.delivery_office) {
                    deliveryInfo += '<br/><small>' + htmlEscape(order.delivery_office) + '</small>';
                    if (order.delivery_street) {
                        deliveryInfo += '<br/><small style="font-size: 10px; color: #7f8c8d;">' + htmlEscape(order.delivery_street) + '</small>';
                    }
                }
                
                let statusSelect = '<select onchange="updateOrderStatus(' + order.id + ', this.value)" style="padding: 5px; border: 1px solid #e8e6df; border-radius: 3px;">';
                statuses.forEach(st => {
                    statusSelect += '<option value="' + st + '" ' + (st === order.status ? 'selected' : '') + '>' + (statusLabels[st] || st) + '</option>';
                });
                statusSelect += '</select>';
                
                html += `<tr>
                    <td>${order.id}</td>
                    <td>${htmlEscape(order.fullname || 'Неизвестен')}</td>
                    <td>${htmlEscape(order.email)}</td>
                    <td>${itemCount} бр.</td>
                    <td style="color: #27ae60; font-weight: bold;">${totalAmount} €</td>
                    <td>${deliveryInfo}</td>
                    <td>${statusSelect}</td>
                    <td>${order.payment_method === 'card' ? 'Карта' : 'Наложен платеж'}</td>
                    <td>${createdDate}</td>
                    <td class="action-buttons">
                        <button onclick="viewOrderDetails(${order.id}, ${htmlEscape(JSON.stringify(order)).replace(/'/g, "&apos;")})" style="background-color: #3498db; padding: 8px 12px; font-size: 12px;">Детайли</button>
                    </td>
                </tr>`;
            });
            
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        
        function filterUsers() {
            const searchTerm = document.getElementById('user-search').value.toLowerCase();
            const adminFilter = document.getElementById('user-admin-filter').value;
            const activeFilter = document.getElementById('user-active-filter').value;
            
            let filtered = allUsers.filter(user => {
                const matchesSearch = (user.fullname && user.fullname.toLowerCase().includes(searchTerm)) || 
                                    user.email.toLowerCase().includes(searchTerm);
                const matchesAdmin = adminFilter === '' || 
                                   (adminFilter === 'admin' && user.is_admin) || 
                                   (adminFilter === 'user' && !user.is_admin);
                const matchesActive = activeFilter === '' || 
                                    (activeFilter === 'active' && user.is_active) || 
                                    (activeFilter === 'inactive' && !user.is_active);
                return matchesSearch && matchesAdmin && matchesActive;
            });
            
            displayUsersTable(filtered);
        }
        
        function resetUserFilters() {
            document.getElementById('user-search').value = '';
            document.getElementById('user-admin-filter').value = '';
            document.getElementById('user-active-filter').value = '';
            displayUsersTable(allUsers);
        }
        
        function displayUsersTable(users) {
            const container = document.getElementById('users-container');
            if (users.length === 0) {
                container.innerHTML = '<div class="no-products">Няма намерени потребители.</div>';
                return;
            }
            
            let html = '<table class="products-table"><thead><tr><th>№</th><th>Име</th><th>Имейл</th><th>Телефон</th><th>Град</th><th>Последна доставка</th><th>Администратор</th><th>Активен</th><th>Регистриран на</th><th>Действия</th></tr></thead><tbody>';
            
            users.forEach(user => {
                const joinedDate = new Date(user.created_at).toLocaleDateString();
                const adminBadge = user.is_admin ? '<span style="color: #27ae60; font-weight: bold;">Да</span>' : '<span style="color: #e74c3c;">Не</span>';
                const activeBadge = user.is_active ? '<span style="color: #27ae60; font-weight: bold;">Да</span>' : '<span style="color: #e74c3c;">Не</span>';
                
                let shipmentInfo = '—';
                if (user.last_delivery_method) {
                    shipmentInfo = user.last_delivery_method;
                    if (user.last_delivery_office) {
                        shipmentInfo += '<br/><small>' + htmlEscape(user.last_delivery_office) + '</small>';
                    }
                }
                
                html += `<tr>
                    <td>${user.id}</td>
                    <td class="product-name">${htmlEscape(user.fullname)}</td>
                    <td>${htmlEscape(user.email)}</td>
                    <td>${htmlEscape(user.phone || '—')}</td>
                    <td>${htmlEscape(user.city || '—')}</td>
                    <td>${shipmentInfo}</td>
                    <td>${adminBadge}</td>
                    <td>${activeBadge}</td>
                    <td>${joinedDate}</td>
                    <td class="action-buttons">
                        <button class="admin-btn" onclick="toggleUserAdmin(${user.id}, ${user.is_admin})">${user.is_admin ? 'Отнемане на права' : 'Направи администратор'}</button>
                        <button class="active-btn" onclick="toggleUserActive(${user.id}, ${user.is_active})">${user.is_active ? 'Деактивиране' : 'Активиране'}</button>
                        <button class="delete-btn" onclick="deleteUser(${user.id}, '${htmlEscape(user.fullname).replace(/'/g, "\\'")}')">Изтриване</button>
                    </td>
                </tr>`;
            });
            
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        
        // Banner Management Functions
        let allCategories = [];
        
        function updateFileName() {
            const fileInput = document.getElementById('image_input');
            const fileNameSpan = document.getElementById('file-name');
            if (fileInput && fileInput.files.length > 0) {
                fileNameSpan.textContent = 'Избран файл: ' + fileInput.files[0].name;
            } else {
                fileNameSpan.textContent = 'Избран файл: няма';
            }
        }
        
        function loadBanners() {
            fetch('api/get_banners.php')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('banners-container');
                    if (data.success && data.data.length > 0) {
                        container.innerHTML = '';
                        data.data.forEach((banner) => {
                            const statusText = banner.is_active ? '✓ Активен' : '✗ Неактивен';
                            
                            const bannerCard = document.createElement('div');
                            bannerCard.className = 'banner-card';
                            bannerCard.innerHTML = `
                                <div class="banner-preview">
                                    <img src="${htmlEscape(banner.image_url)}" alt="Banner" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27200%27 height=%27120%27%3E%3Crect fill=%27%23ccc%27 width=%27200%27 height=%27120%27/%3E%3C/svg%3E'">
                                </div>
                                <div class="banner-info">
                                    <div class="banner-details">
                                        <h3>Банер #${banner.id}</h3>
                                        <p><strong>Název:</strong> ${htmlEscape(banner.title)}</p>
                                        <p><strong>Статус:</strong> ${statusText}</p>
                                        <p><strong>Насочва към:</strong> ${htmlEscape(banner.link_url)}</p>
                                        <p><strong>Позиция:</strong> ${banner.sort_order}</p>
                                    </div>
                                    <div class="banner-actions">
                                        <button class="active-btn" onclick="toggleBannerActive(${banner.id}, ${banner.is_active})" style="margin-right: 5px;">
                                            ${banner.is_active ? 'Деактивиране' : 'Активиране'}
                                        </button>
                                        <button class="delete-btn" onclick="deleteBanner(${banner.id})">Изтриване</button>
                                    </div>
                                </div>
                            `;
                            container.appendChild(bannerCard);
                        });
                    } else {
                        container.innerHTML = '<div class="no-products">Няма добавени банери. Добавете чрез горната форма.</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Грешка при зареждане на банерите', 'error');
                });
        }

        function updateLinkOptions() {
            const linkType = document.getElementById('banner_link_type').value;
            const categorySelect = document.getElementById('banner_category_select');
            const customUrl = document.getElementById('banner_custom_url');
            const salePct = document.getElementById('sale-percent-group');
            const linkLabel = document.getElementById('link-label');
            const multiSelectHint = document.getElementById('multi-select-hint');

            // Hide all options
            categorySelect.style.display = 'none';
            customUrl.style.display = 'none';
            salePct.style.display = 'none';
            multiSelectHint.style.display = 'none';
            customUrl.removeAttribute('required');
            categorySelect.removeAttribute('required');

            if (linkType === 'sales') {
                salePct.style.display = 'block';
                linkLabel.textContent = '(Опционално)';
            } else if (linkType === 'category') {
                categorySelect.style.display = 'block';
                multiSelectHint.style.display = 'block';
                categorySelect.setAttribute('required', 'required');
                linkLabel.textContent = 'Избор категория *';
            } else if (linkType === 'custom') {
                customUrl.style.display = 'block';
                customUrl.setAttribute('required', 'required');
                linkLabel.textContent = 'URL адрес *';
            }
        }

        function submitAddBanner(event) {
            event.preventDefault();
            
            const formData = new FormData();
            const imageFile = document.getElementById('image_input').files[0];
            const linkType = document.getElementById('banner_link_type').value;
            
            if (!imageFile) {
                showMessage('Моля изберете изображение', 'error');
                return;
            }

            let linkValue = '';
            if (linkType === 'sales') {
                linkValue = '';
            } else if (linkType === 'category') {
                // Get all selected categories
                const categorySelect = document.getElementById('banner_category_select');
                const selectedOptions = Array.from(categorySelect.selectedOptions);
                const selectedValues = selectedOptions.map(option => option.value);
                
                if (selectedValues.length === 0) {
                    showMessage('Моля изберете поне една категория', 'error');
                    return;
                }
                linkValue = selectedValues.join(',');
            } else if (linkType === 'custom') {
                linkValue = document.getElementById('banner_custom_url').value;
                if (!linkValue) {
                    showMessage('Моля въведете URL адрес', 'error');
                    return;
                }
            }

            formData.append('image', imageFile);
            formData.append('link_type', linkType);
            formData.append('link_value', linkValue);
            
            if (linkType === 'sales') {
                const salePercent = document.getElementById('banner_sale_percent').value;
                if (salePercent) {
                    formData.append('sale_percent', salePercent);
                }
            }

            fetch('api/add_banner.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Банер добавен успешно!', 'success');
                    document.getElementById('add-banner-form').reset();
                    document.getElementById('file-name').textContent = 'Избран файл: няма';
                    loadBanners();
                } else {
                    showMessage(data.message || 'Грешка при добавяне на банер', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Грешка при добавяне на банер: ' + error.message, 'error');
            });
        }

        function toggleBannerActive(id, currentActive) {
            const formData = new FormData();
            formData.append('id', id);
            formData.append('is_active', currentActive ? 0 : 1);

            fetch('api/update_banner.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(currentActive ? 'Банер деактивиран' : 'Банер активиран', 'success');
                    loadBanners();
                } else {
                    showMessage(data.message || 'Грешка при обновяване', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Грешка: ' + error.message, 'error');
            });
        }

        function deleteBanner(id) {
            if (confirm('Сигурни ли сте, че искате да изтриете този банер?')) {
                const formData = new FormData();
                formData.append('id', id);

                fetch('api/delete_banner.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Банер изтрит успешно!', 'success');
                        loadBanners();
                    } else {
                        showMessage(data.message || 'Грешка при изтриване', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }

        function getLinkTypeText(linkType, linkValue, salePercent) {
            if (linkType === 'sales') {
                return `Продажби${salePercent > 0 ? ' (' + salePercent + '%)' : ''}`;
            } else if (linkType === 'category') {
                if (!linkValue) return 'Категория';
                // Handle both single and multiple categories (comma-separated)
                const categoryIds = linkValue.split(',').map(id => id.trim());
                const categoryNames = categoryIds.map(id => {
                    const cat = allCategories.find(c => c.id == id);
                    return cat ? cat.name : '';
                }).filter(name => name);
                return 'Категории: ' + categoryNames.join(', ');
            } else if (linkType === 'custom') {
                return 'URL: ' + linkValue;
            }
            return linkType;
        }
    </script>
</body>
</html>