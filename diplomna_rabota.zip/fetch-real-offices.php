<?php
/**
 * Fetch REAL offices directly from Speedy and Econt APIs
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/db.php';

echo "<h2>Fetching Real Offices from APIs</h2>";

// Disable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS=0");

// Clear old offices
$conn->query("DELETE FROM delivery_offices WHERE delivery_method_id IN (2, 3)");
$conn->query("ALTER TABLE delivery_offices AUTO_INCREMENT = 1");

echo "<p>Cleared old office data</p>";

// ============ SPEEDY API ============
echo "<h3>Fetching Speedy Offices...</h3>";

$speedy_token = getenv('SPEEDY_API_KEY');
if (!$speedy_token) {
    $speedy_token = 'YOUR_SPEEDY_API_KEY'; // Replace with real key
}

$speedy_url = 'https://api.speedy.bg/v1/offices';
$speedy_options = [
    'http' => [
        'method' => 'GET',
        'header' => "Authorization: Bearer " . $speedy_token . "\r\nContent-Type: application/json\r\n",
        'timeout' => 10
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false
    ]
];

$speedy_context = stream_context_create($speedy_options);

try {
    $speedy_response = @file_get_contents($speedy_url, false, $speedy_context);
    
    if ($speedy_response === false) {
        echo "<p style='color:red'>❌ Failed to fetch Speedy offices. Check API key.</p>";
    } else {
        $speedy_data = json_decode($speedy_response, true);
        
        if (isset($speedy_data['data']) && is_array($speedy_data['data'])) {
            $speedy_count = 0;
            
            foreach ($speedy_data['data'] as $office) {
                // Only insert active offices in Bulgaria
                if (isset($office['countryId']) && $office['countryId'] == 100) { // Bulgaria code
                    
                    $label = $office['name'] ?? 'Speedy Office';
                    $city = $office['city'] ?? 'Unknown';
                    $street = $office['address'] ?? '';
                    
                    $sql = "INSERT INTO delivery_offices (delivery_method_id, label, city, street, is_active) 
                            VALUES (2, ?, ?, ?, 1)";
                    
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("sss", $label, $city, $street);
                        if ($stmt->execute()) {
                            $speedy_count++;
                        }
                        $stmt->close();
                    }
                }
            }
            
            echo "<p>✅ Loaded <strong>$speedy_count</strong> Speedy offices from API</p>";
        } else {
            echo "<p style='color:orange'>⚠️ Unexpected Speedy API response format</p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Speedy API Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}


// ============ ECONT API ============
echo "<h3>Fetching Econt Offices...</h3>";

$econt_username = getenv('ECONT_USERNAME');
$econt_password = getenv('ECONT_PASSWORD');

if (!$econt_username || !$econt_password) {
    // Try default/demo credentials
    $econt_username = 'YOUR_ECONT_USERNAME';
    $econt_password = 'YOUR_ECONT_PASSWORD';
}

// Econt uses Basic Auth
$econt_url = 'https://api.econt.com/v1/offices';
$auth = base64_encode($econt_username . ':' . $econt_password);

$econt_options = [
    'http' => [
        'method' => 'GET',
        'header' => "Authorization: Basic " . $auth . "\r\nContent-Type: application/json\r\n",
        'timeout' => 10
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false
    ]
];

$econt_context = stream_context_create($econt_options);

try {
    $econt_response = @file_get_contents($econt_url, false, $econt_context);
    
    if ($econt_response === false) {
        echo "<p style='color:red'>❌ Failed to fetch Econt offices. Check API credentials.</p>";
    } else {
        $econt_data = json_decode($econt_response, true);
        
        if (isset($econt_data['offices']) && is_array($econt_data['offices'])) {
            $econt_count = 0;
            
            foreach ($econt_data['offices'] as $office) {
                $label = $office['name'] ?? 'Econt Office';
                $city = $office['city'] ?? 'Unknown';
                $street = $office['address'] ?? '';
                
                $sql = "INSERT INTO delivery_offices (delivery_method_id, label, city, street, is_active) 
                        VALUES (3, ?, ?, ?, 1)";
                
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sss", $label, $city, $street);
                    if ($stmt->execute()) {
                        $econt_count++;
                    }
                    $stmt->close();
                }
            }
            
            echo "<p>✅ Loaded <strong>$econt_count</strong> Econt offices from API</p>";
        } else {
            echo "<p style='color:orange'>⚠️ Unexpected Econt API response format</p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Econt API Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}


// Re-enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS=1");

// Show results
$speedy_count = $conn->query("SELECT COUNT(*) as c FROM delivery_offices WHERE delivery_method_id = 2")->fetch_assoc()['c'];
$econt_count = $conn->query("SELECT COUNT(*) as c FROM delivery_offices WHERE delivery_method_id = 3")->fetch_assoc()['c'];

echo "<h3 style='color: green; margin-top: 2rem;'>✅ Complete!</h3>";
echo "<p><strong>Speedy:</strong> $speedy_count offices</p>";
echo "<p><strong>Econt:</strong> $econt_count offices</p>";
echo "<p><strong>Total:</strong> " . ($speedy_count + $econt_count) . " offices loaded from APIs</p>";

echo "<hr>";
echo "<h3>Sample Offices</h3>";
$sample = $conn->query("SELECT * FROM delivery_offices LIMIT 10");
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Method</th><th>Label</th><th>City</th><th>Street</th></tr>";
while ($row = $sample->fetch_assoc()) {
    $method = ($row['delivery_method_id'] == 2) ? 'Speedy' : 'Econt';
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $method . "</td>";
    echo "<td>" . htmlspecialchars($row['label']) . "</td>";
    echo "<td>" . htmlspecialchars($row['city']) . "</td>";
    echo "<td>" . htmlspecialchars($row['street']) . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<p style='margin-top: 2rem;'><a href='payment.php'>Go to Payment Page</a></p>";
?>
