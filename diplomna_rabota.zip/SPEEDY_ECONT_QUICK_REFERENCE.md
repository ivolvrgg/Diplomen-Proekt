# Speedy & Econt Integration - Quick Reference Card

## ⭐ Important Update
Speedy **deprecated SOAP API** → **Use modern REST API**
- SOAP support ended: Sept 30, 2024
- SOAP decommissioned: Dec 31, 2024
- ✅ Your integration updated to REST API

## 📋 Quick Checklist

- [ ] Get Speedy REST API credentials: https://api.speedy.bg/web-api.html
- [ ] Get Econt credentials: https://www.econt.com/en/service/integrations/econt-api
- [ ] Update `.env` with credentials
- [ ] Run `setup-courier-api.bat` (Windows) or `bash setup-courier-api.sh` (Linux)
- [ ] Test: Visit `http://localhost/test-courier-api.php`
- [ ] Test offices: `curl http://localhost/api/get_delivery_offices.php?method=speedy`
- [ ] Test payment flow in your app

## 🔐 Credentials to Get

### Speedy REST API
**Email:** api.registration@speedy.bg
**You'll receive:**
- API Key
- Customer ID

### Econt
**Website:** https://www.econt.com/en/service/integrations/econt-api
**You'll receive:**
- API Username
- API Password
- Client System ID

## 📝 Update `.env`

```env
# Speedy (REST API - Modern)
SPEEDY_API_KEY=your_key_here
SPEEDY_CUSTOMER_ID=your_id_here
SPEEDY_API_URL=https://api.speedy.bg

# Econt
ECONT_USERNAME=your_username
ECONT_PASSWORD=your_password
ECONT_CLIENT_SYSTEM_ID=your_system_id

# Environment
COURIER_ENV=test  # Use 'test' for development
```

## 🚀 Setup Commands

### Windows
```bash
setup-courier-api.bat
```

### Linux/Mac
```bash
bash setup-courier-api.sh
```

## 🧪 Test Commands

### Test Offices Load
```bash
curl "http://localhost/api/get_delivery_offices.php?method=speedy&city=Sofia"
```

### Test Shipment Creation
```bash
curl -X POST http://localhost/api/create_shipment.php \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "delivery_method": "speedy",
    "delivery_office_id": 5,
    "recipient_name": "Test User",
    "recipient_phone": "0888123456",
    "weight": 1.5
  }'
```

### Web Test Interface
```
http://localhost/test-courier-api.php
```

## 📂 Important Files

| File | Purpose |
|------|---------|
| `.env` | Configuration (EDIT THIS!) |
| `test-courier-api.php` | Web test interface |
| `payment.php` | User-facing payment page |
| `api/get_delivery_offices.php` | Office API endpoint |
| `api/create_shipment.php` | Create shipment endpoint |
| `includes/speedy-service.php` | Speedy REST API implementation |
| `includes/econt-service.php` | Econt REST API implementation |
| `logs/courier_*.log` | API logs for debugging |

## 🔍 Troubleshooting

| Problem | Solution |
|---------|----------|
| "No offices available" | Run migration: `mysql ... < sql/migration_update_speedy_ekont.sql` |
| "API Key not found" | Check `.env` file has `SPEEDY_API_KEY=...` |
| Office count = 0 | Verify DB migration ran successfully |
| Request timeout | Check firewall allows HTTPS to api.speedy.bg |
| 401 Unauthorized | Verify API key is correct in `.env` |

## 📊 API Endpoints

```
GET  /api/get_delivery_offices.php?method=speedy&city=Sofia
POST /api/create_shipment.php
GET  /api/get_shipment_tracking.php?order_id=123
```

## 🔗 Resources

- **Speedy REST API:** https://api.speedy.bg/web-api.html
- **Speedy Examples:** https://services.speedy.bg/api/api_examples.html
- **Speedy Support:** api.support@speedy.bg
- **Econt API:** https://www.econt.com/en/service/integrations/econt-api

## 📖 Documentation

| Document | Purpose |
|----------|---------|
| `SPEEDY_ECONT_QUICKSTART.md` | **START HERE** - Quick setup |
| `SPEEDY_ECONT_SETUP.md` | Detailed setup guide |
| `SPEEDY_REST_API_MIGRATION.md` | REST API migration info |
| `SPEEDY_REST_API_REFERENCE.md` | Technical reference |
| `SPEEDY_ECONT_COMPLETE_SUMMARY.md` | Complete overview |

## ⚙️ Settings

### Development (Test Mode)
```env
COURIER_ENV=test
SPEEDY_API_URL=https://test-api.speedy.bg
# Safe - no real shipments sent
```

### Production (Live)
```env
COURIER_ENV=production
SPEEDY_API_URL=https://api.speedy.bg
# Real shipments sent to Speedy
```

## 💡 Tips

1. **Always test first** - Use `COURIER_ENV=test` initially
2. **Check logs** - `logs/courier_*.log` for debugging
3. **Use web test** - `test-courier-api.php` for quick checks
4. **Verify DB** - Run migrations if offices not loading
5. **Monitor API calls** - Check logs for real API interactions

## 🎯 Next Steps

1. Request credentials from Speedy & Econt
2. Update `.env` file
3. Run setup script
4. Test with `test-courier-api.php`
5. Try payment flow in your app
6. Monitor logs and errors
7. Switch to production when ready

---

**Version:** 2.0 (REST API)
**Last Updated:** March 16, 2026
**Status:** Ready for production (with credentials)
