<?php
/**
 * Import Speedy Offices from Text File
 * This script parses office data and imports it into the delivery_offices table
 */

require_once 'connection.php';

// First, check if we need to add working_hours column
try {
    $checkColumn = $conn->query("SHOW COLUMNS FROM delivery_offices LIKE 'working_hours'");
    if ($checkColumn->num_rows == 0) {
        echo "Adding working_hours column...\n";
        $conn->query("ALTER TABLE delivery_offices ADD COLUMN working_hours VARCHAR(500) DEFAULT NULL");
        echo "✓ Column added\n\n";
    }
} catch (Exception $e) {
    echo "Note: Could not add working_hours column (may already exist)\n\n";
}

// Read the office data from structured file
$filePath = __DIR__ . '/speedy_offices_structured.txt';

if (!file_exists($filePath)) {
    die("Error: File not found at $filePath\n");
}

$content = file_get_contents($filePath);
$lines = explode("\n", $content);

// Parse offices
$offices = array();
$currentOffice = null;
$headerSeen = false;

foreach ($lines as $lineNum => $line) {
    $line = trim($line);
    
    if (empty($line)) continue;
    
    // Skip the main header
    if ($line === 'НАСЕЛЕНИЕ МЯСТО АДРЕС' || $line === 'НАСЕЛЕНО МЯСТО АДРЕС') {
        $headerSeen = true;
        continue;
    }
    
    // Check if line is a city name (contains city marker pattern or office suffix)
    if (preg_match('/^[А-Я][А-Я\s\-\.]+?(?:\‐|$|(\(|[\[]))/u', $line)) {
        // Extract city name (remove any (SPS) or [NUMBER] markers)
        $cityName = preg_replace('/\s*[\[\(].*[\]\)].*$/u', '', $line);
        $cityName = preg_replace('/\‐.*$/', '', $cityName); // Remove anything after dash
        $cityName = trim($cityName);
        
        // Skip pure section headers
        if (empty($cityName) || strlen($cityName) < 2) {
            continue;
        }
        
        // Save previous office if exists
        if ($currentOffice && !empty($currentOffice['city']) && !empty($currentOffice['address'])) {
            $offices[] = $currentOffice;
        }
        
        $currentOffice = array(
            'city' => $cityName,
            'address' => '',
            'weekday_hours' => '',
            'saturday_hours' => ''
        );
    }
    // Check if line contains address (starts with "Адрес:")
    else if (strpos($line, 'Адрес:') === 0 && $currentOffice !== null) {
        $currentOffice['address'] = trim(str_replace('Адрес:', '', $line));
    }
    
    // Check if line contains working hours
    else if (strpos($line, 'Работно време') === 0 && $currentOffice !== null) {
        // Parse pattern: "Работно време (пн. - пт.): 09:00 - 18:00; Работно време (съб.): 09:00 - 14:00"
        if (preg_match('/Работно време\s*\([^)]+\):\s*([^;]+)(?:;\s*Работно време\s*\([^)]+\):\s*(.+))?/u', $line, $matches)) {
            $currentOffice['weekday_hours'] = trim($matches[1]);
            if (isset($matches[2]) && !empty($matches[2])) {
                $currentOffice['saturday_hours'] = trim($matches[2]);
            }
        }
    }
}

// Don't forget the last office
if ($currentOffice && !empty($currentOffice['city']) && !empty($currentOffice['address'])) {
    $offices[] = $currentOffice;
}

echo "Parsed " . count($offices) . " offices\n\n";

if (empty($offices)) {
    die("Error: No offices found in file\n");
}

echo "Sample offices:\n";
for ($i = 0; $i < min(5, count($offices)); $i++) {
    echo "  " . $i+1 . ". " . $offices[$i]['city'];
    if (!empty($offices[$i]['address'])) {
        echo " - " . substr($offices[$i]['address'], 0, 45);
    }
    echo "\n";
}
echo "\n";

// Delete existing Speedy offices (delivery_method_id = 2)
echo "Deleting existing Speedy offices from database...\n";
$delResult = $conn->query("DELETE FROM delivery_offices WHERE delivery_method_id = 2");
if ($delResult) {
    $conn->query("ALTER TABLE delivery_offices AUTO_INCREMENT = 1");
    echo "✓ Deleted existing records\n\n";
} else {
    echo "⚠ Note: " . $conn->error . "\n\n";
}

// Insert new offices
echo "Importing offices to database...\n";
$successCount = 0;
$errorCount = 0;

foreach ($offices as $idx => $office) {
    // Clean up city name
    $cityName = trim($office['city']);
    
    $city = $conn->real_escape_string($cityName);
    $street = $conn->real_escape_string($office['address']);
    $label = "Speedy - " . $cityName;
    $label = $conn->real_escape_string($label);
    
    $hours = $office['weekday_hours'];
    if (!empty($office['saturday_hours'])) {
        $hours .= "; Събота: " . $office['saturday_hours'];
    }
    $hours = $conn->real_escape_string($hours);
    
    $sql = "INSERT INTO delivery_offices (delivery_method_id, label, city, street, working_hours, is_active) 
            VALUES (2, '$label', '$city', '$street', '$hours', 1)";
    
    if ($conn->query($sql)) {
        $successCount++;
        if (($idx + 1) % 50 == 0) {
            echo "  Processing... " . ($idx + 1) . " / " . count($offices) . "\n";
        }
    } else {
        $errorCount++;
        echo "⚠ Error inserting " . $cityName . ": " . $conn->error . "\n";
    }
}

echo "\n✓ Import Complete!\n";
echo "  Successfully imported: $successCount offices\n";
if ($errorCount > 0) {
    echo "  Errors: $errorCount offices\n";
}

// Show final summary
$result = $conn->query("SELECT COUNT(*) as cnt FROM delivery_offices WHERE delivery_method_id = 2");
$row = $result->fetch_assoc();
echo "\nTotal Speedy offices now in database: " . $row['cnt'] . "\n";

// Show sample of imported offices
$sample = $conn->query("SELECT city, street, working_hours FROM delivery_offices WHERE delivery_method_id = 2 LIMIT 5");
echo "\nSample of imported offices:\n";
while ($row = $sample->fetch_assoc()) {
    echo "  - " . $row['city'] . ": " . substr($row['street'], 0, 30) . "...\n";
}

$conn->close();
?>
