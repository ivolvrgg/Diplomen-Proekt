# Google OAuth 2.0 Setup Guide

## Quick Start

### 1. ✅ No Dependencies Needed!

This implementation uses native PHP cURL - **no Composer installation required!**

### 2. Get Google OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. **Create a new project:**
   - Click "Select a Project" at the top
   - Click "New Project"
   - Enter name: `Dronche` (or your app name)

3. **Enable Google+ API:**
   - Search for "Google+ API"
   - Click "Enable"

4. **Create OAuth 2.0 Credentials:**
   - Go to "Credentials" in the left menu
   - Click "Create Credentials" → "OAuth Client ID"
   - Choose "Web application"
   - For **Name**: `Dronche Web App`
   - Under **Authorized JavaScript origins** (origins only, no paths):
     - `http://localhost`
     - `https://yourdomain.com` (for production)
   - Under **Authorized redirect URIs** (full URLs with paths):
     - `http://localhost/api/google-callback.php`
     - `https://yourdomain.com/api/google-callback.php`
   - Click **Create**
   - Copy `Client ID` and `Client Secret`

### ⚠️ IMPORTANT - Two Different URI Fields

When you see the error **"Invalid Origin: URIs must not contain a path"**:

| Field | Example | Notes |
|-------|---------|-------|
| **Authorized JavaScript origins** | `http://localhost` | ✅ **No path** - just the domain |
| **Authorized redirect URIs** | `http://localhost/api/google-callback.php` | ✅ **With path** - full URL with callback file |

### 3. Configure Your Application

Edit `config/google.php` and replace the placeholder values:

```php
define('GOOGLE_CLIENT_ID', 'YOUR_CLIENT_ID_HERE.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'YOUR_CLIENT_SECRET_HERE');
define('GOOGLE_REDIRECT_URI', 'http://localhost/api/google-callback.php');
```

### 4. Run Database Migration

1. Open your browser and go to: `http://localhost/run-google-migration.php`
2. This will add the `google_id` column to your `users` table
3. You should see a success message

### 5. Test It Out!

1. Go to your login page: `http://localhost/user_login.php`
2. Click **"Вход с Google"** button
3. Sign in with your Google account
4. You'll be automatically logged in or registered!

## Features

✅ **Automatic Registration**: First-time Google users are automatically registered
✅ **Account Linking**: If a user already registered with their email, Google ID is linked
✅ **Profile Picture**: Google profile picture is downloaded and saved
✅ **No Password Required**: OAuth users don't need to set a password
✅ **Session Management**: Works seamlessly with your existing session system

## How It Works

1. User clicks "Sign in with Google"
2. Redirects to Google OAuth consent screen
3. User approves access
4. Google redirects back with authorization code
5. Server exchanges code for user information
6. User is created/logged in
7. Redirects to homepage

## Troubleshooting

### "Invalid Origin: URIs must not contain a path" Error
- You're putting a full URL in the **Authorized JavaScript origins** field
- **Fix:** Remove the path - only keep the domain:
  - ❌ Wrong: `http://localhost/api/google-callback.php`
  - ✅ Correct: `http://localhost`
- The full path goes in **Authorized redirect URIs** field instead

### "Redirect URI mismatch" Error
- Make sure the redirect URL in Google Cloud Console exactly matches `GOOGLE_REDIRECT_URI` in your config
- Check the two fields:
  - **Authorized JavaScript origins**: `http://localhost` (no path)
  - **Authorized redirect URIs**: `http://localhost/api/google-callback.php` (with path)

### "Client ID not found" Error
- Verify you've updated `config/google.php` with your credentials
- Check for typos in the Client ID

### Database Error
- Check that your database connection works
- Run `php run-google-migration.php` from the command line or visit the URL in browser

## File Structure

```
config/google.php              - Google OAuth configuration
api/google-callback.php        - OAuth callback handler
includes/google_auth.php       - Helper functions
run-google-migration.php       - Database migration script
user_login.php                 - Updated with Google button
user_register.php              - Updated with Google button
css/user_login.css             - Google button styles
css/user_register.css          - Google button styles
```

## Security Notes

- Never commit `config/google.php` with real credentials to version control
- Store credentials in environment variables for production:
  ```php
  define('GOOGLE_CLIENT_ID', getenv('GOOGLE_CLIENT_ID'));
  define('GOOGLE_CLIENT_SECRET', getenv('GOOGLE_CLIENT_SECRET'));
  ```
- Always use HTTPS in production
- Validate tokens on the server side (already done in the code)

## Production Checklist

- [ ] Create new OAuth app for production domain
- [ ] Update redirect URLs to production domain
- [ ] Use environment variables for credentials
- [ ] Switch to HTTPS
- [ ] Test registration and login flow
- [ ] Test guest cart merging
- [ ] Test profile picture download
