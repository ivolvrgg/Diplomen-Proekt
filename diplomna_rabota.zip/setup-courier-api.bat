@echo off
REM Speedy & Econt API Integration Setup Script (Windows)
REM Run this to set up the courier integration

echo ============================================
echo Speedy ^& Econt API Integration Setup
echo ============================================
echo.

REM Database credentials
set DB_HOST=localhost
set DB_USER=root
set DB_PASS=
set DB_NAME=dron_db
set DB_PORT=3307

echo Setting up database...
echo - Host: %DB_HOST%:%DB_PORT%
echo - Database: %DB_NAME%
echo.

REM 1. Run migration for delivery setup
echo [1/3] Running courier setup migration...
mysql -h %DB_HOST% -u %DB_USER% -P %DB_PORT% %DB_NAME% < sql\migration_courier_setup.sql
if %errorlevel% equ 0 (
    echo [OK] Courier setup migration completed
) else (
    echo [ERROR] Error running courier setup migration
    pause
    exit /b 1
)
echo.

REM 2. Run migration for Speedy and Econt offices
echo [2/3] Loading Speedy and Econt office locations...
mysql -h %DB_HOST% -u %DB_USER% -P %DB_PORT% %DB_NAME% < sql\migration_update_speedy_ekont.sql
if %errorlevel% equ 0 (
    echo [OK] Office locations loaded successfully
) else (
    echo [ERROR] Error loading office locations
    pause
    exit /b 1
)
echo.

REM 3. Check .env file
echo [3/3] Checking configuration...
if not exist .env (
    echo [WARN] .env file not found. Please create one.
    REM Uncomment next line to auto-create .env
    REM (echo.) > .env
)

findstr /M "SPEEDY_USERNAME" .env >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Configuration file exists
) else (
    echo [WARN] Add your courier credentials to .env:
    echo   - SPEEDY_USERNAME
    echo   - SPEEDY_PASSWORD
    echo   - SPEEDY_CUSTOMER_CODE
    echo   - ECONT_USERNAME
    echo   - ECONT_PASSWORD
    echo   - ECONT_CLIENT_SYSTEM_ID
)
echo.

echo ============================================
echo Setup Complete!
echo ============================================
echo.
echo Next steps:
echo 1. Update .env with your courier credentials
echo 2. Test APIs:
echo    curl "http://localhost/api/get_delivery_offices.php?method=speedy^&city=Sofia"
echo 3. Check logs in: logs\courier_*.log
echo.
pause
