# Speedy & Econt API Integration Guide

## Overview
This guide covers complete integration with Speedy and Econt courier APIs for:
- Loading delivery office locations
- Creating shipments
- Tracking shipments
- Computing delivery estimates

## Step 1: Get API Credentials

### For Speedy (Modern REST API - Recommended):
**⚠️ IMPORTANT: Speedy deprecated their SOAP API (EPS):**
- **SOAP API (EPS) deprecated:** Technical support ended Sept 30, 2024
- **Alternative:** Use modern REST API (https://api.speedy.bg)
- **SOAP will be decommissioned:** December 31, 2024

**Recommended: Use REST API**
1. Visit: https://api.speedy.bg/web-api.html
2. Request test credentials: api.registration@speedy.bg
3. You'll need:
   - **API Key**
   - **Customer ID** (your business account)

**API Resources:**
- REST API Docs: https://api.speedy.bg/web-api.html
- Code Examples: https://services.speedy.bg/api/api_examples.html
- Support: api.support@speedy.bg
- Address Form Example: https://services.speedy.bg/address_form/?language=EN

### For Econt:
1. Visit https://www.econt.com/en/service/integrations/econt-api
2. Request API credentials
3. You'll need:
   - **API Username**
   - **API Password**
   - **Client System ID**

**Econt API Documentation:**
- https://www.econt.com/en/service/integrations/econt-api
- They use REST API

## Step 2: Store Credentials Securely

Update your `.env` file:

```env
# Speedy REST API Credentials (Modern - Recommended)
SPEEDY_API_KEY=your_api_key_here
SPEEDY_CUSTOMER_ID=your_customer_id
SPEEDY_API_URL=https://api.speedy.bg
# For test:
# SPEEDY_API_URL=https://test-api.speedy.bg

# Econt API Credentials
ECONT_USERNAME=your_username
ECONT_PASSWORD=your_password
ECONT_CLIENT_SYSTEM_ID=your_system_id
ECONT_API_URL=https://api.econt.com/v1

# Environment
COURIER_ENV=test  # or 'production' when ready
```

## Step 3: Database Preparation

Execute the migration to load all office locations:

```bash
mysql -u root -p dron_db < sql/migration_update_speedy_ekont.sql
```

This will:
- Create delivery_offices table with 300+ Speedy offices
- Create delivery_offices table with 200+ Econt offices
- Set correct pricing (Speedy €4.99, Econt €3.00)

## Step 4: API Implementation Files

The following files will be created:
- `api/delivery-service.php` - Core delivery service class
- `api/speedy-service.php` - Speedy API wrapper
- `api/econt-service.php` - Econt API wrapper
- `api/get_delivery_offices.php` - Endpoint for frontend
- `api/create_shipment.php` - Endpoint to create shipments
- `api/get_shipment_tracking.php` - Endpoint for tracking

## Step 5: Frontend Integration

Your payment.php already has:
- Office selection dropdowns
- Delivery method selection
- Address input for courier

The frontend will automatically populate offices from the database when you select Speedy or Econt.

## Testing

### 1. Load Office Data
```bash
curl http://localhost/api/get_delivery_offices.php?city=Sofia&method=speedy
```

### 2. Create Test Shipment
```bash
curl -X POST http://localhost/api/create_shipment.php \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "delivery_method": "speedy",
    "delivery_office_id": 5,
    "recipient_name": "John Doe",
    "recipient_phone": "0888123456"
  }'
```

### 3. Get Shipment Tracking
```bash
curl http://localhost/api/get_shipment_tracking.php?shipment_id=1&method=speedy
```

## Notes

- **Speedy** typically takes 2-4 business days for delivery
- **Econt** typically takes 2-3 business days
- Both offer pickup at office or home delivery
- You need to register as a business customer for API access
- Test credentials are recommended before going live

## Troubleshooting

### Connection Issues
- Verify firewall allows outbound HTTPS on port 443
- Test with `curl` command line tool
- Check network logs in browser DevTools

### Office Not Found
- Ensure migration SQL was executed
- Check database with: `SELECT * FROM delivery_offices WHERE delivery_method_id = 2 LIMIT 5;`

### Shipment Creation Fails
- Verify all required fields are provided
- Check sender address on file with courier
- Ensure recipient phone format is correct

## Security Notes

- Never commit `.env` file to version control
- Use test credentials during development
- Enable HTTPS for production
- Validate all inputs server-side
- Log API requests securely (without passwords)
