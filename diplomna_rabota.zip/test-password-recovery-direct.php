<?php
// Direct test of the entire password recovery flow
require_once 'config/db.php';

echo "TEST RESULTS:\n";
echo "=============\n\n";

// 1. Check database columns
echo "1. DATABASE COLUMNS:\n";
$result = $conn->query("DESCRIBE users");
$has_reset_code = false;
$has_reset_expires = false;

while ($row = $result->fetch_assoc()) {
    if ($row['Field'] === 'reset_code') $has_reset_code = true;
    if ($row['Field'] === 'reset_code_expires') $has_reset_expires = true;
}

echo "   reset_code: " . ($has_reset_code ? "YES ✓" : "NO ✗") . "\n";
echo "   reset_code_expires: " . ($has_reset_expires ? "YES ✓" : "NO ✗") . "\n\n";

// 2. Check email config
echo "2. EMAIL CONFIG:\n";
$mail = require 'config/mail.php';
echo "   From: " . $mail['from_email'] . "\n";
echo "   Host: " . $mail['host'] . "\n";
echo "   Port: " . $mail['port'] . "\n";
echo "   Username: " . $mail['username'] . "\n\n";

// 3. Check EmailHelper class
echo "3. EMAIL HELPER CLASS:\n";
if (file_exists('includes/EmailHelper.php')) {
    require_once 'includes/EmailHelper.php';
    echo "   File exists: YES ✓\n";
    try {
        $helper = new EmailHelper();
        echo "   Can instantiate: YES ✓\n";
    } catch (Exception $e) {
        echo "   Can instantiate: NO ✗ (" . $e->getMessage() . ")\n";
    }
} else {
    echo "   File exists: NO ✗\n";
}

echo "\n4. PASSWORD RECOVERY FILES:\n";
$files = [
    'password-recovery.php',
    'password-reset.php',
    'api/password-recovery.php'
];

foreach ($files as $file) {
    $exists = file_exists($file);
    echo "   $file: " . ($exists ? "YES ✓" : "NO ✗") . "\n";
}

echo "\n5. MANUAL TEST - Send code:\n";
if (isset($helper)) {
    // Create test user
    $test_email = 'test@example.com';
    $test_code = '123456';
    
    // Clear old test data
    $conn->query("DELETE FROM users WHERE email = 'test@example.com'");
    
    // Insert test user
    $stmt = $conn->prepare("INSERT INTO users (id, fullname, email, is_active) VALUES (?, ?, ?, 1)");
    $test_id = uniqid();
    $stmt->bind_param("sss", $test_id, $test_email, $test_email);
    $stmt->execute();
    
    // Try to send password recovery
    $result = $helper->sendPasswordRecoveryCode($test_email, $test_code);
    echo "   Send to $test_email: " . ($result ? "SUCCESS ✓" : "FAILED ✗") . "\n";
    
    // Check logs
    if (file_exists('logs/email-sent.log')) {
        echo "\n   Email log (last 3 lines):\n";
        $lines = array_slice(file('logs/email-sent.log'), -3);
        foreach ($lines as $line) {
            echo "   " . trim($line) . "\n";
        }
    }
}

echo "\n\nDONE\n";
?>
