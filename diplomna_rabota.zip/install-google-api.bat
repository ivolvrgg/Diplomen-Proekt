@echo off
cd /d C:\xampp\htdocs\Diplomna_rabota
echo Installing Google API Client...
echo Creating composer autoloader...
"C:\xampp\php\php.exe" -r "if(!is_dir('vendor')) mkdir('vendor');"
echo.
"C:\xampp\php\php.exe" composer-setup.php --disable-tls
echo.
echo Running: composer require google/apiclient
"C:\xampp\php\php.exe" composer.phar require google/apiclient --no-interaction --disable-tls
echo Installation complete!
pause
