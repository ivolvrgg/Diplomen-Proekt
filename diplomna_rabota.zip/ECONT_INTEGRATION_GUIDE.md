# Econt Integration Guide

## Overview

Econt is a leading courier and parcel delivery service in Bulgaria, Romania, and Greece. This guide walks you through integrating Econt's API into your Dronche.BG e-commerce platform.

## Features Implemented

✅ **Office/ParcelShop Loading** - Load Econt locations from database or live API  
✅ **Shipment Creation** - Create shipments directly with Econt  
✅ **Real-time Tracking** - Track shipments using barcode numbers  
✅ **Address Validation** - Validate Bulgarian addresses  
✅ **Test Mode** - Safe development without real transactions  
✅ **Production Ready** - Full authentication and error handling  

## Getting Started

### 1. Register with Econt

1. Visit [Econt Integrations](https://www.econt.com/en/service/integrations/econt-api)
2. Click "Request Integration" or contact support
3. Provide your business details:
   - Company name
   - Contact person
   - Phone number
   - Email address
   - Business registration details

4. You'll receive:
   - **Username** (for e-Econt system)
   - **Password** (for e-Econt system)
   - **Client System ID** (optional, for API integration)
   - API documentation access

### 2. Get API Credentials

After registration, log in to [e-Econt](https://econt.com/) to retrieve:

- **Username**: Your registered username
- **Password**: Your account password
- **Client System ID** (optional): If you have multiple systems

**Important**: Credentials must match exactly (case-sensitive, including spaces).

### 3. Configure Environment Variables

Add these to your `.env` file:

```env
# Econt API Configuration
ECONT_USERNAME=your_username_here
ECONT_PASSWORD=your_password_here
ECONT_CLIENT_SYSTEM_ID=your_system_id_here
ECONT_API_URL=https://api.econt.com/v1
COURIER_ENV=test
```

**Test vs Production**:
- `COURIER_ENV=test` - Uses test database, mock shipments
- `COURIER_ENV=production` - Real API calls, real shipments

### 4. Update Database

Run the migration to populate Econt offices:

```bash
mysql -u root -P 3307 dron_db < sql/migration_update_speedy_ekont.sql
```

This imports 200+ Econt ParcelShops across Bulgaria.

## API Architecture

### Authentication

Econt uses **Basic HTTP Authentication**:

```
Authorization: Basic base64(username:password)
```

The system automatically handles this - no manual token management needed.

### Key Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/locations/list` | GET | Get list of ParcelShops |
| `/shipments` | POST | Create new shipment |
| `/tracking` | GET | Get shipment tracking events |

### Supported Services

- **APT (Automated Parcel Terminal)** - ParcelShop delivery
- **Express Service** - Fast delivery option (with contract)
- **Standard Service** - Regular delivery

## Usage Examples

### Get Econt Offices

**Frontend**:
```javascript
// Load offices dynamically
const offices = await fetch('/api/get_delivery_offices.php?method=econt&city=Sofia')
    .then(r => r.json());
console.log(offices.data.offices);
```

**Backend**:
```php
require_once 'includes/delivery-service.php';
require_once 'includes/econt-service.php';

$service = DeliveryServiceFactory::getService('econt');
$result = $service->getOffices('Sofia');

if ($result['success']) {
    foreach ($result['data']['offices'] as $office) {
        echo $office['name'] . ' - ' . $office['city'];
    }
}
```

### Create Shipment

```php
$shipment_data = [
    'order_id' => 123,
    'recipient_name' => 'John Doe',
    'recipient_phone' => '+359 88 123 45 67',
    'delivery_office_id' => 456,
    'weight' => 0.5,
    'contents' => 'Electronics'
];

$result = $service->createShipment($shipment_data);

if ($result['success']) {
    $shipment_id = $result['data']['shipment_id'];
    // Store shipment_id in order for tracking
}
```

### Track Shipment

```php
$tracking = $service->getTracking('ECONT_ABC123');

foreach ($tracking['data']['events'] as $event) {
    echo $event['timestamp'] . ' - ' . $event['description'];
}
```

## Integration Points

### 1. Payment Flow (payment.php)

UI is already integrated:
- Radio button for "econt" delivery method
- Office selection dropdown (with offices from database)
- Hidden fields to store selected office ID

### 2. Order Processing (api/create_shipment.php)

When customer chooses Econt:
1. Selected office ID is read from form
2. `EcontService::createShipment()` is called
3. Shipment ID is stored in orders table
4. Customer receives confirmation

### 3. Order Tracking (api/get_shipment_tracking.php)

When customer views order:
1. Shipment ID is retrieved from database
2. `EcontService::getTracking()` is called
3. Latest tracking events are displayed
4. Customer can track in real-time

## Database Schema

### delivery_offices Table

```sql
CREATE TABLE delivery_offices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    delivery_method_id INT,
    label VARCHAR(255),
    city VARCHAR(100),
    street VARCHAR(255),
    phone VARCHAR(20),
    working_hours VARCHAR(100),
    is_active TINYINT(1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**delivery_method_id = 3** for Econt ParcelShops

### orders Table (Extended)

```sql
ALTER TABLE orders ADD COLUMN external_shipment_id VARCHAR(100);
ALTER TABLE orders ADD COLUMN shipment_status VARCHAR(50);
ALTER TABLE orders ADD COLUMN shipment_created_at DATETIME;
ALTER TABLE orders ADD COLUMN shipment_updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP;
```

## Error Handling

### Common Errors

| Error | Solution |
|-------|----------|
| "Authentication failed" | Check username/password in .env |
| "Invalid office ID" | Verify office exists in database |
| "API Error: HTTP 401" | Credentials incorrect or expired |
| "API Error: HTTP 400" | Invalid shipment data (required fields missing) |

### Logging

All API interactions are logged to:
```
logs/courier_YYYY-MM-DD.log
```

Check logs for debugging:
```bash
tail -f logs/courier_2026-03-16.log
```

## Testing

### Test Mode

With `COURIER_ENV=test`:
- No real API calls are made
- Shipments are created with test IDs (ECONT_TST_*)
- Tracking returns mock data
- Safe for development

### Manual Testing

Use the test interface:
```
http://localhost/test-courier-api.php
```

This page checks:
- Database connectivity
- Configuration variables
- API credentials validity
- Office data loading
- Shipment creation

### Production Testing

Before going live:

1. **Test with Econt**:
   - Use test credentials first
   - Create real test shipments
   - Verify delivery

2. **Verify Settings**:
   - Check COURIER_ENV is set to test initially
   - Test office loading with live API
   - Verify tracking works

3. **Go Live**:
   - Update COURIER_ENV to production
   - Monitor shipments in e-Econt
   - Check logs for errors

## Advanced Features

### Custom Request Headers

For special implementations, you can pass custom headers:

```php
$result = $service->makeRequest(
    'POST',
    '/shipments',
    $data,
    ['X-Custom-Header: value']
);
```

### Address Validation

Econt API validates addresses automatically:
- City must be in service area
- Street must be valid
- Postcode is verified

Addresses are rejected if:
- City not served by Econt in Bulgaria
- Invalid postcode format
- Incomplete address data

### Multi-Language Support

Econt API returns responses in Bulgarian (BG) - the system handles this automatically.

For English interface, strings are pre-translated in the service class.

## Support & Resources

### Documentation Links

- **Official Econt API**: https://www.econt.com/en/service/integrations/econt-api
- **e-Econt Login**: https://econt.com/
- **Integration Support**: support_integrations@econt.com
- **Phone Support**: +359 7001 7300 (Online Shop Integration)

### Emergency Support

For urgent integration issues:
- **Phone**: +359 88 410 50 88
- **Email**: support_integrations@econt.com
- **Hours**: Business hours (Mon-Fri, 08:00-17:00 EET)

## Troubleshooting

### Debug Mode

Enable detailed logging:

```php
// In econt-service.php, top of constructor
error_log("Econt Service Initialized");
error_log("API URL: " . $this->api_url);
error_log("Username: " . (empty($this->username) ? "EMPTY" : "SET"));
```

### Common Issues

**Issue: "No offices available"**
- Check database migration ran successfully
- Verify offices table has data: `SELECT COUNT(*) FROM delivery_offices WHERE delivery_method_id = 3;`
- Try refreshing office cache

**Issue: "Shipment creation failed"**
- Verify all required fields are provided
- Check office_id is valid
- Ensure phone number is in correct format

**Issue: "Tracking shows no events"**
- In test mode, tracking is limited
- In production, shipments take time to update
- Check shipment ID format is correct

## Migration Guide

### From Manual Processing to Automated

If you were previously processing Econt orders manually:

1. **Update existing shipments**:
   ```sql
   -- Map old shipment IDs to orders
   UPDATE orders SET external_shipment_id = NULL WHERE shipment_status IS NULL;
   ```

2. **Test with new shipments**:
   - Process test orders through payment flow
   - Verify shipments appear in e-Econt
   - Check tracking updates properly

3. **Go live**:
   - Set COURIER_ENV=production
   - Monitor first shipment wave
   - Verify customer confirmations reach recipients

## Security Best Practices

1. **Protect Credentials**
   - Store in `.env` file (not git)
   - Use environment variables only
   - Never log credentials

2. **Validate Input**
   - All customer data is sanitized
   - Phone numbers are formatted
   - Addresses are validated

3. **HTTPS Required**
   - All API calls use HTTPS
   - SSL verification enabled in production
   - Self-signed certs disabled in production

4. **Rate Limiting**
   - Econt API has rate limits
   - Implement exponential backoff for retries
   - Cache office lists when possible

## Performance Optimization

### Office Caching

Database is used as cache for offices:
- Avoid repeated API calls
- Load at server startup
- Refresh manually when needed

### Shipment Batch Processing

For bulk shipments:

```php
// Process multiple shipments
foreach ($orders as $order) {
    $service->createShipment($order);
    sleep(1); // Rate limiting
}
```

### Tracking Batch Updates

Implement scheduled tracking updates:

```bash
# Via cron job
*/5 * * * * curl http://localhost/api/update-tracking.php
```

## Future Enhancements

Planned features:

- [ ] Pickup request automation
- [ ] COD (Cash on Delivery) support
- [ ] International shipping beyond BG/RO/GR
- [ ] Label printing (PDF/ZPL)
- [ ] Real-time rate calculation
- [ ] Return shipment automation
- [ ] Webhook integration for delivery notifications
- [ ] SMS/Email notifications to customers

## License & Terms

- **Econt Services**: Subject to Econt Terms of Service
- **Integration Code**: Your proprietary use
- **Data Privacy**: GDPR compliant

See [Econt Terms](https://www.econt.com/en) for full service terms.

## Version History

**v1.0** - Initial integration (Mar 2026)
- Basic office loading
- Shipment creation
- Real-time tracking
- Test mode support
- Database pre-populated with 200+ offices

---

**Last Updated**: March 16, 2026  
**Maintained by**: Dronche.BG Development Team  
**Status**: Production Ready ✅
