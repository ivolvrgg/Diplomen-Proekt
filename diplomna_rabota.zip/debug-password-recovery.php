<?php
echo "<!DOCTYPE html>
<html>
<head>
    <title>Password Recovery Debug</title>
    <style>
        body { font-family: Arial; max-width: 600px; margin: 20px auto; }
        .check { margin: 15px 0; padding: 10px; border-left: 4px solid #ccc; }
        .pass { border-left-color: green; background: #f0fff0; }
        .fail { border-left-color: red; background: #fff0f0; }
        code { background: #f0f0f0; padding: 3px 6px; }
    </style>
</head>
<body>
<h1>🔧 Password Recovery Debug</h1>";

try {
    require_once 'config/db.php';
    
    // Check 1: Database columns
    echo "<h2>1. Database Columns Check</h2>";
    $result = $conn->query('DESCRIBE users');
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[$row['Field']] = $row['Type'];
    }
    
    if (isset($columns['reset_code']) && isset($columns['reset_code_expires'])) {
        echo "<div class='check pass'>✓ Both columns exist:
            <ul>
            <li>reset_code: " . $columns['reset_code'] . "</li>
            <li>reset_code_expires: " . $columns['reset_code_expires'] . "</li>
            </ul></div>";
    } else {
        echo "<div class='check fail'>✗ Missing columns! 
            <p>Found columns: " . implode(', ', array_keys($columns)) . "</p>
            <p><a href='run-password-recovery-migration.php'>Run Migration</a></p></div>";
    }
    
    // Check 2: Email config
    echo "<h2>2. Email Configuration Check</h2>";
    $mail_config = require 'config/mail.php';
    
    if ($mail_config['mailer'] === 'smtp' && $mail_config['host'] && $mail_config['username']) {
        echo "<div class='check pass'>✓ Email configured:
            <ul>
            <li>Mailer: {$mail_config['mailer']}</li>
            <li>Host: {$mail_config['host']}</li>
            <li>From: {$mail_config['from_email']}</li>
            </ul></div>";
    } else {
        echo "<div class='check fail'>✗ Email not configured properly</div>";
    }
    
    // Check 3: EmailHelper class
    echo "<h2>3. EmailHelper Class Check</h2>";
    if (file_exists('includes/EmailHelper.php')) {
        require_once 'includes/EmailHelper.php';
        $helper = new EmailHelper();
        echo "<div class='check pass'>✓ EmailHelper class loaded successfully</div>";
    } else {
        echo "<div class='check fail'>✗ EmailHelper.php not found</div>";
    }
    
    // Check 4: Password recovery files
    echo "<h2>4. Files Check</h2>";
    $files = [
        'password-recovery.php' => 'Recovery request page',
        'password-reset.php' => 'Reset password page',
        'api/password-recovery.php' => 'API endpoint'
    ];
    
    foreach ($files as $file => $desc) {
        $exists = file_exists($file);
        $status = $exists ? 'pass' : 'fail';
        $symbol = $exists ? '✓' : '✗';
        echo "<div class='check $status'>$symbol $desc: <code>$file</code></div>";
    }
    
    // Check 5: Test email sending
    echo "<h2>5. Test Email Sending</h2>";
    if (isset($helper)) {
        $test_result = $helper->sendPasswordRecoveryCode('test@example.com', '123456');
        if ($test_result) {
            echo "<div class='check pass'>✓ Email sending works (test to test@example.com)</div>";
        } else {
            echo "<div class='check fail'>✗ Email sending failed - check <code>logs/email-errors.log</code></div>";
        }
    }
    
    echo "<h2>Ready to Test!</h2>";
    echo "<p><a href='password-recovery.php' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; display: inline-block;'>Go to Password Recovery Page</a></p>";
    
} catch (Exception $e) {
    echo "<div class='check fail'>ERROR: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "</body></html>";
?>
