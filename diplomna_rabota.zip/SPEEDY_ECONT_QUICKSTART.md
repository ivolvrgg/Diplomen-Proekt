# Speedy & Econt API Quick Start Guide

## What Was Created

Your Speedy and Econt API integration is now complete with:

### 📁 Core Files Created:
1. **`includes/delivery-service.php`** - Abstract service class + Factory pattern
2. **`includes/speedy-service.php`** - Speedy REST API integration (Modern)
3. **`includes/econt-service.php`** - Econt REST API integration
4. **`api/get_delivery_offices.php`** - Endpoint to fetch offices
5. **`api/create_shipment.php`** - Endpoint to create shipments
6. **`api/get_shipment_tracking.php`** - Endpoint for tracking
7. **`public/delivery-service.js`** - Frontend delivery service controller
8. **`sql/migration_courier_setup.sql`** - Database tables setup
9. **`setup-courier-api.bat`** - Setup script for Windows
10. **`setup-courier-api.sh`** - Setup script for Linux/Mac
11. **`test-courier-api.php`** - Testing interface

### ✅ What's Already Integrated:
- Your `payment.php` already loads offices from the database
- Delivery methods (Courier, Speedy, Econt) configured
- Office selection UI ready
- Cost mapping (€3.00 Courier, €4.99 Speedy, €3.00 Econt)

---

## Step 1: Get API Credentials

### Speedy (Bulgaria) - REST API ⭐ MODERN
**Use modern REST API - Speedy deprecated their SOAP API**

1. Visit: https://api.speedy.bg/web-api.html
2. Request test credentials: api.registration@speedy.bg
3. Support: api.support@speedy.bg
4. You'll need:
   - **API Key**
   - **Customer ID**

**Important:**
- **SOAP API (EPS)** is deprecated (support ended Sept 30, 2024)
- **SOAP will be decommissioned:** Dec 31, 2024
- **New integrations should use REST API**

### Econt (Bulgaria)
1. Visit: https://www.econt.com/en/service/integrations/econt-api
2. Register for API access
3. You'll need:
   - **API Username**
   - **API Password**
   - **Client System ID**

---

## Step 2: Update Configuration

Edit `.env` file in your project root:

```env
COURIER_ENV=test

# Speedy REST API (Modern)
SPEEDY_API_KEY=your_api_key_here
SPEEDY_CUSTOMER_ID=your_customer_id
SPEEDY_API_URL=https://api.speedy.bg
# For test:
# SPEEDY_API_URL=https://test-api.speedy.bg

# Econt
ECONT_USERNAME=your_actual_username
ECONT_PASSWORD=your_actual_password
ECONT_CLIENT_SYSTEM_ID=your_system_id
```

**⚠ IMPORTANT:** Never commit `.env` to version control!

---

## Step 3: Setup Database

Run the setup migrations:

### Windows:
```bash
setup-courier-api.bat
```

### Linux/Mac:
```bash
bash setup-courier-api.sh
```

Or manually:
```bash
mysql -u root -P 3307 dron_db < sql/migration_courier_setup.sql
mysql -u root -P 3307 dron_db < sql/migration_update_speedy_ekont.sql
```

---

## Step 4: Test the Integration

### Option A: Use Test Page
Open in browser:
```
http://localhost/test-courier-api.php
```

This will show:
- ✓ Database connection
- ✓ Speedy offices loaded
- ✓ Econt offices loaded
- ✓ All endpoints working
- ✓ Configuration status

### Option B: Test with cURL

**Get Speedy offices in Sofia:**
```bash
curl "http://localhost/api/get_delivery_offices.php?method=speedy&city=Sofia"
```

**Get Econt offices:**
```bash
curl "http://localhost/api/get_delivery_offices.php?method=econt"
```

**Create a test shipment:**
```bash
curl -X POST http://localhost/api/create_shipment.php \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "delivery_method": "speedy",
    "delivery_office_id": 5,
    "recipient_name": "John Doe",
    "recipient_phone": "0888123456",
    "weight": 1.5
  }'
```

---

## How It Works

### Frontend Flow:
1. User selects delivery method (Courier/Speedy/Econt)
2. If office-based methods:
   - JavaScript calls `/api/get_delivery_offices.php`
   - Offices load from database (pre-loaded by migration)
   - User selects office
3. User submits payment form
4. Office ID and method sent to server

### Backend Flow:
1. Payment submission to `api/orders.php`
2. Order created with `delivery_method_id` and `delivery_office_id`
3. Order processing may trigger shipment creation
4. `api/create_shipment.php` called with order details
5. Selected courier service creates shipment
6. External shipment ID stored in `orders.external_shipment_id`

### Shipment Tracking:
1. User queries `/api/get_shipment_tracking.php?order_id=123`
2. System fetches from `orders` table
3. Calls appropriate courier's tracking API
4. Returns shipment events and current status

---

## Testing Mode (Development)

By default, `COURIER_ENV=test` in `.env`:
- Shipments are created locally (not sent to couriers)
- No real API credentials needed
- Perfect for development and testing
- All endpoints return realistic mock data

**In test mode:**
- Speedy shipment ID: `SPEEDY_TST_20240316..._xxxx`
- Econt shipment ID: `ECONT_TST_20240316..._xxxx`

To switch to production:
1. Set `COURIER_ENV=production` in `.env`
2. Provide real API credentials
3. Ensure your database is backed up
4. Test with small orders first

---

## Database Tables

### `delivery_methods`
- Stores available courier methods
- Cost, delivery time info

### `delivery_offices`
- 300+ Speedy offices
- 200+ Econt offices
- Location, phone, hours

### `orders` (updated)
- `external_shipment_id` - Returned by courier API
- `shipment_status` - pending/picked_up/in_transit/delivered/failed
- `shipment_created_at` - When shipment was created
- `shipment_updated_at` - Last update

### `shipment_logs`
- Track all shipment events
- For audit trail and debugging

---

## API Endpoints Reference

### Get Offices
```
GET /api/get_delivery_offices.php?method=speedy&city=Sofia

Response:
{
  "success": true,
  "data": {
    "count": 3,
    "offices": [
      {
        "id": 1,
        "name": "Speedy - Sofia Center",
        "city": "Sofia",
        "street": "ul. Vitosha 10",
        "phone": "+359 1 123 45 67",
        "hours": "08:00 - 18:00"
      }
    ]
  }
}
```

### Create Shipment
```
POST /api/create_shipment.php

Request:
{
  "order_id": 123,
  "delivery_method": "speedy",
  "delivery_office_id": 5,
  "recipient_name": "John Doe",
  "recipient_phone": "0888123456",
  "weight": 1.5
}

Response:
{
  "success": true,
  "data": {
    "shipment_id": "SPEEDY_...",
    "status": "pending",
    "method": "speedy",
    "created_at": "2024-03-16 10:30:00"
  }
}
```

### Track Shipment
```
GET /api/get_shipment_tracking.php?order_id=123&method=speedy

Response:
{
  "success": true,
  "data": {
    "shipment_id": "SPEEDY_123",
    "status": "in_transit",
    "created_at": "2024-03-16 10:00:00",
    "events": [
      {
        "timestamp": "2024-03-16 10:00:00",
        "status": "Created",
        "location": "Sofia Center",
        "description": "Shipment created"
      }
    ]
  }
}
```

---

## Troubleshooting

### Offices Not Loading
```sql
-- Check if offices exist:
SELECT COUNT(*) FROM delivery_offices WHERE delivery_method_id = 2;

-- Should return 300+ for Speedy
-- Should return 200+ for Econt
```

### API Error: "No offices available"
1. Verify migration ran: `mysql ... < sql/migration_update_speedy_ekont.sql`
2. Check database connection in `config/db.php`
3. Verify user permissions on `delivery_offices` table

### Credentials Not Found
1. Verify `.env` file exists
2. Check file has correct permissions
3. For Speedy REST API: `echo getenv('SPEEDY_API_KEY');` should return your API key
4. Test with: `http://localhost/test-courier-api.php`

### Shipment Creation Fails
1. Check `logs/courier_*.log` files
2. Ensure order exists in database
3. Verify delivery office ID is valid

### SOAP Client Error
1. Verify PHP `php_soap.dll` extension is enabled
2. Check firewall allows HTTPS to Speedy servers
3. In test mode, uses mock data (no SOAP needed)

---

## Advanced: Real API Integration

When you're ready for production:

1. **Get real credentials** from both couriers
   - Speedy: api.registration@speedy.bg (REST API)
   - Econt: https://www.econt.com/en/service/integrations/econt-api
2. **Update `.env`** with actual credentials  
3. **Set `COURIER_ENV=production`**
4. **The REST API calls are already implemented** in both services

Currently, the code creates "test" shipments. To enable real shipments:
- REST API implementation for Speedy already added
- REST API integration for Econt ready to go
- Test with small orders first
- Monitor logs: `logs/courier_*.log`

**Key implementation notes:**
- Speedy uses modern REST API (not deprecated SOAP)
- Both services fall back to database offices if API unavailable
- Test mode enabled by default (safe for development)
- Production mode uses real API calls with your credentials

---

## Files Reference

| File | Purpose |
|------|---------|
| `includes/delivery-service.php` | Base delivery service class |
| `includes/speedy-service.php` | Speedy REST API implementation |
| `includes/econt-service.php` | Econt REST API implementation |
| `api/get_delivery_offices.php` | API endpoint for offices |
| `api/create_shipment.php` | API endpoint for creating shipments |
| `api/get_shipment_tracking.php` | API endpoint for tracking |
| `public/delivery-service.js` | Frontend delivery UI controller |
| `sql/migration_courier_setup.sql` | Database tables |
| `.env` | Configuration file |
| `test-courier-api.php` | Testing interface |

---

## Next Steps

1. ✅ Get API credentials from Speedy and Econt
2. ✅ Update `.env` with credentials
3. ✅ Run database migrations
4. ✅ Test with `http://localhost/test-courier-api.php`
5. ✅ Test payment flow with office selection
6. ✅ Verify shipments are created and tracked
7. ⭐ Switch to production when ready

---

## Support Resources

**Speedy REST API (Modern - Recommended):**
- REST API Documentation: https://api.speedy.bg/web-api.html
- API Examples: https://services.speedy.bg/api/api_examples.html
- Request Credentials: api.registration@speedy.bg
- Technical Support: api.support@speedy.bg

**Econt:**
- API Documentation: https://www.econt.com/en/service/integrations/econt-api
- Contact: Support via their website

**Your Application:**
- **Logs:** Check `logs/courier_*.log` for debugging
- **Test Page:** `http://localhost/test-courier-api.php`

**Important Reminder:**
- ⚠️ Speedy SOAP API (EPS) is deprecated - use REST API
- SOAP technical support ended: Sept 30, 2024
- SOAP decommissioned: Dec 31, 2024

Your integration is ready to go! 🚀
