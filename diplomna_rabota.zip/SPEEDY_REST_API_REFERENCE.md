# Speedy REST API Implementation Reference

## Overview

This document explains how the Speedy REST API is implemented in your integration.

## Authentication

**Method:** Bearer Token (API Key in HTTP Header)

```php
Authorization: Bearer YOUR_API_KEY
```

**How it's used in your code:**
```php
// In speedy-service.php
curl_setopt_array($curl, [
    // ...
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $this->api_key,
        'User-Agent: DroncheBG/1.0'
    ]
]);
```

## API Endpoints Used

### 1. Get Parcel Shops (Offices)

**Endpoint:** `GET /v1/locations/parcel-shops`

**Parameters:**
- `language` - Language code (e.g., 'BG' for Bulgarian)
- `city` - Optional city filter

**Request:**
```php
GET https://api.speedy.bg/v1/locations/parcel-shops?language=BG&city=Sofia
Authorization: Bearer API_KEY
```

**Response (Sample):**
```json
{
  "items": [
    {
      "id": 12345,
      "name": "Speedy - Sofia Center",
      "city": "Sofia",
      "address": "ul. Vitosha 10",
      "phone": "+359 1 123 45 67",
      "workingHours": "08:00 - 18:00"
    }
  ]
}
```

**Implemented in:** `getOfficesFromAPI()` method

### 2. Create Shipment

**Endpoint:** `POST /v1/shipments`

**Request Body:**
```json
{
  "serviceType": "STANDARD",
  "recipient": {
    "name": "John Doe",
    "phone": "+359888123456",
    "address": "ul. Vitosha 10",
    "city": "Sofia",
    "country": "BG"
  },
  "parcel": {
    "weight": 1.5,
    "width": 0,
    "height": 0,
    "depth": 0
  },
  "deliveryType": "OFFICE"
}
```

**Response:**
```json
{
  "shipmentNumber": "123456789",
  "status": "pending",
  "createdAt": "2024-03-16T10:30:00"
}
```

**Implemented in:** `createRealShipment()` method

### 3. Track Shipment

**Endpoint:** `GET /v1/shipments/{shipmentNumber}/tracking`

**Request:**
```
GET https://api.speedy.bg/v1/shipments/123456789/tracking
Authorization: Bearer API_KEY
```

**Response:**
```json
{
  "shipmentNumber": "123456789",
  "status": "in_transit",
  "events": [
    {
      "timestamp": "2024-03-16T10:00:00",
      "status": "Created",
      "location": "Shipper",
      "description": "Shipment created"
    },
    {
      "timestamp": "2024-03-16T11:30:00",
      "status": "Picked Up",
      "location": "Sofia Center",
      "description": "Picked up from sender"
    }
  ]
}
```

**Implemented in:** `getRealTracking()` method

## Request Flow

### Loading Offices

```
1. User selects "Speedy" in payment form
2. JavaScript calls: GET /api/get_delivery_offices.php?method=speedy&city=Sofia
3. Backend:
   a. Tries to load from database (faster)
   b. If not found and API available, calls Speedy REST API
   c. Returns offices with office IDs
4. Frontend displays list and user selects office
```

### Creating Shipment

```
1. User submits payment form with office selection
2. Backend receives: POST /api/orders.php
   {
     "order_id": 123,
     "delivery_method": "speedy",
     "delivery_office_id": 5,
     "recipient_name": "John Doe",
     "recipient_phone": "0888123456"
   }
3. Backend calls: POST /api/create_shipment.php
4. Speedy service:
   a. In TEST mode: Creates local shipment record
   b. In PRODUCTION mode: Calls Speedy REST API
   c. Stores external shipment ID in database
5. Returns shipment confirmation
```

### Tracking Shipment

```
1. User clicks "Track Order" or admin queries shipment
2. Backend receives: GET /api/get_shipment_tracking.php?order_id=123
3. Speedy service:
   a. Gets shipment ID from database
   b. If production mode: Calls Speedy REST API /tracking
   c. Returns events and current status
4. Frontend displays tracking info
```

## Error Handling

**HTTP Status Codes:**

| Code | Meaning | Action |
|------|---------|--------|
| 200 | Success | Process response |
| 400 | Bad Request | Check request format |
| 401 | Unauthorized | Check API key |
| 403 | Forbidden | Check permissions |
| 404 | Not Found | Resource doesn't exist |
| 429 | Rate Limited | Wait and retry |
| 500 | Server Error | Speedy API issue |

**Error Response:**
```json
{
  "error": "Invalid API key",
  "message": "Authentication failed"
}
```

**Your code handles errors:**
```php
if ($http_code >= 400) {
    $error_msg = $result['error'] ?? $result['message'] ?? 'HTTP ' . $http_code;
    throw new Exception('API Error: ' . $error_msg);
}
```

## Environment Variables

**Configuration in .env:**

```env
# REST API Credentials
SPEEDY_API_KEY=your_api_key_from_speedy
SPEEDY_CUSTOMER_ID=your_customer_id_number
SPEEDY_API_URL=https://api.speedy.bg

# For Testing (different endpoint)
# SPEEDY_API_URL=https://test-api.speedy.bg

# Environment Mode
COURIER_ENV=test  # or 'production'
```

## Test vs Production Mode

### Test Mode (Default)
```php
if ($this->is_test) {
    // Creates mock shipments locally
    // No real API calls
    // Perfect for development
    // Shipment ID: SPEEDY_TST_20240316..._xxxx
}
```

### Production Mode
```php
if (!$this->is_test && $this->api_key !== 'test_api_key') {
    // Makes real API calls to Speedy
    // Requires valid credentials
    // Creates real shipments
    // Shipment ID: SPEEDY_123456789
}
```

## Logging

All API requests and responses are logged:

```php
$this->log('SPEEDY_API_' . $method, $request_data, $response_data);
```

**Logs Location:** `logs/courier_YYYY-MM-DD.log`

**Log Format:**
```
[2024-03-16 10:30:45] SPEEDY_API_POST
Request: {"endpoint": "/v1/shipments", ...}
Response: {"shipmentNumber": "123456789", ...}
```

## Rate Limiting

Speedy API has rate limits (check their documentation):
- Typical: 1000 requests per hour
- Your code includes retry logic for 429 responses
- Monitor logs for rate limit errors

## Best Practices

**1. Always Check Test Mode First**
```php
if ($this->is_test) {
    // Safe testing without real API calls
}
```

**2. Store Shipment IDs in Database**
```php
// Save external shipment ID for tracking
$stmt = $conn->prepare("UPDATE orders SET external_shipment_id = ? WHERE id = ?");
```

**3. Log All API Interactions**
```php
$this->log('ACTION', $request, $response);
```

**4. Handle Errors Gracefully**
```php
try {
    // API call
} catch (Exception $e) {
    $this->log('ERROR', $data, ['error' => $e->getMessage()]);
    return $this->response(false, 'User-friendly error message');
}
```

**5. Use Database as Fallback**
```php
// Try database first (faster)
$offices = $this->getOfficesFromDatabase($city);
// Only call API if needed
if (empty($offices)) {
    $offices = $this->getOfficesFromAPI($city);
}
```

## Testing Your Implementation

### 1. Test Office Loading
```bash
curl "http://localhost/api/get_delivery_offices.php?method=speedy&city=Sofia"
```

### 2. Test in Test Mode (Safe)
```bash
# Set COURIER_ENV=test in .env
# Create shipments without hitting real API
curl -X POST http://localhost/api/create_shipment.php \
  -H "Content-Type: application/json" \
  -d '{...}'
```

### 3. Verify Credentials
```bash
# In your test-courier-api.php
# Check if SPEEDY_API_KEY environment variable is loaded
```

### 4. Monitor Logs
```bash
tail -f logs/courier_*.log
```

## Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| "API Error: 401 Unauthorized" | Invalid API key | Check SPEEDY_API_KEY in .env |
| "No offices available" | Database empty | Run migration: `migration_update_speedy_ekont.sql` |
| "Connection timeout" | Network issue | Check SPEEDY_API_URL is correct |
| "Invalid JSON" | Malformed request | Check request body format |
| "Shipment not found" | Wrong shipment ID | Verify shipment was created first |

## Additional Resources

- **Speedy API Docs:** https://api.speedy.bg/web-api.html
- **Code Examples:** https://services.speedy.bg/api/api_examples.html
- **Your Implementation:** `includes/speedy-service.php`
- **Endpoint:** `api/get_delivery_offices.php`, `api/create_shipment.php`

---

**Note:** This is the modern REST API (recommended). The old SOAP API is deprecated and ends Dec 31, 2024.
