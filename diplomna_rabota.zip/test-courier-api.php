<?php
/**
 * Test Speedy & Econt API Integration
 * 
 * Run this file in your browser to test the courier APIs:
 * http://localhost/test-courier-api.php
 */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/delivery-service.php';
require_once __DIR__ . '/includes/speedy-service.php';
require_once __DIR__ . '/includes/econt-service.php';

$test_results = [];
$errors = [];

echo "<!DOCTYPE html>
<html>
<head>
    <title>Courier API Test</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { color: green; background: #e8f5e9; padding: 10px; border-left: 4px solid green; }
        .error { color: red; background: #ffebee; padding: 10px; border-left: 4px solid red; }
        .info { color: blue; background: #e3f2fd; padding: 10px; border-left: 4px solid blue; }
        h1 { color: #333; }
        h2 { color: #666; border-bottom: 2px solid #588157; padding-bottom: 10px; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
        .metric { margin: 10px 0; }
        .label { font-weight: bold; }
    </style>
</head>
<body>
    <h1>🚚 Speedy & Econt API Integration Test</h1>
";

// Test 1: Database Connection
echo "<div class='test-section'>
    <h2>Test 1: Database Connection</h2>";

try {
    $result = $conn->query("SELECT COUNT(*) as count FROM delivery_offices WHERE delivery_method_id IN (2, 3)");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "<div class='success'>✓ Database connected. Found " . $row['count'] . " delivery offices</div>";
        $test_results['database'] = true;
    }
} catch (Exception $e) {
    echo "<div class='error'>✗ Database error: " . $e->getMessage() . "</div>";
    $test_results['database'] = false;
}

echo "</div>";

// Test 2: Speedy Service
echo "<div class='test-section'>
    <h2>Test 2: Speedy Service</h2>";

try {
    $speedy = new SpeedyService();
    
    // Get offices
    echo "<div class='info'>Testing get_offices()...</div>";
    $response = $speedy->getOffices('Sofia');
    
    if ($response['success']) {
        $count = count($response['data']['offices'] ?? []);
        echo "<div class='success'>✓ Speedy offices loaded: $count found</div>";
        
        if ($count > 0) {
            echo "<div class='metric'>";
            echo "<span class='label'>Sample office:</span><br>";
            $sample = $response['data']['offices'][0];
            echo "Name: " . htmlspecialchars($sample['name']) . "<br>";
            echo "City: " . htmlspecialchars($sample['city']) . "<br>";
            echo "Phone: " . htmlspecialchars($sample['phone']) . "<br>";
            echo "</div>";
        }
        $test_results['speedy_offices'] = true;
    } else {
        echo "<div class='error'>✗ Failed: " . $response['message'] . "</div>";
        $test_results['speedy_offices'] = false;
    }
} catch (Exception $e) {
    echo "<div class='error'>✗ Error: " . $e->getMessage() . "</div>";
    $test_results['speedy_offices'] = false;
}

echo "</div>";

// Test 3: Econt Service
echo "<div class='test-section'>
    <h2>Test 3: Econt Service</h2>";

try {
    $econt = new EcontService();
    
    echo "<div class='info'>Testing get_offices()...</div>";
    $response = $econt->getOffices('Sofia');
    
    if ($response['success']) {
        $count = count($response['data']['offices'] ?? []);
        echo "<div class='success'>✓ Econt offices loaded: $count found</div>";
        
        if ($count > 0) {
            echo "<div class='metric'>";
            echo "<span class='label'>Sample office:</span><br>";
            $sample = $response['data']['offices'][0];
            echo "Name: " . htmlspecialchars($sample['name']) . "<br>";
            echo "City: " . htmlspecialchars($sample['city']) . "<br>";
            echo "Phone: " . htmlspecialchars($sample['phone']) . "<br>";
            echo "</div>";
        }
        $test_results['econt_offices'] = true;
    } else {
        echo "<div class='error'>✗ Failed: " . $response['message'] . "</div>";
        $test_results['econt_offices'] = false;
    }
} catch (Exception $e) {
    echo "<div class='error'>✗ Error: " . $e->getMessage() . "</div>";
    $test_results['econt_offices'] = false;
}

echo "</div>";

// Test 4: API Endpoints
echo "<div class='test-section'>
    <h2>Test 4: API Endpoints</h2>";

$endpoints = [
    '/api/get_delivery_offices.php?method=speedy&city=Sofia' => 'Get Speedy offices',
    '/api/get_delivery_offices.php?method=econt&city=Sofia' => 'Get Econt offices',
    '/api/get_delivery_offices.php?method=courier' => 'Get Courier info'
];

foreach ($endpoints as $endpoint => $description) {
    echo "<div class='metric'>";
    echo "<span class='label'>$description</span><br>";
    echo "<code>" . htmlspecialchars($endpoint) . "</code>";
    echo "</div>";
}

echo "</div>";

// Test 5: Configuration
echo "<div class='test-section'>
    <h2>Test 5: Configuration from .env</h2>";

$env_vars = [
    'SPEEDY_API_KEY' => 'API Key for Speedy REST API',
    'SPEEDY_CUSTOMER_ID' => 'Customer ID for Speedy',
    'SPEEDY_API_URL' => 'API URL for Speedy',
    'ECONT_USERNAME' => 'Username for Econt API',
    'ECONT_PASSWORD' => 'Password for Econt API',
    'COURIER_ENV' => 'Environment (test/production)'
];

foreach ($env_vars as $var => $description) {
    $value = getenv($var);
    if ($value) {
        // Mask sensitive values
        $display_value = (strpos($var, 'PASSWORD') !== false || strpos($var, 'KEY') !== false) ? '***' : $value;
        echo "<div class='success'>✓ $var = " . htmlspecialchars($display_value) . " ($description)</div>";
    } else {
        echo "<div class='error'>✗ $var not set ($description)</div>";
    }
}

// Check .env file
if (file_exists('.env')) {
    echo "<div class='success'>✓ .env file exists</div>";
} else {
    echo "<div class='error'>✗ .env file not found</div>";
}

echo "</div>";

// Test 6: Logs
echo "<div class='test-section'>
    <h2>Test 6: Logs Directory</h2>";

$log_dir = __DIR__ . '/logs';
if (is_dir($log_dir) && is_writable($log_dir)) {
    echo "<div class='success'>✓ Logs directory exists and is writable</div>";
    
    $logs = glob($log_dir . '/courier_*.log');
    if (!empty($logs)) {
        echo "<div class='metric'>";
        echo "<span class='label'>Found " . count($logs) . " log file(s):</span><br>";
        foreach ($logs as $log) {
            $size = filesize($log);
            echo "- " . basename($log) . " (" . number_format($size) . " bytes)<br>";
        }
        echo "</div>";
    }
} else {
    echo "<div class='error'>✗ Logs directory not writable</div>";
}

echo "</div>";

// Summary
echo "<div class='test-section'>";
echo "<h2>Test Summary</h2>";
$passed = count(array_filter($test_results, fn($v) => $v === true));
$total = count($test_results);
echo "<div class='metric'>";
echo "<span class='label'>Tests Passed: $passed/$total</span>";
echo "</div>";

if ($passed === $total) {
    echo "<div class='success'>✓ All tests passed! API integration is ready.</div>";
} else {
    echo "<div class='error'>⚠ Some tests failed. Check the results above.</div>";
}

echo "</div>";

echo "</body></html>";
?>
