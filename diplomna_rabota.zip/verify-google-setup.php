<?php
/**
 * Google OAuth Setup Verification
 * Visit: http://localhost/verify-google-setup.php
 */

echo "<h1>Google OAuth Setup Verification</h1>";
echo "<p>Checking your configuration...</p>";

$checks = [];

// Check 1: Google Config File
echo "<h3>1. Configuration File</h3>";
if (file_exists('config/google.php')) {
    include 'config/google.php';
    $checks['config_exists'] = true;
    echo "✓ config/google.php exists<br>";
    
    if (defined('GOOGLE_CLIENT_ID')) {
        if (strpos(GOOGLE_CLIENT_ID, 'YOUR_') === 0) {
            echo "⚠️ <strong>WARNING:</strong> GOOGLE_CLIENT_ID not configured (still has placeholder)<br>";
            $checks['client_id_set'] = false;
        } else {
            echo "✓ GOOGLE_CLIENT_ID is configured<br>";
            $checks['client_id_set'] = true;
        }
    }
    
    if (defined('GOOGLE_CLIENT_SECRET')) {
        if (strpos(GOOGLE_CLIENT_SECRET, 'YOUR_') === 0) {
            echo "⚠️ <strong>WARNING:</strong> GOOGLE_CLIENT_SECRET not configured (still has placeholder)<br>";
            $checks['client_secret_set'] = false;
        } else {
            echo "✓ GOOGLE_CLIENT_SECRET is configured<br>";
            $checks['client_secret_set'] = true;
        }
    }
} else {
    echo "❌ config/google.php not found<br>";
    $checks['config_exists'] = false;
}

// Check 2: PHP Extensions
echo "<h3>2. Required PHP Extensions</h3>";
if (extension_loaded('curl')) {
    echo "✓ PHP cURL extension is enabled<br>";
    $checks['curl'] = true;
} else {
    echo "❌ PHP cURL extension is NOT enabled (required for Google OAuth)<br>";
    $checks['curl'] = false;
}

if (extension_loaded('json')) {
    echo "✓ PHP JSON extension is enabled<br>";
    $checks['json'] = true;
} else {
    echo "❌ PHP JSON extension is NOT enabled<br>";
    $checks['json'] = false;
}

// Check 3: API Files
echo "<h3>3. Required Files</h3>";
$required_files = [
    'api/google-callback.php' => 'Google OAuth Callback',
    'includes/google_auth.php' => 'Helper Functions',
    'run-google-migration.php' => 'Database Migration'
];

foreach ($required_files as $file => $description) {
    if (file_exists($file)) {
        echo "✓ $description ($file)<br>";
        $checks[$file] = true;
    } else {
        echo "❌ Missing: $description ($file)<br>";
        $checks[$file] = false;
    }
}

// Check 4: Database
echo "<h3>4. Database</h3>";
try {
    include 'config/db.php';
    if (isset($conn)) {
        echo "✓ Database connection successful<br>";
        $checks['database'] = true;
        
        // Check if google_id column exists
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'google_id'");
        if ($result && $result->num_rows > 0) {
            echo "✓ google_id column exists<br>";
            $checks['google_id_column'] = true;
        } else {
            echo "⚠️ google_id column missing (run: /run-google-migration.php)<br>";
            $checks['google_id_column'] = false;
        }
    }
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "<br>";
    $checks['database'] = false;
}

// Check 5: Pages Updated
echo "<h3>5. Updated Pages</h3>";
$pages = ['user_login.php', 'user_register.php'];
foreach ($pages as $page) {
    if (file_exists($page)) {
        $content = file_get_contents($page);
        if (strpos($content, 'google-login-btn') !== false) {
            echo "✓ $page has Google button<br>";
            $checks[$page] = true;
        } else {
            echo "⚠️ $page missing Google button<br>";
            $checks[$page] = false;
        }
    }
}

// Summary
echo "<hr>";
echo "<h3>Setup Summary</h3>";

$required_checks = [
    'config_exists',
    'client_id_set',
    'client_secret_set',
    'curl',
    'json',
    'api/google-callback.php',
    'includes/google_auth.php',
    'run-google-migration.php',
    'database',
    'google_id_column',
    'user_login.php',
    'user_register.php'
];

$passed = 0;
$failed = 0;
$warning = 0;

foreach ($required_checks as $check) {
    if (isset($checks[$check])) {
        if ($checks[$check] === true) $passed++;
        else $failed++;
    } else {
        $warning++;
    }
}

echo "<strong>Passed:</strong> $passed<br>";
echo "<strong>Failed:</strong> $failed<br>";
echo "<strong>Warnings:</strong> $warning<br>";

if ($failed === 0 && $passed > 0) {
    echo "<br><strong style='color: green;'>✓ Your Google OAuth setup is complete!</strong><br>";
    echo "<p>You can now:</p>";
    echo "<ul>";
    echo "<li><a href='user_login.php'>Test Login with Google</a></li>";
    echo "<li><a href='user_register.php'>Test Registration with Google</a></li>";
    echo "</ul>";
} else {
    echo "<br><strong style='color: red;'>❌ Please complete the setup steps above before using Google OAuth</strong><br>";
}
?>
