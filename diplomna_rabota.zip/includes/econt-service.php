<?php
/**
 * Econt Courier Service - REST API Integration
 * 
 * Econt provides fast delivery services across Bulgaria
 * API: https://www.econt.com/en/service/integrations/econt-api
 */

class EcontService extends DeliveryService {
    
    private $username;
    private $password;
    private $client_system_id;
    private $api_url;
    private $auth_token;
    
    public function __construct() {
        parent::__construct();
        
        $this->username = getenv('ECONT_USERNAME') ?: 'test_user';
        $this->password = getenv('ECONT_PASSWORD') ?: 'test_pass';
        $this->client_system_id = getenv('ECONT_CLIENT_SYSTEM_ID') ?: 'test_system';
        $this->api_url = getenv('ECONT_API_URL') ?: 'https://api.econt.com/v1';
        
        if ($this->is_test) {
            // Use test environment for Econt
            $this->api_url = 'https://api-test.econt.com/v1';
        }
    }
    
    /**
     * Authenticate with Econt API
     */
    private function authenticate() {
        try {
            if ($this->auth_token && !empty($this->auth_token)) {
                return true; // Already authenticated
            }
            
            if ($this->is_test || $this->username === 'test_user' || $this->password === 'test_pass') {
                // For test, use dummy token
                $this->auth_token = 'test_token_' . date('YmdHis');
                return true;
            }
            
            // Econt uses Basic Auth, no separate login needed
            // Token is base64(username:password)
            $this->auth_token = base64_encode($this->username . ':' . $this->password);
            return true;
            
        } catch (Exception $e) {
            $this->log('ECONT_AUTH_ERROR', [], ['error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * Make HTTP request to Econt API
     */
    private function makeRequest($method, $endpoint, $data = null, $headers = []) {
        try {
            $url = $this->api_url . $endpoint;
            
            // Add default authentication header if not provided
            $auth_added = false;
            foreach ($headers as $header) {
                if (strpos($header, 'Authorization:') === 0) {
                    $auth_added = true;
                    break;
                }
            }
            
            if (!$auth_added && $this->auth_token) {
                $headers[] = 'Authorization: Basic ' . $this->auth_token;
            }
            
            $curl_options = [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => !$this->is_test,
                CURLOPT_SSL_VERIFYHOST => !$this->is_test ? 2 : 0,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => array_merge([
                    'Content-Type: application/json',
                    'Accept: application/json',
                    'User-Agent: DroncheBG/1.0'
                ], $headers)
            ];
            
            if ($method !== 'GET' && $data) {
                $curl_options[CURLOPT_POSTFIELDS] = json_encode($data);
            }
            
            $curl = curl_init();
            curl_setopt_array($curl, $curl_options);
            
            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($curl);
            
            curl_close($curl);
            
            if ($curl_error) {
                throw new Exception('CURL Error: ' . $curl_error);
            }
            
            $result = json_decode($response, true);
            
            if ($http_code >= 400) {
                $error_msg = $result['message'] ?? $result['error'] ?? 'HTTP ' . $http_code;
                throw new Exception('API Error: ' . $error_msg);
            }
            
            $this->log('ECONT_API_' . $method, ['endpoint' => $endpoint, 'data' => $data], $result);
            
            return $result;
            
        } catch (Exception $e) {
            $this->log('ECONT_REQUEST_ERROR', ['method' => $method, 'endpoint' => $endpoint], ['error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Get all Econt offices, filtered by city
     */
    public function getOffices($city = null) {
        try {
            // First, try database (populated by migration)
            $offices = $this->getOfficesFromDatabase($city);
            
            if (!empty($offices)) {
                return $this->response(true, 'Offices retrieved', [
                    'count' => count($offices),
                    'offices' => $offices
                ]);
            }
            
            // If not in database and authenticated, try API
            if (!$this->is_test && $this->authenticate()) {
                return $this->getOfficesFromAPI($city);
            }
            
            throw new Exception('No offices available');
            
        } catch (Exception $e) {
            $this->log('GET_OFFICES_ERROR', ['city' => $city, 'error' => $e->getMessage()]);
            return $this->response(false, 'Failed to get offices: ' . $e->getMessage());
        }
    }
    
    /**
     * Get offices from database
     */
    private function getOfficesFromDatabase($city = null) {
        global $conn;
        
        $query = "SELECT id, label, city, street, phone, working_hours, is_active 
                  FROM delivery_offices 
                  WHERE delivery_method_id = 3 AND is_active = 1";
        
        if ($city) {
            $city = $conn->real_escape_string($city);
            $query .= " AND city LIKE '%$city%'";
        }
        
        $query .= " ORDER BY city ASC, label ASC";
        
        $result = $conn->query($query);
        
        if (!$result) {
            throw new Exception('Database query failed: ' . $conn->error);
        }
        
        $offices = [];
        while ($row = $result->fetch_assoc()) {
            $offices[] = [
                'id' => $row['id'],
                'name' => $row['label'],
                'city' => $row['city'],
                'street' => $row['street'],
                'phone' => $row['phone'] ?: '+359 2 937 50 00',
                'hours' => $row['working_hours'] ?: '08:00 - 18:00',
                'type' => 'Econt ParcelShop'
            ];
        }
        
        return $offices;
    }
    
    /**
     * Get offices from Econt API (live call)
     */
    private function getOfficesFromAPI($city = null) {
        try {
            $endpoint = '/locations/list';
            $params = [
                'countryCode' => 'BG',
                'type' => 'APT' // APT = Automated Parcel Terminal (ParcelShop)
            ];
            
            if ($city) {
                $params['city'] = $city;
            }
            
            $full_endpoint = $endpoint . '?' . http_build_query($params);
            
            // Ensure authentication
            if (!$this->authenticate()) {
                throw new Exception('Failed to authenticate with Econt API');
            }
            
            $response = $this->makeRequest('GET', $full_endpoint);
            
            $offices = [];
            if (isset($response['offices']) && is_array($response['offices'])) {
                foreach ($response['offices'] as $location) {
                    $offices[] = [
                        'id' => $location['id'] ?? $location['poiId'],
                        'name' => $location['name'] ?? 'Econt ParcelShop',
                        'city' => $location['city'],
                        'street' => $location['address'] ?? 'N/A',
                        'phone' => $location['phone'] ?? '+359 2 937 50 00',
                        'hours' => $this->formatWorkingHours($location),
                        'type' => 'Econt ParcelShop',
                        'poi_id' => $location['poiId'] ?? $location['id']
                    ];
                }
            }
            
            $this->log('GET_OFFICES_API_SUCCESS', ['city' => $city], ['count' => count($offices)]);
            
            return $offices;
            
        } catch (Exception $e) {
            $this->log('ECONT_API_ERROR', ['action' => 'GetLocations', 'city' => $city], ['error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Format working hours from API response
     */
    private function formatWorkingHours($location) {
        if (isset($location['workingHours'])) {
            return $location['workingHours'];
        }
        return '08:00 - 18:00';
    }
    
    /**
     * Create a shipment in Econt
     */
    public function createShipment($shipment_data) {
        try {
            $required = ['recipient_name', 'recipient_phone', 'delivery_office_id', 'weight', 'order_id'];
            $this->validateFields($shipment_data, $required);
            
            if ($this->is_test) {
                return $this->createTestShipment($shipment_data);
            }
            
            if (!$this->authenticate()) {
                throw new Exception('Authentication failed');
            }
            
            return $this->createRealShipment($shipment_data);
            
        } catch (Exception $e) {
            $this->log('CREATE_SHIPMENT_ERROR', $shipment_data, ['error' => $e->getMessage()]);
            return $this->response(false, 'Failed to create shipment: ' . $e->getMessage());
        }
    }
    
    /**
     * Create test shipment
     */
    private function createTestShipment($shipment_data) {
        $shipment_id = 'ECONT_TST_' . date('YmdHis') . '_' . rand(1000, 9999);
        
        global $conn;
        
        // Update order with shipment ID
        $order_id = intval($shipment_data['order_id']);
        $stmt = $conn->prepare("UPDATE orders SET external_shipment_id = ?, shipment_status = ? WHERE id = ?");
        $stmt->bind_param("ssi", $shipment_id, $status = 'pending', $order_id);
        $stmt->execute();
        $stmt->close();
        
        $this->log('CREATE_SHIPMENT_TEST', $shipment_data, ['shipment_id' => $shipment_id]);
        
        return $this->response(true, 'Test shipment created', [
            'shipment_id' => $shipment_id,
            'status' => 'pending',
            'method' => 'econt',
            'created_at' => date('Y-m-d H:i:s'),
            'note' => 'Test mode - shipment not sent to Econt'
        ]);
    }
    
    /**
     * Create real shipment via REST API
     */
    private function createRealShipment($shipment_data) {
        try {
            // Validate required fields
            if (empty($this->username) || empty($this->password) || $this->username === 'test_user') {
                throw new Exception('Econt API credentials not configured. Please contact support.');
            }
            
            // Build shipment request
            $shipment_request = [
                'shipments' => [
                    [
                        'clientSystemId' => $this->client_system_id,
                        'label' => 'DRONCHE_' . $shipment_data['order_id'],
                        'services' => [
                            'documents' => false,
                            'fragile' => false,
                            'palletized' => false
                        ],
                        'receiverType' => 'Parcel Machine',
                        'receiver' => [
                            'phone' => $this->formatPhoneNumber($shipment_data['recipient_phone']),
                            'name' => $shipment_data['recipient_name'],
                            'personId' => ''
                        ],
                        'senderAddress' => [
                            'countryCode' => 'BG',
                            'city' => 'Sofia',
                            'address' => 'Online Store'
                        ],
                        'receiverAddress' => [
                            'countryCode' => 'BG',
                            'city' => 'Sofia',
                            'address' => 'Econt Office',
                            'poiId' => intval($shipment_data['delivery_office_id'])
                        ],
                        'shipmentWeight' => [
                            'kg' => floatval($shipment_data['weight']) ?: 1
                        ]
                    ]
                ]
            ];
            
            // Make API request
            $response = $this->makeRequest('POST', '/shipments', $shipment_request, [
                'Authorization: Basic ' . base64_encode($this->username . ':' . $this->password)
            ]);
            
            // Parse response
            if (isset($response['shipments']) && count($response['shipments']) > 0) {
                $created_shipment = $response['shipments'][0];
                $shipment_id = $created_shipment['parcels'][0]['barcode'] ?? 'ECONT_' . time();
                
                // Update order in database
                global $conn;
                $stmt = $conn->prepare("UPDATE orders SET external_shipment_id = ?, shipment_status = ?, shipment_created_at = NOW() WHERE id = ?");
                $status = 'in_transit';
                $stmt->bind_param("ssi", $shipment_id, $status, $shipment_data['order_id']);
                $stmt->execute();
                $stmt->close();
                
                $this->log('CREATE_SHIPMENT_SUCCESS', $shipment_data, ['shipment_id' => $shipment_id, 'response' => $response]);
                
                return $this->response(true, 'Shipment created successfully', [
                    'shipment_id' => $shipment_id,
                    'status' => 'in_transit',
                    'method' => 'econt',
                    'created_at' => date('Y-m-d H:i:s'),
                    'office_id' => $shipment_data['delivery_office_id']
                ]);
            }
            
            throw new Exception('Invalid response from Econt API');
            
        } catch (Exception $e) {
            $this->log('CREATE_SHIPMENT_ERROR', $shipment_data, ['error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Format phone number for Econt API
     */
    private function formatPhoneNumber($phone) {
        // Remove all non-digit characters except leading +
        $phone = preg_replace('/[^\d\+]/', '', $phone);
        
        // Ensure it starts with +359 for Bulgaria
        if (!preg_match('/^\+/', $phone)) {
            $phone = '+359' . ltrim($phone, '0');
        }
        
        return $phone;
    }
    
    /**
     * Get shipment tracking
     */
    public function getTracking($shipment_id) {
        try {
            global $conn;
            
            // Get shipment from database
            $stmt = $conn->prepare("SELECT id, shipment_status, delivery_method_id, created_at 
                                     FROM orders 
                                     WHERE external_shipment_id = ?");
            $stmt->bind_param("s", $shipment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return $this->response(false, 'Shipment not found');
            }
            
            $shipment = $result->fetch_assoc();
            $stmt->close();
            
            // Basic tracking info
            $tracking = [
                'shipment_id' => $shipment_id,
                'status' => $shipment['shipment_status'] ?: 'pending',
                'created_at' => $shipment['created_at'],
                'events' => [
                    [
                        'timestamp' => $shipment['created_at'],
                        'status' => 'Created',
                        'location' => 'Sender',
                        'description' => 'Shipment created'
                    ]
                ]
            ];
            
            // If authenticated, try to get real tracking
            if (!$this->is_test && $this->authenticate()) {
                $tracking['events'] = $this->getRealTracking($shipment_id);
            }
            
            return $this->response(true, 'Tracking information', $tracking);
            
        } catch (Exception $e) {
            $this->log('GET_TRACKING_ERROR', ['shipment_id' => $shipment_id, 'error' => $e->getMessage()]);
            return $this->response(false, 'Failed to get tracking: ' . $e->getMessage());
        }
    }
    
    /**
     * Get real tracking from API
     */
    private function getRealTracking($shipment_id) {
        try {
            // Ensure authentication
            if (!$this->authenticate()) {
                return [];
            }
            
            $endpoint = '/tracking?barcode=' . urlencode($shipment_id);
            
            $response = $this->makeRequest('GET', $endpoint, null, [
                'Authorization: Basic ' . $this->auth_token
            ]);
            
            $events = [];
            if (isset($response['parcels']) && is_array($response['parcels'])) {
                foreach ($response['parcels'] as $parcel) {
                    if (isset($parcel['operations'])) {
                        foreach ($parcel['operations'] as $operation) {
                            $events[] = [
                                'timestamp' => $operation['timestamp'] ?? date('Y-m-d H:i:s'),
                                'status' => $operation['operationCode'] ?? 'TRACKING',
                                'location' => $operation['operationAddress'] ?? 'In Transit',
                                'description' => $this->getOperationDescription($operation['operationCode'] ?? 0)
                            ];
                        }
                    }
                }
            }
            
            return $events;
            
        } catch (Exception $e) {
            $this->log('GET_TRACKING_API_ERROR', ['shipment_id' => $shipment_id], ['error' => $e->getMessage()]);
            return [];
        }
    }
    
    /**
     * Get human-readable description for operation codes
     */
    private function getOperationDescription($code) {
        $descriptions = [
            1 => 'Arrival Scan',
            2 => 'Departure Scan',
            11 => 'Received in Office',
            12 => 'Out for Delivery',
            14 => 'Delivered',
            21 => 'Processed in Office',
            38 => 'Returned to Office',
            39 => 'Courier Pick-up',
            44 => 'Unsuccessful Delivery',
            111 => 'Return to Sender',
            134 => 'Prepared for Self-collecting',
        ];
        
        return $descriptions[$code] ?? 'Tracking Update';
    }
    
    /**
     * Calculate delivery time and cost
     */
    public function calculateDelivery($from_city, $to_city, $weight = 1) {
        return [
            'cost' => 3.00,
            'min_days' => 2,
            'max_days' => 3,
            'carrier' => 'Econt',
            'note' => 'Business days only'
        ];
    }
}
?>
