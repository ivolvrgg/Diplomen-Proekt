<?php
// scripts.php - Common JavaScript for interactive features
// Usage: <?php include 'includes/scripts.php'; ?>
    <!-- Cookie Consent Script -->
    <script src="cookies.js"></script>
    
    <script>
    (function () {
        document.addEventListener('DOMContentLoaded', function () {
            // helper
            const onEach = (list, fn) => { if (list && list.length) list.forEach(fn); };

            // Mobile menu toggle functionality
            const mobileToggle = document.querySelector('.mobile-menu-toggle');
            if (mobileToggle) {
                mobileToggle.addEventListener('click', function() {
                    const menu = document.querySelector('nav ul.menu');
                    if (menu) menu.classList.toggle('show');
                    this.classList.toggle('open');
                });
            }

            // Simple Button-style Dropdown functionality - click to toggle only
            const dropdownElements = document.querySelectorAll('.dropdown');

            dropdownElements.forEach(dropdown => {
                const btn = dropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                const content = dropdown.querySelector('.dropdown-content');
                
                if (!btn || !content) return;

                // Click to toggle dropdown
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Toggle the dropdown
                    const isOpen = content.classList.contains('show');
                    
                    // Close all other dropdowns
                    dropdownElements.forEach(otherDropdown => {
                        if (otherDropdown !== dropdown) {
                            const otherContent = otherDropdown.querySelector('.dropdown-content');
                            const otherBtn = otherDropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                            if (otherContent) {
                                otherContent.classList.remove('show');
                                if (otherBtn) {
                                    otherBtn.classList.remove('active');
                                }
                            }
                        }
                    });
                    
                    // Toggle current dropdown
                    if (isOpen) {
                        content.classList.remove('show');
                        btn.classList.remove('active');
                    } else {
                        content.classList.add('show');
                        btn.classList.add('active');
                    }
                });
                
                // Prevent closing when clicking inside the dropdown content
                content.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            });

            // Close dropdowns when clicking outside
            document.addEventListener('click', function(e) {
                dropdownElements.forEach(dropdown => {
                    const btn = dropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                    const content = dropdown.querySelector('.dropdown-content');
                    // Don't close if clicking on button or inside dropdown content
                    if (!dropdown.contains(e.target)) {
                        if (content) {
                            content.classList.remove('show');
                            if (btn) {
                                btn.classList.remove('active');
                            }
                        }
                    }
                });
            });

            // Live Search functionality with Bulgarian/English support
            const searchInput = document.querySelector('.search-input');
            const searchBtn = document.querySelector('.search-btn');
            const searchDropdown = document.getElementById('searchDropdown');
            let searchTimeout;
            
            function performSearch() {
                const query = searchInput.value.trim();
                if (query.length > 0) {
                    window.location.href = 'search.php?q=' + encodeURIComponent(query);
                }
            }
            
            function fetchSearchResults(query) {
                if (query.length < 2) {
                    searchDropdown.classList.remove('show');
                    return;
                }
                
                // Show loading state
                searchDropdown.innerHTML = '<div class="search-loading">Търси...</div>';
                searchDropdown.classList.add('show');
                
                fetch('api/live-search.php?q=' + encodeURIComponent(query) + '&limit=8')
                    .then(response => response.json())
                    .then(data => {
                        if (!Array.isArray(data) || data.length === 0) {
                            searchDropdown.innerHTML = '<div class="search-no-results">Няма намерени продукти</div>';
                            return;
                        }
                        
                        let html = '';
                        data.forEach(product => {
                            // Show sale price if available, otherwise show regular price
                            const displayPrice = product.sale_price ? `${parseFloat(product.sale_price).toFixed(2)} €` : `${parseFloat(product.price).toFixed(2)} €`;
                            const priceHtml = product.sale_price 
                                ? `<div class="search-result-price"><span class="sale-price">${parseFloat(product.sale_price).toFixed(2)} €</span><span class="original-price">${parseFloat(product.price).toFixed(2)} €</span></div>`
                                : `<div class="search-result-price">${parseFloat(product.price).toFixed(2)} €</div>`;
                            
                            html += `
                                <a href="itempage.php?id=${product.id}" class="search-result-item">
                                    <img src="${product.image}" alt="${product.name}" class="search-result-image">
                                    <div class="search-result-info">
                                        <div class="search-result-name">${product.name}</div>
                                        ${priceHtml}
                                    </div>
                                </a>
                            `;
                        });
                        searchDropdown.innerHTML = html;
                    })
                    .catch(error => {
                        console.error('Search error:', error);
                        searchDropdown.innerHTML = '<div class="search-no-results">Грешка при търсенето</div>';
                    });
            }
            
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    clearTimeout(searchTimeout);
                    const query = e.target.value.trim();
                    
                    if (query.length < 2) {
                        searchDropdown.classList.remove('show');
                        return;
                    }
                    
                    // Debounce the search
                    searchTimeout = setTimeout(() => {
                        fetchSearchResults(query);
                    }, 300);
                });
                
                searchInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        clearTimeout(searchTimeout);
                        performSearch();
                    }
                });
                
                searchInput.addEventListener('focus', function() {
                    if (this.value.length >= 2) {
                        fetchSearchResults(this.value);
                    }
                });
            }
            
            if (searchBtn) {
                searchBtn.addEventListener('click', performSearch);
            }
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.search-bar')) {
                    searchDropdown.classList.remove('show');
                }
            });

            // Cart-specific functionality
            const qtyBtns = document.querySelectorAll('.quantity-btn');
            if (qtyBtns && qtyBtns.length) {
                onEach(qtyBtns, btn => {
                    btn.addEventListener('click', function() {
                        const span = this.parentElement.querySelector('span');
                        if (!span) return;
                        let quantity = parseInt(span.textContent) || 0;
                        if (this.textContent.trim() === '+' && quantity < 10) {
                            span.textContent = quantity + 1;
                        } else if (this.textContent.trim() === '-' && quantity > 1) {
                            span.textContent = quantity - 1;
                        }
                    });
                });
            }

            // Remove button functionality
            const removeBtns = document.querySelectorAll('.remove-btn');
            if (removeBtns && removeBtns.length) {
                onEach(removeBtns, btn => {
                    btn.addEventListener('click', function() {
                        const item = this.closest('.cart-item');
                        if (item) item.remove();
                    });
                });
            }

            // Carousel functionality (guarded)
            let currentSlide = 0;
            const slides = document.querySelectorAll('.slide');
            const indicators = document.querySelectorAll('.indicator');

            if (slides && slides.length) {
                const totalSlides = slides.length;
                const updateCarousel = function() {
                    const carousel = document.querySelector('.carousel');
                    if (carousel) carousel.style.transform = `translateX(-${currentSlide * 100}%)`;
                    if (indicators && indicators.length) {
                        indicators.forEach((indicator, index) => indicator.classList.toggle('active', index === currentSlide));
                    }
                };

                const prevBtn = document.querySelector('.prev-btn');
                const nextBtn = document.querySelector('.next-btn');

                if (prevBtn) prevBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide > 0) ? currentSlide - 1 : totalSlides - 1;
                    updateCarousel();
                });

                if (nextBtn) nextBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide < totalSlides - 1) ? currentSlide + 1 : 0;
                    updateCarousel();
                });

                if (indicators && indicators.length) {
                    indicators.forEach((indicator, index) => {
                        indicator.addEventListener('click', () => {
                            currentSlide = index;
                            updateCarousel();
                        });
                    });
                }
            }

            // Profile tab navigation
            const profileNavBtns = document.querySelectorAll('.profile-nav .nav-btn');
            const profileSections = document.querySelectorAll('.section');

            if (profileNavBtns.length > 0) {
                profileNavBtns.forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        
                        // Logout button - redirect
                        if (this.classList.contains('logout-btn')) {
                            window.location.href = 'api/logout.php';
                            return;
                        }

                        // Get target section
                        const targetSection = this.getAttribute('data-section');
                        if (!targetSection) return;

                        // Hide all sections
                        profileSections.forEach(section => {
                            section.classList.remove('active');
                        });

                        // Remove active from all buttons
                        profileNavBtns.forEach(b => b.classList.remove('active'));

                        // Show target section
                        const sectionId = targetSection + '-section';
                        const section = document.getElementById(sectionId);
                        if (section) {
                            section.classList.add('active');
                        }

                        // Mark this button active
                        this.classList.add('active');
                        
                        console.log('Profile section switched to:', targetSection);
                    });
                });
            }
        });
    })();
    
    // Product quantity selector functions
    window.incrementQty = function() {
        const qtyInput = document.getElementById('quantity');
        if (qtyInput) {
            let val = parseInt(qtyInput.value) || 1;
            const max = parseInt(qtyInput.getAttribute('max')) || 999;
            if (val < max) {
                qtyInput.value = val + 1;
            }
        }
    };
    
    window.decrementQty = function() {
        const qtyInput = document.getElementById('quantity');
        if (qtyInput) {
            let val = parseInt(qtyInput.value) || 1;
            if (val > 1) {
                qtyInput.value = val - 1;
            }
        }
    };
    
    // Robust image error handling
    document.addEventListener('DOMContentLoaded', function() {
        // Handle broken images
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            img.addEventListener('error', function() {
                // Create a simple placeholder
                this.style.display = 'block';
                this.style.backgroundColor = '#f0f0f0';
                this.style.color = '#999';
                this.style.minHeight = '100px';
                
                // Replace with a simple gray placeholder that maintains aspect ratio
                const canvas = document.createElement('canvas');
                const w = this.width || 300;
                const h = this.height || 200;
                canvas.width = w;
                canvas.height = h;
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#f5f5f5';
                ctx.fillRect(0, 0, w, h);
                ctx.fillStyle = '#ccc';
                ctx.font = '14px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('No Image Available', w/2, h/2);
                
                this.src = canvas.toDataURL();
                this.style.backgroundColor = 'transparent';
            }, {once: true});
        });
    });
    
    // Update cart badge - works for both guests and logged-in users
    window.updateCartBadge = function() {
        const badge = document.getElementById('cart-badge');
        if (!badge) {
            console.log('Badge not found');
            return;
        }
        
        console.log('=== Cart Badge Update Starting ===');
        
        // First check server for logged-in users
        fetch('api/cart.php', {
            method: 'GET',
            credentials: 'include'
        })
        .then(response => {
            console.log('Server response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Server cart data received:', data);
            
            let serverCount = 0;
            if (data && Array.isArray(data) && data.length > 0) {
                serverCount = data.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
                console.log('Server cart count:', serverCount);
            }
            
            // If server has items, show server cart count
            if (serverCount > 0) {
                badge.style.display = 'flex';
                badge.textContent = serverCount;
                console.log('✓ Badge shown from server (logged-in):', serverCount);
                return;
            }
            
            console.log('No server cart items, checking localStorage...');
            
            // Otherwise check guest cart in localStorage
            const guestCartStr = localStorage.getItem('guest_cart');
            let guestCount = 0;
            if (guestCartStr) {
                try {
                    const guestCart = JSON.parse(guestCartStr);
                    if (Array.isArray(guestCart)) {
                        guestCount = guestCart.reduce((sum, item) => sum + (parseInt(item.quantity) || 1), 0);
                        console.log('Guest cart count:', guestCount);
                    }
                } catch (e) {
                    console.log('Error parsing guest cart', e);
                }
            }
            
            // Show guest cart or hide if empty
            if (guestCount > 0) {
                badge.style.display = 'flex';
                badge.textContent = guestCount;
                console.log('✓ Badge shown from localStorage (guest):', guestCount);
            } else {
                badge.style.display = 'none';
                console.log('✗ Badge hidden, no items in any cart');
            }
        })
        .catch(err => {
            console.error('Error fetching server cart:', err);
            
            // Fallback to guest cart
            const guestCartStr = localStorage.getItem('guest_cart');
            let guestCount = 0;
            if (guestCartStr) {
                try {
                    const guestCart = JSON.parse(guestCartStr);
                    if (Array.isArray(guestCart)) {
                        guestCount = guestCart.reduce((sum, item) => sum + (parseInt(item.quantity) || 1), 0);
                    }
                } catch (e) {
                    console.log('Error parsing guest cart', e);
                }
            }
            
            if (guestCount > 0) {
                badge.style.display = 'flex';
                badge.textContent = guestCount;
                console.log('✓ Badge shown from localStorage (fallback):', guestCount);
            } else {
                badge.style.display = 'none';
                console.log('✗ Badge hidden');
            }
        });
    };
    
    // Run on page load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', window.updateCartBadge);
    } else {
        window.updateCartBadge();
    }
    
    // Update when storage changes
    window.addEventListener('storage', window.updateCartBadge);

    // Banner Carousel functions
    let currentBannerSlide = 0;
    let totalBannerSlides = 0;
    let bannerAutoPlayInterval;

    function initBannerCarousel() {
        const carousel = document.getElementById('bannerCarousel');
        const slides = carousel ? carousel.querySelectorAll('.banner-slide') : [];
        totalBannerSlides = slides.length;
        
        if (totalBannerSlides > 0) {
            updateBannerCarouselDisplay();
            // Auto-play banner carousel every 5 seconds if more than 1 slide
            if (totalBannerSlides > 1) {
                bannerAutoPlayInterval = setInterval(() => {
                    moveBannerCarousel(1);
                }, 5000);
            }
        }
    }

    function updateBannerCarouselDisplay() {
        const carousel = document.getElementById('bannerCarousel');
        if (carousel) {
            carousel.style.transform = `translateX(-${currentBannerSlide * 100}%)`;
        }
        
        // Update navigation dots
        const dots = document.querySelectorAll('.banner-nav-dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentBannerSlide);
        });
    }

    window.moveBannerCarousel = function(direction) {
        if (totalBannerSlides === 0) return;
        
        currentBannerSlide += direction;
        
        if (currentBannerSlide >= totalBannerSlides) {
            currentBannerSlide = 0;
        } else if (currentBannerSlide < 0) {
            currentBannerSlide = totalBannerSlides - 1;
        }
        
        updateBannerCarouselDisplay();
        
        // Reset auto-play timer
        if (totalBannerSlides > 1) {
            clearInterval(bannerAutoPlayInterval);
            bannerAutoPlayInterval = setInterval(() => {
                moveBannerCarousel(1);
            }, 5000);
        }
    };

    window.goToBannerSlide = function(index) {
        if (index >= 0 && index < totalBannerSlides) {
            currentBannerSlide = index;
            updateBannerCarouselDisplay();
            
            // Reset auto-play timer
            if (totalBannerSlides > 1) {
                clearInterval(bannerAutoPlayInterval);
                bannerAutoPlayInterval = setInterval(() => {
                    moveBannerCarousel(1);
                }, 5000);
            }
        }
    };

    // Initialize banner carousel when DOM is ready
    document.addEventListener('DOMContentLoaded', initBannerCarousel);

</script>


