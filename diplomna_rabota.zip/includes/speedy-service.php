<?php
/**
 * Speedy Courier Service - REST API Integration
 * 
 * Speedy provides comprehensive shipping services across Bulgaria and Europe
 * NOTE: Using modern REST API (SOAP/EPS is deprecated and will be decommissioned end of 2024)
 * 
 * API Documentation: https://api.speedy.bg/web-api.html
 * API Examples: https://services.speedy.bg/api/api_examples.html
 * Support: api.support@speedy.bg
 * Credentials: api.registration@speedy.bg
 */

class SpeedyService extends DeliveryService {
    
    private $api_key;
    private $api_url;
    private $auth_token;
    private $customer_id;
    
    public function __construct() {
        parent::__construct();
        
        $this->api_key = getenv('SPEEDY_API_KEY') ?: 'test_api_key';
        $this->customer_id = getenv('SPEEDY_CUSTOMER_ID') ?: '9999';
        $this->api_url = getenv('SPEEDY_API_URL') ?: 'https://api.speedy.bg';
        
        if ($this->is_test) {
            // Test environment
            $this->api_url = 'https://test-api.speedy.bg';
        }
    }
    
    /**
     * Make HTTP request to Speedy REST API
     */
    private function makeRequest($method, $endpoint, $data = null, $headers = []) {
        try {
            $url = $this->api_url . $endpoint;
            
            $curl_options = [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => !$this->is_test,
                CURLOPT_SSL_VERIFYHOST => !$this->is_test ? 2 : 0,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => array_merge([
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->api_key,
                    'User-Agent: DroncheBG/1.0'
                ], $headers)
            ];
            
            if ($method !== 'GET' && $data) {
                $curl_options[CURLOPT_POSTFIELDS] = json_encode($data);
            }
            
            $curl = curl_init();
            curl_setopt_array($curl, $curl_options);
            
            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($curl);
            
            curl_close($curl);
            
            if ($curl_error) {
                throw new Exception('CURL Error: ' . $curl_error);
            }
            
            $result = json_decode($response, true);
            
            if ($http_code >= 400) {
                $error_msg = $result['error'] ?? $result['message'] ?? 'HTTP ' . $http_code;
                throw new Exception('API Error: ' . $error_msg);
            }
            
            $this->log('SPEEDY_API_' . $method, ['endpoint' => $endpoint, 'data' => $data], $result);
            
            return $result;
            
        } catch (Exception $e) {
            $this->log('SPEEDY_REQUEST_ERROR', ['method' => $method, 'endpoint' => $endpoint], ['error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Get all Speedy offices, filtered by city if provided
     */
    public function getOffices($city = null) {
        try {
            // First, try to get from database (populated by migration)
            $offices = $this->getOfficesFromDatabase($city);
            
            if (!empty($offices)) {
                return $this->response(true, 'Offices retrieved from database', [
                    'count' => count($offices),
                    'offices' => $offices
                ]);
            }
            
            // If not in database, try to fetch from API
            if (!$this->is_test && $this->api_key !== 'test_api_key') {
                return $this->getOfficesFromAPI($city);
            }
            
            throw new Exception('No offices available');
            
        } catch (Exception $e) {
            $this->log('GET_OFFICES_ERROR', ['city' => $city, 'error' => $e->getMessage()]);
            return $this->response(false, 'Failed to get offices: ' . $e->getMessage());
        }
    }
    
    /**
     * Get offices from database
     */
    private function getOfficesFromDatabase($city = null) {
        global $conn;
        
        $query = "SELECT id, label, city, street, phone, working_hours, is_active 
                  FROM delivery_offices 
                  WHERE delivery_method_id = 2 AND is_active = 1";
        
        if ($city) {
            $city = $conn->real_escape_string($city);
            $query .= " AND city LIKE '%$city%'";
        }
        
        $query .= " ORDER BY city ASC, label ASC";
        
        $result = $conn->query($query);
        
        if (!$result) {
            throw new Exception('Database query failed: ' . $conn->error);
        }
        
        $offices = [];
        while ($row = $result->fetch_assoc()) {
            $offices[] = [
                'id' => $row['id'],
                'name' => $row['label'],
                'city' => $row['city'],
                'street' => $row['street'],
                'phone' => $row['phone'] ?: '+359 1 123 45 67',
                'hours' => $row['working_hours'] ?: '08:00 - 18:00',
                'type' => 'Speedy Center'
            ];
        }
        
        return $offices;
    }
    
    /**
     * Get offices from Speedy REST API (live call)
     * Documentation: https://api.speedy.bg/web-api.html
     */
    private function getOfficesFromAPI($city = null) {
        try {
            // Build query parameters
            $params = [
                'language' => 'BG'
            ];
            
            if ($city) {
                $params['city'] = $city;
            }
            
            $endpoint = '/v1/locations/parcel-shops?' . http_build_query($params);
            
            $response = $this->makeRequest('GET', $endpoint);
            
            $offices = [];
            if (isset($response['items']) && is_array($response['items'])) {
                foreach ($response['items'] as $location) {
                    $offices[] = [
                        'id' => $location['id'] ?? null,
                        'name' => $location['name'] ?? 'Speedy Office',
                        'city' => $location['city'] ?? 'N/A',
                        'street' => $location['address'] ?? 'N/A',
                        'phone' => $location['phone'] ?? '+359 1 7001 7001',
                        'hours' => $this->formatWorkingHours($location),
                        'type' => 'Speedy Parcel Shop',
                        'external_id' => $location['id'] ?? null
                    ];
                }
            }
            
            $this->log('GET_OFFICES_API', ['city' => $city], ['count' => count($offices)]);
            
            return $offices;
            
        } catch (Exception $e) {
            $this->log('SPEEDY_API_ERROR', ['action' => 'GetLocations', 'error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Format working hours from REST API response
     */
    private function formatWorkingHours($location) {
        if (isset($location['workingHours'])) {
            return $location['workingHours'];
        }
        if (isset($location['hours'])) {
            return $location['hours'];
        }
        return '08:00 - 18:00';
    }
    
    /**
     * Create a shipment in Speedy
     */
    public function createShipment($shipment_data) {
        try {
            $required = ['recipient_name', 'recipient_phone', 'delivery_office_id', 'weight', 'order_id'];
            $this->validateFields($shipment_data, $required);
            
            if (!$this->soap_client && !$this->is_test) {
                throw new Exception('SOAP client not available for production');
            }
            
            // In test mode or without SOAP, create a dummy shipment
            if ($this->is_test || !$this->soap_client) {
                return $this->createTestShipment($shipment_data);
            }
            
            // Real API call (requires proper credentials)
            return $this->createRealShipment($shipment_data);
            
        } catch (Exception $e) {
            $this->log('CREATE_SHIPMENT_ERROR', $shipment_data, ['error' => $e->getMessage()]);
            return $this->response(false, 'Failed to create shipment: ' . $e->getMessage());
        }
    }
    
    /**
     * Create test shipment (for development)
     */
    private function createTestShipment($shipment_data) {
        $shipment_id = 'SPEEDY_TST_' . date('YmdHis') . '_' . rand(1000, 9999);
        
        global $conn;
        
        // Store shipment info in database
        $order_id = intval($shipment_data['order_id']);
        $stmt = $conn->prepare("UPDATE orders SET external_shipment_id = ?, shipment_status = ? WHERE id = ?");
        $stmt->bind_param("ssi", $shipment_id, $status = 'pending', $order_id);
        $stmt->execute();
        $stmt->close();
        
        $this->log('CREATE_SHIPMENT_TEST', $shipment_data, ['shipment_id' => $shipment_id]);
        
        return $this->response(true, 'Test shipment created', [
            'shipment_id' => $shipment_id,
            'status' => 'pending',
            'method' => 'speedy',
            'created_at' => date('Y-m-d H:i:s'),
            'note' => 'Test mode - shipment not sent to Speedy'
        ]);
    }
    
    /**
     * Create real shipment via REST API
     * Documentation: https://api.speedy.bg/web-api.html#shipments
     */
    private function createRealShipment($shipment_data) {
        try {
            // Get office details
            global $conn;
            $office_id = intval($shipment_data['delivery_office_id']);
            
            $stmt = $conn->prepare("SELECT city, street FROM delivery_offices WHERE id = ? AND delivery_method_id = 2");
            $stmt->bind_param("i", $office_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception('Delivery office not found');
            }
            
            $office = $result->fetch_assoc();
            $stmt->close();
            
            // Prepare shipment request for Speedy REST API
            $payload = [
                'serviceType' => 'STANDARD', // or 'COURIER', 'DOCUMENT'
                'recipient' => [
                    'name' => $shipment_data['recipient_name'],
                    'phone' => $shipment_data['recipient_phone'],
                    'address' => $office['street'],
                    'city' => $office['city'],
                    'country' => 'BG'
                ],
                'parcel' => [
                    'weight' => $shipment_data['weight'] ?? 1,
                    'width' => 0,
                    'height' => 0,
                    'depth' => 0
                ],
                'deliveryType' => 'OFFICE' // Delivery to office
            ];
            
            // Call Speedy API to create shipment
            $response = $this->makeRequest('POST', '/v1/shipments', $payload);
            
            if (!isset($response['shipmentNumber'])) {
                throw new Exception('Failed to create shipment: ' . json_encode($response));
            }
            
            $shipment_id = 'SPEEDY_' . $response['shipmentNumber'];
            
            // Store in database
            $order_id = intval($shipment_data['order_id']);
            $status = 'pending';
            $stmt = $conn->prepare("UPDATE orders SET external_shipment_id = ?, shipment_status = ? WHERE id = ?");
            $stmt->bind_param("ssi", $shipment_id, $status, $order_id);
            $stmt->execute();
            $stmt->close();
            
            $this->log('CREATE_SHIPMENT_API', $shipment_data, ['shipment_id' => $shipment_id]);
            
            return [
                'shipment_id' => $shipment_id,
                'status' => 'pending',
                'method' => 'speedy',
                'created_at' => date('Y-m-d H:i:s'),
                'external_reference' => $response['shipmentNumber'] ?? null
            ];
            
        } catch (Exception $e) {
            $this->log('CREATE_SHIPMENT_API_ERROR', $shipment_data, ['error' => $e->getMessage()]);
            throw $e;
        }
    }
    
    /**
     * Get shipment tracking
     */
    public function getTracking($shipment_id) {
        try {
            global $conn;
            
            // Get shipment from database
            $stmt = $conn->prepare("SELECT o.id, o.shipment_status, o.delivery_method_id, o.created_at 
                                     FROM orders o 
                                     WHERE o.external_shipment_id = ?");
            $stmt->bind_param("s", $shipment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return $this->response(false, 'Shipment not found');
            }
            
            $shipment = $result->fetch_assoc();
            $stmt->close();
            
            // Simulate tracking
            $tracking = [
                'shipment_id' => $shipment_id,
                'status' => $shipment['shipment_status'] ?: 'pending',
                'created_at' => $shipment['created_at'],
                'events' => [
                    [
                        'timestamp' => $shipment['created_at'],
                        'status' => 'Created',
                        'location' => 'Shipper',
                        'message' => 'Shipment created'
                    ]
                ]
            ];
            
            // If in production and API available, get real tracking
            if (!$this->is_test && $this->soap_client) {
                $tracking['events'] = $this->getRealTracking($shipment_id);
            }
            
            return $this->response(true, 'Tracking information retrieved', $tracking);
            
        } catch (Exception $e) {
            $this->log('GET_TRACKING_ERROR', ['shipment_id' => $shipment_id, 'error' => $e->getMessage()]);
            return $this->response(false, 'Failed to get tracking: ' . $e->getMessage());
        }
    }
    
    /**
     * Get real tracking from REST API
     * Documentation: https://api.speedy.bg/web-api.html#tracking
     */
    private function getRealTracking($shipment_id) {
        try {
            // Extract shipment number from our ID format (SPEEDY_123456)
            $ext_id = str_replace('SPEEDY_', '', $shipment_id);
            
            $response = $this->makeRequest('GET', '/v1/shipments/' . $ext_id . '/tracking');
            
            $events = [];
            if (isset($response['events']) && is_array($response['events'])) {
                foreach ($response['events'] as $event) {
                    $events[] = [
                        'timestamp' => $event['timestamp'] ?? date('Y-m-d H:i:s'),
                        'status' => $event['status'] ?? 'Unknown',
                        'location' => $event['location'] ?? 'N/A',
                        'message' => $event['description'] ?? ''
                    ];
                }
            }
            
            return $events;
            
        } catch (Exception $e) {
            $this->log('GET_TRACKING_ERROR', ['shipment_id' => $shipment_id], ['error' => $e->getMessage()]);
            return [];
        }
    }
    
    /**
     * Calculate delivery time and cost
     */
    public function calculateDelivery($from_city, $to_city, $weight = 1) {
        return [
            'cost' => 4.99,
            'min_days' => 2,
            'max_days' => 4,
            'carrier' => 'Speedy',
            'note' => 'Business days only'
        ];
    }
}
?>
