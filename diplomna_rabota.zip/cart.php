<?php
$page_title = 'Количка - Dronche.BG';
$page_css = 'css/cart.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="cart-container">
        <div class="container">
            <h1 class="section-title">Количка</h1>
            
            <div class="cart-content">
                <div class="cart-items" id="cart-items">
                    <?php
                    $subtotal = 0;
                    $cart_count = 0;
                    
                    // Check if user is logged in
                    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                    
                    // For guest users, create a unique guest ID based on session
                    if ($user_id === 0) {
                        if (!isset($_SESSION['guest_id'])) {
                            $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
                        }
                        $db_user_id = -1; // Use -1 for guests in database
                    } else {
                        $db_user_id = $user_id;
                    }
                    
                    // Load cart items from database (for both logged-in and guest users)
                    $cart_query = "SELECT c.product_id, c.quantity, c.id as cart_id, p.name, p.price, p.sale_price, p.discount_percent, p.image_1 
                                  FROM cart c 
                                  JOIN products p ON c.product_id = p.id 
                                  WHERE c.user_id = $db_user_id";
                    $cart_result = $conn->query($cart_query);
                    
                    if ($cart_result && $cart_result->num_rows > 0) {
                        while ($item = $cart_result->fetch_assoc()) {
                            // Use sale price if available, otherwise use regular price
                            $display_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price'];
                            $item_total = $display_price * $item['quantity'];
                            $subtotal += $item_total;
                            $cart_count++;
                            $product_id = $item['product_id'];
                    ?>
                    <div class="cart-item" data-product-id="<?php echo htmlspecialchars($product_id); ?>">
                        <img src="<?php echo htmlspecialchars(get_image_url($item['image_1'], $item['name'])); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="cart-item-image" style="width: auto; height: 100px;">
                        <div class="cart-item-details">
                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                            <div class="cart-item-price"><?php echo number_format($display_price, 2); ?> €</div>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="cart-qty-minus" data-product-id="<?php echo htmlspecialchars($product_id); ?>">-</button>
                            <span class="quantity-value"><?php echo intval($item['quantity']); ?></span>
                            <button class="cart-qty-plus" data-product-id="<?php echo htmlspecialchars($product_id); ?>">+</button>
                        </div>
                        <button class="remove-btn" data-product-id="<?php echo htmlspecialchars($product_id); ?>">Премахни</button>
                    </div>
                    <?php
                        }
                    } else {
                        echo '<p style="padding: 20px;">Вашата количка е празна. <a href="homepage.php">Продължете към пазаруването</a></p>';
                    }
                    ?>
                </div>
                
                <div class="cart-summary">
                    <h2>Приключване на поръчката</h2>
                    <div class="summary-row">
                        <span>Общо</span>
                        <span id="subtotal"><?php echo number_format($subtotal, 2); ?> €</span>
                    </div>
                    <div class="summary-row">
                        <span>Доставка</span>
                        <span id="shipping">3.00 €</span>
                    </div>
                    <div class="summary-row total">
                        <span>Общо</span>
                        <span id="total"><?php echo number_format($subtotal + 3, 2); ?> €</span>
                    </div>
                    <button class="checkout-btn" id="checkout-btn" <?php echo $cart_count === 0 ? 'disabled' : ''; ?>>
                        <a href="payment.php" class="checkout-link" <?php echo $cart_count === 0 ? 'onclick="return false;"' : ''; ?>>Продължете към плащане</a>
                    </button>
                    <a href="homepage.php" class="continue-shopping">Продължете към пазаруването</a>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    
    <script>
        let cartListenersAttached = false;
        
        // Load guest cart from localStorage if user is not logged in
        document.addEventListener('DOMContentLoaded', function() {
            const cartContainer = document.getElementById('cart-items');
            
            // Recalculate totals immediately based on what's visible
            updateCartTotals();
            
            // Check if the cart is currently empty
            const isEmpty = cartContainer.querySelector('p') !== null;
            
            // Load guest cart from localStorage
            const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            
            if (guestCart.length > 0) {
                // If there was no database cart, clear the empty message
                if (isEmpty) {
                    cartContainer.innerHTML = '';
                }
                
                // Load product details and render guest cart items
                const promises = guestCart.map(item => {
                    return fetch(`api/cart.php?action=get_product&product_id=${item.product_id}`)
                        .then(r => r.json())
                        .then(data => {
                            if (data.success && data.product) {
                                const product = data.product;
                                const cartItem = document.createElement('div');
                                cartItem.className = 'cart-item guest-cart-item';
                                cartItem.setAttribute('data-product-id', item.product_id);
                                
                                const img = document.createElement('img');
                                img.src = product.image_1;
                                img.alt = product.name;
                                img.className = 'cart-item-image';
                                cartItem.appendChild(img);
                                
                                const details = document.createElement('div');
                                details.className = 'cart-item-details';
                                const h3 = document.createElement('h3');
                                h3.textContent = product.name;
                                const priceDiv = document.createElement('div');
                                priceDiv.className = 'cart-item-price';
                                priceDiv.textContent = parseFloat(product.price).toLocaleString('bg-BG', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' €';
                                details.appendChild(h3);
                                details.appendChild(priceDiv);
                                cartItem.appendChild(details);
                                
                                const qtyDiv = document.createElement('div');
                                qtyDiv.className = 'cart-item-quantity';
                                const minusBtn = document.createElement('button');
                                minusBtn.className = 'cart-qty-minus guest-qty-minus';
                                minusBtn.setAttribute('data-product-id', item.product_id);
                                minusBtn.textContent = '-';
                                const qtySpan = document.createElement('span');
                                qtySpan.className = 'quantity-value';
                                qtySpan.textContent = item.quantity;
                                const plusBtn = document.createElement('button');
                                plusBtn.className = 'cart-qty-plus guest-qty-plus';
                                plusBtn.setAttribute('data-product-id', item.product_id);
                                plusBtn.textContent = '+';
                                qtyDiv.appendChild(minusBtn);
                                qtyDiv.appendChild(qtySpan);
                                qtyDiv.appendChild(plusBtn);
                                cartItem.appendChild(qtyDiv);
                                
                                const removeBtn = document.createElement('button');
                                removeBtn.className = 'remove-btn guest-remove-btn';
                                removeBtn.setAttribute('data-product-id', item.product_id);
                                removeBtn.textContent = 'Премахни';
                                cartItem.appendChild(removeBtn);
                                
                                cartContainer.appendChild(cartItem);
                                updateCartTotals();
                            }
                        })
                        .catch(err => console.error('Error loading product:', err));
                });
                
                // Enable checkout button for guests with items
                Promise.all(promises).then(() => {
                    attachCartEventListeners();
                    const checkoutBtn = document.getElementById('checkout-btn');
                    if (checkoutBtn && guestCart.length > 0) {
                        checkoutBtn.disabled = false;
                        checkoutBtn.querySelector('.checkout-link').onclick = null;
                    }
                });
            } else {
                // Database cart - attach listeners and calculate totals
                attachCartEventListeners();
            }
        });
        
        // Update cart totals
        function updateCartTotals() {
            console.log('updateCartTotals called');
            let subtotal = 0;
            const cartItems = document.querySelectorAll('.cart-item');
            console.log('Found cart items:', cartItems.length);
            
            cartItems.forEach(item => {
                const priceText = item.querySelector('.cart-item-price').textContent.trim();
                // Extract number from formatted price (replace comma with dot first, then remove € and whitespace)
                const price = parseFloat(priceText.replace(',', '.').replace(/[€\s]/g, ''));
                const quantity = parseInt(item.querySelector('.quantity-value').textContent);
                console.log('Item price:', price, 'quantity:', quantity);
                subtotal += price * quantity;
            });
            
            const isEmpty = cartItems.length === 0;
            const shipping = isEmpty ? 0 : 3.00;
            const total = subtotal + shipping;
            
            console.log('New subtotal:', subtotal, 'shipping:', shipping, 'total:', total);
            
            document.getElementById('subtotal').textContent = subtotal.toFixed(2) + ' €';
            document.getElementById('shipping').textContent = shipping.toFixed(2) + ' €';
            document.getElementById('total').textContent = total.toFixed(2) + ' €';
            
            // Update checkout button state
            const checkoutBtn = document.getElementById('checkout-btn');
            const checkoutLink = checkoutBtn?.querySelector('.checkout-link');
            if (checkoutBtn) {
                checkoutBtn.disabled = isEmpty;
                if (isEmpty && checkoutLink) {
                    checkoutLink.onclick = () => false;
                } else if (checkoutLink) {
                    checkoutLink.onclick = null;
                }
            }
        }
        
        // Update quantity in database/session
        function updateQuantity(productId, newQuantity) {
            if (newQuantity <= 0) return;
            
            fetch('api/cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    product_id: productId, 
                    quantity: newQuantity,
                    action: 'update' 
                })
            })
            .then(r => r.json())
            .then(data => {
                if (!data.success && !data.guest) {
                    console.error(data.message);
                    location.reload();
                }
            })
            .catch(err => console.error('Error updating quantity:', err));
        }
        
        // Update guest cart in localStorage
        function updateGuestCartQuantity(productId, newQuantity) {
            if (newQuantity <= 0) {
                removeGuestCartItem(productId);
                return;
            }
            
            let cart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            const item = cart.find(i => i.product_id === parseInt(productId));
            if (item) {
                item.quantity = newQuantity;
                localStorage.setItem('guest_cart', JSON.stringify(cart));
                // Update cart badge
                if (window.updateCartBadge) {
                    window.updateCartBadge();
                }
            }
        }
        
        // Remove item from guest cart
        function removeGuestCartItem(productId) {
            let cart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            cart = cart.filter(i => i.product_id !== parseInt(productId));
            localStorage.setItem('guest_cart', JSON.stringify(cart));
            // Update cart badge
            if (window.updateCartBadge) {
                window.updateCartBadge();
            }
        }
        
        // Attach event listeners to cart items using event delegation
        function attachCartEventListeners() {
            if (cartListenersAttached) return;
            cartListenersAttached = true;
            
            const cartContainer = document.getElementById('cart-items');
            
            if (!cartContainer) return;
            
            // Use event delegation for better reliability
            cartContainer.addEventListener('click', function(e) {
                console.log('Cart click detected on:', e.target, 'Classes:', e.target.className);
                
                // Handle remove button
                if (e.target.classList.contains('remove-btn')) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const btn = e.target;
                    const productId = btn.getAttribute('data-product-id');
                    const isGuest = btn.classList.contains('guest-remove-btn');
                    
                    console.log('Remove button clicked for product:', productId, 'isGuest:', isGuest);
                    
                    if (isGuest) {
                        removeGuestCartItem(productId);
                        // Find and remove the item from DOM
                        const items = cartContainer.querySelectorAll('.cart-item');
                        items.forEach(item => {
                            if (item.getAttribute('data-product-id') == productId) {
                                item.remove();
                            }
                        });
                        updateCartTotals();
                        if (window.updateCartBadge) {
                            window.updateCartBadge();
                        }
                        // Check if cart is empty
                        if (cartContainer.querySelectorAll('.cart-item').length === 0) {
                            cartContainer.innerHTML = '<p style="padding: 20px;">Вашата количка е празна. <a href="homepage.php">Продължете към пазаруването</a></p>';
                            const checkoutBtn = document.getElementById('checkout-btn');
                            if (checkoutBtn) checkoutBtn.disabled = true;
                        }
                    } else {
                        // For logged-in users, remove from DOM immediately and update backend
                        const items = cartContainer.querySelectorAll('.cart-item');
                        items.forEach(item => {
                            if (item.getAttribute('data-product-id') == productId) {
                                item.remove();
                            }
                        });
                        updateCartTotals();
                        if (window.updateCartBadge) {
                            window.updateCartBadge();
                        }
                        // Check if cart is empty
                        if (cartContainer.querySelectorAll('.cart-item').length === 0) {
                            cartContainer.innerHTML = '<p style="padding: 20px;">Вашата количка е празна. <a href="homepage.php">Продължете към пазаруването</a></p>';
                            const checkoutBtn = document.getElementById('checkout-btn');
                            if (checkoutBtn) checkoutBtn.disabled = true;
                        }
                        
                        // Send to API in background
                        fetch('api/cart.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ product_id: parseInt(productId), action: 'remove' })
                        })
                        .then(r => r.json())
                        .then(data => {
                            console.log('Remove response:', data);
                            if (!data.success) {
                                console.error('Failed to remove:', data.message);
                                // Reload page to sync if backend removal failed
                                location.reload();
                            }
                        })
                        .catch(err => {
                            console.error('Error:', err);
                            // Reload page to sync if request failed
                            location.reload();
                        });
                    }
                }
                
                // Handle quantity plus button
                else if (e.target.classList.contains('cart-qty-plus')) {
                    const btn = e.target;
                    const productId = btn.getAttribute('data-product-id');
                    const isGuest = btn.classList.contains('guest-qty-plus');
                    const quantityEl = btn.parentElement.querySelector('.quantity-value');
                    const newQty = parseInt(quantityEl.textContent) + 1;
                    quantityEl.textContent = newQty;
                    
                    if (isGuest) {
                        updateGuestCartQuantity(productId, newQty);
                    } else {
                        updateQuantity(productId, newQty);
                    }
                    updateCartTotals();
                    if (window.updateCartBadge) {
                        window.updateCartBadge();
                    }
                }
                
                // Handle quantity minus button
                else if (e.target.classList.contains('cart-qty-minus')) {
                    const btn = e.target;
                    const productId = btn.getAttribute('data-product-id');
                    const isGuest = btn.classList.contains('guest-qty-minus');
                    const quantityEl = btn.parentElement.querySelector('.quantity-value');
                    let newQty = parseInt(quantityEl.textContent) - 1;
                    if (newQty < 1) newQty = 1;
                    if (newQty === parseInt(quantityEl.textContent)) return;
                    quantityEl.textContent = newQty;
                    
                    if (isGuest) {
                        updateGuestCartQuantity(productId, newQty);
                    } else {
                        updateQuantity(productId, newQty);
                    }
                    updateCartTotals();
                    if (window.updateCartBadge) {
                        window.updateCartBadge();
                    }
                }
            });
        }
    </script>
</body>
</html>
