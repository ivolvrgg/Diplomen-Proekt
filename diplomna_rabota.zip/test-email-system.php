<?php
/**
 * Email System Test Script
 * Visit: /Diplomna_rabota/test-email-system.php
 * 
 * Provides comprehensive testing of the email sending system
 */

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email System Test</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }
        
        .container {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        h1 {
            color: #333;
            border-bottom: 3px solid #588157;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        
        .section {
            margin-bottom: 40px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 5px;
            border-left: 4px solid #588157;
        }
        
        h2 {
            color: #588157;
            margin-top: 0;
            font-size: 18px;
        }
        
        .status-check {
            margin: 15px 0;
            padding: 12px;
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .status-check.success {
            background: #d4edda;
            border-left: 4px solid #28a745;
        }
        
        .status-check.error {
            background: #f8d7da;
            border-left: 4px solid #dc3545;
        }
        
        .status-check.warning {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="email"],
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        button {
            background: #588157;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
        }
        
        button:hover {
            background: #467146;
        }
        
        button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .result {
            margin-top: 20px;
            padding: 15px;
            border-radius: 4px;
            display: none;
        }
        
        .result.success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .result.error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        
        .result.loading {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            color: #004085;
        }
        
        .log-area {
            background: #222;
            color: #0f0;
            padding: 15px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            max-height: 300px;
            overflow-y: auto;
            margin-top: 15px;
        }
        
        .link-button {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        
        .link-button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📧 Email System Test Suite</h1>
        
        <!-- Configuration Check -->
        <div class="section">
            <h2>✓ System Configuration Check</h2>
            <?php
            $checks = [];
            
            // 1. Mail config
            if (file_exists('config/mail.php')) {
                $config = require 'config/mail.php';
                $checks[] = ['name' => 'Mail Configuration', 'status' => 'success', 'message' => 'config/mail.php loaded'];
                
                // Check config contents
                if (!empty($config['host'])) {
                    $checks[] = ['name' => 'SMTP Host', 'status' => 'success', 'message' => $config['host']];
                } else {
                    $checks[] = ['name' => 'SMTP Host', 'status' => 'error', 'message' => 'Not configured'];
                }
                
                if (!empty($config['username'])) {
                    $checks[] = ['name' => 'SMTP Username', 'status' => 'success', 'message' => 'Configured (****)'];
                } else {
                    $checks[] = ['name' => 'SMTP Username', 'status' => 'error', 'message' => 'Not configured'];
                }
            } else {
                $checks[] = ['name' => 'Mail Configuration', 'status' => 'error', 'message' => 'config/mail.php not found'];
            }
            
            // 2. EmailHelper class
            if (file_exists('includes/EmailHelper.php')) {
                $checks[] = ['name' => 'EmailHelper Class', 'status' => 'success', 'message' => 'includes/EmailHelper.php found'];
            } else {
                $checks[] = ['name' => 'EmailHelper Class', 'status' => 'error', 'message' => 'includes/EmailHelper.php not found'];
            }
            
            // 3. Logs directory
            if (is_dir('logs')) {
                if (is_writable('logs')) {
                    $checks[] = ['name' => 'Logs Directory', 'status' => 'success', 'message' => 'logs/ is writable'];
                } else {
                    $checks[] = ['name' => 'Logs Directory', 'status' => 'warning', 'message' => 'logs/ is not writable'];
                }
            } else {
                $checks[] = ['name' => 'Logs Directory', 'status' => 'error', 'message' => 'logs/ directory not found'];
            }
            
            // Display checks
            foreach ($checks as $check) {
                echo "<div class='status-check {$check['status']}'>";
                echo "<span><strong>{$check['name']}:</strong> {$check['message']}</span>";
                echo "</div>";
            }
            ?>
        </div>
        
        <!-- Quick Test -->
        <div class="section">
            <h2>📤 Quick Email Test</h2>
            <form id="testForm" onsubmit="sendTestEmail(event)">
                <div class="form-group">
                    <label for="testEmail">Your Email Address *</label>
                    <input type="email" id="testEmail" name="email" required placeholder="your@email.com">
                </div>
                
                <div class="form-group">
                    <label for="testName">Your Name *</label>
                    <input type="text" id="testName" name="name" required placeholder="John Doe">
                </div>
                
                <button type="button" onclick="sendTestEmail()">Send Test Email</button>
                <div id="testResult" class="result"></div>
                
                <a href="api/email-status.php" class="link-button">📊 Check Email Status API</a>
            </form>
        </div>
        
        <!-- Email Logs -->
        <div class="section">
            <h2>📋 Recent Email Logs</h2>
            <?php
            $logFile = 'logs/email-errors.log';
            if (file_exists($logFile)) {
                $lines = array_reverse(file($logFile));
                $recent = array_slice($lines, 0, 30);
                echo "<div class='log-area'>";
                foreach ($recent as $line) {
                    echo htmlspecialchars($line);
                }
                echo "</div>";
                echo "<p style='font-size: 12px; color: #666; margin-top: 10px;'>Showing last 30 log entries</p>";
            } else {
                echo "<p style='color: #999;'>No email logs yet. Logs will appear here after the first email send.</p>";
            }
            ?>
        </div>
        
        <!-- Features Test -->
        <div class="section">
            <h2>✉️ Features Being Tested</h2>
            <ul style="line-height: 1.8; color: #333;">
                <li><strong>✓ Contact Form Confirmation</strong> - User receives email when submitting contact form</li>
                <li><strong>✓ Registration Welcome Email</strong> - New users receive welcome email on signup</li>
                <li><strong>✓ Order Confirmation</strong> - Order details sent to customer email</li>
                <li><strong>✓ Password Recovery Code</strong> - Recovery code sent to email</li>
                <li><strong>✓ Password Reset Confirmation</strong> - Confirmation email after successful reset</li>
            </ul>
        </div>
        
        <!-- Resources -->
        <div class="section">
            <h2>📚 Resources & Documentation</h2>
            <ul style="line-height: 1.8; color: #333;">
                <li><a href="../EMAIL_SYSTEM_AUDIT.md" style="color: #588157;">📄 Full Email System Audit Report</a></li>
                <li><strong>Config File:</strong> <code style="background: #f0f0f0; padding: 2px 5px;">config/mail.php</code></li>
                <li><strong>EmailHelper Class:</strong> <code style="background: #f0f0f0; padding: 2px 5px;">includes/EmailHelper.php</code></li>
                <li><strong>Email Logs:</strong> <code style="background: #f0f0f0; padding: 2px 5px;">logs/email-errors.log</code></li>
            </ul>
        </div>
    </div>
    
    <script>
        function sendTestEmail() {
            const email = document.getElementById('testEmail').value;
            const name = document.getElementById('testName').value;
            const resultDiv = document.getElementById('testResult');
            
            if (!email || !name) {
                resultDiv.className = 'result error';
                resultDiv.textContent = 'Моля, попълнете всички полета';
                resultDiv.style.display = 'block';
                return;
            }
            
            resultDiv.className = 'result loading';
            resultDiv.textContent = 'Sending test email...';
            resultDiv.style.display = 'block';
            
            fetch('api/test-send-email.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({email, name})
            })
            .then(r => r.json())
            .then(data => {
                resultDiv.textContent = data.message || (data.success ? 'Email sent successfully!' : 'Failed to send email');
                resultDiv.className = 'result ' + (data.success ? 'success' : 'error');
            })
            .catch(err => {
                resultDiv.textContent = 'Error: ' + err;
                resultDiv.className = 'result error';
            });
        }
    </script>
</body>
</html>
