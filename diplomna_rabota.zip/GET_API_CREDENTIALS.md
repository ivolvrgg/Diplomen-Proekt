# 🔑 Getting Real API Credentials

## Option 1: Speedy API Credentials

### Step 1: Register for Speedy API
1. Email: **api.registration@speedy.bg**
2. In the email, request:
   - API key for test environment
   - Customer ID (if you have one)
   - Your company/business name
3. They will send you credentials within 1-2 business days

### Step 2: Add to .env
```
SPEEDY_API_KEY=your_received_api_key
SPEEDY_CUSTOMER_ID=your_customer_id
```

### Testing Speedy API
```bash
# Test your credentials
curl -H "Authorization: Bearer YOUR_API_KEY" \
  https://api.speedy.bg/v1/offices
```

---

## Option 2: Econt API Credentials

### Step 1: Create Account
1. Visit: https://econt.com/
2. Click "Sign Up" or "Registration"
3. Fill in your company details
4. Verify email

### Step 2: Get API Access
1. Login to e-Econt portal
2. Go to: **Settings → API Access** (or Integrations)
3. Request API credentials
4. You'll get:
   - Username
   - Password
   - Client System ID

### Step 3: Add to .env
```
ECONT_USERNAME=your_username
ECONT_PASSWORD=your_password
ECONT_CLIENT_SYSTEM_ID=your_client_system_id
```

### Testing Econt API
```bash
# Test with Basic Auth
curl -u "username:password" \
  https://api.econt.com/v1/offices
```

---

## Option 3: Use Demo/Test Data

If you don't have credentials yet, you can:
1. Request **test credentials** from both companies (usually free)
2. Use a CSV file with real office data
3. Manually create a limited list for testing

---

## Faster Alternative: Office List from CSV

If you have a CSV file with office data, save it as:
- `speedy-offices.csv` 
- `econt-offices.csv`

With columns: `city`, `street`, `phone`, `hours`

Then I can create a script to import them.

---

## What to Do Next:

1. **Email Speedy** → api.registration@speedy.bg (get API key)
2. **Sign up on Econt** → https://econt.com/ (get credentials)
3. **Add credentials to `.env`** file
4. **Run** → http://localhost/fetch-real-offices.php

Once you have credentials, all real office data will load automatically!

---

## Quick Timeline:
- Speedy registration: 1-2 business days
- Econt registration: 24 hours
- Total: 2-3 days to have real data

Need help with anything else while you're waiting?
