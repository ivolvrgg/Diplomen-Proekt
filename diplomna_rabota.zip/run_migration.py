import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="dron_db"
)

cursor = conn.cursor()

# Read SQL file
with open(r'c:\xampp\htdocs\Diplomna_rabota\sql\migration_update_speedy_ekont.sql', 'r', encoding='utf-8') as f:
    sql_content = f.read()

# Execute each statement
statements = [s.strip() for s in sql_content.split(';')]
statements = [s for s in statements if s and not s.startswith('--')]

success = 0
failed = 0

for stmt in statements:
    try:
        cursor.execute(stmt)
        conn.commit()
        success += 1
        print(f"✓ Executed: {stmt[:80]}...")
    except Exception as e:
        failed += 1
        print(f"✗ Failed: {str(e)[:100]}")

print(f"\n=== RESULTS ===")
print(f"Success: {success}")
print(f"Failed: {failed}")

# Check results
cursor.execute("SELECT COUNT(*) as cnt FROM delivery_offices WHERE delivery_method_id = 2")
speedy_count = cursor.fetchone()[0]

cursor.execute("SELECT COUNT(*) as cnt FROM delivery_offices WHERE delivery_method_id = 3")
econt_count = cursor.fetchone()[0]

print(f"\nSpeedy offices: {speedy_count}")
print(f"ECONT offices: {econt_count}")

# Check costs
cursor.execute("SELECT id, name, cost FROM delivery_methods")
print(f"\nDelivery Methods:")
for row in cursor.fetchall():
    print(f"  {row[1]}: €{row[2]}")

cursor.close()
conn.close()
