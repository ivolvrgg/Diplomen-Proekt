@echo off
cd /d C:\xampp\htdocs\Diplomna_rabota
echo Installing dependencies from composer.json...
echo.
"C:\xampp\php\php.exe" composer.phar update --no-interaction
echo.
echo Done!
pause
