<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('log_errors_max_len', 0);

require_once '../config/stripe.php';
require_once '../config/db.php';

// This endpoint should be added to Stripe Dashboard > Webhooks with events:
// - charge.succeeded
// - charge.failed

$endpoint_secret = 'whsec_YOUR_WEBHOOK_SECRET'; // Replace with your Stripe webhook secret

$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, $endpoint_secret
    );
} catch(\UnexpectedValueException $e) {
    // Invalid payload
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    // Invalid signature
    http_response_code(400);
    exit();
}

// Handle the event
switch ($event->type) {
    case 'charge.succeeded':
        $charge = $event->data->object;
        
        // Get the payment intent to retrieve metadata
        if (!empty($charge->payment_intent)) {
            try {
                $payment_intent = \Stripe\PaymentIntent::retrieve($charge->payment_intent);
                
                if ($payment_intent->status === 'succeeded' && !empty($payment_intent->metadata)) {
                    $metadata = $payment_intent->metadata->toArray();
                    
                    // Check if order already exists for this payment
                    $check_stmt = $conn->prepare("SELECT id FROM orders WHERE payment_intent_id = ?");
                    $check_stmt->bind_param("s", $charge->id);
                    $check_stmt->execute();
                    $check_result = $check_stmt->get_result();
                    $check_stmt->close();
                    
                    if ($check_result->num_rows === 0) {
                        // Order doesn't exist yet, create it
                        createOrderFromCheckout($metadata, $charge->id);
                    }
                }
            } catch (Exception $e) {
                error_log("Error retrieving payment intent: " . $e->getMessage());
            }
        }
        
        error_log("Payment succeeded for charge: " . $charge->id);
        break;

    case 'charge.failed':
        $charge = $event->data->object;
        error_log("Payment failed for charge: " . $charge->id . " - " . $charge->failure_message);
        break;

    default:
        error_log('Received unknown event type ' . $event->type);
}

http_response_code(200);
exit();

/**
 * Create order from Stripe checkout metadata
 */
function createOrderFromCheckout($metadata, $charge_id) {
    global $conn;
    
    try {
        $user_id = isset($metadata['user_id']) && $metadata['user_id'] !== 'guest' ? intval($metadata['user_id']) : null;
        $email = $metadata['email'] ?? '';
        $phone = $metadata['phone'] ?? '';
        $delivery_method = $metadata['delivery_method'] ?? 'courier';
        $delivery_method_id = intval($metadata['delivery_method_id'] ?? 1);
        $delivery_office_id = !empty($metadata['delivery_office_id']) ? intval($metadata['delivery_office_id']) : null;
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            $cart_items = [];
            $subtotal = 0;
            
            // Get cart items
            if ($user_id > 0) {
                // Logged-in user - get from database
                $cart_query = "SELECT c.product_id, c.quantity, p.price 
                              FROM cart c 
                              JOIN products p ON c.product_id = p.id 
                              WHERE c.user_id = $user_id";
                $cart_result = $conn->query($cart_query);
                
                if ($cart_result && $cart_result->num_rows > 0) {
                    while ($item = $cart_result->fetch_assoc()) {
                        $item_total = $item['price'] * $item['quantity'];
                        $subtotal += $item_total;
                        $cart_items[] = $item;
                    }
                }
            }
            
            // If no cart items found, log error but don't fail
            if (empty($cart_items)) {
                error_log("Warning: No cart items found for order creation. User: $user_id, Charge: $charge_id");
                $conn->commit();
                return;
            }
            
            // Calculate totals
            $delivery_cost = floatval($metadata['delivery_cost'] ?? 6.00);
            $vat = $subtotal * 0.20;
            $total = $subtotal + $vat + $delivery_cost;
            
            // Insert order with 'processing' status (payment already received)
            $insert_order = $conn->prepare("INSERT INTO orders (user_id, status, subtotal, delivery_cost, vat, total, payment_method, delivery_method_id, delivery_office_id, email, phone, payment_intent_id, created_at, updated_at) 
                                VALUES (?, 'processing', ?, ?, ?, ?, 'card', ?, ?, ?, ?, ?, NOW(), NOW())");
            
            if (!$insert_order) {
                throw new Exception('Prepare failed: ' . $conn->error);
            }
            
            $insert_order->bind_param("idddsissis", $user_id, $subtotal, $delivery_cost, $vat, $total, $delivery_method_id, $delivery_office_id, $email, $phone, $charge_id);
            
            if (!$insert_order->execute()) {
                throw new Exception('Failed to create order: ' . $conn->error);
            }
            $insert_order->close();
            
            $order_id = $conn->insert_id;
            
            // Insert order items
            $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
            
            foreach ($cart_items as $item) {
                $product_id = intval($item['product_id']);
                $quantity = intval($item['quantity']);
                $unit_price = floatval($item['price']);
                
                $item_stmt->bind_param("iiii", $order_id, $product_id, $quantity, $unit_price);
                if (!$item_stmt->execute()) {
                    throw new Exception('Failed to add order item');
                }
                
                // Update stock
                $stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                $stock_stmt->bind_param("ii", $quantity, $product_id);
                if (!$stock_stmt->execute()) {
                    throw new Exception('Failed to update stock');
                }
                $stock_stmt->close();
            }
            $item_stmt->close();
            
            // Clear cart for logged-in users
            if ($user_id > 0) {
                $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
                $clear_stmt->bind_param("i", $user_id);
                $clear_stmt->execute();
                $clear_stmt->close();
            }
            
            // Commit transaction
            $conn->commit();
            
            error_log("Order #$order_id created successfully from Stripe payment (Charge: $charge_id)");
            
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        error_log("Error creating order from checkout: " . $e->getMessage());
    }
}
?>
