<?php
// Live search API endpoint with Bulgarian/English support
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include '../config/db.php';

// Get search query
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 8;

if (strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

/**
 * Convert Bulgarian text to Latin transliteration
 * This allows searching for "drone" even if typed as "дрон"
 */
function transliterate_bulgarian($text) {
    $bulgarian = [
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 
        'е' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i', 'й' => 'y',
        'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o',
        'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u',
        'ф' => 'f', 'х' => 'h', 'ц' => 'ts', 'ч' => 'ch', 'ш' => 'sh',
        'щ' => 'sht', 'ъ' => 'a', 'ю' => 'yu', 'я' => 'ya',
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 
        'Е' => 'E', 'Ж' => 'Zh', 'З' => 'Z', 'И' => 'I', 'Й' => 'Y',
        'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O',
        'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T', 'У' => 'U',
        'Ф' => 'F', 'Х' => 'H', 'Ц' => 'Ts', 'Ч' => 'Ch', 'Ш' => 'Sh',
        'Щ' => 'Sht', 'Ъ' => 'A', 'Ю' => 'Yu', 'Я' => 'Ya'
    ];
    
    return strtr($text, $bulgarian);
}

/**
 * Check if text contains Cyrillic (Bulgarian) characters
 */
function has_cyrillic($text) {
    return preg_match('/[\x{0400}-\x{04FF}]/u', $text) > 0;
}

/**
 * Create search terms for both Bulgarian and English
 */
function create_search_variants($query) {
    $variants = [$query];
    
    // If query contains Cyrillic, add transliterated version
    if (has_cyrillic($query)) {
        $transliterated = transliterate_bulgarian($query);
        $variants[] = $transliterated;
    }
    
    // Add partial matching variants
    $variants[] = $query . '%';
    if (has_cyrillic($query)) {
        $variants[] = transliterate_bulgarian($query) . '%';
    }
    
    return array_unique($variants);
}

try {
    // Create search term with wildcards for LIKE queries
    $search_term = '%' . $query . '%';
    
    // Build SQL query to search with relevance scoring
    $sql = "SELECT 
                id, 
                name, 
                price, 
                image_1,
                description,
                CASE 
                    WHEN LOWER(name) LIKE LOWER(?) THEN 3
                    WHEN LOWER(name) LIKE LOWER(?) THEN 2
                    WHEN LOWER(description) LIKE LOWER(?) THEN 1
                    ELSE 0
                END as relevance
            FROM products 
            WHERE is_active = 1 
                AND (
                    LOWER(name) LIKE LOWER(?)
                    OR LOWER(description) LIKE LOWER(?)
                )
            ORDER BY relevance DESC, name ASC
            LIMIT ?";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    
    // For exact match at start
    $exact_match = $query . '%';
    
    // Bind parameters: exact, prefix, description, full name, full description, limit
    $stmt->bind_param('sssssi', 
        $exact_match,
        $search_term,
        $search_term,
        $search_term,
        $search_term,
        $limit
    );
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = [
            'id' => (int)$row['id'],
            'name' => htmlspecialchars($row['name']),
            'price' => (float)$row['price'],
            'image' => htmlspecialchars($row['image_1'] ?: 'https://via.placeholder.com/100x100?text=No+Image'),
            'description' => htmlspecialchars(substr($row['description'], 0, 100))
        ];
    }
    
    $stmt->close();
    echo json_encode($products);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
