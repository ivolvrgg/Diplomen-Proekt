<?php
$pageTitle = "За нас";
include 'includes/head.php';
?>
<?php include 'includes/navbar_selector.php'; ?>

<div class="about-section">
    <div class="about-hero">
        <h1>За нас</h1>
        <p>Добре дошли в Dronche.BG</p>
    </div>

    <div class="about-content">
        <div class="about-container">
            <section class="about-block">
                <h2>Кой сме ние?</h2>
                <p>
                    Dronche.BG е водещ онлайн магазин, специализиран в продажбата на дронове, RC играчки и аксесоари.
                    Ние се посвещаваме на предоставяне на висококачествени продукти и изключително обслужване на клиентите.
                </p>
            </section>

            <section class="about-block">
                <h2>Нашата мисия</h2>
                <p>
                    Нашата мисия е да направим технологията достъпна и забавна за всички. Ние вярваме, че всеки човек
                    има право да експериментира с безпилотни летателни апарати и RC технология, независимо от възрастта или
                    опита.
                </p>
            </section>

            <section class="about-block">
                <h2>Защо да ни изберете?</h2>
                <ul>
                    <li><strong>Широк избор:</strong> От начинаещи до професионалисти, имаме продукте за всички</li>
                    <li><strong>Конкурентни цени:</strong> Най-добрите цени на пазара</li>
                    <li><strong>Бързо доставка:</strong> Бързо и надежно доставяне в цяла България</li>
                    <li><strong>Поддръжка:</strong> Професионална техническа поддръжка и консултации</li>
                    <li><strong>Качество:</strong> Само оригинални и сертифицирани продукти</li>
                </ul>
            </section>

            <section class="about-block">
                <h2>Свържете се с нас</h2>
                <p>
                    <strong>Адрес:</strong> България, Варна<br>
                    <strong>Телефон:</strong> +359 884 597 448<br>
                    <strong>Email:</strong> dronchebg@gmail.com
                </p>
            </section>
        </div>
    </div>
</div>

<style>
    .about-section {
        background-color: #f5f5f5;
        padding: 0 0 60px 0;
        min-height: 100vh;
    }

    .about-hero {
        background: linear-gradient(135deg, #344e41 0%, #2a3f37 100%);
        color: white;
        padding: 80px 20px;
        text-align: center;
        margin-bottom: 40px;
    }

    .about-hero h1 {
        font-size: 48px;
        margin: 0 0 10px 0;
        font-weight: bold;
    }

    .about-hero p {
        font-size: 20px;
        color: #fb8500;
        margin: 0;
    }

    .about-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .about-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 30px;
    }

    .about-block {
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .about-block:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .about-block h2 {
        color: #344e41;
        margin-top: 0;
        margin-bottom: 15px;
        font-size: 24px;
    }

    .about-block p {
        color: #666;
        line-height: 1.8;
        margin: 0 0 10px 0;
    }

    .about-block ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .about-block ul li {
        color: #666;
        line-height: 1.8;
        margin-bottom: 12px;
        padding-left: 25px;
        position: relative;
    }

    .about-block ul li:before {
        content: "✓";
        position: absolute;
        left: 0;
        color: #fb8500;
        font-weight: bold;
    }
</style>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>
</body>
</html>
