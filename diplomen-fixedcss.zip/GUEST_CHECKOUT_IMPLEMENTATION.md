# Guest Checkout Implementation - Summary

## Overview
Guest users can now make orders without having to create an account. The system supports both guest and logged-in user checkout flows with a unified order system.

##Files Modified/Created

### New Files Created:
1. **api/orders.php** - Order submission API endpoint
   - Handles both guest and logged-in user orders
   - Validates form data (email, payment method, delivery method)
   - Creates order records and order items
   - Updates product stock
   - Clears cart after order creation
   - Returns JSON response with order confirmation URL

2. **order-confirmation.php** - Order confirmation page
   - Displays order summary with items, totals, and details
   - Shows order status, email, delivery method, and payment method
   - Provides links to continue shopping or access profile (for logged-in users)
   - Works for both guest and logged-in user orders

3. **order-confirmation.css** - Styling for confirmation page

### Files Modified:

1. **payment.php** - Guest checkout page
   - Now loads cart items dynamically from database
   - Added phone delivery address input fields
   - Integrated with delivery_offices from database
   - Added form validation
   - Added async form submission to orders API
   - Supports delivery methods: courier, Speedy office, eKont office
   - Calculates and displays order totals correctly

2. **logged_Payment.php** - Logged-in user checkout page
   - Similar to payment.php but with user authentication check
   - Pre-fills email from logged-in user session
   - Redirects unauthenticated users to guest payment page
   - Same delivery and payment options as guest page

3. **includes/navbar_logged.php** - Fixed cart link
   - Changed cart link from cart.php to logged_Cart.php
   - Changed homepage link from homepage.php to logged_Homepage.php
   - Ensures logged-in users see correct cart and homepage

### Database Usage:
- **orders table**: Uses user_id = -1 for guest orders
- **order_items table**: Links orders to products
- **cart table**: Uses user_id = -1 for guest carts
- **delivery_offices table**: Populated with Speedy and eKont offices
- **delivery_methods table**: Courier, Speedy, eKont methods

## Guest Checkout Flow

1. **Browse & Add Items**
   - Guest adds items to cart via itempage.php
   - Items stored in cart table with user_id = -1
   - Guest ID generated from session for tracking (stored in $_SESSION['guest_id'])

2. **View Cart**
   - Guest visits cart.php
   - Items loaded from database where user_id = -1
   - Cart summary shows items, subtotal, shipping, VAT, and total

3. **Checkout**
   - Guest clicks "Продължете към плащане"
   - Redirected to payment.php
   - Form displayed with fields:
     - Payment method: Card or COD (Cash on Delivery)
     - Delivery method: Courier (address), Speedy office, or eKont office
     - Email for order confirmation (required)
     - Address fields (if courier selected)
     - Delivery office selection (if office selected)

4. **Order Submission**
   - Guest submits form
   - JavaScript validates all required fields
   - Form data sent to api/orders.php as JSON
   - API validates, creates order record, and clears cart
   - Guest redirected to order-confirmation.php?order_id=X

5. **Order Confirmation**
   - Order details displayed including:
     - Order ID and date
     - Items with quantities and prices
     - Order totals
     - Email address for confirmation
     - Payment and delivery method
   - Guest can continue shopping or view order details

## Logged-In User Checkout Flow

1. **Browse & Add Items**
   - User adds items to cart via itempage.php or logged_itempage.php
   - Items stored in cart table with user_id from session

2. **View Cart**
   - User visits logged_Cart.php
   - Items loaded from database where user_id = {user_id}
   - Cart summary shows items and totals

3. **Checkout**
   - User clicks "Продължете към плащане"
   - Redirected to logged_Payment.php
   - Form same as guest but email pre-filled from session
   - Same payment and delivery method options

4. **Order Submission**
   - User submits form
   - API creates order with user_id from session
   - User redirected to order-confirmation.php

5. **Order History**
   - User can view past orders in profile.php
   - Order history already implemented in existing profile page

## Technical Details

### User ID Handling
- Logged-in users: user_id from $_SESSION['user_id']
- Guest users: user_id = -1 in database
- Guest tracking: $_SESSION['guest_id'] = 'guest_' + md5 hash (optional, for analytics)

### Email Handling
- Guest: Required field on form
- Logged-in: Pre-filled from session, can be changed

### Delivery Methods
- **Courier (1)**: Cost 6.00€ - Requires address input
- **Speedy (2)**: Cost 4.99€ - Select from database offices
- **eKont (3)**: Cost 3.99€ - Select from database offices

### Order Status
- Initial status: 'pending'
- Can be updated to: 'paid', 'shipped', 'delivered', 'cancelled'

### Validation
- Email format validated
- Payment method validated
- Delivery method validated
- Address required for courier delivery
- Office selection required for office delivery
- Cart must not be empty

## Testing Recommendations

1. **Guest User Test**
   - Add items as guest
   - Verify cart items load correctly
   - Test all delivery methods
   - Verify order creation
   - Check order confirmation page

2. **Logged-In User Test**
   - Log in
   - Add items
   - Verify cart loads correctly
   - Verify email is pre-filled
   - Test order creation
   - Check order appears in profile

3. **Edge Cases**
   - Empty cart submission (should be prevented by validation)
   - Invalid email format
   - Missing delivery address
   - Missing office selection
   - Session timeout scenarios

## Future Enhancements

1. **Payment Processing**
   - Integrate with payment gateway for card payments
   - Handle payment confirmation/verification

2. **Guest Order Tracking**
   - Allow guests to track orders with order ID and email
   - Send order confirmation emails

3. **Address Management**
   - Enhance courier address storage (currently not saved)
   - Validate addresses with postal code service

4. **Inventory Management**
   - Real-time stock updates
   - Handle out-of-stock products

5. **Email Notifications**
   - Confirmation email on order creation
   - Status update emails
   - Shipping notification emails

## Notes

- Guest orders use user_id = -1 by default
- Session-based guest tracking (not persistent across sessions)
- Order confirmation page works for both guest and logged-in orders
- Guest users can still browse profile page but won't see order history
- All timestamps use NOW() for UTC timestamp
- VAT currently hardcoded at 20%
- Shipping cost varies by delivery method
