<?php
$page_title = 'Плащане | Dronche.BG';
$page_css = 'css/payment.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
<?php include 'config/stripe.php'; ?>
<?php
// Get Stripe publishable key from environment or use live key
$stripe_publishable_key = getenv('STRIPE_PUBLISHABLE_KEY');
if (!$stripe_publishable_key) {
    $stripe_publishable_key = 'pk_live_51T4KmZDXo0KK7clOQJfbBlILcdtjXTUpa5EBo9E8K0uEAfuhY2L8U9jbCuYRGMtcrTdD1xGf8BnRuor82AYhU4BM00cRGX2fNG';
}
?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="payment-container">
        <div class="container">
            <h1 class="section-title">Плащане</h1>
            
            <div class="payment-content">
                <div class="order-summary">
                    <h2>Вашата поръчка</h2>
                    <div class="order-items" id="order-items">
                        <?php
                        $subtotal = 0;
                        $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                        
                        if ($user_id === 0) {
                            // Guest user - cart will be loaded from localStorage via JavaScript
                            if (!isset($_SESSION['guest_id'])) {
                                $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
                            }
                            echo '<p><em>Зареждане на количката...</em></p>';
                        } else {
                            // Logged-in user - fetch from database
                            $db_user_id = $user_id;
                            
                            $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price 
                                          FROM cart c 
                                          JOIN products p ON c.product_id = p.id 
                                          WHERE c.user_id = " . intval($db_user_id);
                            $cart_result = $conn->query($cart_query);
                            
                            if (!$cart_result) {
                                echo '<p style="color: red;">Възникна грешка при зареждане на количката. Грешка: ' . htmlspecialchars($conn->error) . '</p>';
                            } else if ($cart_result && $cart_result->num_rows > 0) {
                                while ($item = $cart_result->fetch_assoc()) {
                                    $item_total = $item['price'] * $item['quantity'];
                                    $subtotal += $item_total;
                            ?>
                            <div class="order-item">
                                <span class="item-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                <span class="item-price"><?php echo number_format($item['price'] * $item['quantity'], 2); ?> €</span>
                            </div>
                            <?php
                                }
                            } else {
                                echo '<p>Вашата количка е празна. <a href="cart.php">Назад към количката</a></p>';
                            }
                        }
                        ?>
                    </div>
                    <div class="order-total">
                        <span>Подсума:</span>
                        <span class="subtotal-price"><?php echo number_format($subtotal, 2); ?> €</span>
                    </div>
                    <div class="order-total" style="margin-top: 0.5rem;">
                        <span>Доставка:</span>
                        <span class="delivery-price">6.00 €</span>
                    </div>
                    <div class="order-total" style="margin-top: 0.5rem;">
                        <span>ДДС (20%):</span>
                        <span class="vat-price"><?php echo number_format($subtotal * 0.20, 2); ?> €</span>
                    </div>
                    <div class="order-total" style="margin-top: 1rem; border-top: 2px solid #588157; padding-top: 1rem;">
                        <span><strong>ОБЩО:</strong></span>
                        <span class="total-price"><strong><?php echo number_format(($subtotal * 1.20) + 6, 2); ?> €</strong></span>
                    </div>
                </div>

                <form class="payment-form" id="payment-form">
                    <h2>Метод на плащане</h2>
                    
                    <div class="payment-methods">
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="card" checked>
                            <span class="payment-label">Плащане с карта</span>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="cod">
                            <span class="payment-label">Наложен платеж</span>
                        </label>
                    </div>

                    <h2 style="margin-top: 2rem;">Начин на доставка</h2>
                    
                    <div class="delivery-methods">
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="courier" class="delivery-radio">
                                <span class="delivery-label">До адрес</span>
                            </label>
                            <div class="address-fields" style="display: none;">
                                <div class="address-field">
                                    <label for="city-input">Град</label>
                                    <input type="text" id="city-input" name="city" class="address-input" placeholder="Град">
                                </div>

                                <div class="address-field">
                                    <label for="street-input">Улица</label>
                                    <input type="text" id="street-input" name="street" class="address-input" placeholder="Улица">
                                </div>

                                <div class="address-field">
                                    <label for="block-input">Блок</label>
                                    <input type="text" id="block-input" name="block" class="address-input" placeholder="Номер на блок">
                                </div>

                                <div class="address-field">
                                    <label for="entrance-input">Вход</label>
                                    <input type="text" id="entrance-input" name="entrance" class="address-input" placeholder="Вход (А, Б, В и т.н.)">
                                </div>

                                <div class="address-field">
                                    <label for="apartment-input">Апартамент</label>
                                    <input type="text" id="apartment-input" name="apartment" class="address-input" placeholder="Номер на апартамент">
                                </div>
                            </div>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="speedy" class="delivery-radio">
                                <span class="delivery-label">Speedy</span>
                            </label>
                            <div id="speedy-offices" class="delivery-select-wrapper" style="display: none;">
                                <input type="text" class="delivery-search" placeholder="Избери офис...">
                                <div class="delivery-dropdown">
                                    <?php
                                    $offices_query = "SELECT id, label FROM delivery_offices WHERE delivery_method_id = 2 AND is_active = 1 ORDER BY label";
                                    $offices_result = $conn->query($offices_query);
                                    if ($offices_result && $offices_result->num_rows > 0) {
                                        while ($office = $offices_result->fetch_assoc()) {
                                            echo '<div class="delivery-option-item" data-office-id="' . intval($office['id']) . '">' . htmlspecialchars($office['label']) . '</div>';
                                        }
                                    }
                                    ?>
                                </div>
                                <input type="hidden" class="delivery-select-value" name="delivery-office-speedy" id="delivery-office-speedy">
                                <input type="hidden" name="delivery-office-id-speedy" id="delivery-office-id-speedy">
                            </div>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="econt" class="delivery-radio">
                                <span class="delivery-label">eKont</span>
                            </label>
                            <div id="econt-offices" class="delivery-select-wrapper" style="display: none;">
                                <input type="text" class="delivery-search" placeholder="Избери офис...">
                                <div class="delivery-dropdown">
                                    <?php
                                    $offices_query = "SELECT id, label FROM delivery_offices WHERE delivery_method_id = 3 AND is_active = 1 ORDER BY label";
                                    $offices_result = $conn->query($offices_query);
                                    if ($offices_result && $offices_result->num_rows > 0) {
                                        while ($office = $offices_result->fetch_assoc()) {
                                            echo '<div class="delivery-option-item" data-office-id="' . intval($office['id']) . '">' . htmlspecialchars($office['label']) . '</div>';
                                        }
                                    }
                                    ?>
                                </div>
                                <input type="hidden" class="delivery-select-value" name="delivery-office-econt" id="delivery-office-econt">
                                <input type="hidden" name="delivery-office-id-econt" id="delivery-office-id-econt">
                            </div>
                        </div>
                    </div>

                    <h2 style="margin-top: 2rem;">Данни за плащане</h2>
                    
                    <div id="card-payment-section">
                        <p style="color: #666; font-size: 14px;">Ще бъдете пренасочени към сигурната платежна страница на Stripe.</p>
                    </div>

                    <h2 style="margin-top: 2rem;">Контактни данни</h2>
                    
                    <div class="form-group">
                        <label for="phone">Телефонен номер *</label>
                        <input type="tel" id="phone" name="phone" placeholder="+359 123 456 789" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Имейл за потвърждение <?php echo !is_logged_in() ? '*' : ''; ?></label>
                        <?php if (!is_logged_in()): ?>
                        <input type="email" id="email" name="email" placeholder="вашият@имейл.com" required>
                        <?php else: ?>
                        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>" disabled style="background-color: #f0f0f0; cursor: not-allowed;">
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="btn-pay" id="submit-btn">Завърши поръчка</button>
                    <div id="form-message" style="margin-top: 1rem; display: none;"></div>
                </form>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    <script>
        const form = document.getElementById('payment-form');
        const messageDiv = document.getElementById('form-message');
        const submitBtn = document.getElementById('submit-btn');
        let orderId = null;
        let total = 0;

        // Load guest cart from localStorage if not logged in
        document.addEventListener('DOMContentLoaded', function() {
            const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
            
            if (!isLoggedIn) {
                const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                
                if (guestCart.length > 0) {
                    let html = '';
                    let subtotal = 0;
                    let pendingRequests = 0;
                    let completedRequests = 0;
                    
                    // Check if items have all required fields, fetch product details if missing
                    const promises = guestCart.map(item => {
                        // If price or name is missing, fetch from API
                        if (!item.price || !item.name) {
                            pendingRequests++;
                            return fetch(`api/cart.php?action=get_product&product_id=${item.product_id}`)
                                .then(r => r.json())
                                .then(data => {
                                    if (data.success && data.product) {
                                        item.name = item.name || data.product.name;
                                        item.price = item.price || parseFloat(data.product.price);
                                    }
                                    completedRequests++;
                                    return item;
                                })
                                .catch(err => {
                                    console.error('Error loading product:', err);
                                    completedRequests++;
                                    return item;
                                });
                        } else {
                            return Promise.resolve(item);
                        }
                    });
                    
                    Promise.all(promises).then(cartItems => {
                        let html = '';
                        let subtotal = 0;
                        
                        cartItems.forEach(item => {
                            const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
                            subtotal += itemTotal;
                            html += `
                                <div class="order-item">
                                    <span class="item-name">${item.name || 'Неизвестен продукт'}</span>
                                    <span class="item-price">${(itemTotal).toFixed(2)} €</span>
                                </div>
                            `;
                        });
                        
                        document.getElementById('order-items').innerHTML = html;
                        
                        // Update totals
                        const vat = (subtotal * 0.20).toFixed(2);
                        const total = (subtotal * 1.20 + 6).toFixed(2);
                        
                        document.querySelector('.subtotal-price').textContent = subtotal.toFixed(2) + ' €';
                        document.querySelector('.vat-price').textContent = vat + ' €';
                        document.querySelector('.total-price').textContent = total + ' €';
                    });
                } else {
                    document.getElementById('order-items').innerHTML = '<p>Вашата количка е празна. <a href="cart.php">Назад към количката</a></p>';
                }
            }

            // Restore form data from sessionStorage if returning from Stripe
            const savedFormData = sessionStorage.getItem('checkoutFormData');
            if (savedFormData) {
                try {
                    const formData = JSON.parse(savedFormData);
                    
                    // Restore payment method
                    if (formData.paymentMethod) {
                        const paymentRadio = document.querySelector(`input[name="payment-method"][value="${formData.paymentMethod}"]`);
                        if (paymentRadio) {
                            paymentRadio.checked = true;
                        }
                    }
                    
                    // Restore delivery method
                    if (formData.deliveryMethod) {
                        const deliveryRadio = document.querySelector(`input[name="delivery-method"][value="${formData.deliveryMethod}"]`);
                        if (deliveryRadio) {
                            deliveryRadio.checked = true;
                            deliveryRadio.dispatchEvent(new Event('change'));
                        }
                    }
                    
                    // Restore address fields
                    if (formData.city) document.getElementById('city-input').value = formData.city;
                    if (formData.street) document.getElementById('street-input').value = formData.street;
                    if (formData.block) document.getElementById('block-input').value = formData.block;
                    if (formData.entrance) document.getElementById('entrance-input').value = formData.entrance;
                    if (formData.apartment) document.getElementById('apartment-input').value = formData.apartment;
                    
                    // Restore phone
                    if (formData.phone) document.getElementById('phone').value = formData.phone;
                    
                    // Restore delivery office selection
                    if (formData.deliveryOfficeId && formData.deliveryMethod === 'speedy') {
                        document.getElementById('delivery-office-id-speedy').value = formData.deliveryOfficeId;
                        document.getElementById('delivery-office-speedy').value = formData.deliveryOfficeName || '';
                    } else if (formData.deliveryOfficeId && formData.deliveryMethod === 'econt') {
                        document.getElementById('delivery-office-id-econt').value = formData.deliveryOfficeId;
                        document.getElementById('delivery-office-econt').value = formData.deliveryOfficeName || '';
                    }
                    
                    // Show message that form was restored
                    showMessage('Вашите данни са восстановени. Проверете ги и продължете.', 'info');
                } catch (e) {
                    console.error('Error restoring form data:', e);
                }
            }
        });

        // Payment method toggle
        document.querySelectorAll('input[name="payment-method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const cardSection = document.getElementById('card-payment-section');
                if (this.value === 'card') {
                    cardSection.style.display = 'block';
                } else {
                    cardSection.style.display = 'none';
                }
            });
        });

        // Delivery method toggle
        document.querySelectorAll('.delivery-radio').forEach(radio => {
            radio.addEventListener('change', function() {
                const allWrappers = document.querySelectorAll('.delivery-select-wrapper');
                const allAddressFields = document.querySelectorAll('.address-fields');
                
                allWrappers.forEach(wrapper => wrapper.style.display = 'none');
                allAddressFields.forEach(fields => fields.style.display = 'none');
                
                const selectedOption = this.closest('.delivery-option');
                const selectedWrapper = selectedOption.querySelector('.delivery-select-wrapper');
                const selectedAddressFields = selectedOption.querySelector('.address-fields');
                
                if (selectedWrapper) {
                    selectedWrapper.style.display = 'block';
                }
                if (selectedAddressFields) {
                    selectedAddressFields.style.display = 'block';
                }
            });
        });

        // Delivery office selection - Fixed version
        document.querySelectorAll('.delivery-option-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const wrapper = this.closest('.delivery-select-wrapper');
                const searchInput = wrapper.querySelector('.delivery-search');
                const officeId = this.getAttribute('data-office-id');
                const officeName = this.textContent.trim();
                
                // Determine which delivery method this is for
                if (wrapper.id.includes('speedy')) {
                    document.getElementById('delivery-office-speedy').value = officeName;
                    document.getElementById('delivery-office-id-speedy').value = officeId;
                } else if (wrapper.id.includes('econt')) {
                    document.getElementById('delivery-office-econt').value = officeName;
                    document.getElementById('delivery-office-id-econt').value = officeId;
                }
                
                searchInput.value = officeName;
                
                // Close dropdown
                wrapper.querySelector('.delivery-dropdown').style.display = 'none';
            });
        });

        // Search functionality - Fixed version
        document.querySelectorAll('.delivery-search').forEach(search => {
            search.addEventListener('focus', function() {
                this.nextElementSibling.style.display = 'block';
            });

            search.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const dropdown = this.nextElementSibling;
                
                dropdown.style.display = 'block';
                
                dropdown.querySelectorAll('.delivery-option-item').forEach(item => {
                    const text = item.textContent.toLowerCase();
                    if (text.includes(searchTerm)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.delivery-select-wrapper')) {
                document.querySelectorAll('.delivery-dropdown').forEach(dropdown => {
                    dropdown.style.display = 'none';
                });
            }
        });

        // Form submission
        form.addEventListener('submit', async function(e) {
            e.preventDefault();

            const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
            const deliveryMethod = document.querySelector('input[name="delivery-method"]:checked').value;
            const emailInput = document.querySelector('input[name="email"]');
            let email = emailInput.value.trim();
            let phone = document.getElementById('phone').value.trim();

            // Validation
            if (!phone) {
                showMessage('Моля, въведете телефонен номер', 'error');
                return;
            }

            // Basic phone validation (at least 10 digits)
            const phoneDigits = phone.replace(/\D/g, '');
            if (phoneDigits.length < 10) {
                showMessage('Моля, въведете валиден телефонен номер', 'error');
                return;
            }

            if (!email) {
                showMessage('Моля, въведете имейл адрес', 'error');
                return;
            }

            if (!paymentMethod) {
                showMessage('Моля, изберете начин на плащане', 'error');
                return;
            }

            if (!deliveryMethod) {
                showMessage('Моля, изберете начин на доставка', 'error');
                return;
            }

            if (deliveryMethod === 'courier') {
                const city = document.getElementById('city-input').value.trim();
                const street = document.getElementById('street-input').value.trim();
                
                if (!city || !street) {
                    showMessage('Моля, попълнете адреса за доставка', 'error');
                    return;
                }
            } else if (deliveryMethod === 'speedy') {
                const officeId = document.getElementById('delivery-office-id-speedy').value;
                if (!officeId) {
                    showMessage('Моля, изберете Speedy офис', 'error');
                    return;
                }
            } else if (deliveryMethod === 'econt') {
                const officeId = document.getElementById('delivery-office-id-econt').value;
                if (!officeId) {
                    showMessage('Моля, изберете eKont офис', 'error');
                    return;
                }
            }

            // Prepare data
            const formData = {
                payment_method: paymentMethod,
                delivery_method: deliveryMethod,
                email: email,
                phone: phone
            };

            if (deliveryMethod === 'courier') {
                formData.city = document.getElementById('city-input').value.trim();
                formData.street = document.getElementById('street-input').value.trim();
                formData.block = document.getElementById('block-input').value.trim();
                formData.entrance = document.getElementById('entrance-input').value.trim();
                formData.apartment = document.getElementById('apartment-input').value.trim();
            } else if (deliveryMethod === 'speedy') {
                formData.delivery_office_id = document.getElementById('delivery-office-id-speedy').value;
            } else if (deliveryMethod === 'econt') {
                formData.delivery_office_id = document.getElementById('delivery-office-id-econt').value;
            }

            // Add cart data for guest users
            const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
            if (!isLoggedIn) {
                const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                if (guestCart.length > 0) {
                    formData.cart = guestCart;
                } else {
                    showMessage('Вашата количка е празна', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Плати сега';
                    return;
                }
            }

            // Save form data to sessionStorage for card payments (in case they return from Stripe)
            if (paymentMethod === 'card') {
                const saveData = {
                    paymentMethod: paymentMethod,
                    deliveryMethod: deliveryMethod,
                    phone: phone,
                    city: formData.city,
                    street: formData.street,
                    block: formData.block,
                    entrance: formData.entrance,
                    apartment: formData.apartment,
                    deliveryOfficeId: formData.delivery_office_id,
                    deliveryOfficeName: deliveryMethod === 'speedy' ? document.getElementById('delivery-office-speedy').value : 
                                       (deliveryMethod === 'econt' ? document.getElementById('delivery-office-econt').value : '')
                };
                sessionStorage.setItem('checkoutFormData', JSON.stringify(saveData));
            }

            submitBtn.disabled = true;
            submitBtn.textContent = 'Обработка...';

            try {
                // If payment method is card, create payment intent first (order created by webhook after payment)
                if (paymentMethod === 'card') {
                    // Get cart data
                    let cartData = [];
                    if (!isLoggedIn) {
                        cartData = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                    }

                    // Create Stripe Checkout session (order will be created by webhook after payment)
                    const intentResponse = await fetch('api/create-payment-intent.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            payment_method: paymentMethod,
                            delivery_method: deliveryMethod,
                            email: email,
                            phone: phone,
                            city: formData.city,
                            street: formData.street,
                            block: formData.block,
                            entrance: formData.entrance,
                            apartment: formData.apartment,
                            delivery_office_id: formData.delivery_office_id,
                            cart: cartData
                        })
                    });

                    const intentResult = await intentResponse.json();

                    if (!intentResult.success) {
                        showMessage('Възникна грешка при обработката на плащането: ' + intentResult.message, 'error');
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Плати сега';
                        return;
                    }

                    // Redirect to Stripe Checkout page (order created after successful payment via webhook)
                    window.location.href = intentResult.checkout_url;
                } else {
                    // Cash on Delivery - create order immediately
                    const orderResponse = await fetch('api/orders.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(formData)
                    });

                    const orderResult = await orderResponse.json();

                    if (!orderResult.success) {
                        showMessage(orderResult.message || 'Възникна грешка при обработката на поръчката', 'error');
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Плати сега';
                        return;
                    }

                    // Order created successfully for COD
                    showMessage('Поръчката е успешно създадена! Ще получите потвърждение по имейл.', 'success');
                    
                    // Clear checkout data after successful COD order
                    localStorage.removeItem('guest_cart');
                    sessionStorage.removeItem('checkoutFormData');

                    setTimeout(() => {
                        window.location.href = orderResult.redirect_url;
                    }, 1500);
                }
            } catch (error) {
                showMessage('Грешка при свързване със сървъра: ' + error.message, 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Плати сега';
            }
        });

        function showMessage(message, type) {
            messageDiv.textContent = message;
            messageDiv.style.display = 'block';
            
            if (type === 'error') {
                messageDiv.style.color = '#d32f2f';
                messageDiv.style.backgroundColor = '#ffebee';
                messageDiv.style.border = '1px solid #ef5350';
            } else if (type === 'info') {
                messageDiv.style.color = '#0277bd';
                messageDiv.style.backgroundColor = '#e1f5fe';
                messageDiv.style.border = '1px solid #4fc3f7';
            } else {
                messageDiv.style.color = '#388e3c';
                messageDiv.style.backgroundColor = '#e8f5e9';
                messageDiv.style.border = '1px solid #66bb6a';
            }
            
            messageDiv.style.padding = '1rem';
            messageDiv.style.borderRadius = '4px';

            if (type === 'error') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }
    </script>
</body>
</html>
