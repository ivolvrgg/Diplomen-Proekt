# Stripe Integration Setup Guide

## Overview
Your website is now integrated with Stripe for secure credit card payments. This guide walks through the final setup steps.

---

## Step 1: Database Update (IMPORTANT)

Run the SQL migration to add the required columns to your `orders` table:

```sql
-- In phpMyAdmin or your database client, run:
ALTER TABLE orders ADD COLUMN payment_intent_id VARCHAR(255) NULL UNIQUE;
ALTER TABLE orders ADD COLUMN stripe_payment_status VARCHAR(50) NULL DEFAULT 'pending';
CREATE INDEX idx_payment_intent_id ON orders(payment_intent_id);
CREATE INDEX idx_stripe_payment_status ON orders(stripe_payment_status);
```

Or use the migration file: `sql/migration_add_stripe.sql`

---

## Step 2: Environment Variable Setup

Your `.env` file is already created with your API keys at the root directory:
- `c:\xampp\htdocs\Diplomna_rabota\.env`

**Ensure this file is added to your `.gitignore` if you use Git:**
```
.env
vendor/
composer.lock
```

---

## Step 3: Stripe Webhook Configuration (IMPORTANT)

Stripe webhooks allow you to process real-time payment events:

1. Go to [Stripe Dashboard](https://dashboard.stripe.com)
2. Navigate to **Developers > Webhooks**
3. Click **Add an endpoint**
4. Enter your webhook URL:
   ```
   https://yoursite.com/Diplomna_rabota/api/stripe-webhook.php
   ```
   (Replace with your actual domain)

5. Select events to listen to:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `payment_intent.canceled`

6. Click **Add events** then **Add endpoint**

7. On the webhook details page, find the **Signing secret** and copy it

8. Update your webhook secret in `api/stripe-webhook.php`:
   ```php
   $endpoint_secret = 'whsec_YOUR_WEBHOOK_SECRET'; // Paste your secret here
   ```

---

## Step 4: Test Payment Integration

### Test Card Numbers (Use in Test Mode)
- **Visa Success**: 4242 4242 4242 4242
- **Visa Fail**: 4000 0000 0000 0002
- **Expiry**: Any future date (MM/YY)
- **CVC**: Any 3 digits

### Important: You're Currently in LIVE MODE
Your current Stripe keys are **live keys** (starting with `pk_live_` and `sk_live_`).

**⚠️ LIVE MODE CHARGES REAL MONEY** – Proceed with caution!

To test safely, switch to test keys:
1. In Stripe Dashboard, toggle **View test data** at the top
2. Copy your **test** Publishable Key (`pk_test_...`)
3. Copy your **test** Secret Key (`sk_test_...`)
4. Update `.env` and code with test keys
5. Test thoroughly before switching back to live keys

---

## Step 5: Configure Your Payment Page

Your payment form now includes:
- ✅ Stripe Card Element (encrypted, PCI compliant)
- ✅ Real-time card validation
- ✅ Automatic payment intent creation
- ✅ Card payment processing
- ✅ Cash on delivery (COD) option

### Payment Flow:
1. User enters phone, email, delivery address
2. For **card payments**: Stripe Elements securely captures card data
3. Payment intent created server-side
4. Stripe processes the payment
5. Order marked as "processing"
6. User redirected to order confirmation

---

## Step 6: Monitoring & Support

### View Payment Activity
- Go to **Stripe Dashboard > Payments**
- Filter by date to see recent transactions
- Click any payment to view details

### Webhooks Status
- **Developers > Webhooks** shows delivery history
- Check logs if payments don't auto-confirm

### Payment Statuses in Your Database
- `pending` - Order created, awaiting payment
- `succeeded` - Payment completed successfully
- `failed` - Payment failed
- `canceled` - Payment was canceled
- `processing` - Order being processed after payment
- `shipped` - Order shipped

---

## File Structure

```
config/
  stripe.php              ← Stripe API configuration

api/
  create-payment-intent.php   ← Creates payment intents
  stripe-webhook.php          ← Webhook handler for Stripe events
  orders.php              ← Updated to work with Stripe

payment.php             ← Updated payment form with Stripe Elements
.env                    ← Your Stripe API keys (NEVER commit to Git)

sql/
  migration_add_stripe.sql    ← Database schema update

vendor/
  stripe/stripe-php/      ← Stripe SDK (installed via Composer)
```

---

## Security Checklist

- ✅ Secret keys stored in `.env` (not in code)
- ✅ `.env` added to `.gitignore`
- ✅ Using Stripe Elements (no card data touches your server)
- ✅ Payment intents created server-side
- ✅ Webhook signature verification enabled
- ✅ HTTPS recommended for production

---

## Troubleshooting

### "Card element not showing"
- Check browser console for JavaScript errors
- Verify Stripe API key is valid
- Ensure `https://js.stripe.com/v3/` loads

### "Payment intent creation fails"
- Check `api/create-payment-intent.php` error logs
- Verify order exists in database
- Confirm Stripe secret key is correct

### "Webhooks not firing"
- Verify webhook secret in `api/stripe-webhook.php`
- Check webhook endpoint is publicly accessible
- Review Stripe Dashboard webhook logs

---

## Production Deployment

Before going live:

1. ✅ Switch to live API keys (you already have them)
2. ✅ Update webhook URL to your production domain
3. ✅ Re-add webhook with production URL
4. ✅ Test with real transactions (small amount)
5. ✅ Set up error logging and monitoring
6. ✅ Enable HTTPS on your website
7. ✅ Review Stripe compliance documentation

---

## Support Resources

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe API Reference](https://stripe.com/docs/api/payment_intents)
- [Stripe Testing](https://stripe.com/docs/testing)
- [Customer Support](https://support.stripe.com)
