<?php
// Quick migration runner for Stripe columns
include 'config/db.php';

$migrations = [
    "ALTER TABLE orders ADD COLUMN payment_intent_id VARCHAR(255) NULL UNIQUE",
    "ALTER TABLE orders ADD COLUMN stripe_payment_status VARCHAR(50) NULL DEFAULT 'pending'"
];

foreach ($migrations as $sql) {
    try {
        if ($conn->query($sql)) {
            echo "✓ " . substr($sql, 0, 40) . "...\n";
        } else {
            if (strpos($conn->error, "Duplicate column name") !== false) {
                echo "✓ Column already exists\n";
            } else {
                echo "Error: " . $conn->error . "\n";
            }
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
    }
}

$conn->close();
echo "\nDone!\n";
?>
