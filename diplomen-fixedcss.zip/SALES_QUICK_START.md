# 🚀 Sales Feature - Quick Start Guide

## Step 1: Run Database Migration

1. Open your browser
2. Go to: **`http://localhost/Diplomna_rabota/run-sales-migration.php`**
3. You should see:
   ```
   ✓ Executed: ADD COLUMN `sale_price`...
   ✓ Executed: ADD COLUMN `discount_percent`...
   Migration completed!
   ```

✅ **If you see this, skip to Step 2!**

---

## Step 2: Add a Sale to a Product

### Method A: From Edit Form (Detailed)
1. Go to Admin Panel: `http://localhost/Diplomna_rabota/admin.php`
2. Click tab: **"Управление на продукти"**
3. Click button: **"Редактиране"** on any product
4. Scroll down to section: **"Управление на намаление"**
5. Choose one option:
   - **Option 1**: Enter discount percentage (e.g., `20`) → Click **"Приложи намаление"**
   - **Option 2**: Enter sale price (e.g., `25.99`) → Click **"Приложи намаление"**
6. Click **"Запазване на промените"** at bottom

### Method B: Quick Add (Fast)
1. In product list under **"Управление на продукти"**
2. Click **"Добавяне на намаление"** button
3. Enter discount percentage when prompted
4. Done! Sale is applied immediately

### Method C: Remove Sale
1. Click **"Премахни намаление"** button on product with sale
2. Confirm action
3. Sale removed!

---

## Step 3: View Sale on Product Page

1. Go to product page: `http://localhost/Diplomna_rabota/itempage.php?id=1`
2. You should see:

```
Old Price (strikethrough): 29.99 €
New Price (blood red/orange): 23.99 €  [SALE 20%]
```

3. Sale badge shows discount percentage

---

## Visual Preview

### On Item Page:
```
┌─────────────────────────────────────┐
│ Product Title                       │
├─────────────────────────────────────┤
│                                     │
│ ~~29.99 €~~                        │
│ 23.99 €  ┌─────────┐               │
│          │  SALE   │               │
│          │  20%    │               │
│          └─────────┘               │
│                                     │
│ На склад                            │
│                                     │
└─────────────────────────────────────┘
```

---

## Colors Used

| Element | Color | Hex Code |
|---------|-------|----------|
| Sale Price | Blood Red/Orange | `#FF4500` |
| Sale Badge | Gradient | `#FF4500` → `#C70039` |
| Old Price | Gray | `#999` |
| Old Price Style | Strikethrough | — |

---

## Calculation Examples

### Example 1: 20% Discount
- Original Price: €100.00
- You enter: 20% discount
- Result: Sale Price = €80.00

### Example 2: Fixed Sale Price
- Original Price: €100.00
- You enter: €75.00 sale price
- Result: Discount = 25%

---

## FAQ

### Q: How do I add a 20% discount to product with ID 5?
A: 
1. Redact the product
2. Enter `20` in "Процент намаление"
3. Click "Приложи намаление"

### Q: Can I add sale for just part of a day?
A: Currently no. Sales are always active until removed. (Feature can be added later)

### Q: Does the cart use the sale price?
A: Yes! ✅ Orders automatically calculate with sale price.

### Q: What if I enter both percent AND price?
A: Use whichever one is set. The system calculates the missing value.

### Q: Can guests see the sale?
A: Yes! ✅ Sales display for all users, logged in or guest.

---

## Troubleshooting

### ❌ Sale doesn't appear on product page
- Clear browser cache (Ctrl+Shift+Delete)
- Check that `sale_price` value is saved in database
- Check browser console for errors (F12)

### ❌ Admin buttons not showing
- Make sure you're logged in as admin
- Check if you have admin privileges
- Try logging out and back in

### ❌ Migration failed
- Check that you're using admin account
- Make sure MySQL connection is working
- Try running migration again

### ❌ Can't apply sale
- Make sure discount is between 1-99%
- Make sure sale price is less than original
- Check browser console for error messages

---

## Testing Checklist

Use this to verify everything works:

- [ ] Migration ran successfully
- [ ] Can edit a product
- [ ] Can see "Управление на намаление" section
- [ ] Discount percent field works
- [ ] Sale price field works
- [ ] "Приложи намаление" button applies sale
- [ ] "Премахни намаление" button removes sale
- [ ] Quick add button works from product list
- [ ] Sale displays on product page
- [ ] Old price shows with strikethrough
- [ ] Sale price shows in blood red/orange
- [ ] Badge shows discount percentage
- [ ] Cart uses sale price for calculations
- [ ] Order total includes sale discount

✅ All checked? You're ready to go!

---

## Support

For detailed documentation, see:
- `SALES_FEATURE.md` - Full feature documentation
- `SALES_IMPLEMENTATION.md` - Technical implementation details

---

**Happy Selling! 🎉**
