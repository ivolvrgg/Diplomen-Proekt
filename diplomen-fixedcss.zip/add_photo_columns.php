<?php
/**
 * Direct Database Column Addition
 * This script directly adds the photo upload columns to your database
 */

require_once 'connection.php';

echo "Checking and adding photo upload columns...\n\n";

// Connection test
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

echo "✓ Connected to database: dron_db\n\n";

// Check current table structure
echo "Current users table columns:\n";
$result = $conn->query("DESCRIBE users");
$existingColumns = [];
while ($row = $result->fetch_assoc()) {
    $existingColumns[] = $row['Field'];
    echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
}

echo "\n" . str_repeat("-", 50) . "\n\n";

// Columns to add
$columnsToAdd = [
    'profile_picture' => "VARCHAR(255) DEFAULT NULL COMMENT 'Photo file path or URL'",
    'profile_picture_data' => "LONGBLOB DEFAULT NULL COMMENT 'Binary image data'",
    'profile_picture_mime_type' => "VARCHAR(100) DEFAULT NULL COMMENT 'Image MIME type'"
];

echo "Adding missing photo columns...\n\n";

$allSuccess = true;
foreach ($columnsToAdd as $columnName => $columnDef) {
    if (in_array($columnName, $existingColumns)) {
        echo "✓ $columnName (already exists)\n";
    } else {
        echo "Adding $columnName...";
        $sql = "ALTER TABLE users ADD COLUMN $columnName $columnDef";
        if ($conn->query($sql)) {
            echo " ✓ Success\n";
        } else {
            echo " ✗ Error: " . $conn->error . "\n";
            $allSuccess = false;
        }
    }
}

echo "\n" . str_repeat("-", 50) . "\n";
echo "✓ Verifying new table structure:\n\n";

$result = $conn->query("DESCRIBE users");
$photoColumns = [];
while ($row = $result->fetch_assoc()) {
    if (strpos($row['Field'], 'profile_picture') !== false) {
        echo "  ✓ " . $row['Field'] . " (" . $row['Type'] . ")\n";
        $photoColumns[] = $row['Field'];
    }
}

echo "\n";
if (count($photoColumns) === 3) {
    echo "✓✓✓ PHOTO UPLOAD SYSTEM READY! ✓✓✓\n";
    echo "\nYou can now:\n";
    echo "  1. Upload photos: POST to /api/upload_profile_picture.php\n";
    echo "  2. View photos: GET /api/get_profile_picture.php?user_id={id}\n";
} else {
    echo "✗ Some columns are missing (" . count($photoColumns) . "/3). Please try again.\n";
}
?>
