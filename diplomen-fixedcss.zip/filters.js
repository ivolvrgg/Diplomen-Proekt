// Filter Functionality Script

(function() {
    'use strict';

    const productsGrid = document.getElementById('productsGrid');
    const priceSlider = document.getElementById('priceSlider');
    const priceValue = document.getElementById('priceValue');
    const stockFilter = document.querySelector('.stock-filter');
    const sortSelect = document.getElementById('sortSelect');
    const resetButton = document.getElementById('resetFilters');
    const filterToggle = document.getElementById('filterToggleMobile');
    const filtersSidebar = document.querySelector('.filters-sidebar');

    // Get all products
    const productCards = document.querySelectorAll('.product-card');

    // Filter state
    const filterState = {
        price: 5000,
        inStock: false,
        sort: 'name-asc'
    };

    // Initialize filters when DOM is loaded
    function init() {
        if (priceSlider) {
            priceSlider.addEventListener('input', handlePriceFilter);
        }
        if (stockFilter) {
            stockFilter.addEventListener('change', handleStockFilter);
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', handleSort);
        }
        if (resetButton) {
            resetButton.addEventListener('click', resetFilters);
        }
        if (filterToggle) {
            filterToggle.addEventListener('click', toggleFiltersMobile);
        }

        applyFilters();
    }

    // Handle price filter
    function handlePriceFilter(e) {
        const value = parseInt(e.target.value);
        filterState.price = value;
        
        if (priceValue) {
            priceValue.textContent = value;
        }

        applyFilters();
    }

    // Handle stock filter
    function handleStockFilter(e) {
        filterState.inStock = e.target.checked;
        applyFilters();
    }

    // Handle sort
    function handleSort(e) {
        filterState.sort = e.target.value;
        sortProducts();
    }

    // Apply filters to products
    function applyFilters() {
        let visibleCount = 0;

        productCards.forEach(card => {
            const price = parseInt(card.dataset.price) || 0;
            const stock = parseInt(card.dataset.stock) || 0;

            let show = true;

            // Price filter
            if (price > filterState.price) {
                show = false;
            }

            // Stock filter
            if (filterState.inStock && stock === 0) {
                show = false;
            }

            // Show or hide product
            if (show) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });

        // Show empty state if no products
        handleEmptyState(visibleCount);

        // Apply sort to visible products
        sortProducts();
    }

    // Sort products
    function sortProducts() {
        const visibleCards = Array.from(productCards).filter(card => {
            return !card.classList.contains('hidden');
        });

        visibleCards.sort((a, b) => {
            const sortType = filterState.sort;

            switch (sortType) {
                case 'name-asc':
                    return a.dataset.name.localeCompare(b.dataset.name, 'bg');
                case 'name-desc':
                    return b.dataset.name.localeCompare(a.dataset.name, 'bg');
                case 'price-asc':
                    return parseInt(a.dataset.price) - parseInt(b.dataset.price);
                case 'price-desc':
                    return parseInt(b.dataset.price) - parseInt(a.dataset.price);
                default:
                    return 0;
            }
        });

        // Reorder products in grid
        visibleCards.forEach(card => {
            productsGrid.appendChild(card);
        });
    }

    // Handle empty state
    function handleEmptyState(visibleCount) {
        let emptyState = document.querySelector('.empty-state');

        if (visibleCount === 0) {
            if (!emptyState) {
                emptyState = document.createElement('div');
                emptyState.className = 'empty-state';
                emptyState.innerHTML = '<p>Няма продукти, които съответстват на вашите филтри.</p>';
                productsGrid.appendChild(emptyState);
            }
        } else {
            if (emptyState) {
                emptyState.remove();
            }
        }
    }

    // Reset all filters
    function resetFilters() {
        filterState.price = 5000;
        filterState.inStock = false;
        filterState.sort = 'name-asc';

        if (priceSlider) {
            priceSlider.value = 5000;
        }
        if (priceValue) {
            priceValue.textContent = '5000';
        }
        if (stockFilter) {
            stockFilter.checked = false;
        }
        if (sortSelect) {
            sortSelect.value = 'name-asc';
        }

        applyFilters();
    }

    // Toggle filters on mobile
    function toggleFiltersMobile() {
        if (filtersSidebar) {
            filtersSidebar.classList.toggle('show');
            
            if (filterToggle) {
                filterToggle.innerHTML = filtersSidebar.classList.contains('show') 
                    ? '<i class="fas fa-times"></i>' 
                    : '<i class="fas fa-sliders-h"></i>';
            }
        }
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose API for external use
    window.filterProducts = {
        resetFilters: resetFilters,
        getFilterState: () => filterState,
        setFilterState: (state) => {
            Object.assign(filterState, state);
            applyFilters();
        }
    };
})();
