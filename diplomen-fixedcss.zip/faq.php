<?php
$pageTitle = "Често задавани въпроси (FAQ)";
include 'includes/head.php';
?>
<?php include 'includes/navbar_selector.php'; ?>

<div class="faq-section">
    <div class="faq-hero">
        <h1>Често задавани въпроси</h1>
        <p>Намерете отговори на вашите въпроси</p>
    </div>

    <div class="faq-content">
        <div class="faq-container">
            <div class="faq-item">
                <div class="faq-question">
                    <h3>Как да направя поръчка?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        За да направите поръчка, просто разгледайте нашият каталог, добавете желаните продукти в количката и 
                        следвайте процеса на касата. Можете да плащате чрез различни методи на плащане, включително кредитни/дебитни карти,банков превод и наложен платеж.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Какво е времето за доставка?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Стандартното време за доставка е 2-5 работни дни, в зависимост от вашата локация.
                        За отдалечени райони може да отнеме малко повече време. Можете да проследите вашата поръчка след като поръчате.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Какви са вашите правила за връщане?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Ако не сте доволни от вашата покупка, можете да върнете продукта в течение на 14 дни.
                        Продуктът трябва да бъде в оригиналното си състояние с всички аксесоари. 
                        Ще възстатим пълната сума след получаване и проверка на продукта.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Предлагате ли гаранция?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Да, всички наши продукти идват с производителска гаранция. Периодът на гаранция варира в зависимост от продукта,
                        но обикновено е 12 месеца. Детайли за гаранцията можете да намерите в описанието на всеки продукт.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Как да контактувам с поддръжката?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Можете да се свържете с нас чрез менюто за контакти или за подване на оплакване или на телефон: +359 884 597 448 ,или имейл: dronchebg@gmail.com.
                        Нашият екип е готов да ви помогне с всякъкви въпроси или проблеми, които може да имате.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Подходящи ли са дроновете за начинаещи?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Да! Имаме дронове подходящи за всички нива на опит, от начинаещи до професионалисти.
                        При всяка покупка ще намерите подробни инструкции и препоръки за безопасност.
                        Препоръчваме да прочетете инструкциите преди първото използване.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Как да активирам профила си?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        За да активирате профила си, трябва да се регистрирате с вашия имейл адрес.
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Какви методи на плащане приемате?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        Приемаме множество методи на плащане включително:
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <li>Кредитни карти (Visa, MasterCard)</li>
                            <li>Дебитни карти</li>
                            <li>Банков превод</li>
                            <li>Наложен платеж</li>
                            <li>За повече опции се свържете с нас</li>
                        </ul>
                    </p>
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question">
                    <h3>Доставлявате ли международно?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>
                        В момента доставляме в цяла България. За международни поръчки, моля свържете се с нас директно
                        на email: dronchebg@gmail.com, за да обсъдим възможностите.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .faq-section {
        background-color: #f5f5f5;
        padding: 0 0 60px 0;
        min-height: 100vh;
    }

    .faq-hero {
        background: linear-gradient(135deg, #344e41 0%, #2a3f37 100%);
        color: white;
        padding: 80px 20px;
        text-align: center;
        margin-bottom: 40px;
    }

    .faq-hero h1 {
        font-size: 48px;
        margin: 0 0 10px 0;
        font-weight: bold;
    }

    .faq-hero p {
        font-size: 20px;
        color: #fb8500;
        margin: 0;
    }

    .faq-content {
        max-width: 900px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .faq-container {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .faq-item {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }

    .faq-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .faq-question {
        padding: 20px;
        background-color: #344e41;
        color: white;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        user-select: none;
        transition: background-color 0.3s ease;
    }

    .faq-question:hover {
        background-color: #2a3f37;
    }

    .faq-question h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
    }

    .faq-toggle {
        font-size: 24px;
        transition: transform 0.3s ease;
    }

    .faq-item.active .faq-toggle {
        transform: rotate(45deg);
    }

    .faq-answer {
        padding: 20px;
        background-color: #ffffff;
        color: #666;
        display: none;
        line-height: 1.8;
    }

    .faq-item.active .faq-answer {
        display: block;
    }

    .faq-answer p {
        margin: 0;
    }

    .faq-answer ul {
        list-style: none;
        padding-left: 20px;
    }

    .faq-answer ul li {
        margin-bottom: 8px;
        position: relative;
        padding-left: 15px;
    }

    .faq-answer ul li:before {
        content: "•";
        position: absolute;
        left: 0;
        color: #fb8500;
        font-weight: bold;
    }

    @media (max-width: 768px) {
        .faq-hero h1 {
            font-size: 36px;
        }

        .faq-hero p {
            font-size: 16px;
        }

        .faq-question h3 {
            font-size: 16px;
        }
    }
</style>

<script>
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', () => {
            const faqItem = question.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Close all items
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                faqItem.classList.add('active');
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>
</body>
</html>
