<?php
$page_title = 'Dronche.BG - Каталог';
$page_css = 'css/catalog.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <section class="catalog-header">
            <div class="container">
                <h1>Каталог</h1>
                <p>Избирете категория, за да видите всички продукти</p>
            </div>
        </section>

        <section class="categories-showcase">
            <div class="container">
                <div class="categories-grid">
                    <?php
                    // Get all categories
                    $categories_query = "SELECT c.*, COUNT(p.id) as product_count FROM categories c 
                                       LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
                                       GROUP BY c.id
                                       ORDER BY c.sort_order ASC";
                    $categories_result = $conn->query($categories_query);
                    
                    if ($categories_result && $categories_result->num_rows > 0) {
                        while ($category = $categories_result->fetch_assoc()) {
                            // Get first product image from category for thumbnail using prepared statement
                            $thumb_query = "SELECT image_1 FROM products WHERE category_id = ? AND is_active = 1 LIMIT 1";
                            $thumb_stmt = $conn->prepare($thumb_query);
                            
                            if ($thumb_stmt) {
                                $thumb_stmt->bind_param("i", $category['id']);
                                $thumb_stmt->execute();
                                $thumb_result = $thumb_stmt->get_result();
                                $thumb_product = $thumb_result->fetch_assoc();
                                $thumb_image = $thumb_product['image_1'] ?? 'https://via.placeholder.com/400x300?text=' . urlencode($category['name']);
                                $thumb_stmt->close();
                            } else {
                                $thumb_image = 'https://via.placeholder.com/400x300?text=' . urlencode($category['name']);
                            }
                    ?>
                    <div class="category-card">
                        <a href="category-products.php?id=<?php echo $category['id']; ?>" class="category-link">
                            <img src="<?php echo htmlspecialchars($thumb_image); ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" class="category-image">
                            <div class="category-name"><?php echo htmlspecialchars($category['name']); ?></div>
                        </a>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
