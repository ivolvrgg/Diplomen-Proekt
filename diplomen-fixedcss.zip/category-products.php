<?php
$page_css = 'css/category-products.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <?php
        // Get category ID from URL
        $category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        
        if ($category_id > 0) {
            // Get category details using prepared statement
            $cat_query = "SELECT * FROM categories WHERE id = ?";
            $cat_stmt = $conn->prepare($cat_query);
            
            if ($cat_stmt) {
                $cat_stmt->bind_param("i", $category_id);
                $cat_stmt->execute();
                $cat_result = $cat_stmt->get_result();
                
                if ($cat_result && $cat_result->num_rows > 0) {
                    $category = $cat_result->fetch_assoc();
                    $page_title = $category['name'] . ' - Dronche.BG';
            ?>
        
         <section class="category-header">
            <div class="container">
                <h1 class="category-title"><?php echo htmlspecialchars($category['name']); ?></h1>
            </div>
        </section>
        <section class="category-products">
           

            <div class="container">
                
                <div class="products-wrapper">
                    <!-- Filter Sidebar -->
                    <aside class="filters-sidebar">
                        <div class="filter-header">
                            <h3>Филтри</h3>
                            <button class="filter-toggle-mobile" id="filterToggleMobile">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>

                        <!-- Price Range Filter -->
                        <div class="filter-group">
                            <h4>Цена</h4>
                            <div class="price-filter">
                                <input type="range" min="0" max="5000" value="5000" class="price-slider" id="priceSlider">
                                <div class="price-display">
                                    <span>0 €</span> - <span id="priceValue">5000</span> €
                                </div>
                            </div>
                        </div>

                        <!-- Stock Filter -->
                        <div class="filter-group">
                            <h4>Наличност</h4>
                            <label class="filter-checkbox">
                                <input type="checkbox" value="inStock" class="stock-filter">
                                <span>Само на склад</span>
                            </label>
                        </div>

                        <!-- Sort Filter -->
                        <div class="filter-group">
                            <h4>Сортиране</h4>
                            <select id="sortSelect" class="sort-select">
                                <option value="name-asc">Име (А-Я)</option>
                                <option value="name-desc">Име (Я-А)</option>
                                <option value="price-asc">Цена (ниска-висока)</option>
                                <option value="price-desc">Цена (висока-ниска)</option>
                            </select>
                        </div>

                        <button class="filter-reset" id="resetFilters">Изчисти филтрите</button>
                    </aside>

                    <!-- Products Grid -->
                    <div class="products-section">
                        <div class="products-grid" id="productsGrid">
                    <?php
                    // Get all products for this category using prepared statement
                    $products_query = "SELECT * FROM products WHERE category_id = ? AND is_active = 1 ORDER BY name ASC";
                    $products_stmt = $conn->prepare($products_query);
                    
                    if ($products_stmt) {
                        $products_stmt->bind_param("i", $category_id);
                        $products_stmt->execute();
                        $products_result = $products_stmt->get_result();
                        
                        if ($products_result && $products_result->num_rows > 0) {
                            while ($product = $products_result->fetch_assoc()) {
                                $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                        ?>
                    <div class="product-card" data-price="<?php echo $product['sale_price'] && $product['sale_price'] > 0 ? $product['sale_price'] : $product['price']; ?>" data-stock="<?php echo $product['stock']; ?>" data-name="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="product-image-wrapper">
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                            <div class="product-overlay">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="view-details-btn">Детайли</a>
                            </div>
                        </div>
                        
                        <div class="product-info">
                            <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-price">
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                    <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                    <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                <?php } else { ?>
                                    <?php echo number_format($product['price'], 2); ?> €
                                <?php } ?>
                            </p>
                            <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                            </p>
                        </div>
                        
                        <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                    </div>
                    <?php
                            }
                        } else {
                            echo '<div class="empty-state"><p>Няма продукти в тази категория.</p></div>';
                        }
                        $products_stmt->close();
                    }
                    ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
                    $cat_stmt->close();
                } else {
                    echo '<div class="container"><p>Категорията не е намерена.</p></div>';
                }
            } else {
                echo '<div class="container"><p>Грешка при зареждане на категорията.</p></div>';
            }
        } else {
            echo '<div class="container"><p>Невалидна категория.</p></div>';
        }
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
    <script src="filters.js"></script>
</body>
</html>
