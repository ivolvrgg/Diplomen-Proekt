# Photo Upload Implementation Guide

## Overview
This project includes a complete photo upload system for user profile pictures. Photos are stored as binary data directly in the MySQL database with proper security and validation.

## Database Setup

### 1. Update your database with the new columns

Run one of these migrations in your MySQL database:

#### Option A: Run the migration for existing tables
```sql
-- From: sql/migrations_add_photo_upload.sql
ALTER TABLE `users` 
ADD COLUMN `profile_picture_data` LONGBLOB DEFAULT NULL,
ADD COLUMN `profile_picture_mime_type` VARCHAR(100) DEFAULT NULL;
```

#### Option B: Use the updated schema (for new installation)
```sql
-- From: sql/schema_updated_with_photos.sql
-- Same as schema.sql but with photo columns included
```

### Database Columns

The `users` table now includes:
- `profile_picture` (VARCHAR 255) - Optional: path or reference
- `profile_picture_data` (LONGBLOB) - Binary image data
- `profile_picture_mime_type` (VARCHAR 100) - Image type (e.g., 'image/jpeg', 'image/png')

## API Endpoints

### Upload Photo
**Endpoint:** `POST /api/upload_profile_picture.php`

**Example Request:**
```javascript
const formData = new FormData();
formData.append('profile_picture', fileInput.files[0]);

fetch('/api/upload_profile_picture.php', {
  method: 'POST',
  body: formData
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    console.log('Photo uploaded:', data.profile_picture);
  }
});
```

**Response:**
```json
{
  "success": true,
  "message": "Снимката е качена успешно",
  "profile_picture": "api/get_profile_picture.php?user_id=1&t=1708900234"
}
```

**Validation:**
- Max file size: 2 MB
- Allowed formats: JPEG, PNG, GIF, WebP
- Requires user to be logged in (session validated)

### Retrieve Photo
**Endpoint:** `GET /api/get_profile_picture.php?user_id={id}`

**Example:**
```html
<img src="api/get_profile_picture.php?user_id=1" alt="Profile Picture">
```

**Query Parameters:**
- `user_id` (required): ID of the user
- `t` (optional): Cache buster timestamp to force refresh

## File Structure

```
api/
├── upload_profile_picture.php    # Handles photo uploads
└── get_profile_picture.php       # Retrieves and displays photos

sql/
├── migrations_add_photo_upload.sql        # Migration to add columns
└── schema_updated_with_photos.sql         # Updated schema with photos

uploads/
└── profile_pictures/             # Directory for file backups (optional)
```

## Security Features

1. **File Type Validation**: Uses `finfo_file()` to verify actual file type (not just extension)
2. **File Size Limit**: Maximum 2 MB per image
3. **Session Authentication**: Requires logged-in user
4. **Error Handling**: Returns detailed error messages in API responses
5. **MIME Type Storage**: Stores actual detected MIME type for proper rendering

## How It Works

### Upload Flow
1. User selects an image file
2. Frontend sends POST request to `upload_profile_picture.php`
3. Server validates:
   - User is authenticated (session)
   - File size is under 2 MB
   - File type is allowed (JPEG, PNG, GIF, WebP)
   - MIME type is verified with `finfo_file()`
4. Image data is converted to hex format using `bin2hex()`
5. Data stored in database using `UNHEX()` for safe binary storage
6. Returns profile picture URL with cache-buster

### Retrieval Flow
1. User requests `get_profile_picture.php?user_id={id}`
2. Server fetches `profile_picture_data` and `profile_picture_mime_type`
3. Sets appropriate `Content-Type` header
4. Outputs binary image data directly to browser

## Configuration

### File Size Limits
To change the maximum file size (currently 2 MB), edit `api/upload_profile_picture.php`:
```php
$maxSize = 2 * 1024 * 1024; // Change this value
```

### Allowed MIME Types
To add or remove supported formats, edit:
```php
$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
```

## Troubleshooting

### Issue: "Файлът е твърде голям"
- Image exceeds 2 MB size limit
- Solution: Compress image or increase `$maxSize` limit

### Issue: "Позволени са само JPEG, PNG, GIF и WebP файлове"
- File format not supported
- Solution: Convert image to JPEG, PNG, GIF, or WebP

### Issue: "Connection failed" error
- Database connection issue
- Solution: Check `config/db.php` for correct credentials

### Issue: "No profile picture data"
- Column doesn't exist in database
- Solution: Run the migration script first

## Performance Notes

- Profile pictures are stored in database for simplicity
- For very large-scale applications, consider:
  - Storing images on file system + filename in DB
  - Using CDN for image delivery
  - Implementing caching headers for browser cache

## Future Enhancements

1. Add image resizing/thumbnail generation
2. Support multiple profile pictures with gallery
3. Implement image optimization/compression
4. Add image cropping functionality
5. Support for other image formats (WEBP, AVIF)
