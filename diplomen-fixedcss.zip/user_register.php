<?php
$page_title = 'Регистрация - Dronche.BG';
$page_css = 'css/user_register.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// If user is already logged in, redirect to homepage
if (is_logged_in()) {
    header('Location: homepage.php');
    exit;
}
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Регистрация</h1>
                <form class="login-form" id="registrationForm">
                    <div class="form-group">
                        <label for="fullname">Пълно име</label>
                        <input type="text" id="fullname" name="fullname" required placeholder="Въведи своето пълно име">
                        <span class="error-message" id="fullnameError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Парола</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="password" name="password" required placeholder="Въведи парола" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">Потвърди паролата</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="confirm-password" name="confirm-password" required placeholder="Потвърди своята парола" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="confirm-password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="confirmPasswordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="terms" required>
                            Съгласен/а съм с условията
                        </label>
                    </div>
                    
                    <button type="submit" class="login-btn">Регистрирай се</button>
                </form>
                
                <div class="signup-link">
                    Имаш акаунт? <a href="user_login.php">Влез тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            const terms = document.querySelector('input[name="terms"]').checked;
            
            // Clear previous errors
            document.getElementById('fullnameError').textContent = '';
            document.getElementById('emailError').textContent = '';
            document.getElementById('passwordError').textContent = '';
            document.getElementById('confirmPasswordError').textContent = '';
            
            // Client-side validation for confirm password
            if (password !== confirmPassword) {
                document.getElementById('confirmPasswordError').textContent = 'Паролите не съвпадат';
                return;
            }
            
            if (!terms) {
                alert('Трябва да приемете условията');
                return;
            }
            
            // Submit to server
            const formData = new FormData();
            formData.append('fullname', fullname);
            formData.append('email', email);
            formData.append('password', password);
            formData.append('confirm-password', confirmPassword);
            
            fetch('api/register.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Регистрирахте се успешно!');
                    window.location.href = data.redirect;
                } else {
                    // Show errors from server
                    if (data.errors && Array.isArray(data.errors)) {
                        data.errors.forEach(error => {
                            if (error.includes('име')) {
                                document.getElementById('fullnameError').textContent = error;
                            } else if (error.includes('email') || error.includes('Email')) {
                                document.getElementById('emailError').textContent = error;
                            } else if (error.includes('пароля') || error.includes('Пароля')) {
                                if (error.includes('съвпадат')) {
                                    document.getElementById('confirmPasswordError').textContent = error;
                                } else {
                                    document.getElementById('passwordError').textContent = error;
                                }
                            } else {
                                alert(error);
                            }
                        });
                    }
                }
            })
            .catch(err => {
                alert('Възникна грешка при регистрацията');
                console.error(err);
            });
        });

        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.getElementById(targetId);
                passwordInput.type = this.checked ? 'text' : 'password';
            });
        });
    </script>
</body>
</html>
