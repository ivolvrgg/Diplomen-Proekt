<?php
/**
 * Photo Upload Setup Script
 * This script adds photo storage support to the users table
 * Run this once to enable photo uploads
 */

require_once 'connection.php';

// Start output buffering to capture any output
ob_start();

try {
    echo "Starting photo upload database setup...\n\n";
    
    // Check if columns already exist
    $checkQuery = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
                   WHERE TABLE_NAME = 'users' AND TABLE_SCHEMA = 'dron_db' 
                   AND COLUMN_NAME IN ('profile_picture_data', 'profile_picture_mime_type')";
    
    $result = $conn->query($checkQuery);
    
    if ($result && $result->num_rows > 0) {
        echo "✓ Photo columns already exist in the database.\n";
        echo "Your database is already set up for photo uploads!\n";
    } else {
        echo "Adding photo storage columns to users table...\n";
        
        // Add profile_picture_data column
        echo "- Adding profile_picture_data column (LONGBLOB)...";
        $sql1 = "ALTER TABLE `users` ADD COLUMN `profile_picture_data` LONGBLOB DEFAULT NULL AFTER `profile_picture`";
        
        if ($conn->query($sql1)) {
            echo " ✓ Success\n";
        } else {
            throw new Exception("Failed to add profile_picture_data: " . $conn->error);
        }
        
        // Add profile_picture_mime_type column
        echo "- Adding profile_picture_mime_type column (VARCHAR)...";
        $sql2 = "ALTER TABLE `users` ADD COLUMN `profile_picture_mime_type` VARCHAR(100) DEFAULT NULL AFTER `profile_picture_data`";
        
        if ($conn->query($sql2)) {
            echo " ✓ Success\n";
        } else {
            throw new Exception("Failed to add profile_picture_mime_type: " . $conn->error);
        }
        
        // Add index for faster queries
        echo "- Adding index for faster profile image queries...";
        $sql3 = "ALTER TABLE `users` ADD INDEX `idx_user_profile_image` (`id`, `profile_picture_data`(100))";
        
        if ($conn->query($sql3)) {
            echo " ✓ Success\n";
        } else {
            // Index might already exist, not critical
            echo " (skipped - may already exist)\n";
        }
        
        echo "\n✓ Photo upload setup completed successfully!\n";
    }
    
    // Verify the columns exist
    echo "\nVerifying database structure:\n";
    $verifyQuery = "DESCRIBE `users`";
    $verifyResult = $conn->query($verifyQuery);
    
    $hasPhotoData = false;
    $hasMimeType = false;
    
    while ($row = $verifyResult->fetch_assoc()) {
        if ($row['Field'] === 'profile_picture_data') {
            $hasPhotoData = true;
            echo "✓ profile_picture_data: " . $row['Type'] . "\n";
        }
        if ($row['Field'] === 'profile_picture_mime_type') {
            $hasMimeType = true;
            echo "✓ profile_picture_mime_type: " . $row['Type'] . "\n";
        }
    }
    
    if ($hasPhotoData && $hasMimeType) {
        echo "\n✓ Database is ready for photo uploads!\n";
        echo "\nYou can now:\n";
        echo "1. Use api/upload_profile_picture.php to upload photos\n";
        echo "2. Use api/get_profile_picture.php?user_id={id} to retrieve photos\n";
        echo "3. Photos will be stored securely in the database\n";
    } else {
        throw new Exception("Columns not properly created. Please try again.");
    }
    
} catch (Exception $e) {
    echo "\n✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}

// Get output
$output = ob_get_clean();

// Display formatted output
?>
<!DOCTYPE html>
<html>
<head>
    <title>Photo Upload Setup</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
            margin-top: 0;
            text-align: center;
            border-bottom: 3px solid #667eea;
            padding-bottom: 20px;
        }
        .output {
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            color: #333;
            white-space: pre-wrap;
            word-wrap: break-word;
            max-height: 400px;
            overflow-y: auto;
        }
        .success { color: #27ae60; font-weight: bold; }
        .error { color: #e74c3c; font-weight: bold; }
        .info { color: #3498db; }
        .checkmark { color: #27ae60; }
        .footer {
            margin-top: 30px;
            text-align: center;
            color: #666;
            font-size: 13px;
        }
        a {
            color: #667eea;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📸 Photo Upload Setup</h1>
        <div class="output"><?php echo htmlspecialchars($output); ?></div>
        <div class="footer">
            <p>✓ Setup complete. You can now test photo uploads.</p>
            <p><a href="../">← Back to application</a></p>
        </div>
    </div>
</body>
</html>
