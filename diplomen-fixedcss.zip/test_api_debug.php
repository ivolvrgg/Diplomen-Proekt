<?php
session_start();
$_SESSION['is_admin'] = 1;

echo "=== TEST 1: Database Connection ===\n";
$conn = @new mysqli('localhost', 'root', '', 'dron_db');
if ($conn->connect_error) {
    echo "DB ERROR: " . $conn->connect_error;
    exit;
}
echo "✓ Connection OK\n\n";

echo "=== TEST 2: Tables Exist ===\n";
$tables = ['complaints', 'contact_messages'];
foreach ($tables as $table) {
    $r = $conn->query("SELECT COUNT(*) as cnt FROM $table");
    if ($r) {
        $d = $r->fetch_assoc();
        echo "✓ $table exists, rows: " . $d['cnt'] . "\n";
    } else {
        echo "✗ $table ERROR: " . $conn->error . "\n";
    }
}
echo "\n";

echo "=== TEST 3: Sample Query (Complaints) ===\n";
$q = "SELECT c.* FROM complaints c LIMIT 1";
$r = $conn->query($q);
if ($r) {
    $row = $r->fetch_assoc();
    if ($row) {
        echo "Sample row:\n";
        var_dump($row);
    } else {
        echo "No rows in complaints table\n";
    }
} else {
    echo "Query error: " . $conn->error . "\n";
}
echo "\n";

echo "=== TEST 4: JSON Encode Test ===\n";
$test_data = ['success' => true, 'complaints' => [['id' => 1, 'title' => 'Test']]];
$json = json_encode($test_data);
echo "JSON output: " . $json . "\n";
echo "Is valid JSON: " . (json_decode($json) ? 'YES' : 'NO') . "\n";
echo "\n";

echo "=== TEST 5: Actual API Response ===\n";
ob_start();
header('Content-Type: application/json; charset=utf-8');
error_reporting(0);
ini_set('display_errors', 0);
if(!isset($_SESSION['is_admin'])){echo '{"success":false}';exit;}
$conn=@new mysqli('localhost','root','','dron_db');
if(!$conn||$conn->connect_error){echo json_encode(['success'=>false,'error'=>'DB Error']);exit;}
$q="SELECT c.* FROM complaints c ORDER BY c.created_at DESC LIMIT 5";
$r=$conn->query($q);
$c=[];
if($r){while($w=$r->fetch_assoc()){$c[]=$w;}}
$output = json_encode(['success'=>true,'complaints'=>$c]);
echo $output;
$conn->close();
$response = ob_get_clean();
echo "Response length: " . strlen($response) . " bytes\n";
echo "Response (raw): " . bin2hex($response) . "\n";
echo "Response (text): " . $response . "\n";
?>