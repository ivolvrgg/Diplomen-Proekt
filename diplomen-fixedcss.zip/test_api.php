<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>API Test</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .test-box { background: #f0f0f0; padding: 20px; margin: 10px 0; border: 1px solid #ccc; }
        code { background: #e0e0e0; padding: 10px; display: block; margin: 10px 0; word-break: break-all; }
        .success { color: green; }
        .error { color: red; }
        pre { background: #e0e0e0; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>Cart API Test</h1>
    
    <div class="test-box">
        <h2>Session Info</h2>
        <p>User ID: <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'Not set'; ?></p>
        <p>Is Logged In: <?php echo isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0 ? 'YES' : 'NO'; ?></p>
    </div>
    
    <div class="test-box">
        <h2>Call API Cart Endpoint</h2>
        <button onclick="testAPI()">Test GET /api/cart.php</button>
        <div id="result"></div>
    </div>
    
    <script>
        function testAPI() {
            const resultDiv = document.getElementById('result');
            resultDiv.innerHTML = '<p>Loading...</p>';
            
            // Try multiple paths
            const paths = [
                'api/cart.php',
                '/Diplomna_rabota/api/cart.php',
                './api/cart.php'
            ];
            
            Promise.all(paths.map(path => 
                fetch(path, {
                    method: 'GET',
                    credentials: 'include'
                })
                .then(response => ({
                    path: path,
                    status: response.status,
                    promise: response.json()
                }))
                .then(obj => obj.promise.then(data => ({
                    path: obj.path,
                    status: obj.status,
                    data: data
                })))
                .catch(err => ({
                    path: path,
                    error: err.message
                }))
            ))
            .then(results => {
                let html = '<h3>Results from all paths:</h3>';
                
                results.forEach(result => {
                    html += '<div style="margin: 10px 0; padding: 10px; border: 1px solid #ccc;">';
                    html += '<strong>Path: ' + result.path + '</strong><br>';
                    
                    if (result.error) {
                        html += '<span class="error">Error: ' + result.error + '</span>';
                    } else {
                        html += 'Status: ' + result.status + '<br>';
                        html += '<pre>' + JSON.stringify(result.data, null, 2) + '</pre>';
                        
                        // Count items
                        if (Array.isArray(result.data)) {
                            const count = result.data.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
                            html += '<span class="success"><strong>Total items: ' + count + '</strong></span>';
                        }
                    }
                    html += '</div>';
                });
                
                resultDiv.innerHTML = html;
            });
        }
    </script>
</body>
</html>
