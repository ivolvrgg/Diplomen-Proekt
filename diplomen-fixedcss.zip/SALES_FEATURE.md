# Sales/Discount Feature - Setup Guide

## Overview
This implementation adds a complete sales/discount system to your e-commerce platform with:
- Admin panel controls to add/remove sales
- Product page display with sale pricing and discount badges
- Blood red/orange color scheme for sale prices
- Percentage and fixed price discount options

## Features Implemented

### 1. **Database Schema**
New columns added to `products` table:
- `sale_price` (DECIMAL 10,2) - The discounted price
- `discount_percent` (INT) - The discount percentage

### 2. **Admin Panel Features**
- **Redact/Edit Product**: Click "Редактиране" button to open edit form
- **Add Sale Section**: New section in edit form with:
  - Discount Percent input (1-99%)
  - Sale Price input (alternative to percentage)
  - "Приложи намаление" button
  - "Премахни намаление" button (shows when sale exists)
  - Current sale info display
- **Quick Actions**: 
  - If product has no sale: "Добавяне на намаление" button
  - If product has sale: "Премахни намаление" button

### 3. **Product Page Display**
When a product has a sale:
- Old price shown above with strikethrough (gray color)
- New sale price displayed in blood red/orange (#FF4500)
- Sale badge box showing "SALE" and discount percentage
- Badge styled with red-orange gradient

### 4. **API Endpoints**
- `api/add_sale.php` - Add or update a sale on a product
  - Parameters: `product_id`, `discount_percent` (optional), `sale_price` (optional)
  - Returns: success status, sale_price, discount_percent
- `api/remove_sale.php` - Remove sale from a product
  - Parameters: `product_id`
  - Returns: success status

## Setup Instructions

### Step 1: Run Database Migration

Open your browser and navigate to:
```
http://localhost/Diplomna_rabota/run-sales-migration.php
```

You should see output confirming the migration:
```
✓ Executed: ADD COLUMN `sale_price`...
✓ Executed: ADD COLUMN `discount_percent`...
Migration completed!
```

### Step 2: Verify Installation

1. Go to Admin Panel: `http://localhost/Diplomna_rabota/admin.php`
2. Click "Управление на продукти" tab
3. Click "Редактиране" on any product
4. You should see the new "Управление на намаление" section

### Step 3: Add a Sale

#### Method 1: From Product Edit Form
1. Click "Редактиране" on a product
2. In "Управление на намаление" section:
   - Enter discount % (e.g., 20) OR sale price (e.g., 25.99)
   - Click "Приложи намаление"
3. Click "Запазване на промените"

#### Method 2: Quick Add from Product List
1. In "Управление на продукти" tab
2. Click "Добавяне на намаление" button
3. Enter discount percentage when prompted
4. Sale is applied immediately

#### Method 3: Remove Sale
1. Click "Премахни намаление" button
2. Confirm the action
3. Sale is removed immediately

## Files Modified/Created

### New Files:
- `sql/migration_add_sales.sql` - Database schema migration
- `run-sales-migration.php` - Migration runner
- `api/add_sale.php` - Add sale API endpoint
- `api/remove_sale.php` - Remove sale API endpoint

### Modified Files:
- `itempage.php` - Added sale display logic
- `itempage.css` - Added sale display styles
- `admin.php` - Added sale management UI and functions

## CSS Classes Reference

### Item Page Styling:
- `.sale-price-container` - Container for price and badge
- `.original-price-line` - Original price with strikethrough
- `.original-price` - Gray strikethrough price
- `.sale-price` - Blood red/orange new price (#FF4500)
- `.sale-badge` - Badge box styling
- `.sale-text` - "SALE" text in badge
- `.discount-percent` - Percentage text in badge

## Technical Details

### Sale Price Calculation
- If discount_percent provided: `sale_price = original_price * (1 - discount_percent/100)`
- If sale_price provided: `discount_percent = round((1 - sale_price/original_price) * 100)`

### Color Scheme
- Sale Price Text: `#FF4500` (Blood Red/Orange)
- Sale Badge Background: Gradient from `#FF4500` to `#C70039`
- Old Price: `#999` (Gray)

### Validation
- Discount percent: 1-99%
- Sale price must be less than original price
- At least one (percent or price) must be provided

## Testing Checklist

- [ ] Database migration runs successfully
- [ ] Admin can add sale via edit form
- [ ] Admin can add sale via quick button
- [ ] Sale displays correctly on product page
- [ ] Old price shows with strikethrough
- [ ] New price shows in blood red/orange
- [ ] Sale badge shows with discount percentage
- [ ] Admin can remove sale
- [ ] Sale persists after page refresh
- [ ] Cart uses correct sale price (if implemented)

## Notes

- Sales only apply to individual products, not categories
- All admin actions logged (no audit trail added, but can be added)
- Sale display is responsive and works on mobile
- Cart functionality updated to use sale_price if available (check cart.php)

## Troubleshooting

### Migration doesn't work
- Ensure all SQL statements are valid
- Check database connection in `config/db.php`
- Try running SQL manually in phpMyAdmin

### Sale doesn't show on product page
- Check browser console for JavaScript errors
- Verify `sale_price` and `discount_percent` are set in database
- Clear browser cache

### Admin buttons not working
- Check browser console for errors
- Verify admin privileges (is_admin flag)
- Check API response in Network tab

## Future Enhancements

Consider implementing:
- Sale start/end dates
- Bulk sale application
- Sale audit log
- Seasonal promotions
- Bundle discounts
