<?php
if (!isset($page_title)) {
    $page_title = 'Dronche.BG';
}
if (!isset($page_css)) {
    $page_css = '';
}
?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo htmlspecialchars($page_title); ?>
    </title>

    <!-- Component CSS Files -->
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/footer.css">

    <!-- Page-specific CSS -->
    <?php if (!empty($page_css)): ?>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($page_css); ?>">
    <?php endif; ?>

    <!-- Third-party CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/cookies.css">
    <link rel="stylesheet" href="css/filters.css">
    
    <style>
        img {
            background: linear-gradient(135deg, #f5f5f5 25%, transparent 25%) -10px 0,
                        linear-gradient(225deg, #f5f5f5 25%, transparent 25%) -10px 0,
                        linear-gradient(315deg, #f5f5f5 25%, transparent 25%),
                        linear-gradient(45deg, #f5f5f5 25%, transparent 25%);
            background-size: 20px 20px;
            background-color: #f0f0f0;
        }
        
        img[src*="cdn-global-hk"],
        img[src*="placeholder"],
        img[src*="via.placeholder"] {
            min-height: 100px;
        }
    </style>
</head>
<body>
    <a href="#main-content" class="skip-link">Skip to main content</a>
