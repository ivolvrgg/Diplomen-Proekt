<?php
// Quick migration runner
include 'config/db.php';

$sql = "ALTER TABLE orders ADD COLUMN phone VARCHAR(20) DEFAULT NULL";

try {
    if ($conn->query($sql)) {
        echo "✓ Successfully added 'phone' column to orders table\n";
    } else {
        if (strpos($conn->error, "Duplicate column name") !== false) {
            echo "✓ Column 'phone' already exists\n";
        } else {
            echo "Error: " . $conn->error . "\n";
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

$conn->close();
?>
