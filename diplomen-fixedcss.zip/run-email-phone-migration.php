<?php
// Migration runner for adding email and phone to complaints table
include 'config/db.php';

$sql = "ALTER TABLE complaints 
ADD COLUMN email VARCHAR(255) NOT NULL DEFAULT '' AFTER user_id,
ADD COLUMN phone VARCHAR(20) NOT NULL DEFAULT '' AFTER email";

try {
    if ($conn->query($sql)) {
        echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin: 20px;'>";
        echo "<strong>✓ Success!</strong> Email and phone columns have been added to the 'complaints' table.";
        echo "</div>";
    } else {
        if (strpos($conn->error, "Duplicate column") !== false) {
            echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin: 20px;'>";
            echo "<strong>✓ Already Exists!</strong> The email and phone columns already exist in the 'complaints' table.";
            echo "</div>";
        } else {
            echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 4px; margin: 20px;'>";
            echo "<strong>✗ Error:</strong> " . $conn->error;
            echo "</div>";
        }
    }
} catch (Exception $e) {
    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 4px; margin: 20px;'>";
    echo "<strong>✗ Exception:</strong> " . $e->getMessage();
    echo "</div>";
}

$conn->close();
?>
