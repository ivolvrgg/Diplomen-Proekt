<?php
// Test cart badge functionality
$_SESSION['guest_id'] = 'test_guest';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cart Badge Test</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .test-box { 
            background: #f0f0f0; 
            padding: 20px; 
            margin: 10px 0; 
            border: 1px solid #ccc;
        }
        button { padding: 10px 20px; margin: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Cart Badge Test</h1>
    
    <div class="test-box">
        <h2>Test localStorage cart</h2>
        <button onclick="testAddToCart()">Add Item to Cart</button>
        <button onclick="testClearCart()">Clear Cart</button>
        <button onclick="testCheckBadge()">Check Badge</button>
        <button onclick="testUpdateBadge()">Manually Update Badge</button>
        <p id="test-output"></p>
    </div>
    
    <div class="test-box">
        <h2>Navigation Bar Preview</h2>
        <nav style="background-color: #344e41; padding: 1rem; display: flex; gap: 2rem; align-items: center; color: #faf8f3;">
            <div style="font-weight: bold;">DRONCHE.BG</div>
            <ul style="list-style: none; display: flex; gap: 2rem; align-items: center; margin: 0; padding: 0;">
                <li><a href="#" style="color: #faf8f3; text-decoration: none;">HOME</a></li>
                <li class="cart-link-container" style="position: relative; display: inline-block;">
                    <a href="#" style="color: #faf8f3; text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
                        🛒 CART
                        <span class="cart-badge" id="cart-badge" style="position: absolute; top: -10px; right: -10px; background-color: #ff0000; color: #fff; border-radius: 50%; width: 24px; height: 24px; display: none; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: bold; z-index: 10;">0</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    
    <script>
        function testAddToCart() {
            let cart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            cart.push({
                product_id: Math.floor(Math.random() * 1000),
                quantity: 1,
                name: 'Test Product'
            });
            localStorage.setItem('guest_cart', JSON.stringify(cart));
            document.getElementById('test-output').innerHTML = 'Item added! Cart now has ' + cart.length + ' items.';
            testUpdateBadge();
        }
        
        function testClearCart() {
            localStorage.removeItem('guest_cart');
            document.getElementById('test-output').innerHTML = 'Cart cleared!';
            testUpdateBadge();
        }
        
        function testCheckBadge() {
            const badge = document.getElementById('cart-badge');
            const cart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            document.getElementById('test-output').innerHTML = 'Badge found: ' + (badge ? 'YES' : 'NO') + 
                '<br>Cart items: ' + cart.length + 
                '<br>Badge display: ' + (badge ? badge.style.display : 'N/A') +
                '<br>Badge text: ' + (badge ? badge.textContent : 'N/A');
        }
        
        function testUpdateBadge() {
            const badge = document.getElementById('cart-badge');
            if (!badge) {
                document.getElementById('test-output').innerHTML = 'Badge element not found!';
                return;
            }
            
            const guestCart = localStorage.getItem('guest_cart');
            if (guestCart) {
                try {
                    const cartItems = JSON.parse(guestCart);
                    const cartCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);
                    
                    if (cartCount > 0) {
                        badge.textContent = cartCount;
                        badge.style.display = 'flex';
                        document.getElementById('test-output').innerHTML = 'Badge updated! Count: ' + cartCount;
                    } else {
                        badge.style.display = 'none';
                        document.getElementById('test-output').innerHTML = 'Badge hidden (0 items)';
                    }
                } catch (e) {
                    document.getElementById('test-output').innerHTML = 'Error: ' + e.message;
                }
            } else {
                badge.style.display = 'none';
                document.getElementById('test-output').innerHTML = 'No cart found, hiding badge';
            }
        }
        
        // Test on page load
        window.addEventListener('load', function() {
            document.getElementById('test-output').innerHTML = 'Page loaded. Try adding an item to see the badge!';
            testUpdateBadge();
        });
    </script>
</body>
</html>
