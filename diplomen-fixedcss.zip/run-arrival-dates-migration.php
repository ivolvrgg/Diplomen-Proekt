<?php
// Migration runner for adding expected arrival dates to orders table
require_once 'config/db.php';

echo "Running migration: Add expected arrival dates to orders table\n";
echo "=" . str_repeat("=", 60) . "\n\n";

try {
    // Check if columns already exist
    $check_query = "SHOW COLUMNS FROM orders LIKE 'expected_arrival_start'";
    $check_result = $conn->query($check_query);
    
    if ($check_result && $check_result->num_rows > 0) {
        echo "✓ Columns 'expected_arrival_start' and 'expected_arrival_end' already exist\n";
        echo "✓ Migration skipped - already applied\n";
    } else {
        // Add columns for expected arrival dates
        $sql1 = "ALTER TABLE orders 
                 ADD COLUMN expected_arrival_start DATE DEFAULT NULL AFTER updated_at,
                 ADD COLUMN expected_arrival_end DATE DEFAULT NULL AFTER expected_arrival_start";
        
        if ($conn->query($sql1)) {
            echo "✓ Successfully added 'expected_arrival_start' and 'expected_arrival_end' columns\n";
        } else {
            throw new Exception("Failed to add columns: " . $conn->error);
        }
        
        // Create index for faster queries
        $sql2 = "CREATE INDEX idx_orders_arrival_dates ON orders (expected_arrival_start, expected_arrival_end)";
        
        if ($conn->query($sql2)) {
            echo "✓ Successfully created index for arrival dates\n";
        } else {
            if (strpos($conn->error, "Duplicate key name") !== false) {
                echo "✓ Index 'idx_orders_arrival_dates' already exists\n";
            } else {
                throw new Exception("Failed to create index: " . $conn->error);
            }
        }
        
        echo "\n✓ Migration completed successfully!\n";
    }
    
} catch (Exception $e) {
    echo "\n✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}

echo "\n" . str_repeat("=", 60) . "\n";
$conn->close();
?>
