# Stripe Integration - Quick Setup Checklist

## ✅ COMPLETED AUTOMATICALLY

- [x] Stripe PHP SDK installed via Composer
- [x] Configuration files created:
  - `config/stripe.php` - API configuration
  - `.env` - Your Stripe API keys
- [x] Payment integration files created:
  - `api/create-payment-intent.php` - Payment intent handler
  - `api/stripe-webhook.php` - Webhook handler
- [x] Payment form updated with Stripe Elements
- [x] Documentation created: `STRIPE_SETUP.md`

---

## 🔴 REQUIRED: DO THIS NOW

### 1. Update Your Database
Run this SQL in phpMyAdmin or MySQL command line:

```sql
ALTER TABLE orders ADD COLUMN payment_intent_id VARCHAR(255) NULL UNIQUE;
ALTER TABLE orders ADD COLUMN stripe_payment_status VARCHAR(50) NULL DEFAULT 'pending';
CREATE INDEX idx_payment_intent_id ON orders(payment_intent_id);
CREATE INDEX idx_stripe_payment_status ON orders(stripe_payment_status);
```

**Status**: ⏳ Awaiting your action

---

### 2. Configure Stripe Webhooks
1. Go to https://dashboard.stripe.com
2. Navigate to **Developers > Webhooks**
3. Add endpoint: `https://yoursite.com/Diplomna_rabota/api/stripe-webhook.php`
4. Select events: 
   - payment_intent.succeeded
   - payment_intent.payment_failed
   - payment_intent.canceled
5. Copy the webhook secret
6. Update `api/stripe-webhook.php` line 16 with your webhook secret:
   ```php
   $endpoint_secret = 'whsec_PASTE_YOUR_SECRET_HERE';
   ```

**Status**: ⏳ Awaiting your action

---

## 🟢 CURRENT STATUS

Your Stripe configuration:
- **Publishable Key**: `pk_live_51T4KmZDXo0KK7clOQJfbBlILcdtjXTUpa5EBo9E8K0uEAfuhY2L8U9jbCuYRGMtcrTdD1xGf8BnRuor82AYhU4BM00cRGX2fNG`
- **Secret Key**: `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`
- **Mode**: 🔴 LIVE (will charge real money)

---

## 💡 RECOMMENDED: Test Before Going Live

Switch to Stripe test keys to test safely:

1. In Stripe Dashboard, toggle **View test data**
2. Copy your **test** keys from the Developers page
3. Update `.env` with test keys:
   ```
   STRIPE_PUBLISHABLE_KEY=pk_test_YOUR_TEST_KEY
   STRIPE_SECRET_KEY=sk_test_YOUR_SECRET_TEST_KEY
   ```
4. Also update both keys in:
   - `config/stripe.php`
   - `payment.php` (near top of file after connection)

5. Test with these card numbers:
   - **Success**: 4242 4242 4242 4242
   - **Failure**: 4000 0000 0000 0002
   - **Expiry**: Any future date
   - **CVC**: Any 3 digits

**Status**: ⏳ Optional but recommended

---

## ⚠️ IMPORTANT NOTES

- **Your API keys are in LIVE mode** - they will charge real money immediately
- The `.env` file contains sensitive information - **NEVER commit to Git**
- Your keys are already added to `.gitignore` (you should verify this)
- The payment form now uses Stripe Elements (PCI Level 1 compliant)
- Card data is encrypted and never touches your server

---

## 📞 Need Help?

Read the full setup guide: `STRIPE_SETUP.md`

Key files:
- `config/stripe.php` - Stripe SDK configuration
- `api/create-payment-intent.php` - Creates payment intents
- `api/stripe-webhook.php` - Handles Stripe events
- `payment.php` - Updated payment form
