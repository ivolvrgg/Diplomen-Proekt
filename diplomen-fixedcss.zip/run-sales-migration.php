<?php
include 'config/db.php';

// Read and execute migration
$migration_sql = file_get_contents('sql/migration_add_sales.sql');
$statements = array_filter(array_map('trim', explode(';', $migration_sql)));

foreach ($statements as $statement) {
    if (!empty($statement)) {
        if ($conn->query($statement)) {
            echo "✓ Executed: " . substr($statement, 0, 50) . "...<br>";
        } else {
            echo "✗ Failed: " . $conn->error . "<br>";
        }
    }
}

echo "<br>Migration completed!";
?>
