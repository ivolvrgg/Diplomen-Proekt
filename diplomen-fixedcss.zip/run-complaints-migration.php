<?php
// Migration runner for complaints table
include 'config/db.php';

$sql = "CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    order_id INT,
    title VARCHAR(500) NOT NULL,
    description LONGTEXT NOT NULL,
    category ENUM('product_quality', 'shipping', 'customer_service', 'other') DEFAULT 'other',
    status ENUM('new', 'in_progress', 'resolved', 'closed') DEFAULT 'new',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_user_id (user_id)
)";

try {
    if ($conn->query($sql)) {
        echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin: 20px;'>";
        echo "<strong>✓ Success!</strong> The 'complaints' table has been created successfully.";
        echo "</div>";
    } else {
        if (strpos($conn->error, "already exists") !== false) {
            echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin: 20px;'>";
            echo "<strong>✓ Already Exists!</strong> The 'complaints' table already exists.";
            echo "</div>";
        } else {
            echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 4px; margin: 20px;'>";
            echo "<strong>✗ Error:</strong> " . $conn->error;
            echo "</div>";
        }
    }
} catch (Exception $e) {
    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 4px; margin: 20px;'>";
    echo "<strong>✗ Exception:</strong> " . $e->getMessage();
    echo "</div>";
}

$conn->close();
?>
