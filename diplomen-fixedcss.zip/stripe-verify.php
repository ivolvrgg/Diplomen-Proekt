<?php
/**
 * Stripe Integration Verification Script
 * Visit: /Diplomna_rabota/stripe-verify.php
 */

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Stripe Integration Verification</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .check { margin: 15px 0; padding: 10px; border-left: 4px solid #ddd; }
        .check.success { border-left-color: #4caf50; background: #e8f5e9; }
        .check.error { border-left-color: #f44336; background: #ffebee; }
        .check.warning { border-left-color: #ff9800; background: #fff3e0; }
        .status { font-weight: bold; margin: 0 0 5px 0; }
        .details { font-size: 12px; color: #666; margin-top: 5px; }
        code { background: #f5f5f5; padding: 2px 5px; border-radius: 3px; }
        h1 { color: #333; border-bottom: 2px solid #2196F3; padding-bottom: 10px; }
        .summary { margin-top: 30px; padding: 15px; background: #f0f0f0; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🔐 Stripe Integration Verification</h1>";

$checks = [];
$all_passed = true;

// 1. Check Stripe config file
$stripe_config_exists = file_exists(__DIR__ . '/config/stripe.php');
$checks[] = [
    'name' => 'Stripe Config File',
    'status' => $stripe_config_exists ? 'success' : 'error',
    'message' => $stripe_config_exists 
        ? 'config/stripe.php found ✓'
        : 'config/stripe.php NOT found ✗'
];
if (!$stripe_config_exists) $all_passed = false;

// 2. Check .env file
$env_exists = file_exists(__DIR__ . '/.env');
$checks[] = [
    'name' => '.env File',
    'status' => $env_exists ? 'success' : 'error',
    'message' => $env_exists 
        ? '.env found ✓'
        : '.env NOT found ✗'
];
if (!$env_exists) $all_passed = false;

// 3. Check Stripe PHP SDK
$vendor_dir = __DIR__ . '/vendor/stripe/stripe-php';
$sdk_exists = is_dir($vendor_dir);
$checks[] = [
    'name' => 'Stripe PHP SDK',
    'status' => $sdk_exists ? 'success' : 'error',
    'message' => $sdk_exists 
        ? 'Stripe SDK installed ✓'
        : 'Stripe SDK NOT installed ✗ (Run: php composer.phar require stripe/stripe-php)'
];
if (!$sdk_exists) $all_passed = false;

// 4. Check API key files
$create_intent = file_exists(__DIR__ . '/api/create-payment-intent.php');
$checks[] = [
    'name' => 'Payment Intent API',
    'status' => $create_intent ? 'success' : 'error',
    'message' => $create_intent 
        ? 'api/create-payment-intent.php found ✓'
        : 'api/create-payment-intent.php NOT found ✗'
];
if (!$create_intent) $all_passed = false;

// 5. Check webhook file
$webhook = file_exists(__DIR__ . '/api/stripe-webhook.php');
$checks[] = [
    'name' => 'Webhook Handler',
    'status' => $webhook ? 'success' : 'error',
    'message' => $webhook 
        ? 'api/stripe-webhook.php found ✓'
        : 'api/stripe-webhook.php NOT found ✗'
];
if (!$webhook) $all_passed = false;

// 6. Check payment.php updates
$payment_file = file_get_contents(__DIR__ . '/payment.php');
$has_stripe_js = strpos($payment_file, 'js.stripe.com/v3') !== false;
$checks[] = [
    'name' => 'Payment Form Update',
    'status' => $has_stripe_js ? 'success' : 'error',
    'message' => $has_stripe_js 
        ? 'payment.php includes Stripe ✓'
        : 'payment.php NOT updated ✗'
];
if (!$has_stripe_js) $all_passed = false;

// 7. Check database connection
include_once __DIR__ . '/config/db.php';
$db_connected = isset($conn) && $conn->connect_error === null;
$checks[] = [
    'name' => 'Database Connection',
    'status' => $db_connected ? 'success' : 'error',
    'message' => $db_connected 
        ? 'Database connected ✓'
        : 'Database connection FAILED ✗'
];
if (!$db_connected) $all_passed = false;

// 8. Check if orders table has Stripe columns
if ($db_connected) {
    $result = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_intent_id'");
    $has_stripe_columns = $result && $result->num_rows > 0;
    $checks[] = [
        'name' => 'Database Schema',
        'status' => $has_stripe_columns ? 'success' : 'warning',
        'message' => $has_stripe_columns 
            ? 'Stripe columns in database ✓'
            : 'Stripe columns NOT in database (Run the migration!) ⚠'
    ];
    if (!$has_stripe_columns) $all_passed = false;
}

// Display all checks
foreach ($checks as $check) {
    $class = "check " . $check['status'];
    echo "<div class=\"$class\">
        <div class=\"status\">[" . strtoupper($check['status']) . "] " . $check['name'] . "</div>
        <div class=\"details\">" . $check['message'] . "</div>
    </div>";
}

// Summary
echo "<div class=\"summary\">";
if ($all_passed) {
    echo "<h2 style='color: #4caf50; margin-top: 0;'>✓ All checks passed!</h2>";
    echo "<p>Your Stripe integration is ready to use. You still need to:</p>";
    echo "<ol>";
    echo "<li>Configure Stripe Webhooks in your dashboard</li>";
    echo "<li>Update webhook secret in api/stripe-webhook.php</li>";
    echo "<li>Test payments with test card numbers</li>";
    echo "</ol>";
    echo "<p><strong>Test Cards (when using test keys):</strong></p>";
    echo "<ul>";
    echo "<li><code>4242 4242 4242 4242</code> - Success</li>";
    echo "<li><code>4000 0000 0000 0002</code> - Failure</li>";
    echo "</ul>";
} else {
    echo "<h2 style='color: #f44336; margin-top: 0;'>✗ Some checks failed</h2>";
    echo "<p>Please review the errors above and fix them before proceeding.</p>";
}
echo "</div>";

echo "</body></html>";
?>
