<?php
$page_title = 'Вход - Dronche.BG';
$page_css = 'css/user_login.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// If user is already logged in, redirect to homepage
if (is_logged_in()) {
    header('Location: homepage.php');
    exit;
}
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Вход</h1>
                <form class="login-form" id="loginForm">
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароля</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="password" name="password" required placeholder="Въведи своя пароля" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            Помни ме
                        </label>
                    </div>
                    
                    <button type="submit" class="login-btn">Вход</button>
                </form>
                
                <div class="signup-link">
                    Нямаш акаунт? <a href="user_register.php">Регистрирай се тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        // Merge guest cart into logged-in user's cart
        function mergeGuestCart() {
            const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            if (guestCart.length === 0) return Promise.resolve();

            return fetch('api/cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ action: 'merge', items: guestCart })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.removeItem('guest_cart');
                    console.log('Guest cart merged successfully');
                }
            })
            .catch(error => {
                console.error('Error merging guest cart:', error);
            });
        }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const rememberMe = document.querySelector('[name="remember"]').checked;
            const btn = document.querySelector('.login-btn');
            
            // Clear previous errors
            document.getElementById('emailError').textContent = '';
            document.getElementById('passwordError').textContent = '';
            
            // Set loading state
            btn.disabled = true;
            btn.textContent = 'Моля изчакайте...';
            
            // Submit to server
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('remember', rememberMe ? '1' : '0');
            
            fetch('api/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Merge guest cart before redirect
                    mergeGuestCart().then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    // Re-enable button
                    btn.disabled = false;
                    btn.textContent = 'Вход';
                    
                    // Show error
                    const errorMsg = data.message || 'Възникна грешка';
                    const errorField = data.error_field;
                    
                    if (errorField === 'email') {
                        document.getElementById('emailError').textContent = errorMsg;
                    } else if (errorField === 'password') {
                        document.getElementById('passwordError').textContent = errorMsg;
                    } else {
                        alert(errorMsg);
                    }
                }
            })
            .catch(err => {
                // Re-enable button on error
                btn.disabled = false;
                btn.textContent = 'Вход';
                alert('Възникна грешка при вход: ' + err.message);
            });
        });

        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.getElementById(targetId);
                passwordInput.type = this.checked ? 'text' : 'password';
            });
        });
    </script>
</body>
</html>
