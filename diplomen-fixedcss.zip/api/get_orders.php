<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    // Get all orders with user and item details
    $query = "
        SELECT 
            o.id, o.user_id, o.status, o.subtotal, o.delivery_cost, o.vat, o.total, 
            o.payment_method, o.email, o.created_at, o.updated_at, o.delivery_method_id, o.delivery_office_id,
            u.fullname, u.phone, u.city,
            CASE 
                WHEN o.delivery_method_id = 1 THEN 'Courier'
                WHEN o.delivery_method_id = 2 THEN 'Speedy'
                WHEN o.delivery_method_id = 3 THEN 'Econt'
                ELSE 'Unknown'
            END as delivery_method,
            do.label as delivery_office,
            do.street as delivery_street,
            CONCAT(a.street, ', ', a.city, COALESCE(CONCAT(', Вх. ', a.entrance), ''), COALESCE(CONCAT(', Ап. ', a.apartment), '')) as shipping_address,
            GROUP_CONCAT(
                CONCAT(
                    '|', oi.product_id, '|', p.name, '|', oi.quantity, '|', oi.unit_price, '|'
                ) SEPARATOR '||'
            ) as order_items_str
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        LEFT JOIN order_items oi ON o.id = oi.order_id
        LEFT JOIN products p ON oi.product_id = p.id
        LEFT JOIN delivery_offices do ON o.delivery_office_id = do.id
        LEFT JOIN addresses a ON o.shipping_address_id = a.id
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ";

    $stmt = $conn->prepare($query);

    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        // Parse order items
        $items = [];
        if (!empty($row['order_items_str'])) {
            $itemsArray = explode('||', $row['order_items_str']);
            foreach ($itemsArray as $item) {
                if (!empty($item)) {
                    $parts = explode('|', $item);
                    $items[] = [
                        'product_id' => $parts[1],
                        'name' => $parts[2],
                        'quantity' => $parts[3],
                        'unit_price' => $parts[4]
                    ];
                }
            }
        }
        
        $row['items'] = $items;
        unset($row['order_items_str']);
        $orders[] = $row;
    }

    $stmt->close();

    echo json_encode([
        'success' => true,
        'orders' => $orders,
        'count' => count($orders)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
