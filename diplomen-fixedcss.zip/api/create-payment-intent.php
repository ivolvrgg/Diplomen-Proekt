<?php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
ob_clean();
header('Content-Type: application/json; charset=utf-8');

require_once '../config/db.php';
require_once '../config/stripe.php';
require_once '../includes/auth_check.php';

$response = ['success' => false, 'message' => '', 'checkout_url' => null];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }

    // Get checkout information
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $payment_method = trim($data['payment_method'] ?? 'card');
    $delivery_method = trim($data['delivery_method'] ?? '');
    
    if (empty($email)) {
        throw new Exception('Email is required');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Get user info
    $user_id = get_user_id();
    if ($user_id === 0) {
        $db_user_id = null;
    } else {
        $db_user_id = $user_id;
    }

    // Get cart items and calculate total
    $cart_items = [];
    $subtotal = 0;
    
    if ($db_user_id > 0) {
        // Logged-in user - get from database
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price 
                       FROM cart c 
                       JOIN products p ON c.product_id = p.id 
                       WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);

        if (!$cart_result || $cart_result->num_rows === 0) {
            throw new Exception('Cart is empty');
        }

        while ($item = $cart_result->fetch_assoc()) {
            $item_total = $item['price'] * $item['quantity'];
            $subtotal += $item_total;
            $cart_items[] = $item;
        }
    } else {
        // Guest user - get from request data
        $cart_data = $data['cart'] ?? [];
        if (empty($cart_data)) {
            throw new Exception('Cart is empty');
        }

        foreach ($cart_data as $item) {
            $product_id = intval($item['product_id'] ?? 0);
            $quantity = intval($item['quantity'] ?? 0);

            if ($product_id <= 0 || $quantity <= 0) {
                throw new Exception('Invalid cart item');
            }

            $product_query = "SELECT id, name, price FROM products WHERE id = $product_id";
            $product_result = $conn->query($product_query);

            if (!$product_result || $product_result->num_rows === 0) {
                throw new Exception('Product not found: ' . $product_id);
            }

            $product = $product_result->fetch_assoc();
            $item_total = $product['price'] * $quantity;
            $subtotal += $item_total;
            
            $cart_items[] = [
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity
            ];
        }
    }

    // Map delivery methods
    $delivery_mapping = [
        'courier' => ['id' => 1, 'cost' => 6.00],
        'speedy' => ['id' => 2, 'cost' => 4.99],
        'econt' => ['id' => 3, 'cost' => 3.99]
    ];

    if (!isset($delivery_mapping[$delivery_method])) {
        throw new Exception('Invalid delivery method');
    }

    $delivery_method_id = $delivery_mapping[$delivery_method]['id'];
    $delivery_cost = $delivery_mapping[$delivery_method]['cost'];

    // Calculate totals
    $vat = $subtotal * 0.20;
    $total = $subtotal + $vat + $delivery_cost;
    $amount = floatval($total);

    if ($amount <= 0) {
        throw new Exception('Invalid amount');
    }

    // Create Stripe Checkout Session (hosted payment page)
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'eur',
                'product_data' => [
                    'name' => 'Order from Dronche.BG',
                ],
                'unit_amount' => intval($amount * 100), // Amount in cents
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/Diplomna_rabota/order-confirmation.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/Diplomna_rabota/payment.php',
        'customer_email' => $email,
        'metadata' => [
            'user_id' => $db_user_id ?? 'guest',
            'email' => $email,
            'phone' => $phone,
            'delivery_method' => $delivery_method,
            'delivery_method_id' => (string)$delivery_method_id,
            'delivery_office_id' => (string)($data['delivery_office_id'] ?? ''),
            'delivery_cost' => (string)$delivery_cost,
        ],
    ]);

    // Store session metadata in database for reference (optional)
    // Metadata is already stored in the Stripe session, so we can retrieve it from there when needed


    $response['success'] = true;
    $response['checkout_url'] = $session->url;
    $response['message'] = 'Checkout session created successfully';

} catch (\Stripe\Exception\ApiErrorException $e) {
    $response['success'] = false;
    $response['message'] = 'Stripe API Error: ' . $e->getMessage();
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

ob_clean();
echo json_encode($response);
exit;
?>

