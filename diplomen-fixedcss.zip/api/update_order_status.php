<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    // Get order ID and new status
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : null;
    $status = isset($_POST['status']) ? trim($_POST['status']) : null;

    if (!$order_id || !$status) {
        echo json_encode(['success' => false, 'message' => 'Order ID and status are required']);
        exit;
    }

    // Validate status
    $valid_statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
    if (!in_array($status, $valid_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        exit;
    }

    // Verify order exists
    $checkStmt = $conn->prepare("SELECT id FROM orders WHERE id = ?");
    if (!$checkStmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $checkStmt->bind_param("i", $order_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows === 0) {
        $checkStmt->close();
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }

    $checkStmt->close();

    // Update order status
    $stmt = $conn->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");

    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->bind_param("si", $status, $order_id);

    if ($stmt->execute()) {
        $stmt->close();
        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
    } else {
        throw new Exception('Failed to update order: ' . $conn->error);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
