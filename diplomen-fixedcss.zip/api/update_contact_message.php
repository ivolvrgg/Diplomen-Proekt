<?php
header('Content-Type: application/json');
session_start();
if(!isset($_SESSION['is_admin'])){echo '{"success":false}';exit;}
$conn=new mysqli('localhost','root','','dron_db');
$id=isset($_POST['id'])?intval($_POST['id']):0;
$st=isset($_POST['status'])?$_POST['status']:'';
if(!$id||!$st){echo '{"success":false}';exit;}
$st=$conn->real_escape_string($st);
if($conn->query("UPDATE contact_messages SET status='$st',updated_at=NOW() WHERE id=$id")){echo '{"success":true}';}else{echo '{"success":false}';}
