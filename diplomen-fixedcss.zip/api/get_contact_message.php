<?php
ob_start();
header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['is_admin'])) {
    echo '{"success":false}';
    ob_end_flush();
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id) {
    echo '{"success":false}';
    ob_end_flush();
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'dron_db');
if ($conn->connect_error) {
    echo '{"success":false}';
    ob_end_flush();
    exit;
}

$result = $conn->query("SELECT * FROM contact_messages WHERE id=$id");
$message = null;
if ($result && $result->num_rows > 0) {
    $message = $result->fetch_assoc();
}
$conn->close();

echo json_encode(['success' => ($message ? true : false), 'message' => $message]);
ob_end_flush();
?>
