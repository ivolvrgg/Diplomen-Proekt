<?php
header('Content-Type: application/json');
require_once '../config/db.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не сте влезли']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Само POST заявки са позволени']);
    exit;
}

// Verify CSRF token
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
    exit;
}

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Невалидни данни']);
    exit;
}

$user_id = intval($_SESSION['user_id']);
$fullname = isset($data['fullname']) ? trim($data['fullname']) : '';
$email = isset($data['email']) ? trim($data['email']) : '';
$phone = isset($data['phone']) ? trim($data['phone']) : '';
$city = isset($data['city']) ? trim($data['city']) : '';

// Validate required fields
if (empty($fullname) || empty($email)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Име и Email са задължителни']);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Невалиден Email адрес']);
    exit;
}

// Check if email already exists for another user using prepared statement
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
$stmt->bind_param("si", $email, $user_id);
$stmt->execute();
$emailCheckResult = $stmt->get_result();
$stmt->close();

if ($emailCheckResult && $emailCheckResult->num_rows > 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Този Email адрес вече съществува']);
    exit;
}

// Update user profile using prepared statement
$stmt = $conn->prepare("UPDATE users SET fullname = ?, email = ?, phone = ?, city = ? WHERE id = ?");
$stmt->bind_param("ssssi", $fullname, $email, $phone, $city, $user_id);

if ($stmt->execute()) {
    $stmt->close();
    echo json_encode(['success' => true, 'message' => 'Профилът е обновен успешно']);
} else {
    $stmt->close();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Грешка при запазване: ' . $conn->error]);
}
?>
