<?php
header('Content-Type: application/json');
require_once '../config/db.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не сте влезли']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Само POST заявки са позволени']);
    exit;
}

// Check if file was uploaded
if (!isset($_FILES['profile_picture'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Файлът не е попълнен']);
    exit;
}

$file = $_FILES['profile_picture'];
$user_id = intval($_SESSION['user_id']);

// Check for upload errors
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Upload error: ' . $file['error']]);
    exit;
}

// Validate file size (max 2MB to be safe)
$maxSize = 2 * 1024 * 1024; // 2MB
if ($file['size'] > $maxSize) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Файлът е твърде голям (максимум 2MB)']);
    exit;
}

// Validate file type
$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedMimeTypes)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Позволени са само JPEG, PNG, GIF и WebP файлове. Намерено: ' . $mimeType]);
    exit;
}

// Read image data from file
$imageData = file_get_contents($file['tmp_name']);
if ($imageData === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Грешка при четене на файла']);
    exit;
}

// Convert to hex for safe storage in database (handles binary data properly)
$hexData = bin2hex($imageData);

// Update user profile picture in database
$stmt = $conn->prepare("UPDATE users SET profile_picture_data = UNHEX(?), profile_picture_mime_type = ? WHERE id = ?");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Грешка при подготовка: ' . $conn->error]);
    exit;
}

// Bind parameters - hex string, mime type, user id
$stmt->bind_param("ssi", $hexData, $mimeType, $user_id);

// Execute the update
if ($stmt->execute()) {
    $stmt->close();
    echo json_encode([
        'success' => true,
        'message' => 'Снимката е качена успешно',
        'profile_picture' => 'api/get_profile_picture.php?user_id=' . $user_id . '&t=' . time()
    ]);
} else {
    $error = $stmt->error;
    $stmt->close();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Грешка при обновяване: ' . $error]);
}
?>
