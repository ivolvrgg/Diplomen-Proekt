<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    // Get all users with their last delivery method
    $stmt = $conn->prepare("
        SELECT 
            u.id, 
            u.fullname, 
            u.email, 
            u.phone, 
            u.city, 
            u.is_active, 
            u.is_admin, 
            u.created_at, 
            u.updated_at,
            CASE 
                WHEN o.delivery_method_id = 1 THEN 'Courier'
                WHEN o.delivery_method_id = 2 THEN 'Speedy'
                WHEN o.delivery_method_id = 3 THEN 'Econt'
                ELSE 'Unknown'
            END as last_delivery_method,
            do.label as last_delivery_office
        FROM users u
        LEFT JOIN orders o ON u.id = o.user_id AND o.id = (
            SELECT MAX(id) FROM orders WHERE user_id = u.id
        )
        LEFT JOIN delivery_offices do ON o.delivery_office_id = do.id
        ORDER BY u.created_at DESC
    ");

    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    $stmt->close();

    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
