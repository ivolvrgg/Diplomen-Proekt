<?php
ob_start();
header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['is_admin'])) {
    echo '{"success":false}';
    ob_end_flush();
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'dron_db');
if ($conn->connect_error) {
    echo '{"success":false}';
    ob_end_flush();
    exit;
}

$query = "SELECT * FROM complaints";
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status = $conn->real_escape_string($_GET['status']);
    $query .= " WHERE status = '" . $status . "'";
}
$query .= " ORDER BY created_at DESC";

$result = $conn->query($query);
$complaints = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $complaints[] = $row;
    }
}
$conn->close();

echo json_encode(['success' => true, 'complaints' => $complaints]);
ob_end_flush();
?>
