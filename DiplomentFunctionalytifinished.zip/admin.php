<?php
session_start();
include 'includes/admin_check.php';
include 'config/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Product Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 28px;
        }

        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }

        .back-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        .back-btn:hover {
            background-color: #2980b9;
        }

        .header-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .welcome {
            font-size: 14px;
            margin-bottom: 5px;
        }

        .section {
            background-color: white;
            padding: 25px;
            border-radius: 5px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-row-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #2980b9;
        }

        button.delete-btn {
            background-color: #e74c3c;
            padding: 8px 15px;
            font-size: 14px;
            margin: 0;
        }

        button.delete-btn:hover {
            background-color: #c0392b;
        }

        .products-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .products-table th {
            background-color: #34495e;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: bold;
        }

        .products-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        .products-table tr:hover {
            background-color: #f9f9f9;
        }

        .products-table tr:nth-child(even) {
            background-color: #f0f0f0;
        }

        .product-name {
            font-weight: bold;
            color: #2c3e50;
        }

        .product-price {
            color: #27ae60;
            font-weight: bold;
        }

        .product-stock {
            text-align: center;
        }

        .product-stock.low {
            color: #e74c3c;
            font-weight: bold;
        }

        .product-stock.adequate {
            color: #27ae60;
        }

        .action-buttons {
            white-space: nowrap;
        }

        .message {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .message.info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .no-products {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-size: 16px;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #3498db;
        }

        .tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 2px solid #ddd;
        }

        .tab {
            padding: 12px 20px;
            cursor: pointer;
            background-color: transparent;
            border: none;
            font-size: 16px;
            border-bottom: 3px solid transparent;
            color: #7f8c8d;
            transition: all 0.3s;
            margin: 0;
        }

        .tab.active {
            color: #3498db;
            border-bottom-color: #3498db;
        }

        .tab:hover {
            color: #2980b9;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        @media (max-width: 768px) {
            .form-row,
            .form-row-3 {
                grid-template-columns: 1fr;
            }

            .products-table {
                font-size: 12px;
            }

            .products-table th,
            .products-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Admin Panel</h1>
                <div class="welcome">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?> (<?php echo htmlspecialchars($_SESSION['user_email']); ?>)</div>
            </div>
            <div class="header-buttons">
                <button class="back-btn" onclick="window.location.href='homepage.php'">← Back to Website</button>
                <button class="logout-btn" onclick="logout()">Logout</button>
            </div>
        </div>

        <div id="message-container"></div>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab active" onclick="switchTab('add-product')">Add Product</button>
            <button class="tab" onclick="switchTab('manage-products')">Manage Products</button>
            <button class="tab" onclick="switchTab('manage-orders')">Manage Orders</button>
            <button class="tab" onclick="switchTab('manage-users')">Manage Users</button>
        </div>

        <!-- Add Product Tab -->
        <div id="add-product" class="tab-content active">
            <div class="section">
                <h2>Add New Product</h2>
                <form id="add-product-form" onsubmit="submitAddProduct(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="category_id">Category *</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Select Category</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="product_name">Product Name *</label>
                            <input type="text" id="product_name" name="name" required placeholder="Enter product name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="product_description">Description</label>
                        <textarea id="product_description" name="description" placeholder="Enter product description"></textarea>
                    </div>

                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="product_price">Price ($) *</label>
                            <input type="number" id="product_price" name="price" step="0.01" min="0.01" required placeholder="0.00">
                        </div>
                        <div class="form-group">
                            <label for="product_stock">Stock *</label>
                            <input type="number" id="product_stock" name="stock" min="0" required placeholder="0">
                        </div>
                    </div>

                    <h3 style="margin-top: 20px; margin-bottom: 15px; color: #2c3e50;">Product Images</h3>
                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="image_1">Image 1 URL</label>
                            <input type="url" id="image_1" name="image_1" placeholder="https://example.com/image1.jpg">
                        </div>
                        <div class="form-group">
                            <label for="image_2">Image 2 URL</label>
                            <input type="url" id="image_2" name="image_2" placeholder="https://example.com/image2.jpg">
                        </div>
                        <div class="form-group">
                            <label for="image_3">Image 3 URL</label>
                            <input type="url" id="image_3" name="image_3" placeholder="https://example.com/image3.jpg">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="image_4">Image 4 URL</label>
                            <input type="url" id="image_4" name="image_4" placeholder="https://example.com/image4.jpg">
                        </div>
                        <div class="form-group">
                            <label for="video_url">Video URL</label>
                            <input type="url" id="video_url" name="video_url" placeholder="https://example.com/video.mp4">
                        </div>
                    </div>

                    <button type="submit" style="width: 100%; margin-top: 20px;">Add Product</button>
                </form>
            </div>
        </div>

        <!-- Manage Products Tab -->
        <div id="manage-products" class="tab-content">
            <div class="section">
                <h2>Manage Existing Products</h2>
                <div id="edit-product-form-container" style="display:none; margin-bottom: 30px; padding: 20px; background-color: #f9f9f9; border: 2px solid #3498db; border-radius: 5px;">
                    <h3 style="margin-top: 0;">Edit Product</h3>
                    <form id="edit-product-form" onsubmit="submitEditProduct(event)">
                        <input type="hidden" id="edit_product_id" name="product_id">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="edit_category_id">Category *</label>
                                <select id="edit_category_id" name="category_id" required>
                                    <option value="">Select Category</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_product_name">Product Name *</label>
                                <input type="text" id="edit_product_name" name="name" required placeholder="Enter product name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="edit_product_description">Description</label>
                            <textarea id="edit_product_description" name="description" placeholder="Enter product description"></textarea>
                        </div>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label for="edit_product_price">Price ($) *</label>
                                <input type="number" id="edit_product_price" name="price" step="0.01" min="0.01" required placeholder="0.00">
                            </div>
                            <div class="form-group">
                                <label for="edit_product_stock">Stock *</label>
                                <input type="number" id="edit_product_stock" name="stock" min="0" required placeholder="0">
                            </div>
                        </div>
                        <h3 style="margin-top: 20px; margin-bottom: 15px; color: #2c3e50;">Product Images</h3>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label for="edit_image_1">Image 1 URL</label>
                                <input type="url" id="edit_image_1" name="image_1" placeholder="https://example.com/image1.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_image_2">Image 2 URL</label>
                                <input type="url" id="edit_image_2" name="image_2" placeholder="https://example.com/image2.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_image_3">Image 3 URL</label>
                                <input type="url" id="edit_image_3" name="image_3" placeholder="https://example.com/image3.jpg">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="edit_image_4">Image 4 URL</label>
                                <input type="url" id="edit_image_4" name="image_4" placeholder="https://example.com/image4.jpg">
                            </div>
                            <div class="form-group">
                                <label for="edit_video_url">Video URL</label>
                                <input type="url" id="edit_video_url" name="video_url" placeholder="https://example.com/video.mp4">
                            </div>
                        </div>
                        <button type="submit" style="width: 100%; margin-top: 20px;">Save Changes</button>
                        <button type="button" onclick="cancelEditProduct()" style="width: 100%; margin-top: 10px; background-color: #95a5a6;">Cancel</button>
                    </form>
                </div>
                <div id="products-container" class="loading">Loading products...</div>
            </div>
        </div>

        <!-- Manage Users Tab -->
        <div id="manage-users" class="tab-content">
            <div class="section">
                <h2>Manage Users</h2>
                <div id="users-container" class="loading">Loading users...</div>
            </div>
        </div>

        <!-- Manage Orders Tab -->
        <div id="manage-orders" class="tab-content">
            <div class="section">
                <h2>Manage Orders</h2>
                <div id="orders-container" class="loading">Loading orders...</div>
            </div>
        </div>
    </div>

    <script>
        let currentPage = 1;
        const productsPerPage = 50;

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadCategories();
            loadProducts();
            loadUsers();
            loadOrders();
        });

        function showMessage(message, type = 'info') {
            const container = document.getElementById('message-container');
            const messageEl = document.createElement('div');
            messageEl.className = `message ${type}`;
            messageEl.textContent = message;
            container.innerHTML = '';
            container.appendChild(messageEl);
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                messageEl.style.display = 'none';
            }, 5000);
        }

        function switchTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(el => {
                el.classList.remove('active');
            });

            // Show selected tab
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }

        function loadCategories() {
            fetch('api/get_categories.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const select = document.getElementById('category_id');
                        const editSelect = document.getElementById('edit_category_id');
                        data.categories.forEach(category => {
                            const option1 = document.createElement('option');
                            option1.value = category.id;
                            option1.textContent = category.name;
                            select.appendChild(option1);
                            
                            const option2 = document.createElement('option');
                            option2.value = category.id;
                            option2.textContent = category.name;
                            editSelect.appendChild(option2);
                        });
                    } else {
                        showMessage('Error loading categories: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                });
        }

        function loadProducts() {
            const container = document.getElementById('products-container');
            container.innerHTML = '<div class="loading">Loading products...</div>';

            fetch('api/get_products_admin.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.products.length === 0) {
                            container.innerHTML = '<div class="no-products">No products found. Add your first product using the Add Product tab.</div>';
                            return;
                        }

                        let html = '<table class="products-table"><thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Created</th><th>Actions</th></tr></thead><tbody>';
                        
                        data.products.forEach(product => {
                            const stockClass = product.stock < 5 ? 'low' : 'adequate';
                            const createdDate = new Date(product.created_at).toLocaleDateString();
                            
                            html += `<tr>
                                <td>${product.id}</td>
                                <td class="product-name">${htmlEscape(product.name)}</td>
                                <td>${htmlEscape(product.category_name || 'N/A')}</td>
                                <td class="product-price">$${parseFloat(product.price).toFixed(2)}</td>
                                <td class="product-stock ${stockClass}">${product.stock}</td>
                                <td>${createdDate}</td>
                                <td class="action-buttons">
                                    <button onclick="editProduct(${product.id}, ${htmlEscape(JSON.stringify(product)).replace(/'/g, "&apos;")})" style="background-color: #27ae60; margin-right: 5px;">Edit</button>
                                    <button class="delete-btn" onclick="deleteProduct(${product.id}, '${htmlEscape(product.name).replace(/'/g, "\\'")}')">Delete</button>
                                </td>
                            </tr>`;
                        });

                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Error loading products: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Error loading products</div>';
                });
        }

        function submitAddProduct(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('add-product-form'));
            
            fetch('api/add_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Product added successfully!', 'success');
                    document.getElementById('add-product-form').reset();
                    loadProducts();
                    // Switch to manage products tab
                    setTimeout(() => {
                        document.getElementById('manage-products').classList.add('active');
                        document.getElementById('add-product').classList.remove('active');
                        document.querySelectorAll('.tab')[1].classList.add('active');
                        document.querySelectorAll('.tab')[0].classList.remove('active');
                    }, 1000);
                } else {
                    showMessage('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Error: ' + error.message, 'error');
            });
        }

        function deleteProduct(productId, productName) {
            if (confirm(`Are you sure you want to delete "${productName}"? This action cannot be undone.`)) {
                const formData = new FormData();
                formData.append('product_id', productId);

                fetch('api/delete_product.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Product deleted successfully!', 'success');
                        loadProducts();
                    } else {
                        showMessage('Error: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                });
            }
        }

        function loadOrders() {
            const container = document.getElementById('orders-container');
            container.innerHTML = '<div class="loading">Loading orders...</div>';

            fetch('api/get_orders.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.orders.length === 0) {
                            container.innerHTML = '<div class="no-products">No orders found.</div>';
                            return;
                        }

                        let html = '<table class="products-table"><thead><tr><th>ID</th><th>Customer</th><th>Email</th><th>Items</th><th>Amount</th><th>Delivery</th><th>Status</th><th>Payment</th><th>Created</th><th>Actions</th></tr></thead><tbody>';
                        
                        const statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
                        const statusColors = {
                            'pending': '#f39c12',
                            'paid': '#27ae60',
                            'shipped': '#3498db',
                            'delivered': '#16a085',
                            'cancelled': '#e74c3c'
                        };

                        data.orders.forEach(order => {
                            const createdDate = new Date(order.created_at).toLocaleDateString();
                            const totalAmount = parseFloat(order.total).toFixed(2);
                            const itemCount = order.items.length;
                            const statusColor = statusColors[order.status] || '#95a5a6';
                            
                            // Build delivery info
                            let deliveryInfo = order.delivery_method || 'Unknown';
                            if (order.delivery_office) {
                                deliveryInfo += '<br/><small>' + htmlEscape(order.delivery_office) + '</small>';
                            }
                            
                            let statusSelect = '<select onchange="updateOrderStatus(' + order.id + ', this.value)" style="padding: 5px; border: 1px solid #ddd; border-radius: 3px;">';
                            statuses.forEach(st => {
                                statusSelect += '<option value="' + st + '" ' + (st === order.status ? 'selected' : '') + '>' + st.charAt(0).toUpperCase() + st.slice(1) + '</option>';
                            });
                            statusSelect += '</select>';

                            html += `<tr>
                                <td>${order.id}</td>
                                <td>${htmlEscape(order.fullname || 'Unknown')}</td>
                                <td>${htmlEscape(order.email)}</td>
                                <td>${itemCount} item(s)</td>
                                <td style="color: #27ae60; font-weight: bold;">$${totalAmount}</td>
                                <td>${deliveryInfo}</td>
                                <td>${statusSelect}</td>
                                <td>${order.payment_method === 'card' ? 'Card' : 'Cash on Delivery'}</td>
                                <td>${createdDate}</td>
                                <td class="action-buttons">
                                    <button onclick="viewOrderDetails(${order.id}, ${htmlEscape(JSON.stringify(order)).replace(/'/g, "&apos;")})" style="background-color: #3498db; padding: 8px 12px; font-size: 12px;">View Details</button>
                                </td>
                            </tr>`;
                        });

                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Error loading orders: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Error loading orders</div>';
                });
        }

        function updateOrderStatus(orderId, newStatus) {
            if (confirm('Update order #' + orderId + ' status to "' + newStatus + '"?')) {
                const formData = new FormData();
                formData.append('order_id', orderId);
                formData.append('status', newStatus);

                fetch('api/update_order_status.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Order status updated successfully!', 'success');
                        loadOrders();
                    } else {
                        showMessage('Error: ' + data.message, 'error');
                        loadOrders(); // Reload to reset select
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                    loadOrders(); // Reload to reset select
                });
            } else {
                loadOrders(); // Reload to reset select if cancelled
            }
        }

        function viewOrderDetails(orderId, orderData) {
            const order = typeof orderData === 'string' ? JSON.parse(orderData) : orderData;
            
            let detailsHTML = '<h3>Order #' + order.id + ' Details</h3>';
            detailsHTML += '<p><strong>Customer:</strong> ' + htmlEscape(order.fullname || 'Unknown') + '</p>';
            detailsHTML += '<p><strong>Email:</strong> ' + htmlEscape(order.email) + '</p>';
            detailsHTML += '<p><strong>Phone:</strong> ' + htmlEscape(order.phone || 'N/A') + '</p>';
            detailsHTML += '<p><strong>City:</strong> ' + htmlEscape(order.city || 'N/A') + '</p>';
            detailsHTML += '<p><strong>Status:</strong> ' + order.status.charAt(0).toUpperCase() + order.status.slice(1) + '</p>';
            detailsHTML += '<p><strong>Payment Method:</strong> ' + (order.payment_method === 'card' ? 'Card' : 'Cash on Delivery') + '</p>';
            detailsHTML += '<p><strong>Order Date:</strong> ' + new Date(order.created_at).toLocaleString() + '</p>';
            
            detailsHTML += '<h4>Items:</h4><ul>';
            order.items.forEach(item => {
                detailsHTML += '<li>' + htmlEscape(item.name) + ' - Qty: ' + item.quantity + ' × $' + parseFloat(item.unit_price).toFixed(2) + '</li>';
            });
            detailsHTML += '</ul>';
            
            detailsHTML += '<h4>Pricing:</h4>';
            detailsHTML += '<p>Subtotal: $' + parseFloat(order.subtotal).toFixed(2) + '</p>';
            detailsHTML += '<p>VAT: $' + parseFloat(order.vat).toFixed(2) + '</p>';
            detailsHTML += '<p>Delivery: $' + parseFloat(order.delivery_cost).toFixed(2) + '</p>';
            detailsHTML += '<p><strong>Total: $' + parseFloat(order.total).toFixed(2) + '</strong></p>';
            
            alert(detailsHTML.replace(/<[^>]*>/g, '\n'));
        }

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'api/logout.php';
            }
        }

        function htmlEscape(str) {
            return str
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function editProduct(productId, productData) {
            // Parse product data
            const product = typeof productData === 'string' ? JSON.parse(productData) : productData;
            
            // Populate form with product data
            document.getElementById('edit_product_id').value = product.id;
            document.getElementById('edit_category_id').value = product.category_id;
            document.getElementById('edit_product_name').value = product.name;
            document.getElementById('edit_product_description').value = product.description || '';
            document.getElementById('edit_product_price').value = product.price;
            document.getElementById('edit_product_stock').value = product.stock;
            document.getElementById('edit_image_1').value = product.image_1 || '';
            document.getElementById('edit_image_2').value = product.image_2 || '';
            document.getElementById('edit_image_3').value = product.image_3 || '';
            document.getElementById('edit_image_4').value = product.image_4 || '';
            document.getElementById('edit_video_url').value = product.video_url || '';
            
            // Show edit form
            document.getElementById('edit-product-form-container').style.display = 'block';
            
            // Scroll to form
            document.getElementById('edit-product-form-container').scrollIntoView({ behavior: 'smooth' });
        }

        function submitEditProduct(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('edit-product-form'));
            
            fetch('api/update_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Product updated successfully!', 'success');
                    cancelEditProduct();
                    loadProducts();
                } else {
                    showMessage('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Error: ' + error.message, 'error');
            });
        }

        function cancelEditProduct() {
            document.getElementById('edit-product-form-container').style.display = 'none';
            document.getElementById('edit-product-form').reset();
        }

        function loadUsers() {
            const container = document.getElementById('users-container');
            container.innerHTML = '<div class="loading">Loading users...</div>';

            fetch('api/get_users.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.users.length === 0) {
                            container.innerHTML = '<div class="no-products">No users found.</div>';
                            return;
                        }

                        let html = '<table class="products-table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Last Shipment</th><th>Admin</th><th>Active</th><th>Joined</th><th>Actions</th></tr></thead><tbody>';
                        
                        data.users.forEach(user => {
                            const joinedDate = new Date(user.created_at).toLocaleDateString();
                            const adminBadge = user.is_admin ? '<span style="color: #27ae60; font-weight: bold;">Yes</span>' : '<span style="color: #e74c3c;">No</span>';
                            const activeBadge = user.is_active ? '<span style="color: #27ae60; font-weight: bold;">Yes</span>' : '<span style="color: #e74c3c;">No</span>';
                            
                            // Get delivery method and office name
                            let shipmentInfo = '-';
                            if (user.last_delivery_method) {
                                shipmentInfo = user.last_delivery_method;
                                if (user.last_delivery_office) {
                                    shipmentInfo += '<br/><small>' + htmlEscape(user.last_delivery_office) + '</small>';
                                }
                            }
                            
                            html += `<tr>
                                <td>${user.id}</td>
                                <td class="product-name">${htmlEscape(user.fullname)}</td>
                                <td>${htmlEscape(user.email)}</td>
                                <td>${htmlEscape(user.phone || '-')}</td>
                                <td>${htmlEscape(user.city || '-')}</td>
                                <td>${shipmentInfo}</td>
                                <td>${adminBadge}</td>
                                <td>${activeBadge}</td>
                                <td>${joinedDate}</td>
                                <td class="action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <button onclick="toggleUserAdmin(${user.id}, ${user.is_admin})" style="background-color: #f39c12; padding: 8px 12px; font-size: 12px;">${user.is_admin ? 'Revoke Admin' : 'Make Admin'}</button>
                                    <button onclick="toggleUserActive(${user.id}, ${user.is_active})" style="background-color: #3498db; padding: 8px 12px; font-size: 12px;">${user.is_active ? 'Deactivate' : 'Activate'}</button>
                                    <button class="delete-btn" onclick="deleteUser(${user.id}, '${htmlEscape(user.fullname).replace(/'/g, "\\'")}')">Delete</button>
                                </td>
                            </tr>`;
                        });

                        html += '</tbody></table>';
                        container.innerHTML = html;
                    } else {
                        showMessage('Error loading users: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                    container.innerHTML = '<div class="no-products">Error loading users</div>';
                });
        }

        function toggleUserAdmin(userId, currentAdminStatus) {
            if (confirm(`Are you sure you want to ${currentAdminStatus ? 'revoke' : 'grant'} admin privileges?`)) {
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('is_admin', currentAdminStatus ? 0 : 1);

                fetch('api/update_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message, 'success');
                        loadUsers();
                    } else {
                        showMessage('Error: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                });
            }
        }

        function toggleUserActive(userId, currentActiveStatus) {
            if (confirm(`Are you sure you want to ${currentActiveStatus ? 'deactivate' : 'activate'} this user?`)) {
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('is_active', currentActiveStatus ? 0 : 1);

                fetch('api/update_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message, 'success');
                        loadUsers();
                    } else {
                        showMessage('Error: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                });
            }
        }

        function deleteUser(userId, userName) {
            if (confirm(`Are you sure you want to delete user "${userName}"? This action cannot be undone and will remove all their data.`)) {
                const formData = new FormData();
                formData.append('user_id', userId);

                fetch('api/delete_user.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('User deleted successfully!', 'success');
                        loadUsers();
                    } else {
                        showMessage('Error: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    showMessage('Error: ' + error.message, 'error');
                });
            }
        }
    </script>
</body>
</html>
