<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']) && intval($_SESSION['user_id']) > 0;
    }
}

// Get current user ID
if (!function_exists('get_user_id')) {
    function get_user_id() {
        return isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
    }
}

// Get current user name
if (!function_exists('get_user_name')) {
    function get_user_name() {
        return isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
    }
}

// Get current user email
if (!function_exists('get_user_email')) {
    function get_user_email() {
        return isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
    }
}

// Require login - redirect if not logged in
if (!function_exists('require_login')) {
    function require_login() {
        if (!is_logged_in()) {
            header('Location: user_login.php');
            exit;
        }
    }
}

// Redirect if already logged in
if (!function_exists('require_logout')) {
    function require_logout() {
        if (is_logged_in()) {
            header('Location: homepage.php');
            exit;
        }
    }
}
?>
