<?php
$page_title = 'Плащане | Dronche.BG';
$page_css = 'payment.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="payment-container">
        <div class="container">
            <h1 class="section-title">Плащане</h1>
            
            <div class="payment-content">
                <div class="order-summary">
                    <h2>Вашата поръчка</h2>
                    <div class="order-items" id="order-items">
                        <?php
                        $subtotal = 0;
                        $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                        
                        if ($user_id === 0) {
                            // Guest user - cart will be loaded from localStorage via JavaScript
                            if (!isset($_SESSION['guest_id'])) {
                                $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
                            }
                            echo '<p><em>Зареждане на количката...</em></p>';
                        } else {
                            // Logged-in user - fetch from database
                            $db_user_id = $user_id;
                            
                            $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price 
                                          FROM cart c 
                                          JOIN products p ON c.product_id = p.id 
                                          WHERE c.user_id = " . intval($db_user_id);
                            $cart_result = $conn->query($cart_query);
                            
                            if (!$cart_result) {
                                echo '<p style="color: red;">Възникна грешка при зареждане на количката. Грешка: ' . htmlspecialchars($conn->error) . '</p>';
                            } else if ($cart_result && $cart_result->num_rows > 0) {
                                while ($item = $cart_result->fetch_assoc()) {
                                    $item_total = $item['price'] * $item['quantity'];
                                    $subtotal += $item_total;
                            ?>
                            <div class="order-item">
                                <span class="item-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                <span class="item-price"><?php echo number_format($item['price'] * $item['quantity'], 2); ?> €</span>
                            </div>
                            <?php
                                }
                            } else {
                                echo '<p>Вашата количка е празна. <a href="cart.php">Назад към количката</a></p>';
                            }
                        }
                        ?>
                    </div>
                    <div class="order-total">
                        <span>Подсума:</span>
                        <span class="subtotal-price"><?php echo number_format($subtotal, 2); ?> €</span>
                    </div>
                    <div class="order-total" style="margin-top: 0.5rem;">
                        <span>Доставка:</span>
                        <span class="delivery-price">6.00 €</span>
                    </div>
                    <div class="order-total" style="margin-top: 0.5rem;">
                        <span>ДДС (20%):</span>
                        <span class="vat-price"><?php echo number_format($subtotal * 0.20, 2); ?> €</span>
                    </div>
                    <div class="order-total" style="margin-top: 1rem; border-top: 2px solid #ffd700; padding-top: 1rem;">
                        <span><strong>ОБЩО:</strong></span>
                        <span class="total-price"><strong><?php echo number_format(($subtotal * 1.20) + 6, 2); ?> €</strong></span>
                    </div>
                </div>

                <form class="payment-form" id="payment-form">
                    <h2>Метод на плащане</h2>
                    
                    <div class="payment-methods">
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="card" checked>
                            <span class="payment-label">Плащане с карта</span>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="cod">
                            <span class="payment-label">Наложен платеж</span>
                        </label>
                    </div>

                    <h2 style="margin-top: 2rem;">Начин на доставка</h2>
                    
                    <div class="delivery-methods">
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="courier" class="delivery-radio">
                                <span class="delivery-label">До адрес</span>
                            </label>
                            <div class="address-fields" style="display: none;">
                                <div class="address-field">
                                    <label for="city-input">Град</label>
                                    <input type="text" id="city-input" name="city" class="address-input" placeholder="Град">
                                </div>

                                <div class="address-field">
                                    <label for="street-input">Улица</label>
                                    <input type="text" id="street-input" name="street" class="address-input" placeholder="Улица">
                                </div>

                                <div class="address-field">
                                    <label for="block-input">Блок</label>
                                    <input type="text" id="block-input" name="block" class="address-input" placeholder="Номер на блок">
                                </div>

                                <div class="address-field">
                                    <label for="entrance-input">Вход</label>
                                    <input type="text" id="entrance-input" name="entrance" class="address-input" placeholder="Вход (А, Б, В и т.н.)">
                                </div>

                                <div class="address-field">
                                    <label for="apartment-input">Апартамент</label>
                                    <input type="text" id="apartment-input" name="apartment" class="address-input" placeholder="Номер на апартамент">
                                </div>
                            </div>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="speedy" class="delivery-radio">
                                <span class="delivery-label">Speedy</span>
                            </label>
                            <div id="speedy-offices" class="delivery-select-wrapper" style="display: none;">
                                <input type="text" class="delivery-search" placeholder="Избери офис...">
                                <div class="delivery-dropdown">
                                    <?php
                                    $offices_query = "SELECT id, label FROM delivery_offices WHERE delivery_method_id = 2 AND is_active = 1 ORDER BY label";
                                    $offices_result = $conn->query($offices_query);
                                    if ($offices_result && $offices_result->num_rows > 0) {
                                        while ($office = $offices_result->fetch_assoc()) {
                                            echo '<div class="delivery-option-item" data-office-id="' . intval($office['id']) . '">' . htmlspecialchars($office['label']) . '</div>';
                                        }
                                    }
                                    ?>
                                </div>
                                <input type="hidden" class="delivery-select-value" name="delivery-office-speedy" id="delivery-office-speedy">
                                <input type="hidden" name="delivery-office-id-speedy" id="delivery-office-id-speedy">
                            </div>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="econt" class="delivery-radio">
                                <span class="delivery-label">eKont</span>
                            </label>
                            <div id="econt-offices" class="delivery-select-wrapper" style="display: none;">
                                <input type="text" class="delivery-search" placeholder="Избери офис...">
                                <div class="delivery-dropdown">
                                    <?php
                                    $offices_query = "SELECT id, label FROM delivery_offices WHERE delivery_method_id = 3 AND is_active = 1 ORDER BY label";
                                    $offices_result = $conn->query($offices_query);
                                    if ($offices_result && $offices_result->num_rows > 0) {
                                        while ($office = $offices_result->fetch_assoc()) {
                                            echo '<div class="delivery-option-item" data-office-id="' . intval($office['id']) . '">' . htmlspecialchars($office['label']) . '</div>';
                                        }
                                    }
                                    ?>
                                </div>
                                <input type="hidden" class="delivery-select-value" name="delivery-office-econt" id="delivery-office-econt">
                                <input type="hidden" name="delivery-office-id-econt" id="delivery-office-id-econt">
                            </div>
                        </div>
                    </div>

                    <h2 style="margin-top: 2rem;">Данни за плащане</h2>
                    
                    <div id="card-payment-section">
                        <div class="form-group">
                            <label for="card-name">Име на картата</label>
                            <input type="text" id="card-name" name="card_name" placeholder="Име и фамилия">
                        </div>
                        
                        <div class="form-group">
                            <label for="card-number">Номер на карта</label>
                            <input type="text" id="card-number" name="card_number" placeholder="1234 5678 9012 3456">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="expiry-date">Валидна до</label>
                                <input type="text" id="expiry-date" name="expiry_date" placeholder="ММ/ГГ">
                            </div>
                            
                            <div class="form-group">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" name="cvv" placeholder="123">
                            </div>
                        </div>
                    </div>

                    <h2 style="margin-top: 2rem;">Контактни данни</h2>
                    
                    <div class="form-group">
                        <label for="phone">Телефонен номер *</label>
                        <input type="tel" id="phone" name="phone" placeholder="+359 123 456 789" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Имейл за потвърждение <?php echo !is_logged_in() ? '*' : ''; ?></label>
                        <?php if (!is_logged_in()): ?>
                        <input type="email" id="email" name="email" placeholder="вашият@имейл.com" required>
                        <?php else: ?>
                        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>" disabled style="background-color: #f0f0f0; cursor: not-allowed;">
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="btn-pay" id="submit-btn">Завърши поръчка</button>
                    <div id="form-message" style="margin-top: 1rem; display: none;"></div>
                </form>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    <script>
        const form = document.getElementById('payment-form');
        const messageDiv = document.getElementById('form-message');
        const submitBtn = document.getElementById('submit-btn');

        // Load guest cart from localStorage if not logged in
        document.addEventListener('DOMContentLoaded', function() {
            const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
            
            if (!isLoggedIn) {
                const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                
                if (guestCart.length > 0) {
                    let html = '';
                    let subtotal = 0;
                    let pendingRequests = 0;
                    let completedRequests = 0;
                    
                    // Check if items have all required fields, fetch product details if missing
                    const promises = guestCart.map(item => {
                        // If price or name is missing, fetch from API
                        if (!item.price || !item.name) {
                            pendingRequests++;
                            return fetch(`api/cart.php?action=get_product&product_id=${item.product_id}`)
                                .then(r => r.json())
                                .then(data => {
                                    if (data.success && data.product) {
                                        item.name = item.name || data.product.name;
                                        item.price = item.price || parseFloat(data.product.price);
                                    }
                                    completedRequests++;
                                    return item;
                                })
                                .catch(err => {
                                    console.error('Error loading product:', err);
                                    completedRequests++;
                                    return item;
                                });
                        } else {
                            return Promise.resolve(item);
                        }
                    });
                    
                    Promise.all(promises).then(cartItems => {
                        let html = '';
                        let subtotal = 0;
                        
                        cartItems.forEach(item => {
                            const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
                            subtotal += itemTotal;
                            html += `
                                <div class="order-item">
                                    <span class="item-name">${item.name || 'Неизвестен продукт'}</span>
                                    <span class="item-price">${(itemTotal).toFixed(2)} €</span>
                                </div>
                            `;
                        });
                        
                        document.getElementById('order-items').innerHTML = html;
                        
                        // Update totals
                        const vat = (subtotal * 0.20).toFixed(2);
                        const total = (subtotal * 1.20 + 6).toFixed(2);
                        
                        document.querySelector('.subtotal-price').textContent = subtotal.toFixed(2) + ' €';
                        document.querySelector('.vat-price').textContent = vat + ' €';
                        document.querySelector('.total-price').textContent = total + ' €';
                    });
                } else {
                    document.getElementById('order-items').innerHTML = '<p>Вашата количка е празна. <a href="cart.php">Назад към количката</a></p>';
                }
            }
        });

        // Payment method toggle
        document.querySelectorAll('input[name="payment-method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const cardSection = document.getElementById('card-payment-section');
                if (this.value === 'card') {
                    cardSection.style.display = 'block';
                    document.getElementById('card-name').required = true;
                    document.getElementById('card-number').required = true;
                    document.getElementById('expiry-date').required = true;
                    document.getElementById('cvv').required = true;
                } else {
                    cardSection.style.display = 'none';
                    document.getElementById('card-name').required = false;
                    document.getElementById('card-number').required = false;
                    document.getElementById('expiry-date').required = false;
                    document.getElementById('cvv').required = false;
                }
            });
        });

        // Delivery method toggle
        document.querySelectorAll('.delivery-radio').forEach(radio => {
            radio.addEventListener('change', function() {
                const allWrappers = document.querySelectorAll('.delivery-select-wrapper');
                const allAddressFields = document.querySelectorAll('.address-fields');
                
                allWrappers.forEach(wrapper => wrapper.style.display = 'none');
                allAddressFields.forEach(fields => fields.style.display = 'none');
                
                const selectedOption = this.closest('.delivery-option');
                const selectedWrapper = selectedOption.querySelector('.delivery-select-wrapper');
                const selectedAddressFields = selectedOption.querySelector('.address-fields');
                
                if (selectedWrapper) {
                    selectedWrapper.style.display = 'block';
                }
                if (selectedAddressFields) {
                    selectedAddressFields.style.display = 'block';
                }
            });
        });

        // Delivery office selection - Fixed version
        document.querySelectorAll('.delivery-option-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const wrapper = this.closest('.delivery-select-wrapper');
                const searchInput = wrapper.querySelector('.delivery-search');
                const officeId = this.getAttribute('data-office-id');
                const officeName = this.textContent.trim();
                
                // Determine which delivery method this is for
                if (wrapper.id.includes('speedy')) {
                    document.getElementById('delivery-office-speedy').value = officeName;
                    document.getElementById('delivery-office-id-speedy').value = officeId;
                } else if (wrapper.id.includes('econt')) {
                    document.getElementById('delivery-office-econt').value = officeName;
                    document.getElementById('delivery-office-id-econt').value = officeId;
                }
                
                searchInput.value = officeName;
                
                // Close dropdown
                wrapper.querySelector('.delivery-dropdown').style.display = 'none';
            });
        });

        // Search functionality - Fixed version
        document.querySelectorAll('.delivery-search').forEach(search => {
            search.addEventListener('focus', function() {
                this.nextElementSibling.style.display = 'block';
            });

            search.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const dropdown = this.nextElementSibling;
                
                dropdown.style.display = 'block';
                
                dropdown.querySelectorAll('.delivery-option-item').forEach(item => {
                    const text = item.textContent.toLowerCase();
                    if (text.includes(searchTerm)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.delivery-select-wrapper')) {
                document.querySelectorAll('.delivery-dropdown').forEach(dropdown => {
                    dropdown.style.display = 'none';
                });
            }
        });

        // Form submission
        form.addEventListener('submit', async function(e) {
            e.preventDefault();

            const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
            const deliveryMethod = document.querySelector('input[name="delivery-method"]:checked').value;
            const emailInput = document.querySelector('input[name="email"]');
            let email = emailInput.value.trim();
            let phone = document.getElementById('phone').value.trim();

            // Validation
            if (!phone) {
                showMessage('Моля, въведете телефонен номер', 'error');
                return;
            }

            // Basic phone validation (at least 10 digits)
            const phoneDigits = phone.replace(/\D/g, '');
            if (phoneDigits.length < 10) {
                showMessage('Моля, въведете валиден телефонен номер', 'error');
                return;
            }

            if (!email) {
                showMessage('Моля, въведете имейл адрес', 'error');
                return;
            }

            if (!paymentMethod) {
                showMessage('Моля, изберете начин на плащане', 'error');
                return;
            }

            if (!deliveryMethod) {
                showMessage('Моля, изберете начин на доставка', 'error');
                return;
            }

            if (deliveryMethod === 'courier') {
                const city = document.getElementById('city-input').value.trim();
                const street = document.getElementById('street-input').value.trim();
                
                if (!city || !street) {
                    showMessage('Моля, попълнете адреса за доставка', 'error');
                    return;
                }
            } else if (deliveryMethod === 'speedy') {
                const officeId = document.getElementById('delivery-office-id-speedy').value;
                if (!officeId) {
                    showMessage('Моля, изберете Speedy офис', 'error');
                    return;
                }
            } else if (deliveryMethod === 'econt') {
                const officeId = document.getElementById('delivery-office-id-econt').value;
                if (!officeId) {
                    showMessage('Моля, изберете eKont офис', 'error');
                    return;
                }
            }

            // Prepare data
            const formData = {
                payment_method: paymentMethod,
                delivery_method: deliveryMethod,
                email: email,
                phone: phone
            };

            if (deliveryMethod === 'courier') {
                formData.city = document.getElementById('city-input').value.trim();
                formData.street = document.getElementById('street-input').value.trim();
                formData.block = document.getElementById('block-input').value.trim();
                formData.entrance = document.getElementById('entrance-input').value.trim();
                formData.apartment = document.getElementById('apartment-input').value.trim();
            } else if (deliveryMethod === 'speedy') {
                formData.delivery_office_id = document.getElementById('delivery-office-id-speedy').value;
            } else if (deliveryMethod === 'econt') {
                formData.delivery_office_id = document.getElementById('delivery-office-id-econt').value;
            }

            // Add cart data for guest users
            const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
            if (!isLoggedIn) {
                const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                if (guestCart.length > 0) {
                    formData.cart = guestCart;
                } else {
                    showMessage('Вашата количка е празна', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Плати сега';
                    return;
                }
            }

            submitBtn.disabled = true;
            submitBtn.textContent = 'Обработка...';

            try {
                const response = await fetch('api/orders.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('Поръчката е успешно създадена!', 'success');
                    // Clear guest cart if exists
                    if (localStorage.getItem('guest_cart')) {
                        localStorage.removeItem('guest_cart');
                    }
                    
                    setTimeout(() => {
                        window.location.href = result.redirect_url;
                    }, 1500);
                } else {
                    showMessage(result.message || 'Възникна грешка при обработката на поръчката', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Плати сега';
                }
            } catch (error) {
                showMessage('Грешка при свързване със сървъра: ' + error.message, 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Плати сега';
            }
        });

        function showMessage(message, type) {
            messageDiv.textContent = message;
            messageDiv.style.display = 'block';
            messageDiv.style.color = type === 'error' ? '#d32f2f' : '#388e3c';
            messageDiv.style.padding = '1rem';
            messageDiv.style.backgroundColor = type === 'error' ? '#ffebee' : '#e8f5e9';
            messageDiv.style.borderRadius = '4px';
            messageDiv.style.border = '1px solid ' + (type === 'error' ? '#ef5350' : '#66bb6a');

            if (type === 'error') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }
    </script>
</body>
</html>
