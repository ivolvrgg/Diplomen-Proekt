<?php
// Database configuration file for reusable connections

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'dron_db';
$db_port = 3307;

try {
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name, $db_port);
    
    if ($conn->connect_error) {
        // Check if we should return JSON (for API requests)
        if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Database connection failed: ' . $conn->connect_error
            ]);
            exit;
        } else {
            die("Connection failed: " . $conn->connect_error);
        }
    }
    
    $conn->set_charset("utf8mb4");
    
    if ($conn->error) {
        if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Database charset error: ' . $conn->error
            ]);
            exit;
        } else {
            die("Charset error: " . $conn->error);
        }
    }
} catch (Exception $e) {
    if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
        exit;
    } else {
        die("Database error: " . $e->getMessage());
    }
}

// Function to get proper image URL with fallback
function get_image_url($image_url, $product_name = 'Product') {
    if (empty($image_url)) {
        // Return SVG placeholder for missing images
        return 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2714%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E';
    }
    
    // Check if URL is valid and accessible
    if (filter_var($image_url, FILTER_VALIDATE_URL)) {
        return $image_url;
    }
    
    // Return SVG placeholder for invalid URLs
    return 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2714%27 fill=%27%23999%27%3E' . htmlspecialchars($product_name) . '%3C/text%3E%3C/svg%3E';
}
?>

