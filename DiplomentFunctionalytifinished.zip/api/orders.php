<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
header('Content-Type: application/json');
include '../config/db.php';
include '../includes/auth_check.php';

// Initialize response
$response = ['success' => false, 'message' => '', 'order_id' => null];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Get request data
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }

    // Get user info
    $user_id = get_user_id();
    if ($user_id === 0) {
        // Guest user - use NULL for database
        $db_user_id = null;
        if (!isset($_SESSION['guest_id'])) {
            $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
        }
    } else {
        $db_user_id = $user_id;
    }

    // Validate required fields
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $payment_method = trim($data['payment_method'] ?? '');
    $delivery_method = trim($data['delivery_method'] ?? '');

    if (empty($email)) {
        throw new Exception('Email is required');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    if (empty($phone)) {
        throw new Exception('Phone number is required');
    }

    // Basic phone validation (at least 10 digits)
    $phoneDigits = preg_replace('/\D/', '', $phone);
    if (strlen($phoneDigits) < 10) {
        throw new Exception('Invalid phone number');
    }

    if (!in_array($payment_method, ['card', 'cod'])) {
        throw new Exception('Invalid payment method');
    }

    if (!in_array($delivery_method, ['courier', 'speedy', 'econt'])) {
        throw new Exception('Invalid delivery method');
    }

    // Get cart items
    $cart_items = [];
    $subtotal = 0;
    
    if ($db_user_id > 0) {
        // Logged-in user - get from database
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price 
                       FROM cart c 
                       JOIN products p ON c.product_id = p.id 
                       WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);

        if (!$cart_result || $cart_result->num_rows === 0) {
            throw new Exception('Cart is empty');
        }

        while ($item = $cart_result->fetch_assoc()) {
            $item_total = $item['price'] * $item['quantity'];
            $subtotal += $item_total;
            $cart_items[] = $item;
        }
    } else {
        // Guest user - get from request data
        $cart_data = $data['cart'] ?? [];
        if (empty($cart_data)) {
            throw new Exception('Cart is empty');
        }

        // Validate and fetch product data for each item
        foreach ($cart_data as $item) {
            $product_id = intval($item['product_id'] ?? 0);
            $quantity = intval($item['quantity'] ?? 0);

            if ($product_id <= 0 || $quantity <= 0) {
                throw new Exception('Invalid cart item');
            }

            // Get product details
            $product_query = "SELECT id, name, price FROM products WHERE id = $product_id";
            $product_result = $conn->query($product_query);

            if (!$product_result || $product_result->num_rows === 0) {
                throw new Exception('Product not found: ' . $product_id);
            }

            $product = $product_result->fetch_assoc();
            $item_total = $product['price'] * $quantity;
            $subtotal += $item_total;
            
            $cart_items[] = [
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity
            ];
        }
    }

    // Map delivery methods to database IDs and costs
    $delivery_mapping = [
        'courier' => ['id' => 1, 'cost' => 6.00],
        'speedy' => ['id' => 2, 'cost' => 4.99],
        'econt' => ['id' => 3, 'cost' => 3.99]
    ];

    if (!isset($delivery_mapping[$delivery_method])) {
        throw new Exception('Invalid delivery method');
    }

    $delivery_method_id = $delivery_mapping[$delivery_method]['id'];
    $delivery_cost = $delivery_mapping[$delivery_method]['cost'];

    // Calculate order totals
    $vat = $subtotal * 0.20;
    $total = $subtotal + $vat + $delivery_cost;

    // Handle delivery address for courier method
    $shipping_address_id = null;
    $delivery_office_id = null;

    if ($delivery_method === 'courier') {
        // For courier, get address from request
        $city = trim($data['city'] ?? '');
        $street = trim($data['street'] ?? '');
        $block = trim($data['block'] ?? '');
        $entrance = trim($data['entrance'] ?? '');
        $apartment = trim($data['apartment'] ?? '');

        if (empty($city) || empty($street)) {
            throw new Exception('Address is required for courier delivery');
        }

        // For guests or to store inline, we'll save delivery info in the order
        // The system should be updated to store address details directly in orders table
        // For now, we'll use null but the frontend should validate addresses are entered
    } else {
        // For office delivery, get office ID
        $delivery_office_id = intval($data['delivery_office_id'] ?? 0);
        if ($delivery_office_id <= 0) {
            throw new Exception('Delivery office is required');
        }

        // Verify office exists
        $office_check = $conn->query("SELECT id FROM delivery_offices WHERE id = $delivery_office_id AND is_active = 1");
        if (!$office_check || $office_check->num_rows === 0) {
            throw new Exception('Invalid delivery office');
        }
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Insert order using prepared statement
        $insert_order = $conn->prepare("INSERT INTO orders (user_id, status, subtotal, delivery_cost, vat, total, payment_method, delivery_method_id, delivery_office_id, email, phone, created_at, updated_at) 
                            VALUES (?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        
        if (!$insert_order) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        $insert_order->bind_param("idddsisiss", $db_user_id, $subtotal, $delivery_cost, $vat, $total, $payment_method, $delivery_method_id, $delivery_office_id, $email, $phone);
        
        if (!$insert_order->execute()) {
            throw new Exception('Failed to create order: ' . $conn->error);
        }
        $insert_order->close();

        $order_id = $conn->insert_id;

        // Insert order items
        $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
        
        foreach ($cart_items as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $unit_price = floatval($item['price']);

            $item_stmt->bind_param("iiii", $order_id, $product_id, $quantity, $unit_price);

            if (!$item_stmt->execute()) {
                throw new Exception('Failed to add order item: ' . $conn->error);
            }

            // Update product stock using prepared statement
            $stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
            $stock_stmt->bind_param("ii", $quantity, $product_id);
            if (!$stock_stmt->execute()) {
                throw new Exception('Failed to update stock: ' . $conn->error);
            }
            $stock_stmt->close();
        }
        $item_stmt->close();

        // Clear cart using prepared statement
        $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_stmt->bind_param("i", $db_user_id);
        if (!$clear_stmt->execute()) {
            throw new Exception('Failed to clear cart: ' . $conn->error);
        }
        $clear_stmt->close();

        // Clear session cart
        $_SESSION['cart'] = [];

        // Commit transaction
        $conn->commit();

        $response['success'] = true;
        $response['message'] = 'Order created successfully';
        $response['order_id'] = $order_id;
        // Redirect to homepage for guests, profile for logged-in users
        $response['redirect_url'] = ($user_id === 0) ? '/Diplomna_rabota/homepage.php' : '/Diplomna_rabota/profile.php?tab=orders';

    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;
?>
