<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Guest Cart Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .test { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #ccc; }
        .pass { border-left-color: #4caf50; color: #2e7d32; }
        .fail { border-left-color: #f44336; color: #c62828; }
        .warn { border-left-color: #ff9800; color: #e65100; }
        code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; }
        h1 { color: #333; }
    </style>
</head>
<body>
    <h1>🔍 Guest Checkout Diagnostic Report</h1>";

// Test 1: Session status
echo "<div class='test ";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "pass'>✓ Session is active";
} else {
    echo "fail'>✗ Session is NOT active";
}
echo "</div>";

// Test 2: Guest ID generation
$_SESSION['test_guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
echo "<div class='test pass'>✓ Guest ID generated: <code>" . htmlspecialchars($_SESSION['test_guest_id']) . "</code></div>";

// Test 3: Database connection
include 'config/db.php';
echo "<div class='test ";
if ($conn && !$conn->connect_error) {
    echo "pass'>✓ Database connection successful";
} else {
    echo "fail'>✗ Database connection FAILED: " . $conn->connect_error;
}
echo "</div>";

// Test 4: Check cart table exists and structure
if ($conn && !$conn->connect_error) {
    $check_table = $conn->query("SHOW TABLES LIKE 'cart'");
    echo "<div class='test ";
    if ($check_table && $check_table->num_rows > 0) {
        echo "pass'>✓ Cart table exists";
    } else {
        echo "fail'>✗ Cart table does NOT exist";
    }
    echo "</div>";
    
    // Test 5: Check cart table structure
    $columns = $conn->query("SHOW COLUMNS FROM cart");
    if ($columns && $columns->num_rows > 0) {
        echo "<div class='test pass'>✓ Cart table structure:";
        echo "<ul>";
        while ($col = $columns->fetch_assoc()) {
            echo "<li><code>" . $col['Field'] . "</code> (" . $col['Type'] . ")</li>";
        }
        echo "</ul></div>";
    }
    
    // Test 6: Test INSERT with user_id = -1
    echo "<div class='test ";
    $test_insert = $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES (-1, 1, 1)");
    if ($test_insert) {
        echo "pass'>✓ Can INSERT with user_id = -1";
        // Clean up test record
        $conn->query("DELETE FROM cart WHERE user_id = -1 AND product_id = 1");
    } else {
        echo "fail'>✗ Cannot INSERT with user_id = -1: " . $conn->error;
    }
    echo "</div>";
    
    // Test 7: Test SELECT with user_id = -1
    echo "<div class='test ";
    $test_select = $conn->query("SELECT COUNT(*) as count FROM cart WHERE user_id = -1");
    if ($test_select) {
        echo "pass'>✓ Can SELECT with user_id = -1";
    } else {
        echo "fail'>✗ Cannot SELECT with user_id = -1: " . $conn->error;
    }
    echo "</div>";
    
    // Test 8: Products table
    echo "<div class='test ";
    $prod_check = $conn->query("SELECT COUNT(*) as count FROM products WHERE is_active = 1 LIMIT 1");
    if ($prod_check) {
        $prod_row = $prod_check->fetch_assoc();
        if ($prod_row['count'] > 0) {
            echo "pass'>✓ Products table has active products";
        } else {
            echo "warn'>⚠ No active products found";
        }
    } else {
        echo "fail'>✗ Cannot query products table: " . $conn->error;
    }
    echo "</div>";
    
    // Test 9: Check cart.php file
    echo "<div class='test ";
    if (file_exists('api/cart.php')) {
        echo "pass'>✓ api/cart.php file exists";
        $file_size = filesize('api/cart.php');
        echo " (File size: " . $file_size . " bytes)";
    } else {
        echo "fail'>✗ api/cart.php file NOT found";
    }
    echo "</div>";
}

echo "<hr>";
echo "<h2>🧪 Manual Test</h2>";
echo "<p>Try adding a product to your cart now. Open browser console (F12) and check for error messages.</p>";
echo "<p><strong>Database:</strong> " . $conn->get_charset()->charset . "</p>";
echo "<p><strong>Server:</strong> PHP " . phpversion() . "</p>";
echo "<p><strong>Session ID:</strong> <code>" . session_id() . "</code></p>";

echo "</body>
</html>";
?>
