<?php
$page_css = 'category-products.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <?php
        // Get category ID from URL
        $category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        
        if ($category_id > 0) {
            // Get category details using prepared statement
            $cat_query = "SELECT * FROM categories WHERE id = ?";
            $cat_stmt = $conn->prepare($cat_query);
            
            if ($cat_stmt) {
                $cat_stmt->bind_param("i", $category_id);
                $cat_stmt->execute();
                $cat_result = $cat_stmt->get_result();
                
                if ($cat_result && $cat_result->num_rows > 0) {
                    $category = $cat_result->fetch_assoc();
                    $page_title = $category['name'] . ' - Dronche.BG';
            ?>
        
        <section class="category-header">
            <div class="container">
                <h1 class="category-title"><?php echo htmlspecialchars($category['name']); ?></h1>
            </div>
        </section>

        <section class="category-products">
            <div class="container">
                <div class="products-grid">
                    <?php
                    // Get all products for this category using prepared statement
                    $products_query = "SELECT * FROM products WHERE category_id = ? AND is_active = 1 ORDER BY name ASC";
                    $products_stmt = $conn->prepare($products_query);
                    
                    if ($products_stmt) {
                        $products_stmt->bind_param("i", $category_id);
                        $products_stmt->execute();
                        $products_result = $products_stmt->get_result();
                        
                        if ($products_result && $products_result->num_rows > 0) {
                            while ($product = $products_result->fetch_assoc()) {
                                $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                        ?>
                    <div class="product-card">
                        <div class="product-image-wrapper">
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                            <div class="product-overlay">
                                <a href="itempage.php?id=<?php echo $product['id']; ?>" class="view-details-btn">Детайли</a>
                            </div>
                        </div>
                        
                        <div class="product-info">
                            <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-price"><?php echo number_format($product['price'], 2); ?> €</p>
                            <p class="product-stock <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                            </p>
                        </div>
                        
                        <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                    </div>
                    <?php
                            }
                        } else {
                            echo '<div class="empty-state"><p>Няма продукти в тази категория.</p></div>';
                        }
                        $products_stmt->close();
                    }
                    ?>
                </div>
            </div>
        </section>

        <?php
                    $cat_stmt->close();
                } else {
                    echo '<div class="container"><p>Категорията не е намерена.</p></div>';
                }
            } else {
                echo '<div class="container"><p>Грешка при зареждане на категорията.</p></div>';
            }
        } else {
            echo '<div class="container"><p>Невалидна категория.</p></div>';
        }
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
