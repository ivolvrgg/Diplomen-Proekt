<?php
$page_title = 'Детайл на продукт - Airsoft Store';
$page_css = 'itempage.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
    
    <?php include 'includes/navbar.php'; ?>

    <main id="main-content" class="product-container">
        <div class="container">
            <?php
            // Get product ID from URL
            $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            
            if ($product_id > 0) {
                $query = "SELECT p.*, c.name as category_name FROM products p 
                         LEFT JOIN categories c ON p.category_id = c.id 
                         WHERE p.id = $product_id AND p.is_active = 1";
                $result = $conn->query($query);
                
                if ($result && $result->num_rows > 0) {
                    $product = $result->fetch_assoc();
            ?>
            <div class="product-content">
                <div class="product-gallery">
                    <img src="<?php echo htmlspecialchars($product['image_1']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="main-image">
                    
                    <div class="image-carousel">
                        <button class="carousel-arrow prev-arrow" aria-label="Previous image">❮</button>
                        <div class="carousel-track">
                            <?php
                            // Display all available images
                            for ($i = 1; $i <= 4; $i++) {
                                $image_field = "image_$i";
                                if (!empty($product[$image_field])) {
                            ?>
                            <img src="<?php echo htmlspecialchars($product[$image_field]); ?>" alt="<?php echo htmlspecialchars($product['name']); ?> view <?php echo $i; ?>" class="carousel-image">
                            <?php
                                }
                            }
                            
                            // Add video if available
                            if (!empty($product['video_url'])) {
                                $video_id = basename($product['video_url']);
                            ?>
                            <div class="carousel-video-item" data-video-id="<?php echo htmlspecialchars($video_id); ?>">
                                <img src="https://img.youtube.com/vi/<?php echo htmlspecialchars($video_id); ?>/mqdefault.jpg" alt="Product Video" class="carousel-image carousel-video-thumb">
                            </div>
                            <?php
                            }
                            ?>
                        </div>
                        <button class="carousel-arrow next-arrow" aria-label="Next image">❯</button>
                    </div>
                </div>
                
                <div class="product-info">
                    <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                    
                    <?php if (!empty($product['category_name'])) { ?>
                    <p class="product-category">Категория: <?php echo htmlspecialchars($product['category_name']); ?></p>
                    <?php } ?>
                    
                    <div class="price-container">
                        <div class="price"><?php echo number_format($product['price'], 2); ?> лв.</div>
                        <div class="availability">
                            <?php echo $product['stock'] > 0 ? 'На склад' : 'Край на наличността'; ?>
                        </div>
                    </div>
                    
                    <div class="product-description">
                        <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'Качествен продукт')); ?></p>
                    </div>
                    
                    <div class="quantity-selector">
                        <label for="quantity">Количество:</label>
                        <input type="number" id="quantity" class="quantity-input" min="1" max="<?php echo max($product['stock'], 10); ?>" value="1">
                    </div>
                    
                    <button class="add-to-cart" onclick="addToCartWithQty(<?php echo $product['id']; ?>)" 
                        <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                        Добави в количка
                    </button>
                </div>
            </div>
            
            <div class="related-products">
                <h2>Свързани продукти</h2>
                <div class="related-grid">
                    <?php
                    // Get related products from same category
                    $related_query = "SELECT * FROM products WHERE category_id = " . $product['category_id'] . " 
                                    AND id != $product_id AND is_active = 1 LIMIT 4";
                    $related_result = $conn->query($related_query);
                    
                    if ($related_result && $related_result->num_rows > 0) {
                        while ($related = $related_result->fetch_assoc()) {
                    ?>
                    <div class="related-item">
                        <a href="itempage.php?id=<?php echo $related['id']; ?>" style="text-decoration: none; color: inherit;">
                            <img src="<?php echo htmlspecialchars($related['image_1']); ?>" alt="<?php echo htmlspecialchars($related['name']); ?>" class="related-image">
                            <div class="related-info">
                                <div class="related-title"><?php echo htmlspecialchars($related['name']); ?></div>
                                <div class="related-price"><?php echo number_format($related['price'], 2); ?> лв.</div>
                            </div>
                        </a>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
            
            <?php
                } else {
                    echo '<p>Продуктът не е намерен.</p>';
                }
            } else {
                echo '<p>Невалиден продукт.</p>';
            }
            ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
    
    <script>
        function addToCartWithQty(productId) {
            const quantity = document.getElementById('quantity').value;
            
            fetch('api/cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ product_id: productId, quantity: parseInt(quantity) })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Продукт добавен в количката!');
                    document.getElementById('quantity').value = 1;
                }
            });
        }
        
        // Product gallery carousel
        const carouselTrack = document.querySelector('.carousel-track');
        const carouselImages = document.querySelectorAll('.carousel-image');
        const prevArrow = document.querySelector('.prev-arrow');
        const nextArrow = document.querySelector('.next-arrow');
        let currentSlide = 0;

        function updateCarousel() {
            carouselImages.forEach((img, index) => {
                img.style.borderColor = index === currentSlide ? '#ffd700' : 'transparent';
            });
            
            const currentItem = document.querySelectorAll('.carousel-track > *')[currentSlide];
            
            if (currentItem.classList.contains('carousel-video-item')) {
                const videoId = currentItem.getAttribute('data-video-id');
                const mainImage = document.querySelector('.product-gallery > img, .product-gallery > iframe');
                if (mainImage) {
                    mainImage.outerHTML = `<iframe width="100%" height="500" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen></iframe>`;
                }
            } else {
                const mainMedia = document.querySelector('.product-gallery > img, .product-gallery > iframe');
                if (mainMedia && mainMedia.tagName === 'IFRAME') {
                    mainMedia.outerHTML = `<img src="${carouselImages[currentSlide].src}" alt="${carouselImages[currentSlide].alt}" class="main-image">`;
                } else if (mainMedia && mainMedia.tagName === 'IMG') {
                    mainMedia.src = carouselImages[currentSlide].src;
                }
            }
        }

        prevArrow?.addEventListener('click', () => {
            const totalItems = document.querySelectorAll('.carousel-track > *').length;
            currentSlide = (currentSlide - 1 + totalItems) % totalItems;
            updateCarousel();
        });

        nextArrow?.addEventListener('click', () => {
            const totalItems = document.querySelectorAll('.carousel-track > *').length;
            currentSlide = (currentSlide + 1) % totalItems;
            updateCarousel();
        });
    </script>
</body>
</html>
