<?php
// navbar.php - Navigation bar for non-logged-in users
// Usage: <?php include 'includes/navbar.php'; ?>
    <nav>
        <div class="logo">
            <p>DRONCHE.BG</p>
        </div>
        
        <div class="search-bar">
            <input type="text" placeholder="Търси продукти..." class="search-input">
            <button class="search-btn" aria-label="Търси"><i class="fas fa-search"></i></button>
        </div>
        
        <button class="mobile-menu-toggle" aria-label="Меню">☰</button>
        
        <ul class="menu">
            <li><a href="homepage.php">НАЧАЛНА СТРАНИЦА</a></li>
            <li class="dropdown">
                <button type="button" class="dropdown-btn">КАТАЛОГ <i class="fas fa-chevron-down"></i></button>
                <div class="dropdown-content">
                    <a href="category-products.php?id=1">Дронове</a>
                    <a href="category-products.php?id=2">RC Самолети</a>
                    <a href="category-products.php?id=3">RC Лодки</a>
                    <a href="category-products.php?id=4">RC Коли</a>
                    <a href="category-products.php?id=5">Батерии</a>
                    <a href="category-products.php?id=6">Джойстици</a>
                </div>
            </li>
            <li><a href="cart.php"><i class="fas fa-shopping-cart"></i> КОЛИЧКА</a></li>
            <li><a href="user_login.php"><i class="fas fa-sign-in-alt"></i> ВХОД</a></li>
        </ul>
    </nav>
