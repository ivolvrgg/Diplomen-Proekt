<?php
// scripts.php - Common JavaScript for interactive features
// Usage: <?php include 'includes/scripts.php'; ?>
    <script>
    (function () {
        document.addEventListener('DOMContentLoaded', function () {
            // helper
            const onEach = (list, fn) => { if (list && list.length) list.forEach(fn); };

            // Mobile menu toggle functionality
            const mobileToggle = document.querySelector('.mobile-menu-toggle');
            if (mobileToggle) {
                mobileToggle.addEventListener('click', function() {
                    const menu = document.querySelector('nav ul.menu');
                    if (menu) menu.classList.toggle('show');
                    this.classList.toggle('open');
                });
            }

            // Simple Button-style Dropdown functionality - click to toggle only
            const dropdownElements = document.querySelectorAll('.dropdown');

            dropdownElements.forEach(dropdown => {
                const btn = dropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                const content = dropdown.querySelector('.dropdown-content');
                
                if (!btn || !content) return;

                // Click to toggle dropdown
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Toggle the dropdown
                    const isOpen = content.classList.contains('show');
                    
                    // Close all other dropdowns
                    dropdownElements.forEach(otherDropdown => {
                        if (otherDropdown !== dropdown) {
                            const otherContent = otherDropdown.querySelector('.dropdown-content');
                            const otherBtn = otherDropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                            if (otherContent) {
                                otherContent.classList.remove('show');
                                if (otherBtn) {
                                    otherBtn.classList.remove('active');
                                }
                            }
                        }
                    });
                    
                    // Toggle current dropdown
                    if (isOpen) {
                        content.classList.remove('show');
                        btn.classList.remove('active');
                    } else {
                        content.classList.add('show');
                        btn.classList.add('active');
                    }
                });
                
                // Prevent closing when clicking inside the dropdown content
                content.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            });

            // Close dropdowns when clicking outside
            document.addEventListener('click', function(e) {
                dropdownElements.forEach(dropdown => {
                    const btn = dropdown.querySelector('.dropdown-btn, .dropdown-btn1');
                    const content = dropdown.querySelector('.dropdown-content');
                    // Don't close if clicking on button or inside dropdown content
                    if (!dropdown.contains(e.target)) {
                        if (content) {
                            content.classList.remove('show');
                            if (btn) {
                                btn.classList.remove('active');
                            }
                        }
                    }
                });
            });

            // Cart-specific functionality
            const qtyBtns = document.querySelectorAll('.quantity-btn');
            if (qtyBtns && qtyBtns.length) {
                onEach(qtyBtns, btn => {
                    btn.addEventListener('click', function() {
                        const span = this.parentElement.querySelector('span');
                        if (!span) return;
                        let quantity = parseInt(span.textContent) || 0;
                        if (this.textContent.trim() === '+' && quantity < 10) {
                            span.textContent = quantity + 1;
                        } else if (this.textContent.trim() === '-' && quantity > 1) {
                            span.textContent = quantity - 1;
                        }
                    });
                });
            }

            // Remove button functionality
            const removeBtns = document.querySelectorAll('.remove-btn');
            if (removeBtns && removeBtns.length) {
                onEach(removeBtns, btn => {
                    btn.addEventListener('click', function() {
                        const item = this.closest('.cart-item');
                        if (item) item.remove();
                    });
                });
            }

            // Carousel functionality (guarded)
            let currentSlide = 0;
            const slides = document.querySelectorAll('.slide');
            const indicators = document.querySelectorAll('.indicator');

            if (slides && slides.length) {
                const totalSlides = slides.length;
                const updateCarousel = function() {
                    const carousel = document.querySelector('.carousel');
                    if (carousel) carousel.style.transform = `translateX(-${currentSlide * 100}%)`;
                    if (indicators && indicators.length) {
                        indicators.forEach((indicator, index) => indicator.classList.toggle('active', index === currentSlide));
                    }
                };

                const prevBtn = document.querySelector('.prev-btn');
                const nextBtn = document.querySelector('.next-btn');

                if (prevBtn) prevBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide > 0) ? currentSlide - 1 : totalSlides - 1;
                    updateCarousel();
                });

                if (nextBtn) nextBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide < totalSlides - 1) ? currentSlide + 1 : 0;
                    updateCarousel();
                });

                if (indicators && indicators.length) {
                    indicators.forEach((indicator, index) => {
                        indicator.addEventListener('click', () => {
                            currentSlide = index;
                            updateCarousel();
                        });
                    });
                }
            }
        });
    })();
    </script>
