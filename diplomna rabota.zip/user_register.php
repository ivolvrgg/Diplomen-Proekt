<?php
$page_title = 'Регистрация - Dronche.BG';
$page_css = 'user_register.css';
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Регистрация</h1>
                <form class="login-form" id="registrationForm">
                    <div class="form-group">
                        <label for="fullname">Пълно име</label>
                        <input type="text" id="fullname" name="fullname" required placeholder="Въведи своето пълно име">
                        <span class="error-message" id="fullnameError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароля</label>
                        <input type="password" id="password" name="password" required placeholder="Въведи своя пароля">
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">Потвърди паролата</label>
                        <input type="password" id="confirm-password" name="confirm-password" required placeholder="Потвърди своя пароля">
                        <span class="error-message" id="confirmPasswordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="terms" required>
                            Съгласен/а съм с условията
                        </label>
                    </div>
                    
                    <button type="submit" class="login-btn">Регистрирай се</button>
                </form>
                
                <div class="signup-link">
                    Имаш акаунт? <a href="user_login.php">Влез тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            
            if (password !== confirmPassword) {
                document.getElementById('confirmPasswordError').textContent = 'Паролите не съвпадат';
                return;
            }
            // Handle registration logic here
        });
    </script>
</body>
</html>
