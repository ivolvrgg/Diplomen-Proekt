<?php
$page_title = 'Плащане | Dronche.BG';
$page_css = 'logged_Payment.css';
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>

    <main id="main-content" class="payment-container">
        <div class="container">
            <h1 class="section-title">Плащане</h1>
            
            <div class="payment-content">
                <div class="order-summary">
                    <h2>Вашата поръчка</h2>
                    <div class="order-items">
                        <div class="order-item">
                            <span class="item-name">Double M4 059М+ John Wick</span>
                            <span class="item-price">639.00 лв.</span>
                        </div>
                        <div class="order-item">
                            <span class="item-name">ASG CZ Scorpion EVO 3 ATEK</span>
                            <span class="item-price">745.00 лв.</span>
                        </div>
                        <div class="order-item">
                            <span class="item-name">Arcturus Grey CQB</span>
                            <span class="item-price">390.00 лв.</span>
                        </div>
                    </div>
                    <div class="order-total">
                        <span>Общо:</span>
                        <span class="total-price">1 774.00 лв.</span>
                    </div>
                </div>

                <form class="payment-form">
                    <h2>Метод на плащане</h2>
                    
                    <div class="payment-methods">
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="card" checked>
                            <span class="payment-label">Плащане с карта</span>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="cod">
                            <span class="payment-label">Наложен платеж</span>
                        </label>
                    </div>

                    <h2 style="margin-top: 2rem;">Начин на доставка</h2>
                    
                    <div class="delivery-methods">
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="address" class="delivery-radio">
                                <span class="delivery-label">До адрес</span>
                            </label>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="speedy" class="delivery-radio">
                                <span class="delivery-label">Speedy</span>
                            </label>
                        </div>
                        
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="econt" class="delivery-radio">
                                <span class="delivery-label">eKont</span>
                            </label>
                        </div>
                    </div>

                    <h2 style="margin-top: 2rem;">Данни за плащане</h2>
                    
                    <div id="card-payment-section">
                        <div class="form-group">
                            <label for="card-name">Име на картата</label>
                            <input type="text" id="card-name" placeholder="Име и фамилия" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="card-number">Номер на карта</label>
                            <input type="text" id="card-number" placeholder="1234 5678 9012 3456" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="expiry-date">Валидна до</label>
                                <input type="text" id="expiry-date" placeholder="ММ/ГГ" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" placeholder="123" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Имейл за потвърждение</label>
                        <input type="email" id="email" placeholder="вашият@имейл.com" required>
                    </div>
                    
                    <button type="submit" class="btn-pay">Плати сега</button>
                </form>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
</body>
</html>
