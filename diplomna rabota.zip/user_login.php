<?php
$page_title = 'Вход - Dronche.BG';
$page_css = 'user_login.css';
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Вход</h1>
                <form class="login-form" id="loginForm">
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароля</label>
                        <input type="password" id="password" name="password" required placeholder="Въведи своя пароля">
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            Помни ме
                        </label>
                        <a href="#" class="forgot-password">Забравена пароля?</a>
                    </div>
                    
                    <button type="submit" class="login-btn">Вход</button>
                </form>
                
                <div class="signup-link">
                    Нямаш акаунт? <a href="user_register.php">Регистрирай се тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
