<?php
$page_title = 'Dronche.BG';
$page_css = 'homepage.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_logged.php'; ?>
    
    <main id="main-content">
        <section class="featured-products">
            <div class="carousel-container">
                <div class="carousel-wrapper">
                    <div class="carousel">
                        <div class="slide">
                            <img src="https://images.unsplash.com/photo-1516268335757-f0ec2afb6172?w=400" alt="DJI Mini 3 Pro">
                            <h2>1299 лв</h2>
                            <p>DJI Mini 3 Pro</p>
                        </div>
                        
                        <div class="slide">
                            <img src="https://images.unsplash.com/photo-1559163238-94ce64fbea90?w=400" alt="RC Racing Car">
                            <h2>89 лв</h2>
                            <p>High Speed RC Racing Car</p>
                        </div>
                        
                        <div class="slide">
                            <img src="https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400" alt="RC Самолет">
                            <h2>459 лв</h2>
                            <p>Professional RC Airplane</p>
                        </div>
                    </div>
                    <div class="carousel-nav">
                        <button class="carousel-btn prev-btn">❮</button>
                        <button class="carousel-btn next-btn">❯</button>
                    </div>
                </div>
                
                <div class="indicators">
                    <div class="indicator active"></div>
                    <div class="indicator"></div>
                    <div class="indicator"></div>
                </div>
            </div>
        </section>
        
        <section class="best-sellers">
            <h2 class="section-title">Бестселъри</h2>
            <div class="bestsellers-container">
                <?php
                $bestsellers_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 3";
                $bestsellers_result = $conn->query($bestsellers_query);
                
                while ($product = $bestsellers_result->fetch_assoc()) {
                    $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                ?>
                <div class="bestseller-card">
                    <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image">
                        <div class="bestseller-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price"><?php echo number_format($product['price'], 2); ?> лв</p>
                            <p class="description"><?php echo htmlspecialchars(substr($product['description'] ?? '', 0, 60)); ?></p>
                        </div>
                    </a>
                    <a href="logged_itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
        
        <section class="product-categories">
            <h2 class="section-title">Категории</h2>
            <div class="categories-container">
                <div class="category-card">
                    <a href="catalog.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1516268335757-f0ec2afb6172?w=400" alt="ДРОНОВЕ" class="category-image">
                        <div class="category-name">ДРОНОВЕ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="rc-planes.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400" alt="RC САМОЛЕТИ" class="category-image">
                        <div class="category-name">RC САМОЛЕТИ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="rc-boats.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1559163238-94ce64fbea90?w=400" alt="RC ЛОДКИ" class="category-image">
                        <div class="category-name">RC ЛОДКИ</div>
                    </a>
                </div>
                
                <div class="category-card">
                    <a href="rc-cars.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1581235720704-06d3acfcb36f?w=400" alt="RC КОЛИ" class="category-image">
                        <div class="category-name">RC КОЛИ</div>
                    </a>
                </div>

                <div class="category-card">
                    <a href="batteries.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1579481516173-29c5c2e417c9?w=400" alt="БАТЕРИИ" class="category-image">
                        <div class="category-name">БАТЕРИИ</div>
                    </a>
                </div>

                <div class="category-card">
                    <a href="joysticks.php" class="category-link">
                        <img src="https://images.unsplash.com/photo-1598933247716-3eea7e4e13ba?w=400" alt="ДЖОЙСТИЦИ" class="category-image">
                        <div class="category-name">ДЖОЙСТИЦИ</div>
                    </a>
                </div>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
