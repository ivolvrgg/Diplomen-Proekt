<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dron_db";
$port = 3307;

// Create connection (host, user, pass, db, port)
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully";

// Close connection
$conn->close();
?>