<?php
header('Content-Type: application/json');
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $product_id = intval($data['product_id'] ?? 0);
    $quantity = intval($data['quantity'] ?? 1);
    
    if ($product_id > 0 && $quantity > 0) {
        // Verify product exists
        $check = $conn->query("SELECT id FROM products WHERE id = $product_id AND is_active = 1");
        
        if ($check && $check->num_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Продукт добавен']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Продуктът не е намерен']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Невалидни данни']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
