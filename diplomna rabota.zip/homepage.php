<?php
$page_title = 'Dronche.BG';
$page_css = 'homepage.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar.php'; ?>
    
    <main id="main-content">
        <section class="featured-products">
            <div class="carousel-container">
                <div class="carousel-wrapper">
                    <div class="carousel">
                        <?php
                        // Get top 5 products for carousel
                        $carousel_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 5";
                        $carousel_result = $conn->query($carousel_query);
                        
                        while ($product = $carousel_result->fetch_assoc()) {
                        ?>
                        <div class="slide">
                            <img src="<?php echo htmlspecialchars($product['image_1']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <h2><?php echo number_format($product['price'], 2); ?> лв</h2>
                            <p><?php echo htmlspecialchars($product['name']); ?></p>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="carousel-nav">
                        <button class="carousel-btn prev-btn">❮</button>
                        <button class="carousel-btn next-btn">❯</button>
                    </div>
                </div>
                
                <div class="indicators">
                    <?php
                    $carousel_result->data_seek(0);
                    $count = 0;
                    while ($product = $carousel_result->fetch_assoc()) {
                        $active = ($count === 0) ? 'active' : '';
                    ?>
                    <div class="indicator <?php echo $active; ?>"></div>
                    <?php
                        $count++;
                    }
                    ?>
                </div>
            </div>
        </section>
        
        <section class="best-sellers">
            <h2 class="section-title">Бестселъри</h2>
            <div class="bestsellers-container">
                <?php
                // Get best sellers (top products by stock or recent)
                $bestsellers_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 3";
                $bestsellers_result = $conn->query($bestsellers_query);
                
                while ($product = $bestsellers_result->fetch_assoc()) {
                    $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                ?>
                <div class="bestseller-card">
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image">
                        <div class="bestseller-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price"><?php echo number_format($product['price'], 2); ?> лв</p>
                            <p class="description"><?php echo htmlspecialchars(substr($product['description'] ?? '', 0, 60)); ?></p>
                        </div>
                    </a>
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
        
        <section class="product-categories">
            <h2 class="section-title">Категории</h2>
            <div class="categories-container">
                <?php
                // Get all categories
                $cats_query = "SELECT * FROM categories ORDER BY sort_order ASC";
                $cats_result = $conn->query($cats_query);
                
                while ($cat = $cats_result->fetch_assoc()) {
                    // Get first product image from category for thumbnail
                    $thumb_query = "SELECT image_1 FROM products WHERE category_id = " . $cat['id'] . " AND is_active = 1 LIMIT 1";
                    $thumb_result = $conn->query($thumb_query);
                    $thumb_product = $thumb_result->fetch_assoc();
                    $thumb_image = $thumb_product['image_1'] ?? 'https://via.placeholder.com/300x300?text=' . urlencode($cat['name']);
                ?>
                <div class="category-card">
                    <a href="catalog.php?category=<?php echo $cat['id']; ?>" class="category-link">
                        <img src="<?php echo htmlspecialchars($thumb_image); ?>" alt="<?php echo htmlspecialchars($cat['name']); ?>" class="category-image">
                        <div class="category-name"><?php echo htmlspecialchars($cat['name']); ?></div>
                    </a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
