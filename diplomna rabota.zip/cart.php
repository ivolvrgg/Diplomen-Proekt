<?php
$page_title = 'Shopping Cart';
$page_css = 'cart.css';
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar.php'; ?>

    <main id="main-content" class="cart-container">
        <div class="container">
            <h1 class="section-title">Количка</h1>
            
            <div class="cart-content">
                <div class="cart-items">
                    <div class="cart-item">
                        <img src="https://cqb.bg/wp-content/uploads/double-bell-tti-custom-m4.webp" alt="Double M4" class="cart-item-image">
                        <div class="cart-item-details">
                            <h3>Double M4 059М+ John Wick</h3>
                            <div class="cart-item-price">639 лв.</div>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn">-</button>
                            <span>1</span>
                            <button class="quantity-btn">+</button>
                        </div>
                        <button class="remove-btn">Премахни</button>
                    </div>
                    
                    <div class="cart-item">
                        <img src="https://cqb.bg/wp-content/uploads/asg-cz-scorpion-evo-3-a1-atek-bk-fde-65474.jpg" alt="ASG CZ Scorpion" class="cart-item-image">
                        <div class="cart-item-details">
                            <h3>ASG CZ Scorpion EVO 3 ATEK</h3>
                            <div class="cart-item-price">745 лв.</div>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn">-</button>
                            <span>1</span>
                            <button class="quantity-btn">+</button>
                        </div>
                        <button class="remove-btn">Премахни</button>
                    </div>
                    
                    <div class="cart-item">
                        <img src="https://cqb.bg/wp-content/uploads/karabiny-szturmowe-asg-karabини-eleкtrичeски-asg-at-st01-lwt-cqb-sport-grey-arcturus-23205991-1.jpg" alt="Arcturus Grey" class="cart-item-image">
                        <div class="cart-item-details">
                            <h3>Arcturus Grey CQB</h3>
                            <div class="cart-item-price">390 лв.</div>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn">-</button>
                            <span>1</span>
                            <button class="quantity-btn">+</button>
                        </div>
                        <button class="remove-btn">Премахни</button>
                    </div>
                </div>
                
                <div class="cart-summary">
                    <h2>Приключване на поръчката</h2>
                    <div class="summary-row">
                        <span>Общо</span>
                        <span>1784 лв.</span>
                    </div>
                    <div class="summary-row">
                        <span>Доставка</span>
                        <span>6 лв.</span>
                    </div>
                    <div class="summary-row">
                        <span>ДДС</span>
                        <span>357,4 лв.</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span>2144,4 лв.</span>
                    </div>
                    <button class="checkout-btn">
                        <a href="payment.php" class="checkout-link">Продължете към плащане</a>
                    </button>
                    <a href="catalog.php" class="continue-shopping">Продължете към пазаруването</a>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
</body>
</html>
