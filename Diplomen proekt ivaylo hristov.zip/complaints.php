<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include 'config/db.php';
include 'includes/head.php';

// Handle form submission
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $category = isset($_POST['category']) ? $_POST['category'] : 'other';
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : null;
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : null;
    
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;

    // Validation
    if (empty($title)) {
        $error = 'Заглавието на оплакването е задължително.';
    } elseif (empty($email)) {
        $error = 'Email адресът е задължителен.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Невалиден email адрес.';
    } elseif (empty($phone)) {
        $error = 'Телефонният номер е задължителен.';
    } elseif (empty($description)) {
        $error = 'Описанието на оплакването е задължително.';
    } elseif (strlen($title) < 10) {
        $error = 'Заглавието трябва да бъде поне 10 знака дълго.';
    } elseif (strlen($description) < 10) {
        $error = 'Описанието трябва да бъде поне 10 знака дълго.';
    } else {
        // Insert into database
        $title = $conn->real_escape_string($title);
        $email = $conn->real_escape_string($email);
        $phone = $conn->real_escape_string($phone);
        $description = $conn->real_escape_string($description);
        $category = $conn->real_escape_string($category);
        
        $sql = "INSERT INTO complaints (user_id, email, phone, product_id, order_id, title, description, category, status, priority) 
                VALUES ($user_id, '$email', '$phone', " . ($product_id ?: 'NULL') . ", " . ($order_id ?: 'NULL') . ", '$title', '$description', '$category', 'new', 'medium')";
        
        if ($conn->query($sql)) {
            $success = true;
            $title = '';
            $email = '';
            $phone = '';
            $description = '';
            $category = 'other';
            $product_id = '';
            $order_id = '';
        } else {
            $error = 'Неуспешно подаване на оплакване. Моля, опитайте отново.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подай оплакване - Dronche</title>
    <link rel="stylesheet" href="homepage.css">
    <style>
        .complaint-container {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .complaint-container h1 {
            color: #344e41;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .complaint-container p {
            color: #666;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #344e41;
            font-weight: bold;
            font-size: 14px;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #e8e6df;
            border-radius: 4px;
            font-size: 14px;
            font-family: Arial, sans-serif;
        }

        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #DBF227;
            box-shadow: 0 0 5px rgba(251, 133, 0, 0.2);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .submit-btn {
            background-color: #005C53;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }

        .submit-btn:hover {
            background-color: #aabc20;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }

        .info-box {
            background-color: #e7f3ff;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 4px;
        }

        .info-box p {
            margin: 0;
            color: #0056b3;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar_selector.php'; ?>

    <div class="complaint-container">
        <h1>Подай оплакване</h1>
        <p>Ценим вашето мнение. Ако имате проблеми или забележки, моля, уведомете ни.</p>

        <?php if ($success): ?>
            <div class="success-message">
                <strong>✓ Успех!</strong> Вашето оплакване е подадено успешно. Ще го разгледаме в най-краткият срок и ще се свържем с вас.
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-message">
                <strong>✗ Грешка:</strong> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <div class="info-box">
            <p><strong>ℹ️ Забележка:</strong> Моля, дайте колкото се може повече детайли, за да ни помогнете да разберем и разрешим вашия проблем бързо.</p>
        </div>

        <form method="POST" action="complaints.php" accept-charset="UTF-8">
            <div class="form-group">
                <label for="title">Заглавие на оплакването *</label>
                <input type="text" id="title" name="title" placeholder="Кратко заглавие на вашето оплакване" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email адрес *</label>
                <input type="email" id="email" name="email" placeholder="Вашия email адрес" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">Телефонен номер *</label>
                <input type="tel" id="phone" name="phone" placeholder="Вашия телефонен номер" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="category">Категория на оплакването *</label>
                <select id="category" name="category" required>
                    <option value="product_quality">Качество на продукта</option>
                    <option value="shipping">Проблем с доставката</option>
                    <option value="customer_service">Обслужване на клиенти</option>
                    <option value="other">Друго</option>
                </select>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="product_id">ID на продукт (Опционално)</label>
                    <input type="number" id="product_id" name="product_id" placeholder="Оставете празно, ако не е свързано с продукт" value="<?php echo isset($_POST['product_id']) ? htmlspecialchars($_POST['product_id']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="order_id">ID на поръчка (Опционално)</label>
                    <input type="number" id="order_id" name="order_id" placeholder="Оставете празно, ако не е свързано с поръчка" value="<?php echo isset($_POST['order_id']) ? htmlspecialchars($_POST['order_id']) : ''; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="description">Подробно описание на оплакването *</label>
                <textarea id="description" name="description" placeholder="Моля, опишете вашето оплакване подробно..." required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
            </div>

            <button type="submit" class="submit-btn">Подай оплакване</button>
        </form>
    </div>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
