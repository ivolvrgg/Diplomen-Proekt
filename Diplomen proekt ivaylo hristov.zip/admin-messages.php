<?php
$page_title = 'Contact Messages - Admin';
$page_css = 'admin.css';
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
<?php include 'includes/admin_check.php'; ?>

<main id="main-content">
    <div class="admin-container">
        <div class="admin-header">
            <h1>Съобщения от контактна форма</h1>
            <div class="header-actions">
                <a href="admin.php" class="btn-back">Назад към админ панел</a>
            </div>
        </div>

        <div class="messages-section">
            <?php
            // Get filter status
            $filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
            $validFilters = ['all', 'new', 'read', 'replied'];
            if (!in_array($filter, $validFilters)) {
                $filter = 'all';
            }

            // Build query
            $query = "SELECT * FROM contact_messages";
            if ($filter !== 'all') {
                $query .= " WHERE status = '" . $conn->real_escape_string($filter) . "'";
            }
            $query .= " ORDER BY created_at DESC";

            $result = $conn->query($query);
            $total_messages = $result ? $result->num_rows : 0;

            // Handle mark as read/replied
            if (isset($_POST['action']) && isset($_POST['message_id'])) {
                $message_id = intval($_POST['message_id']);
                $action = isset($_POST['action']) ? $_POST['action'] : '';
                
                if ($action === 'read' || $action === 'replied') {
                    $status = $action === 'read' ? 'read' : 'replied';
                    $conn->query("UPDATE contact_messages SET status = '$status' WHERE id = $message_id");
                }
            }

            // Re-fetch after potential update
            $result = $conn->query($query);
            ?>

            <div class="filters">
                <a href="admin-messages.php?filter=all" class="filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">
                    Всички
                </a>
                <a href="admin-messages.php?filter=new" class="filter-btn <?php echo $filter === 'new' ? 'active' : ''; ?>">
                    Нови
                </a>
                <a href="admin-messages.php?filter=read" class="filter-btn <?php echo $filter === 'read' ? 'active' : ''; ?>">
                    Прочетени
                </a>
                <a href="admin-messages.php?filter=replied" class="filter-btn <?php echo $filter === 'replied' ? 'active' : ''; ?>">
                    Отговорени
                </a>
            </div>

            <?php if ($total_messages > 0): ?>
                <div class="messages-table-wrapper">
                    <table class="messages-table">
                        <thead>
                            <tr>
                                <th>Статус</th>
                                <th>Име</th>
                                <th>Email</th>
                                <th>Тема</th>
                                <th>Дата</th>
                                <th>Действие</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($message = $result->fetch_assoc()): ?>
                                <tr class="message-row <?php echo $message['status']; ?>">
                                    <td class="status-cell">
                                        <span class="status-badge status-<?php echo $message['status']; ?>">
                                            <?php 
                                            $statusText = [
                                                'new' => 'Ново',
                                                'read' => 'Прочетено',
                                                'replied' => 'Отговорено'
                                            ];
                                            echo $statusText[$message['status']] ?? $message['status'];
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($message['name']); ?></td>
                                    <td><a href="mailto:<?php echo htmlspecialchars($message['email']); ?>"><?php echo htmlspecialchars($message['email']); ?></a></td>
                                    <td><?php echo htmlspecialchars(substr($message['subject'], 0, 50)); ?></td>
                                    <td><?php echo date('d.m.Y H:i', strtotime($message['created_at'])); ?></td>
                                    <td class="actions-cell">
                                        <a href="javascript:void(0);" class="btn-view" onclick="showMessageModal(<?php echo $message['id']; ?>)">Преглед</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-messages">
                    <p>Няма съобщения в този филтър.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal for viewing full message -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeMessageModal()">&times;</span>
            <div id="modalBody" class="modal-body">
                <!-- Content loaded via JavaScript -->
            </div>
        </div>
    </div>
</main>

<style>
    .admin-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .admin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        padding: 20px;
        background-color: #344e41;
        color: white;
        border-radius: 8px;
    }

    .admin-header h1 {
        margin: 0;
        font-size: 28px;
    }

    .header-actions {
        display: flex;
        gap: 10px;
    }

    .btn-back {
        background-color: #fb8500;
        color: white;
        padding: 10px 20px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
        font-size: 14px;
    }

    .btn-back:hover {
        background-color: #e07000;
    }

    .messages-section {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
    }

    .filters {
        display: flex;
        gap: 10px;
        padding: 20px;
        border-bottom: 1px solid #ddd;
        flex-wrap: wrap;
    }

    .filter-btn {
        padding: 8px 16px;
        border: 2px solid #ddd;
        background-color: white;
        color: #333;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.3s ease;
        font-size: 14px;
    }

    .filter-btn:hover {
        border-color: #344e41;
        color: #344e41;
    }

    .filter-btn.active {
        background-color: #344e41;
        color: white;
        border-color: #344e41;
    }

    .messages-table-wrapper {
        overflow-x: auto;
    }

    .messages-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
    }

    .messages-table thead {
        background-color: #f5f5f5;
    }

    .messages-table th {
        padding: 12px;
        text-align: left;
        color: #344e41;
        font-weight: 600;
        border-bottom: 2px solid #ddd;
    }

    .messages-table td {
        padding: 12px;
        border-bottom: 1px solid #ddd;
    }

    .messages-table tbody tr:hover {
        background-color: #f9f9f9;
    }

    .status-cell {
        text-align: center;
    }

    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .status-new {
        background-color: #ffc107;
        color: #333;
    }

    .status-read {
        background-color: #17a2b8;
        color: white;
    }

    .status-replied {
        background-color: #28a745;
        color: white;
    }

    .actions-cell {
        text-align: center;
    }

    .btn-view {
        background-color: #344e41;
        color: white;
        padding: 6px 12px;
        border-radius: 4px;
        text-decoration: none;
        cursor: pointer;
        border: none;
        font-size: 12px;
        transition: all 0.3s ease;
    }

    .btn-view:hover {
        background-color: #2a3f37;
    }

    .no-messages {
        padding: 40px;
        text-align: center;
        color: #999;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        animation: fadeIn 0.3s ease;
    }

    .modal.show {
        display: block;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 0;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        max-width: 700px;
        max-height: 80vh;
        overflow: auto;
        animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
        from {
            transform: translateY(-50px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        padding: 10px 15px;
        cursor: pointer;
        background-color: #f5f5f5;
        display: block;
        border-bottom: 1px solid #ddd;
    }

    .close:hover {
        color: #000;
    }

    .modal-body {
        padding: 30px;
    }

    .message-detail {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }

    .detail-group {
        display: flex;
        flex-direction: column;
    }

    .detail-label {
        font-weight: 600;
        color: #344e41;
        font-size: 12px;
        text-transform: uppercase;
        margin-bottom: 5px;
    }

    .detail-value {
        color: #333;
        word-break: break-word;
    }

    .message-content {
        background-color: #f9f9f9;
        padding: 15px;
        border-radius: 4px;
        border-left: 4px solid #fb8500;
        margin: 20px 0;
        white-space: pre-wrap;
        word-wrap: break-word;
    }

    .modal-actions {
        display: flex;
        gap: 10px;
        justify-content: flex-end;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #ddd;
    }

    .btn-action {
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .btn-mark-read {
        background-color: #17a2b8;
        color: white;
    }

    .btn-mark-read:hover {
        background-color: #138496;
    }

    .btn-mark-replied {
        background-color: #28a745;
        color: white;
    }

    .btn-mark-replied:hover {
        background-color: #218838;
    }

    .btn-close-modal {
        background-color: #ddd;
        color: #333;
    }

    .btn-close-modal:hover {
        background-color: #ccc;
    }

    @media (max-width: 768px) {
        .admin-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }

        .filters {
            font-size: 12px;
        }

        .filter-btn {
            padding: 6px 12px;
            font-size: 12px;
        }

        .message-detail {
            grid-template-columns: 1fr;
        }

        .messages-table {
            font-size: 12px;
        }

        .messages-table th,
        .messages-table td {
            padding: 8px;
        }

        .btn-view {
            padding: 4px 8px;
            font-size: 11px;
        }
    }
</style>

<script>
function showMessageModal(messageId) {
    fetch('api/get_contact_message.php?id=' + messageId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const message = data.message;
                const modal = document.getElementById('messageModal');
                const modalBody = document.getElementById('modalBody');
                
                let statusText = {
                    'new': 'Ново',
                    'read': 'Прочетено',
                    'replied': 'Отговорено'
                };

                modalBody.innerHTML = `
                    <div class="message-detail">
                        <div class="detail-group">
                            <span class="detail-label">Име</span>
                            <span class="detail-value">${escapeHtml(message.name)}</span>
                        </div>
                        <div class="detail-group">
                            <span class="detail-label">Email</span>
                            <span class="detail-value"><a href="mailto:${escapeHtml(message.email)}">${escapeHtml(message.email)}</a></span>
                        </div>
                        <div class="detail-group">
                            <span class="detail-label">Телефон</span>
                            <span class="detail-value">${message.phone ? escapeHtml(message.phone) : 'N/A'}</span>
                        </div>
                        <div class="detail-group">
                            <span class="detail-label">Дата</span>
                            <span class="detail-value">${new Date(message.created_at).toLocaleString('bg-BG')}</span>
                        </div>
                    </div>
                    
                    <div class="detail-group">
                        <span class="detail-label">Тема</span>
                        <span class="detail-value">${escapeHtml(message.subject)}</span>
                    </div>
                    
                    <div class="message-content">${escapeHtml(message.message)}</div>
                    
                    <div class="modal-actions">
                        ${message.status !== 'read' ? `<form method="POST" style="display:inline;">
                            <input type="hidden" name="message_id" value="${message.id}">
                            <input type="hidden" name="action" value="read">
                            <button type="submit" class="btn-action btn-mark-read">Маркирай като прочетено</button>
                        </form>` : ''}
                        ${message.status !== 'replied' ? `<form method="POST" style="display:inline;">
                            <input type="hidden" name="message_id" value="${message.id}">
                            <input type="hidden" name="action" value="replied">
                            <button type="submit" class="btn-action btn-mark-replied">Маркирай като отговорено</button>
                        </form>` : ''}
                        <button onclick="closeMessageModal()" class="btn-action btn-close-modal">Затвори</button>
                    </div>
                `;
                
                modal.classList.add('show');
            }
        })
        .catch(error => console.error('Error:', error));
}

function closeMessageModal() {
    document.getElementById('messageModal').classList.remove('show');
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('messageModal');
    if (event.target === modal) {
        closeMessageModal();
    }
}
</script>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>
