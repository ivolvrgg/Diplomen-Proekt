<?php
// Set JSON content type immediately
header('Content-Type: application/json; charset=utf-8');

// Configure error handling BEFORE anything else
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set custom error handler to catch ALL errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("PHP Error [$errno] in $errfile:$errline - $errstr");
    // Don't stop execution
    return true;
});

// Set exception handler for uncaught exceptions
set_exception_handler(function($e) {
    http_response_code(500);
    ob_end_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Uncaught exception: ' . $e->getMessage(),
        'error_line' => $e->getLine(),
        'error_file' => $e->getFile()
    ]);
    exit;
});

// Start output buffering to catch any unexpected output
ob_start();
session_start();

// Initialize response
$response = ['success' => false, 'message' => '', 'order_id' => null];

try {
    include '../config/db.php';
    include '../includes/auth_check.php';

    error_log('Orders API: Request started');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Get request data
    $raw_input = file_get_contents('php://input');
    error_log('Orders API: Raw input length: ' . strlen($raw_input));
    if (strlen($raw_input) > 0) {
        error_log('Orders API: Raw input first 200 chars: ' . substr($raw_input, 0, 200));
    }
    
    $data = json_decode($raw_input, true);
    if (!$data) {
        error_log('Orders API: JSON decode failed, trying $_POST');
        $data = $_POST;
    }

    error_log('Orders API: Data received: ' . json_encode(['keys' => array_keys($data)]));

    // Get user info
    $user_id = get_user_id();
    if ($user_id === 0) {
        // Guest user - use NULL for database
        $db_user_id = null;
        if (!isset($_SESSION['guest_id'])) {
            $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
        }
    } else {
        $db_user_id = $user_id;
    }

    error_log('Orders API: User ID: ' . ($db_user_id ?? 'NULL'));

    // Validate required fields
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $payment_method = trim($data['payment_method'] ?? '');
    $delivery_method = trim($data['delivery_method'] ?? '');

    error_log('Orders API: After extraction and trim');
    error_log('  $data["delivery_method"] raw = ' . var_export($data['delivery_method'] ?? 'MISSING', true));
    error_log('  $delivery_method after trim = ' . var_export($delivery_method, true));
    error_log('  strlen = ' . strlen($delivery_method));
    error_log('  in_array check: ' . var_export(in_array($delivery_method, ['courier', 'econt']), true));
    
    error_log('Orders API: Raw delivery_method = "' . ($data['delivery_method'] ?? 'MISSING') . '"');
    error_log('Orders API: Trimmed delivery_method = "' . $delivery_method . '"');
    error_log('Orders API: Payment/Delivery = ' . $payment_method . '/' . $delivery_method);

    if (empty($email)) {
        throw new Exception('Имейл адресът е задължителен');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Неправилен формат на имейл адреса. Пример: example@gmail.com');
    }
    
    // Additional check for common test emails
    if (strpos($email, '@example.com') !== false || strpos($email, '@test.com') !== false) {
        throw new Exception('Моля, използвайте реален имейл адрес. @example.com и @test.com не са валидни.');
    }

    if (empty($phone)) {
        throw new Exception('Телефонният номер е задължителен');
    }

    // Basic phone validation (at least 10 digits)
    $phoneDigits = preg_replace('/\D/', '', $phone);
    if (strlen($phoneDigits) < 10) {
        throw new Exception('Неправилен телефонен номер. Моля, въведете валиден номер.');
    }

    if (!in_array($payment_method, ['card', 'cod'])) {
        throw new Exception('Неправилен начин на плащане');
    }

    if (!in_array($delivery_method, ['courier', 'econt'])) {
        error_log('Orders API: Invalid delivery_method. Received: "' . $delivery_method . '", Valid options: courier, econt');
        
        // Debug: try different comparisons
        error_log('  Checking: "' . $delivery_method . '" === "courier": ' . var_export($delivery_method === 'courier', true));
        error_log('  Checking: "' . $delivery_method . '" === "econt": ' . var_export($delivery_method === 'econt', true));
        error_log('  Hex values: ' . bin2hex($delivery_method));
        error_log('  Array contains: ' . var_export(['courier', 'econt'], true));
        
        throw new Exception('Неправилен начин на доставка');
    }

    // Get cart items
    $cart_items = [];
    $subtotal = 0;
    $invoice_requested = intval($data['invoice_requested'] ?? 0) === 1;
    
    if ($db_user_id !== null) {
        // Logged-in user - get from database
        $cart_query = "SELECT c.product_id, c.quantity, p.name, p.price, p.sale_price, p.discount_percent 
                       FROM cart c 
                       JOIN products p ON c.product_id = p.id 
                       WHERE c.user_id = $db_user_id";
        $cart_result = $conn->query($cart_query);

        if (!$cart_result || $cart_result->num_rows === 0) {
            throw new Exception('Вашата количка е празна');
        }

        while ($item = $cart_result->fetch_assoc()) {
            // Use sale price if available, otherwise use regular price
            $actual_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price'];
            $item_total = $actual_price * $item['quantity'];
            $subtotal += $item_total;
            $item['actual_price'] = $actual_price;
            $cart_items[] = $item;
        }
    } else {
        // Guest user - get from request data
        $cart_data = $data['cart'] ?? [];
        if (empty($cart_data)) {
            throw new Exception('Вашата количка е празна');
        }

        // Validate and fetch product data for each item
        foreach ($cart_data as $item) {
            $product_id = intval($item['product_id'] ?? 0);
            $quantity = intval($item['quantity'] ?? 0);

            if ($product_id <= 0 || $quantity <= 0) {
                throw new Exception('Неправилен артикул в количката');
            }

            // Get product details
            $product_query = "SELECT id, name, price, sale_price, discount_percent FROM products WHERE id = $product_id";
            $product_result = $conn->query($product_query);

            if (!$product_result || $product_result->num_rows === 0) {
                throw new Exception('Продуктът не съществува');
            }

            $product = $product_result->fetch_assoc();
            // Use sale price if available, otherwise use regular price
            $actual_price = (!empty($product['sale_price']) && $product['sale_price'] > 0) ? $product['sale_price'] : $product['price'];
            $item_total = $actual_price * $quantity;
            $subtotal += $item_total;
            
            $cart_items[] = [
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'actual_price' => $actual_price
            ];
        }
    }

    // Map delivery method slug to database ID
    $delivery_mapping = [
        'courier' => 1,
        'econt' => 3
    ];

    if (!isset($delivery_mapping[$delivery_method])) {
        throw new Exception('Неправилен начин на доставка');
    }

    $delivery_method_id = $delivery_mapping[$delivery_method];
    
    // FETCH delivery cost from database to ensure it matches the latest value
    $cost_stmt = $conn->prepare("SELECT cost FROM delivery_methods WHERE id = ? AND is_active = 1");
    $cost_stmt->bind_param("i", $delivery_method_id);
    $cost_stmt->execute();
    $cost_result = $cost_stmt->get_result();
    
    if ($cost_result->num_rows === 0) {
        throw new Exception('Неправилен начин на доставка');
    }
    
    $cost_row = $cost_result->fetch_assoc();
    $delivery_cost = floatval($cost_row['cost']);
    $cost_stmt->close();

    // Calculate order totals
    $vat = 0;
    $total = $subtotal + $delivery_cost;

    // Handle delivery address for courier method
    $shipping_address_id = null;
    $delivery_office_id = null;
    $econt_office_code = null;
    $econt_selected_address = null;
    $delivery_address = null;

    if ($delivery_method === 'courier') {
        // For courier, get address from request
        $city = trim($data['city'] ?? '');
        $street = trim($data['street'] ?? '');
        $block = trim($data['block'] ?? '');
        $entrance = trim($data['entrance'] ?? '');
        $apartment = trim($data['apartment'] ?? '');

        if (empty($city) || empty($street)) {
            throw new Exception('Адресът е задължителен за куриерска доставка');
        }

        // Build complete delivery address
        $delivery_address = $street . ', ' . $city;
        if (!empty($block)) {
            $delivery_address .= ', Блок ' . $block;
        }
        if (!empty($entrance)) {
            $delivery_address .= ', Вх. ' . $entrance;
        }
        if (!empty($apartment)) {
            $delivery_address .= ', Ап. ' . $apartment;
        }
    } else if ($delivery_method === 'econt') {
        // For ECONT, get office code from request (no database validation)
        $econt_office_code = trim($data['delivery_office_id'] ?? '') ?: trim($data['econt_office_code'] ?? '');
        $econt_selected_address = trim($data['econt_selected_address'] ?? '');
        
        if (empty($econt_office_code)) {
            throw new Exception('ECONT office code is required');
        }
        error_log('Orders API: ECONT office_code: ' . $econt_office_code . ', address: ' . $econt_selected_address);
        
        // Set delivery_office_id to NULL (ECONT uses codes, not DB IDs)
        $delivery_office_id = null;
        error_log("ECONT order: office code: $econt_office_code");
    } else {
        // For other office delivery methods, get numeric office ID
        $delivery_office_id = intval($data['delivery_office_id'] ?? 0);
        if ($delivery_office_id <= 0) {
            throw new Exception('Офисът на доставка е задължителен');
        }

        // Verify office exists
        $office_check = $conn->query("SELECT id FROM delivery_offices WHERE id = $delivery_office_id AND is_active = 1");
        if (!$office_check || $office_check->num_rows === 0) {
            throw new Exception('Неправилен офис на доставка');
        }
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Set order status based on payment method
        // Card payment: pending_payment (waiting for payment)
        // Cash on delivery: pending (order confirmed, payment on delivery)
        $order_status = ($payment_method === 'card') ? 'pending_payment' : 'pending';
        
        // Insert order using prepared statement
        $insert_order = $conn->prepare("INSERT INTO orders (user_id, status, subtotal, delivery_cost, vat, total, payment_method, delivery_method_id, delivery_office_id, delivery_address, email, phone, econt_office_code, econt_selected_address, invoice_requested, created_at, updated_at) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        
        if (!$insert_order) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        // Types: i=int, s=string, d=double/decimal
        // For nullable user_id, use NULL (mysqli will convert properly)
        $user_id_param = $db_user_id; // Keep as NULL or int
        $invoice_requested_int = $invoice_requested ? 1 : 0;
        
        // Bind parameters
        $insert_order->bind_param("isddddsiisssssi", $user_id_param, $order_status, $subtotal, $delivery_cost, $vat, $total, $payment_method, $delivery_method_id, $delivery_office_id, $delivery_address, $email, $phone, $econt_office_code, $econt_selected_address, $invoice_requested_int);
        
        error_log("Executing insert with user_id=" . ($user_id_param ?? 'NULL') . ", email=$email, invoice_requested=$invoice_requested_int");
        
        if (!$insert_order->execute()) {
            error_log('Insert failed: ' . $conn->error);
            throw new Exception('Failed to create order: ' . $conn->error);
        }
        $insert_order->close();

        $order_id = $conn->insert_id;

        // Insert order items
        $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
        
        if (!$item_stmt) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        error_log("DEBUG: Processing " . count($cart_items) . " cart items for order $order_id");
        
        foreach ($cart_items as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $unit_price = floatval($item['actual_price']);
            
            error_log("DEBUG: Item {$item['name']}: price=" . $item['price'] . ", sale_price=" . ($item['sale_price'] ?? 'NULL') . ", actual_price=" . $item['actual_price'] . ", using unit_price=$unit_price");

            $item_stmt->bind_param("iiid", $order_id, $product_id, $quantity, $unit_price);

            if (!$item_stmt->execute()) {
                throw new Exception('Failed to add order item: ' . $conn->error);
            }

            // Update product stock using prepared statement
            $stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
            if (!$stock_stmt) {
                throw new Exception('Prepare failed: ' . $conn->error);
            }
            $stock_stmt->bind_param("ii", $quantity, $product_id);
            if (!$stock_stmt->execute()) {
                throw new Exception('Failed to update stock: ' . $conn->error);
            }
            $stock_stmt->close();
        }
        $item_stmt->close();

        // Shipment creation temporarily disabled for testing - just log intent
        error_log('Orders API: Order #' . $order_id . ' created, shipment creation disabled');

        // Generate invoice if requested
        $invoice_info = null;
        if ($invoice_requested) {
            try {
                error_log('Orders API: Generating invoice for order #' . $order_id);
                
                // Get order details for invoice
                $invoice_order = $conn->query("SELECT * FROM orders WHERE id = $order_id")->fetch_assoc();
                $invoice_items = [];
                $items_result = $conn->query("SELECT p.name, oi.quantity, oi.unit_price 
                                            FROM order_items oi
                                            JOIN products p ON oi.product_id = p.id
                                            WHERE oi.order_id = $order_id");
                
                while ($item = $items_result->fetch_assoc()) {
                    $invoice_items[] = $item;
                }
                
                // Generate invoice number
                $invoice_number = 'INV-' . date('Y') . '-' . str_pad($order_id, 6, '0', STR_PAD_LEFT);
                
                // Build HTML invoice
                $invoice_html = buildInvoiceHTML($invoice_order, $invoice_items, $invoice_number);
                
                // Create invoices directory if needed
                $invoice_dir = __DIR__ . '/../uploads/invoices';
                if (!is_dir($invoice_dir)) {
                    mkdir($invoice_dir, 0755, true);
                }
                
                // Save invoice HTML file
                $invoice_path = $invoice_dir . '/' . $invoice_number . '.html';
                file_put_contents($invoice_path, $invoice_html);
                
                // Record invoice in database
                $inv_stmt = $conn->prepare("INSERT INTO invoices (order_id, user_id, invoice_number, file_path, status) VALUES (?, ?, ?, ?, 'generated')");
                $inv_stmt->bind_param("iiss", $order_id, $db_user_id, $invoice_number, $invoice_path);
                if (!$inv_stmt->execute()) {
                    throw new Exception('Failed to insert invoice record: ' . $inv_stmt->error);
                }
                $invoice_id = $conn->insert_id;
                $inv_stmt->close();
                
                $invoice_info = [
                    'invoice_number' => $invoice_number,
                    'file_path' => $invoice_path,
                    'invoice_id' => $invoice_id
                ];
                
                error_log('Orders API: Invoice generated successfully: ' . $invoice_number . ' (ID: ' . $invoice_id . ')');
            } catch (Exception $e) {
                error_log('Orders API: Invoice generation failed: ' . $e->getMessage());
            }
        }

        // Send order confirmation email
        try {
            require_once '../includes/EmailHelper.php';
            $emailer = new EmailHelper();
            
            // Get user name for email
            $user_name = $data['guest_name'] ?? 'Customer';
            if ($user_id !== 0) {
                // For logged-in users, get their full name from database
                $name_query = $conn->query("SELECT fullname FROM users WHERE id = $user_id");
                if ($name_query && $name_query->num_rows > 0) {
                    $user_data = $name_query->fetch_assoc();
                    $user_name = $user_data['fullname'];
                }
            }
            
            // Prepare order data for email
            $email_order_data = [
                'items' => $cart_items,
                'subtotal' => $subtotal,
                'vat' => $vat,
                'delivery_cost' => $delivery_cost,
                'total' => $total,
                'status' => $order_status,
                'phone' => $phone
            ];
            
            // Send and verify email was sent
            $email_sent = $emailer->sendOrderConfirmation($email, $user_name, $order_id, $email_order_data);
            if (!$email_sent) {
                error_log("WARNING: Order confirmation email failed for order #$order_id to $email");
            } else {
                error_log("INFO: Order confirmation email sent successfully for order #$order_id to $email");
            }
            
            // Send invoice email if generated
            if ($invoice_info) {
                try {
                    $emailer->sendInvoice(
                        $email, 
                        $user_name, 
                        $invoice_info['invoice_number'], 
                        $invoice_info['file_path'],
                        $invoice_info['invoice_id'] ?? null
                    );
                    error_log("INFO: Invoice email sent for order #$order_id");
                } catch (Exception $e) {
                    error_log("WARNING: Failed to send invoice email: " . $e->getMessage());
                }
            }
        } catch (Exception $e) {
            // Log email error but don't fail the order
            error_log('Failed to send order confirmation email for order #' . $order_id . ': ' . $e->getMessage());
        }

        // ONLY clear cart after all operations succeed
        $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_stmt->bind_param("i", $db_user_id);
        if ($clear_stmt->execute()) {
            $clear_stmt->close();
        }
        
        // Clear session cart
        $_SESSION['cart'] = [];

        // COMMIT the transaction to save everything to database
        if (!$conn->commit()) {
            throw new Exception('Failed to commit transaction: ' . $conn->error);
        }

        $response['success'] = true;
        $response['message'] = 'Order created successfully';
        $response['order_id'] = $order_id;
        $response['total'] = $total;
        // Redirect to homepage for guests, profile for logged-in users
        $response['redirect_url'] = ($user_id === 0) ? '/Diplomna_rabota/homepage.php' : '/Diplomna_rabota/profile.php?tab=orders';

    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
    // Log the full error for debugging
    error_log('api/orders.php ERROR: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
}

// Ensure absolutely clean output before JSON response
try {
    // End all output buffering levels
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Create the JSON response
    $json_response = json_encode($response, JSON_UNESCAPED_UNICODE);
    
    // Log what we're about to send
    error_log('api/orders.php RESPONSE: ' . $json_response);
    
    // Send the response
    echo $json_response;
} catch (Exception $e) {
    // If something goes wrong in output, log it
    error_log('api/orders.php OUTPUT ERROR: ' . $e->getMessage());
    echo '{"success":false,"message":"Output encoding error"}';
}

/**
 * Build HTML invoice content
 */
function buildInvoiceHTML($order, $items, $invoice_number) {
    global $conn;
    
    // Get delivery method name
    $delivery_query = $conn->query("SELECT name FROM delivery_methods WHERE id = " . intval($order['delivery_method_id']));
    $delivery_method = $delivery_query ? $delivery_query->fetch_assoc() : ['name' => 'Unknown'];
    
    $subtotal = 0;
    $items_html = '';
    
    foreach ($items as $item) {
        $unit_price = floatval($item['unit_price']);
        $item_total = $unit_price * intval($item['quantity']);
        $subtotal += $item_total;
        $items_html .= "
            <tr>
                <td style='padding: 12px; border-bottom: 1px solid #e0e0e0;'>" . htmlspecialchars($item['name']) . "</td>
                <td style='padding: 12px; border-bottom: 1px solid #e0e0e0; text-align: center;'>" . intval($item['quantity']) . "</td>
                <td style='padding: 12px; border-bottom: 1px solid #e0e0e0; text-align: right;'>€ " . number_format($unit_price, 2) . "</td>
                <td style='padding: 12px; border-bottom: 1px solid #e0e0e0; text-align: right;'>€ " . number_format($item_total, 2) . "</td>
            </tr>
        ";
    }
    
    $total_with_delivery = $subtotal + $order['delivery_cost'];
    $order_date = date('d.m.Y', strtotime($order['created_at']));
    $order_id_formatted = str_pad($order['id'], 6, '0', STR_PAD_LEFT);
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: 'Arial', sans-serif;
                color: #333;
                background: white;
            }
            .invoice-container {
                max-width: 900px;
                margin: 0 auto;
                padding: 40px 30px;
                background: white;
            }
            /* Header with logo and company info */
            .header {
                display: grid;
                grid-template-columns: 200px 1fr;
                gap: 40px;
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 3px solid #588157;
            }
            .logo-section {
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
            }
            .logo {
                width: 150px;
                height: 80px;
                background: linear-gradient(135deg, #588157 0%, #7a9f6d 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 8px;
                color: white;
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 10px;
                text-align: center;
            }
            .company-name {
                font-size: 24px;
                font-weight: bold;
                color: #588157;
                margin-top: 10px;
            }
            .company-tagline {
                font-size: 12px;
                color: #999;
                margin-top: 5px;
            }
            /* Invoice info on the right */
            .invoice-header {
                text-align: right;
            }
            .invoice-title {
                font-size: 32px;
                font-weight: bold;
                color: #588157;
                margin-bottom: 20px;
            }
            .invoice-details {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 30px;
                font-size: 13px;
                line-height: 1.8;
            }
            .detail-row {
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }
            .detail-label {
                font-weight: bold;
                color: #666;
                min-width: 120px;
            }
            .detail-value {
                color: #333;
            }
            /* Customer info section */
            .customer-section {
                display: grid;
                grid-template-columns: 1fr 1fr 1fr;
                gap: 40px;
                margin: 40px 0;
                padding: 0;
            }
            .customer-block {
                padding: 0;
            }
            .customer-block-title {
                font-size: 11px;
                font-weight: bold;
                text-transform: uppercase;
                color: #999;
                margin-bottom: 15px;
                letter-spacing: 1px;
            }
            .customer-block-content {
                font-size: 13px;
                line-height: 1.8;
                color: #333;
            }
            .customer-block-content p {
                margin: 5px 0;
            }
            /* Items table */
            .items-section {
                margin: 40px 0;
            }
            .items-table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 0;
            }
            .items-table thead tr {
                background-color: #f5f5f5;
                border-bottom: 2px solid #588157;
            }
            .items-table th {
                padding: 15px 12px;
                text-align: left;
                font-weight: bold;
                font-size: 13px;
                color: #333;
                border: none;
            }
            .items-table th:nth-child(2),
            .items-table th:nth-child(3),
            .items-table th:nth-child(4) {
                text-align: right;
            }
            .items-table td {
                padding: 15px 12px;
                border-bottom: 1px solid #f0f0f0;
                font-size: 13px;
            }
            .items-table td:nth-child(2),
            .items-table td:nth-child(3),
            .items-table td:nth-child(4) {
                text-align: right;
            }
            /* Totals section */
            .totals-section {
                display: grid;
                grid-template-columns: 1fr 250px;
                gap: 40px;
                margin-top: 40px;
            }
            .totals-right {
                text-align: right;
            }
            .total-row {
                display: flex;
                justify-content: space-between;
                padding: 12px 0;
                font-size: 13px;
                border-bottom: 1px solid #e0e0e0;
            }
            .total-row.total-final {
                border-bottom: 2px solid #588157;
                border-top: 2px solid #588157;
                padding: 15px 0;
                font-size: 16px;
                font-weight: bold;
                color: #588157;
            }
            .total-label {
                font-weight: 500;
            }
            .total-value {
                min-width: 100px;
                text-align: right;
            }
            /* Footer */
            .footer {
                margin-top: 50px;
                padding-top: 30px;
                border-top: 1px solid #e0e0e0;
                text-align: center;
                font-size: 12px;
                color: #999;
            }
            .footer p {
                margin: 5px 0;
            }
            /* Print styles */
            @media print {
                body {
                    margin: 0;
                    padding: 0;
                }
                .invoice-container {
                    padding: 0;
                    max-width: 100%;
                }
            }
        </style>
    </head>
    <body>
        <div class='invoice-container'>
            <!-- Main Header -->
            <div class='header' style='text-align: center;'>
                <div class='invoice-header' style='width: 100%;'>
                    <div class='invoice-title'>ФАКТУРА</div>
                    <div class='invoice-details'>
                        <div>
                            <div class='detail-row' style='justify-content: center;'>
                                <span class='detail-label'>Фактура №:</span>
                                <span class='detail-value'>" . htmlspecialchars($invoice_number) . "</span>
                            </div>
                            <div class='detail-row' style='justify-content: center;'>
                                <span class='detail-label'>Дата:</span>
                                <span class='detail-value'>" . $order_date . "</span>
                            </div>
                        </div>
                        <div>
                            <div class='detail-row' style='justify-content: center;'>
                                <span class='detail-label'>Поръчка №:</span>
                                <span class='detail-value'>ORD-" . $order_id_formatted . "</span>
                            </div>
                            <div class='detail-row' style='justify-content: center;'>
                                <span class='detail-label'>Статус:</span>
                                <span class='detail-value'>" . htmlspecialchars(ucfirst($order['status'])) . "</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Customer Info Section -->
            <div class='customer-section'>
                <div class='customer-block'>
                    <div class='customer-block-title'>Фактуриран на</div>
                    <div class='customer-block-content'>
                        <p>" . htmlspecialchars($order['email']) . "</p>
                        <p>" . htmlspecialchars($order['phone']) . "</p>
                    </div>
                </div>
                <div class='customer-block'>
                    <div class='customer-block-title'>Начин на доставка</div>
                    <div class='customer-block-content'>
                        <p>" . htmlspecialchars($delivery_method['name']) . "</p>
                    </div>
                </div>
                <div class='customer-block'>
                    <div class='customer-block-title'>Начин на плащане</div>
                    <div class='customer-block-content'>
                        <p>" . (htmlspecialchars($order['payment_method']) === 'cod' ? 'Плащане при доставка' : 'Платежна карта') . "</p>
                    </div>
                </div>
            </div>
            
            <!-- Items Table -->
            <div class='items-section'>
                <table class='items-table'>
                    <thead>
                        <tr>
                            <th>Описание</th>
                            <th>Количество</th>
                            <th>Единична цена</th>
                            <th>Сума</th>
                        </tr>
                    </thead>
                    <tbody>
                        {$items_html}
                    </tbody>
                </table>
            </div>
            
            <!-- Totals -->
            <div class='totals-section'>
                <div></div>
                <div class='totals-right'>
                    <div class='total-row'>
                        <span class='total-label'>Подсумата:</span>
                        <span class='total-value'>€ " . number_format($subtotal, 2) . "</span>
                    </div>
                    <div class='total-row'>
                        <span class='total-label'>Доставка:</span>
                        <span class='total-value'>€ " . number_format($order['delivery_cost'], 2) . "</span>
                    </div>
                    <div class='total-row total-final'>
                        <span class='total-label'>ОБЩА СУМА:</span>
                        <span class='total-value'>€ " . number_format($total_with_delivery, 2) . "</span>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return $html;
}

// Response handling below...
