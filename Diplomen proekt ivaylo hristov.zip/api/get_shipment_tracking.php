<?php
/**
 * Get Shipment Tracking Endpoint
 * 
 * Returns tracking information for a shipment
 * 
 * Request:
 * GET /api/get_shipment_tracking.php?shipment_id=SPEEDY_123&method=speedy
 * or
 * GET /api/get_shipment_tracking.php?order_id=123&method=speedy
 * 
 * Response:
 * {
 *   "success": true,
 *   "data": {
 *     "shipment_id": "SPEEDY_123",
 *     "status": "in_transit",
 *     "created_at": "2024-03-16 10:00:00",
 *     "events": [
 *       {
 *         "timestamp": "2024-03-16 10:00:00",
 *         "status": "Created",
 *         "location": "Shipper",
 *         "message": "Shipment created"
 *       },
 *       {
 *         "timestamp": "2024-03-16 11:30:00",
 *         "status": "Picked Up",
 *         "location": "Sofia Center",
 *         "message": "Shipment picked up"
 *       }
 *     ]
 *   }
 * }
 */

ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
ob_clean();
header('Content-Type: application/json; charset=utf-8');

// Load required files
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/delivery-service.php';
require_once __DIR__ . '/../includes/speedy-service.php';
require_once __DIR__ . '/../includes/econt-service.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Invalid request method');
    }
    
    // Get parameters
    $shipment_id = trim($_GET['shipment_id'] ?? '');
    $order_id = intval($_GET['order_id'] ?? 0);
    $method = trim($_GET['method'] ?? '');
    
    // Need either shipment_id or order_id
    if (empty($shipment_id) && $order_id <= 0) {
        throw new Exception('Shipment ID or Order ID required');
    }
    
    // If only order_id provided, get shipment_id from database
    if (empty($shipment_id) && $order_id > 0) {
        $stmt = $conn->prepare("SELECT external_shipment_id, delivery_method_id FROM orders WHERE id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        
        if ($result->num_rows === 0) {
            throw new Exception('Order not found');
        }
        
        $order = $result->fetch_assoc();
        $shipment_id = $order['external_shipment_id'];
        
        // Determine method from order if not provided
        if (empty($method)) {
            $method_mapping = [
                1 => 'courier',
                2 => 'speedy',
                3 => 'econt'
            ];
            $method = $method_mapping[$order['delivery_method_id']] ?? 'courier';
        }
    }
    
    if (empty($shipment_id)) {
        throw new Exception('Shipment not found');
    }
    
    // Validate method
    if (!in_array($method, ['speedy', 'econt', 'courier'])) {
        throw new Exception('Invalid delivery method');
    }
    
    // Get appropriate service
    $service = DeliveryServiceFactory::getService($method);
    
    // Fetch tracking
    $result = $service->getTracking($shipment_id);
    
    // Return response
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    header('HTTP/1.1  400 Bad Request');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
}
?>
