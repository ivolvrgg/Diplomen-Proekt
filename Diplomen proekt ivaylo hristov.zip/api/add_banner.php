<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ob_start();

include '../config/db.php';
include '../includes/admin_check.php';

$accidental_output = ob_get_clean();

header('Content-Type: application/json');

if (!empty($accidental_output)) {
    echo json_encode(['success' => false, 'message' => 'Output from includes: ' . substr($accidental_output, 0, 200)]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $error_code = $_FILES['image']['error'] ?? 'no file received';
    echo json_encode(['success' => false, 'message' => 'Upload error: ' . $error_code]);
    exit;
}

$link_type = $_POST['link_type'] ?? 'sales';
$link_value = $_POST['link_value'] ?? '';

if (!in_array($link_type, ['sales', 'category', 'custom'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid link type']);
    exit;
}

// Build link URL based on link type
$link_url = '#';
if ($link_type === 'sales') {
    $sale_percent = isset($_POST['sale_percent']) ? intval($_POST['sale_percent']) : 0;
    if ($sale_percent > 0) {
        $link_url = 'category-products.php?sale=1&discount=' . $sale_percent;
    } else {
        $link_url = 'category-products.php?sale=1';
    }
} elseif ($link_type === 'category') {
    if (empty($link_value)) {
        echo json_encode(['success' => false, 'message' => 'Link value is required']);
        exit;
    }
    // Build category link
    $category_ids = array_map('trim', explode(',', $link_value));
    if (count($category_ids) === 1) {
        $link_url = 'category-products.php?id=' . intval($category_ids[0]);
    } else {
        $ids = implode(',', array_map('intval', $category_ids));
        $link_url = 'category-products.php?ids=' . $ids;
    }
} elseif ($link_type === 'custom') {
    if (empty($link_value)) {
        echo json_encode(['success' => false, 'message' => 'Link value is required']);
        exit;
    }
    $link_url = htmlspecialchars($link_value);
}

// Create uploads/banners directory
$upload_dir = '../uploads/banners/';
if (!is_dir($upload_dir)) {
    if (!@mkdir($upload_dir, 0777, true)) {
        echo json_encode(['success' => false, 'message' => 'Cannot create upload directory: ' . realpath('..') . '/uploads/banners/']);
        exit;
    }
}

if (!is_writable($upload_dir)) {
    echo json_encode(['success' => false, 'message' => 'Upload directory is not writable: ' . $upload_dir]);
    exit;
}

$file = $_FILES['image'];
$file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

if (!in_array($file_ext, $allowed_exts)) {
    echo json_encode(['success' => false, 'message' => 'Invalid file type. Allowed: jpg, jpeg, png, gif, webp']);
    exit;
}

if ($file['size'] > 5 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'File too large (max 5MB)']);
    exit;
}

$filename = 'banner_' . time() . '_' . uniqid() . '.' . $file_ext;
$file_path = $upload_dir . $filename;

if (!move_uploaded_file($file['tmp_name'], $file_path)) {
    echo json_encode(['success' => false, 'message' => 'Failed to move uploaded file']);
    exit;
}

// Check banners table exists
$table_check = $conn->query("SHOW TABLES LIKE 'banners'");
if ($table_check && $table_check->num_rows === 0) {
    @unlink($file_path);
    echo json_encode(['success' => false, 'message' => 'Banners table does not exist. Run run-banners-migration.php first']);
    exit;
}

// Get next sort_order
$sort_result = $conn->query("SELECT MAX(sort_order) as max_sort FROM banners");
$sort_row = $sort_result->fetch_assoc();
$sort_order = ($sort_row['max_sort'] ?? 0) + 1;

// Build image URL 
$image_url = 'uploads/banners/' . $filename;

// Get title and description from form or use defaults
$title = $_POST['title'] ?? 'Banner ' . date('Y-m-d H:i:s');
$description = $_POST['description'] ?? '';

try {
    $stmt = $conn->prepare("INSERT INTO banners (title, description, image_url, link_url, is_active, sort_order) VALUES (?, ?, ?, ?, 1, ?)");
    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->bind_param("ssssi", $title, $description, $image_url, $link_url, $sort_order);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Banner uploaded successfully', 'banner_id' => $stmt->insert_id]);
    } else {
        throw new Exception('Execute failed: ' . $stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    @unlink($file_path);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>
