<?php
require_once '../config/db.php';

$user_id = intval($_GET['user_id'] ?? 0);
if (!$user_id) exit;

$result = $conn->query("SELECT profile_picture_data, profile_picture_mime_type FROM users WHERE id = $user_id");
if (!$result || $result->num_rows == 0) exit;

$row = $result->fetch_assoc();
if (empty($row['profile_picture_data'])) exit;

header('Content-Type: ' . ($row['profile_picture_mime_type'] ?? 'image/jpeg'));
echo $row['profile_picture_data'];
exit;
?>
