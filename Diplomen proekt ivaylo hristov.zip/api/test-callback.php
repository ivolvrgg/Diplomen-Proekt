<?php
echo "Test OK - google-callback.php is accessible";
?>
