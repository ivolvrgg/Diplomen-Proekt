<?php
session_start();
header('Content-Type: application/json');
include '../config/db.php';
include '../includes/admin_check.php';

$response = array();

$banner_id = isset($_POST['id']) ? intval($_POST['id']) : 0;

if (!$banner_id) {
    echo json_encode(['success' => false, 'message' => 'Banner ID required']);
    exit;
}

// Get banner info
$banner = $conn->query("SELECT * FROM banners WHERE id = $banner_id");
if (!$banner || $banner->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Banner not found']);
    exit;
}

$banner_data = $banner->fetch_assoc();

// Delete from database
$query = "DELETE FROM banners WHERE id = $banner_id";

if ($conn->query($query) === TRUE) {
// Delete image file by extracting filename from path
$image_url = $banner_data['image_url'];
if (!empty($image_url)) {
    $file_path = '../' . $image_url;
    @unlink($file_path);
}
    
    echo json_encode(['success' => true, 'message' => 'Banner deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

$conn->close();
?>
