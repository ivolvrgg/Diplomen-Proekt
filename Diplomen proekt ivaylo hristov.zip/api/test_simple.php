<?php
header('Content-Type: application/json; charset=utf-8');
echo '{"success":true,"test":"ok"}';
?>