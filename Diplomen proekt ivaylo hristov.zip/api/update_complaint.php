<?php
header('Content-Type: application/json');
session_start();
if(!isset($_SESSION['is_admin'])){echo '{"success":false}';exit;}
$conn=new mysqli('localhost','root','','dron_db');
$conn->set_charset("utf8mb4");
$id=isset($_POST['id'])?intval($_POST['id']):0;
$st=isset($_POST['status'])?$_POST['status']:'';
$rsp=isset($_POST['response'])?$_POST['response']:'';
if(!$id){echo '{"success":false}';exit;}
$u=[];
if($st){$st=$conn->real_escape_string($st);$u[]="status='$st'";if($st=='resolved'){$u[]="resolved_at=NOW()";}}
if($rsp){$rsp=$conn->real_escape_string($rsp);$u[]="response='$rsp'";}
if(!empty($u)){$u[]="updated_at=NOW()";
if($conn->query("UPDATE complaints SET ".implode(",",$u)." WHERE id=$id")){echo '{"success":true}';}else{echo '{"success":false}';}}else{echo '{"success":false}';}
