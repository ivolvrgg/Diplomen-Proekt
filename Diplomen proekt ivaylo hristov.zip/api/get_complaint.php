<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit;
    }

    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Invalid complaint ID']);
        exit;
    }

    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    $result = $conn->query("SELECT * FROM complaints WHERE id=$id");
    
    if (!$result) {
        throw new Exception('Query failed: ' . $conn->error);
    }

    $complaint = null;
    if ($result->num_rows > 0) {
        $complaint = $result->fetch_assoc();
    }

    echo json_encode(['success' => ($complaint ? true : false), 'complaint' => $complaint], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
