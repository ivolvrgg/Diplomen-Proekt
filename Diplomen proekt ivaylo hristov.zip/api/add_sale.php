<?php
session_start();
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : null;
    $discount_percent = isset($_POST['discount_percent']) ? intval($_POST['discount_percent']) : null;
    $sale_price = isset($_POST['sale_price']) ? floatval($_POST['sale_price']) : null;

    if (!$product_id) {
        echo json_encode(['success' => false, 'message' => 'Product ID is required']);
        exit;
    }

    // Get product to have original price
    $query = "SELECT price FROM products WHERE id = $product_id";
    $result = $conn->query($query);
    
    if (!$result || $result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        exit;
    }

    $product = $result->fetch_assoc();
    $original_price = $product['price'];

    // Calculate values
    if ($discount_percent !== null && $discount_percent > 0 && $discount_percent < 100) {
        $calculated_sale_price = $original_price * (1 - $discount_percent / 100);
        $calculated_discount = $discount_percent;
    } elseif ($sale_price !== null && $sale_price > 0 && $sale_price < $original_price) {
        $calculated_sale_price = $sale_price;
        $calculated_discount = round((1 - $sale_price / $original_price) * 100);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid sale price or discount percent']);
        exit;
    }

    // Update product with sale
    $update_query = "UPDATE products SET sale_price = " . round($calculated_sale_price, 2) . ", 
                     discount_percent = $calculated_discount WHERE id = $product_id";
    
    if ($conn->query($update_query)) {
        echo json_encode([
            'success' => true, 
            'message' => 'Sale added successfully',
            'sale_price' => round($calculated_sale_price, 2),
            'discount_percent' => $calculated_discount
        ]);
    } else {
        throw new Exception('Update failed: ' . $conn->error);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
