<?php
session_start();
header('Content-Type: application/json');

require_once '../config/db.php';
require_once '../includes/auth_check.php';

$response = ['success' => false, 'message' => '', 'order' => null];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        throw new Exception('Method not allowed');
    }

    $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : (isset($_POST['order_id']) ? intval($_POST['order_id']) : 0);
    
    if ($order_id <= 0) {
        throw new Exception('Order ID is required');
    }

    $user_id = get_user_id();
    
    // Get order details using prepared statement
    $stmt = $conn->prepare("SELECT id, user_id, status, total, created_at, expected_arrival_start, expected_arrival_end, email, delivery_method_id, payment_method FROM orders WHERE id = ?");
    
    if (!$stmt) {
        throw new Exception('Database error: ' . $conn->error);
    }
    
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        http_response_code(404);
        throw new Exception('Order not found');
    }
    
    $order = $result->fetch_assoc();
    $stmt->close();
    
    // Check if order belongs to logged-in user (unless admin)
    if ($user_id > 0 && intval($order['user_id']) !== $user_id && !isset($_SESSION['is_admin'])) {
        http_response_code(403);
        throw new Exception('Unauthorized: You do not have permission to view this order');
    }
    
    // Get order items
    $items_stmt = $conn->prepare("SELECT p.name, p.id, oi.quantity, oi.unit_price FROM order_items oi 
                                 JOIN products p ON oi.product_id = p.id 
                                 WHERE oi.order_id = ?");
    
    if (!$items_stmt) {
        throw new Exception('Database error: ' . $conn->error);
    }
    
    $items_stmt->bind_param("i", $order_id);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    
    $items = [];
    while ($item = $items_result->fetch_assoc()) {
        $items[] = [
            'name' => htmlspecialchars($item['name']),
            'product_id' => intval($item['id']),
            'quantity' => intval($item['quantity']),
            'unit_price' => floatval($item['unit_price']),
            'total_price' => floatval($item['unit_price']) * intval($item['quantity'])
        ];
    }
    $items_stmt->close();
    
    // Get delivery method name
    $delivery_stmt = $conn->prepare("SELECT name FROM delivery_methods WHERE id = ?");
    $delivery_method_id = intval($order['delivery_method_id']);
    $delivery_stmt->bind_param("i", $delivery_method_id);
    $delivery_stmt->execute();
    $delivery_result = $delivery_stmt->get_result();
    $delivery_method = 'N/A';
    if ($delivery_result->num_rows > 0) {
        $delivery = $delivery_result->fetch_assoc();
        $delivery_method = htmlspecialchars($delivery['name']);
    }
    $delivery_stmt->close();
    
    // Format status
    $status_text = match($order['status']) {
        'pending' => 'Очакваща плащане',
        'paid' => 'Платена',
        'processing' => 'В обработка',
        'shipped' => 'Изпратена',
        'delivered' => 'Доставена',
        'cancelled' => 'Отменена',
        default => ucfirst(htmlspecialchars($order['status']))
    };
    
    // Format dates
    $arrival_start_formatted = '';
    $arrival_end_formatted = '';
    if (!empty($order['expected_arrival_start'])) {
        $arrival_start_formatted = date('d.m.Y', strtotime($order['expected_arrival_start']));
    }
    if (!empty($order['expected_arrival_end'])) {
        $arrival_end_formatted = date('d.m.Y', strtotime($order['expected_arrival_end']));
    }
    
    $response['success'] = true;
    $response['message'] = 'Order details retrieved successfully';
    $response['order'] = [
        'id' => intval($order['id']),
        'order_number' => 'ORD-' . str_pad(intval($order['id']), 6, '0', STR_PAD_LEFT),
        'status' => htmlspecialchars($order['status']),
        'status_text' => $status_text,
        'total' => floatval($order['total']),
        'created_at' => htmlspecialchars(date('d.m.Y H:i', strtotime($order['created_at']))),
        'expected_arrival_start' => $arrival_start_formatted,
        'expected_arrival_end' => $arrival_end_formatted,
        'email' => htmlspecialchars($order['email']),
        'delivery_method' => $delivery_method,
        'payment_method' => $order['payment_method'] === 'card' ? 'Плащане с карта' : 'Наложен платеж',
        'items' => $items
    ];
    
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;
?>
