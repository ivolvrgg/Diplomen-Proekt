<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']) && $_POST['remember'] === '1';
        
        // Validation
        if (empty($email) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Email и пароля са задължителни', 'error_field' => null]);
            exit;
        }
        
        // Get user from database using prepared statement
        $stmt = $conn->prepare("SELECT id, fullname, email, password_hash, is_active, is_admin FROM users WHERE email = ?");
        if (!$stmt) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if (!$result) {
            throw new Exception('Database query failed: ' . $conn->error);
        }
        
        if ($result->num_rows === 0) {
            $stmt->close();
            echo json_encode(['success' => false, 'message' => 'Неправилен email или парола', 'error_field' => 'email']);
            exit;
        }
        
        $user = $result->fetch_assoc();
        $stmt->close();
        
        // Verify password
        if (!password_verify($password, $user['password_hash'])) {
            echo json_encode(['success' => false, 'message' => 'Неправилен email или парола', 'error_field' => 'password']);
            exit;
        }
            
        // Check if user is active
        if (!$user['is_active']) {
            echo json_encode(['success' => false, 'message' => 'Вашия акаунт е деактивиран', 'error_field' => null]);
            exit;
        }
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $email;
        $_SESSION['user_name'] = $user['fullname'];
        $_SESSION['is_admin'] = (int)$user['is_admin'];
        
        // Redirect to homepage for all users (admins can access admin panel from navbar)
        $redirect = 'homepage.php';
        
        // Handle "Remember Me" - set cookie for 30 days
        if ($remember) {
            $rememberToken = bin2hex(random_bytes(32));
            $expiryDate = date('Y-m-d H:i:s', strtotime('+30 days'));
            
            // Store remember token in database using prepared statement
            $userId = intval($user['id']);
            $updateStmt = $conn->prepare("UPDATE users SET remember_token = ?, remember_token_expiry = ? WHERE id = ?");
            $updateStmt->bind_param("ssi", $rememberToken, $expiryDate, $userId);
            if (!$updateStmt->execute()) {
                throw new Exception('Failed to update remember token: ' . $conn->error);
            }
            $updateStmt->close();
            
            // Set cookie
            setcookie('remember_me', $rememberToken, strtotime('+30 days'), '/', '', false, true);
        }
        
        echo json_encode(['success' => true, 'message' => 'Влизате успешно!', 'redirect' => $redirect]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Невалиден метод на заявка', 'error_field' => null]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Възникна грешка на сървъра: ' . $e->getMessage(), 'error_field' => null]);
}
?>
