﻿<?php
ob_start();
session_start();

try {
    // Include configs
    require_once '../config/db.php';
    require_once '../config/google.php';
    
    // Log for debugging
    $log_file = __DIR__ . '/../logs/google-oauth.log';
    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Callback hit\n", FILE_APPEND);
    
    // Check for error from Google
    if (isset($_GET['error'])) {
        file_put_contents($log_file, "Error: " . $_GET['error'] . "\n", FILE_APPEND);
        header('Location: ../user_login.php?error=' . urlencode($_GET['error']));
        exit;
    }
    
    // Get authorization code
    $code = $_GET['code'] ?? null;
    if (!$code) {
        file_put_contents($log_file, "No code received\n", FILE_APPEND);
        header('Location: ../user_login.php?error=no_code');
        exit;
    }
    
    file_put_contents($log_file, "Code received, exchanging for token...\n", FILE_APPEND);
    
    // Exchange code for token
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'code' => $code,
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'grant_type' => 'authorization_code'
    ]));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        file_put_contents($log_file, "Token error: HTTP $http_code\n", FILE_APPEND);
        throw new Exception('Token error');
    }
    
    $token = json_decode($response, true);
    if (!isset($token['access_token'])) {
        throw new Exception('No token');
    }
    
    // Get user info
    $ch = curl_init('https://www.googleapis.com/oauth2/v2/userinfo?access_token=' . $token['access_token']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $user_response = curl_exec($ch);
    curl_close($ch);
    
    $google_user = json_decode($user_response, true);
    
    if (!isset($google_user['id']) || !isset($google_user['email'])) {
        throw new Exception('Invalid user data');
    }
    
    $google_id = $google_user['id'];
    $email = $google_user['email'];
    $name = $google_user['name'] ?? 'Google User';
    
    file_put_contents($log_file, "User: $email\n", FILE_APPEND);
    file_put_contents($log_file, "Google ID: $google_id\n", FILE_APPEND);
    
    // Check if user exists with Google ID
    file_put_contents($log_file, "Checking existing Google ID...\n", FILE_APPEND);
    $stmt = $conn->prepare("SELECT id, is_admin FROM users WHERE google_id = ?");
    if (!$stmt) {
        file_put_contents($log_file, "Prepare error: " . $conn->error . "\n", FILE_APPEND);
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    $stmt->bind_param("s", $google_id);
    $stmt->execute();
    if ($stmt->error) {
        file_put_contents($log_file, "Execute error on google_id check: " . $stmt->error . "\n", FILE_APPEND);
    }
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $email;
        $_SESSION['user_name'] = $name;
        $_SESSION['is_admin'] = $user['is_admin'];
        file_put_contents($log_file, "Logged in existing Google user - Session ID: " . session_id() . ", user_id: " . $_SESSION['user_id'] . "\n", FILE_APPEND);
        header('Location: ../homepage.php');
        exit;
    }
    
    // Check if email exists
    file_put_contents($log_file, "Checking existing email: $email\n", FILE_APPEND);
    $stmt = $conn->prepare("SELECT id, is_admin FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $update = $conn->prepare("UPDATE users SET google_id = ? WHERE id = ?");
        if (!$update) {
            file_put_contents($log_file, "Update prepare error: " . $conn->error . "\n", FILE_APPEND);
            throw new Exception('Database prepare error for update: ' . $conn->error);
        }
        $update->bind_param("ss", $google_id, $user['id']);
        if (!$update->execute()) {
            file_put_contents($log_file, "Update execute error: " . $update->error . "\n", FILE_APPEND);
            throw new Exception('Failed to update user: ' . $update->error);
        }
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $email;
        $_SESSION['user_name'] = $name;
        $_SESSION['is_admin'] = $user['is_admin'];
        file_put_contents($log_file, "Linked Google ID to existing user: $email - Session ID: " . session_id() . ", user_id: " . $_SESSION['user_id'] . "\n", FILE_APPEND);
        header('Location: ../homepage.php');
        exit;
    }
    
    // Create new user - let MySQL auto-generate the ID
    $now = date('Y-m-d H:i:s');
    file_put_contents($log_file, "Creating new user with Email: $email, GoogleID: $google_id\n", FILE_APPEND);
    
    $insert = $conn->prepare("INSERT INTO users (fullname, email, google_id, is_active, is_admin, created_at, updated_at) VALUES (?, ?, ?, 1, 0, ?, ?)");
    if (!$insert) {
        file_put_contents($log_file, "Insert prepare error: " . $conn->error . "\n", FILE_APPEND);
        throw new Exception('Database prepare error for insert: ' . $conn->error);
    }
    
    $insert->bind_param("sssss", $name, $email, $google_id, $now, $now);
    if (!$insert->execute()) {
        file_put_contents($log_file, "Insert execute error: " . $insert->error . "\n", FILE_APPEND);
        throw new Exception('Failed to create user: ' . $insert->error);
    }
    
    // Get the newly created user's ID
    $new_user_id = $conn->insert_id;
    file_put_contents($log_file, "Successfully created new user: $email with auto-generated ID: $new_user_id\n", FILE_APPEND);
    
    $_SESSION['user_id'] = $new_user_id;
    $_SESSION['user_email'] = $email;
    $_SESSION['user_name'] = $name;
    $_SESSION['is_admin'] = 0;
    
    file_put_contents($log_file, "Session ID: " . session_id() . ", Session user_id: " . $_SESSION['user_id'] . "\n", FILE_APPEND);
    file_put_contents($log_file, "Redirecting to homepage.\n", FILE_APPEND);
    
    header('Location: ../homepage.php');
    exit;
    
} catch (Exception $e) {
    file_put_contents($log_file, "Exception: " . $e->getMessage() . "\n", FILE_APPEND);
    header('Location: ../user_login.php?error=oauth_error');
    exit;
}

// Catch any database errors that might occur outside try-catch
if ($conn->error) {
    file_put_contents($log_file, "Database error: " . $conn->error . "\n", FILE_APPEND);
}
