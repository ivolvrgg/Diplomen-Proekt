<?php
/**
 * Calculate Delivery API - DEPRECATED
 * This endpoint was only for Speedy courier calculations.
 * Speedy has been removed from the system.
 */

header('Content-Type: application/json');
echo json_encode(['error' => 'Speedy courier service has been disabled. Use ECONT or courier delivery instead.']);
?>
