<?php
/**
 * Test Email Sending Endpoint
 * Used by test-email-system.php
 */

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['email']) || !isset($data['name'])) {
        echo json_encode(['success' => false, 'message' => 'Missing email or name']);
        exit;
    }
    
    $email = trim($data['email']);
    $name = trim($data['name']);
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email address']);
        exit;
    }
    
    // Load EmailHelper
    require_once 'includes/EmailHelper.php';
    $emailer = new EmailHelper();
    
    // Create test message
    $subject = 'Test Email - Dronche.BG';
    $html = "
    <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px;'>
        <h2 style='color: #9FC131;'>Test Email</h2>
        <p>Hello $name,</p>
        <p>This is a test email from the Dronche.BG email system.</p>
        
        <div style='background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px;'>
            <p><strong>Test Information:</strong></p>
            <p>Sent: " . date('Y-m-d H:i:s') . "</p>
            <p>From: Dronche.BG System</p>
        </div>
        
        <p style='margin-top: 20px; color: #666;'>If you received this email, the system is working correctly!</p>
        
        <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; color: #999; font-size: 12px;'>
            Dronche.BG | All Rights Reserved
        </p>
    </div>";
    
    // Send using reflection to access private send method via reflexivity
    $reflection = new ReflectionClass('EmailHelper');
    $method = $reflection->getMethod('send');
    $method->setAccessible(true);
    
    $result = $method->invokeArgs($emailer, [$email, $subject, $html]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Test email sent successfully to ' . $email,
            'logged_in_logs' => true
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to send email. Check logs/email-errors.log for details'
        ]);
    }
    
} catch (Exception $e) {
    error_log('Test email error: ' . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
