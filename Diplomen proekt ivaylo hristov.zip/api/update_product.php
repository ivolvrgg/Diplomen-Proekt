<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    // Get form data
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : null;
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : null;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $stock = isset($_POST['stock']) ? intval($_POST['stock']) : 0;
    $image_1 = trim($_POST['image_1'] ?? '');
    $image_2 = trim($_POST['image_2'] ?? '');
    $image_3 = trim($_POST['image_3'] ?? '');
    $image_4 = trim($_POST['image_4'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');

    // Validation
    if (!$product_id || empty($name) || $category_id === null || $price <= 0) {
        echo json_encode(['success' => false, 'message' => 'Product ID, name, category, and price are required']);
        exit;
    }

    // Create slug from name (keeping original slug if name isn't changed)
    $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', preg_replace('/[áàäâã]/i', 'a', preg_replace('/[éèëê]/i', 'e', preg_replace('/[íìïî]/i', 'i', preg_replace('/[óòöô]/i', 'o', preg_replace('/[úùüû]/i', 'u', $name)))))));
    $slug = trim($slug, '-');

    // Update product
    $stmt = $conn->prepare("
        UPDATE products 
        SET category_id = ?, name = ?, slug = ?, description = ?, price = ?, stock = ?, 
            image_1 = ?, image_2 = ?, image_3 = ?, image_4 = ?, video_url = ?
        WHERE id = ?
    ");

    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->bind_param(
        "isssddsssssi",
        $category_id,
        $name,
        $slug,
        $description,
        $price,
        $stock,
        $image_1,
        $image_2,
        $image_3,
        $image_4,
        $video_url,
        $product_id
    );

    if ($stmt->execute()) {
        $stmt->close();
        echo json_encode([
            'success' => true,
            'message' => 'Product updated successfully'
        ]);
    } else {
        throw new Exception('Failed to update product: ' . $conn->error);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
