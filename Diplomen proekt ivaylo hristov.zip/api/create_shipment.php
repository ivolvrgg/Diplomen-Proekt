<?php
/**
 * Create Shipment Endpoint
 * 
 * Creates a shipment for an order with the selected courier service
 * 
 * Request:
 * POST /api/create_shipment.php
 * {
 *   "order_id": 123,
 *   "delivery_method": "speedy",
 *   "delivery_office_id": 5,
 *   "recipient_name": "John Doe",
 *   "recipient_phone": "0888123456",
 *   "weight": 1.5
 * }
 * 
 * Response:
 * {
 *   "success": true,
 *   "message": "Shipment created",
 *   "data": {
 *     "shipment_id": "SPEEDY_...",
 *     "status": "pending",
 *     "created_at": "2024-03-16 10:30:00"
 *   }
 * }
 */

ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
ob_clean();
header('Content-Type: application/json; charset=utf-8');

// Load required files
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/delivery-service.php';
require_once __DIR__ . '/../includes/speedy-service.php';
require_once __DIR__ . '/../includes/econt-service.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }
    
    // Get JSON data
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }
    
    // Validate required fields
    $order_id = intval($data['order_id'] ?? 0);
    $delivery_method = trim($data['delivery_method'] ?? '');
    $delivery_office_id = intval($data['delivery_office_id'] ?? 0);
    $recipient_name = trim($data['recipient_name'] ?? '');
    $recipient_phone = trim($data['recipient_phone'] ?? '');
    $weight = floatval($data['weight'] ?? 1);
    
    if ($order_id <= 0) {
        throw new Exception('Invalid order ID');
    }
    
    if (!in_array($delivery_method, ['speedy', 'econt', 'courier'])) {
        throw new Exception('Invalid delivery method');
    }
    
    if ($delivery_method !== 'courier' && $delivery_office_id <= 0) {
        throw new Exception('Delivery office ID required');
    }
    
    if (empty($recipient_name) || empty($recipient_phone)) {
        throw new Exception('Recipient name and phone required');
    }
    
    // Verify order exists and belongs to user
    $user_id = get_user_id();
    $stmt = $conn->prepare("SELECT id, user_id, delivery_method_id FROM orders WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    if ($result->num_rows === 0) {
        throw new Exception('Order not found');
    }
    
    $order = $result->fetch_assoc();
    
    // Check permission (user must be order owner or admin)
    if ($user_id !== 0 && $order['user_id'] !== null && intval($order['user_id']) !== $user_id) {
        throw new Exception('Unauthorized');
    }
    
    // Prepare shipment data
    $shipment_data = [
        'order_id' => $order_id,
        'delivery_method' => $delivery_method,
        'delivery_office_id' => $delivery_office_id,
        'recipient_name' => $recipient_name,
        'recipient_phone' => $recipient_phone,
        'weight' => $weight,
        'created_by' => 'api/' . get_user_id(),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Get appropriate service
    $service = DeliveryServiceFactory::getService($delivery_method);
    
    // Create shipment
    $result = $service->createShipment($shipment_data);
    
    // Log successful shipment creation
    if ($result['success']) {
        error_log("Shipment created for order $order_id: " . json_encode($result['data']));
    }
    
    // Return response
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
}
?>
