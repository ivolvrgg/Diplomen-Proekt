<?php
// Simple test to verify API works
header('Content-Type: application/json; charset=utf-8');
ob_start();

try {
    error_log('TEST: Basic API response test started');
    
    // Test 1: Can we output JSON?
    $response = ['success' => true, 'message' => 'API is working'];
    
    ob_end_clean();
    echo json_encode($response);
    error_log('TEST: JSON output succeeded');
} catch (Exception $e) {
    ob_end_clean();
    error_log('TEST ERROR: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
?>
