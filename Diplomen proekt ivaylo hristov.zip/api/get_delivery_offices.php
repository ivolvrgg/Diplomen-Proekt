<?php
/**
 * Get Delivery Offices Endpoint
 * 
 * Returns list of offices for selected delivery method and city
 * 
 * Request:
 * GET /api/get_delivery_offices.php?method=speedy&city=Sofia
 * 
 * Response:
 * {
 *   "success": true,
 *   "offices": [
 *     {
 *       "id": 1,
 *       "name": "Speedy - Sofia Center",
 *       "city": "Sofia",
 *       "street": "ul. Vitosha 10",
 *       "phone": "+359 1 123 45 67",
 *       "hours": "08:00 - 18:00"
 *     }
 *   ]
 * }
 */

ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');

// Load required files
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/delivery-service.php';
require_once __DIR__ . '/../includes/speedy-service.php';
require_once __DIR__ . '/../includes/econt-service.php';

try {
    // Get parameters
    $method = trim($_GET['method'] ?? '');
    $city = trim($_GET['city'] ?? '');
    
    // Validate method
    if (!in_array($method, ['speedy', 'econt', 'courier'])) {
        throw new Exception('Invalid delivery method: ' . $method);
    }
    
    // Get appropriate service
    $service = DeliveryServiceFactory::getService($method);
    
    // Fetch offices
    $result = $service->getOffices($city);
    
    // Return response
    ob_clean();
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    ob_clean();
    header('HTTP/1.1 400 Bad Request');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
}
?>
