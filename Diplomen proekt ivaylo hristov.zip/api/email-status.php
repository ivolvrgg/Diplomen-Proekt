<?php
/**
 * Email System Health Check Endpoint
 * Visit: /Diplomna_rabota/api/email-status.php
 * 
 * Provides real-time status of the email sending system
 */

header('Content-Type: application/json; charset=utf-8');

$status = [
    'timestamp' => date('Y-m-d H:i:s'),
    'email_system_health' => 'checking...',
    'config' => [],
    'recent_logs' => [],
    'warnings' => [],
    'errors' => []
];

try {
    // Check configuration file
    if (!file_exists(__DIR__ . '/../config/mail.php')) {
        $status['errors'][] = 'Mail configuration file not found (config/mail.php)';
    } else {
        $config = require __DIR__ . '/../config/mail.php';
        
        // Verify config has required fields
        $required_fields = ['host', 'port', 'username', 'password', 'from_email', 'from_name'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($config[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (!empty($missing_fields)) {
            $status['warnings'][] = 'Missing configuration fields: ' . implode(', ', $missing_fields);
        }
        
        $status['config'] = [
            'host' => $config['host'] ?? 'not set',
            'port' => $config['port'] ?? 'not set',
            'encryption' => $config['encryption'] ?? 'not set',
            'mailer' => $config['mailer'] ?? 'not set',
            'username_set' => !empty($config['username']),
            'password_set' => !empty($config['password']),
            'from_email' => $config['from_email'] ?? 'not set',
            'from_name' => $config['from_name'] ?? 'not set'
        ];
    }
    
    // Check EmailHelper class
    if (!file_exists(__DIR__ . '/../includes/EmailHelper.php')) {
        $status['errors'][] = 'EmailHelper class not found (includes/EmailHelper.php)';
    } else {
        $status['email_helper'] = 'present and correct';
    }
    
    // Check email log file
    $log_file = __DIR__ . '/../logs/email-errors.log';
    if (file_exists($log_file)) {
        $log_size = filesize($log_file);
        $status['log_file'] = [
            'path' => $log_file,
            'size_bytes' => $log_size,
            'exists' => true
        ];
        
        // Read last 20 log entries
        $lines = file($log_file);
        $recent = array_slice(array_reverse($lines), 0, 20);
        $status['recent_logs'] = array_map('trim', $recent);
        
        // Analyze logs for issues
        foreach ($recent as $line) {
            if (stripos($line, 'FAIL') !== false) {
                $status['warnings'][] = 'Recent FAIL entries detected: ' . trim($line);
            }
            if (stripos($line, 'ERROR') !== false && stripos($line, 'ERROR:') === 0) {
                $status['errors'][] = 'Recent ERROR: ' . trim($line);
            }
        }
    } else {
        $status['log_file'] = [
            'path' => $log_file,
            'exists' => false,
            'note' => 'Log file will be created on first email send'
        ];
    }
    
    // Check logs directory
    $logs_dir = __DIR__ . '/../logs';
    if (!is_dir($logs_dir)) {
        $status['warnings'][] = 'Logs directory does not exist: ' . $logs_dir;
    } else {
        $status['logs_directory'] = [
            'path' => $logs_dir,
            'writable' => is_writable($logs_dir)
        ];
    }
    
    // Determine overall health
    if (!empty($status['errors'])) {
        $status['email_system_health'] = 'critical';
    } elseif (!empty($status['warnings'])) {
        $status['email_system_health'] = 'degraded';
    } else {
        $status['email_system_health'] = 'healthy';
    }
    
} catch (Exception $e) {
    $status['error'] = $e->getMessage();
    $status['email_system_health'] = 'error';
}

// Add debug info if debug mode is enabled
if (isset($_GET['debug']) && $_GET['debug'] === 'true') {
    $status['debug_info'] = [
        'php_version' => phpversion(),
        'php_sapi' => php_sapi_name(),
        'openssl_enabled' => extension_loaded('openssl'),
        'stream_context_support' => function_exists('stream_context_create')
    ];
}

echo json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
