<?php
session_start();
header('Content-Type: application/json');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include '../config/db.php';
    include '../includes/EmailHelper.php';
    
    if (!isset($conn)) {
        throw new Exception('Database connection failed');
    }

    // Check if user is admin
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied: Admin privileges required']);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    // Get order ID and new status
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : null;
    $status = isset($_POST['status']) ? trim($_POST['status']) : null;

    if (!$order_id || !$status) {
        echo json_encode(['success' => false, 'message' => 'Order ID and status are required']);
        exit;
    }

    // Validate status
    $valid_statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
    if (!in_array($status, $valid_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        exit;
    }

    // Verify order exists and get user email
    $checkStmt = $conn->prepare("SELECT o.id, u.email, u.fullname FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
    if (!$checkStmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }
    
    $checkStmt->bind_param("i", $order_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows === 0) {
        $checkStmt->close();
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }
    
    $order_data = $result->fetch_assoc();
    $user_email = $order_data['email'];
    $user_name = $order_data['fullname'];
    $checkStmt->close();

    // Update order status
    $stmt = $conn->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);

    if ($stmt->execute()) {
        $stmt->close();
        
        // Send email notification
        try {
            $emailer = new EmailHelper();
            $emailer->sendOrderStatusUpdate($user_email, $user_name, $order_id, $status);
        } catch (Exception $email_error) {
            error_log("Email notification failed for order $order_id: " . $email_error->getMessage());
        }

        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);

    } else {
        $stmt->close();
        throw new Exception('Failed to update order status: ' . $stmt->error);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>

