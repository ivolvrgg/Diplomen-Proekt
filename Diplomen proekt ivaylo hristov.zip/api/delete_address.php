<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['address_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Адрес ID е задължителен']);
    exit;
}

$user_id = $_SESSION['user_id'];
$address_id = $data['address_id'];

try {
    // Verify address belongs to user using prepared statement
    $addr_check = $conn->prepare("SELECT user_id FROM addresses WHERE id = ?");
    $addr_check->bind_param("i", $address_id);
    $addr_check->execute();
    $result = $addr_check->get_result();
    $addr = $result->fetch_assoc();
    $addr_check->close();
    
    if (!$addr || $addr['user_id'] != $user_id) {
        throw new Exception('Адресът не принадлежи на твоя профил');
    }

    $delete_stmt = $conn->prepare("DELETE FROM addresses WHERE id = ? AND user_id = ?");
    $delete_stmt->bind_param("ii", $address_id, $user_id);
    
    if ($delete_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Адресът е изтрит успешно']);
    } else {
        throw new Exception('Грешка при изтриване на адреса');
    }
    $delete_stmt->close();
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
