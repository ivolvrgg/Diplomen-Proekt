<?php echo "API directory PHP works!"; ?>
