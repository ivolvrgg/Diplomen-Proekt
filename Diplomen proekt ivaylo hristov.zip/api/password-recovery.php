<?php
header('Content-Type: application/json');
session_start();

try {
    require_once '../config/db.php';
    
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    if ($action === 'send_code') {
        // Step 1: User requests password recovery - send code to email
        $email = trim($data['email'] ?? '');
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Невалиден email адрес']);
            exit;
        }
        
        // Check if user exists
        $stmt = $conn->prepare("SELECT id, fullname FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            // Don't reveal if email exists (security)
            echo json_encode(['success' => true, 'message' => 'Ако имейлът е регистриран, лично ще получиш код']);
            exit;
        }
        
        $user = $result->fetch_assoc();
        $stmt->close();
        
        // Generate 6-digit code
        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        
        // Save code to database using SQL NOW() + 30 minutes
        $update = $conn->prepare("UPDATE users SET reset_code = ?, reset_code_expires = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE id = ?");
        $update->bind_param("si", $code, $user['id']);
        
        if (!$update->execute()) {
            echo json_encode(['success' => false, 'message' => 'Възникна грешка при запазване на кода']);
            exit;
        }
        $update->close();
        
        // Send email
        require_once '../includes/EmailHelper.php';
        $emailer = new EmailHelper();
        
        if ($emailer->sendPasswordRecoveryCode($email, $code)) {
            echo json_encode(['success' => true, 'message' => 'Код изпратен на твоя email']);
            file_put_contents('../logs/password-recovery.log', 
                "[" . date('Y-m-d H:i:s') . "] Code sent to: $email\n", FILE_APPEND);
        } else {
            echo json_encode(['success' => false, 'message' => 'Не можахме да изпратим имейла. Обиди се по-късно']);
        }
        
    } elseif ($action === 'reset_password') {
        // Step 2: User submits verification code and new password
        $email = trim($data['email'] ?? '');
        $code = trim($data['code'] ?? '');
        $password = $data['password'] ?? '';
        
        // Validate input
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Невалиден email адрес', 'field' => 'email']);
            exit;
        }
        
        if (strlen($code) !== 6 || !ctype_digit($code)) {
            echo json_encode(['success' => false, 'message' => 'Невалиден код', 'field' => 'code']);
            exit;
        }
        
        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'message' => 'Паролата трябва да е минимум 6 символа', 'field' => 'password']);
            exit;
        }
        
        // Find user and verify code
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND reset_code = ? AND reset_code_expires > NOW()");
        $stmt->bind_param("ss", $email, $code);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'Невалиден код или кода е изтекъл', 'field' => 'code']);
            $stmt->close();
            exit;
        }
        
        $user = $result->fetch_assoc();
        $stmt->close();
        
        // Hash new password
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        
        // Update password and clear reset code
        $update = $conn->prepare("UPDATE users SET password_hash = ?, reset_code = NULL, reset_code_expires = NULL WHERE id = ?");
        $update->bind_param("ss", $password_hash, $user['id']);
        
        if (!$update->execute()) {
            echo json_encode(['success' => false, 'message' => 'Възникна грешка при обновяване на паролата']);
            $update->close();
            exit;
        }
        $update->close();
        
        // Send password reset confirmation email
        try {
            require_once '../includes/EmailHelper.php';
            $emailer = new EmailHelper();
            
            // Get user name
            $user_name_stmt = $conn->prepare("SELECT fullname FROM users WHERE email = ?");
            $user_name_stmt->bind_param("s", $email);
            $user_name_stmt->execute();
            $user_name_result = $user_name_stmt->get_result();
            $user_name = 'Customer';
            if ($user_name_result->num_rows > 0) {
                $user_name_data = $user_name_result->fetch_assoc();
                $user_name = $user_name_data['fullname'];
            }
            $user_name_stmt->close();
            
            $emailer->sendPasswordResetConfirmation($email, $user_name);
        } catch (Exception $e) {
            // Log but don't fail - password is already reset
            file_put_contents('../logs/password-recovery.log', 
                "[" . date('Y-m-d H:i:s') . "] Confirmation email failed for $email: " . $e->getMessage() . "\n", FILE_APPEND);
        }
        
        echo json_encode(['success' => true, 'message' => 'Паролата е успешно променена']);
        file_put_contents('../logs/password-recovery.log', 
            "[" . date('Y-m-d H:i:s') . "] Password reset for: $email\n", FILE_APPEND);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'Невалидна действие']);
    }
    
} catch (Exception $e) {
    file_put_contents('../logs/password-recovery.log', 
        "[" . date('Y-m-d H:i:s') . "] ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    
    echo json_encode(['success' => false, 'message' => 'Възникна грешка. Опитай отново']);
}
?>
