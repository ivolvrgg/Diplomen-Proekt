<?php
/**
 * Invoice Viewer & Downloader
 * Displays invoice as HTML or downloads as PDF
 */

header('Content-Type: text/html; charset=utf-8');

require_once '../config/db.php';

try {
    $invoice_id = intval($_GET['invoice_id'] ?? 0);
    
    if ($invoice_id <= 0) {
        throw new Exception('Invalid invoice ID');
    }
    
    // Get invoice from database
    $invoice = $conn->query("SELECT * FROM invoices WHERE id = $invoice_id")->fetch_assoc();
    
    if (!$invoice) {
        throw new Exception('Invoice not found');
    }
    
    // Check if file exists
    if (!file_exists($invoice['file_path'])) {
        throw new Exception('Invoice file not found: ' . $invoice['file_path']);
    }
    
    // Read the invoice HTML
    $invoice_html = file_get_contents($invoice['file_path']);
    
    ?>
    <!DOCTYPE html>
    <html lang="bg">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Фактура - <?php echo htmlspecialchars($invoice['invoice_number']); ?></title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .invoice-container {
                max-width: 900px;
                margin: 0 auto;
                background-color: white;
                padding: 40px;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .invoice-title {
                text-align: center;
                color: #042940;
                margin-bottom: 10px;
                font-size: 28px;
            }
            .invoice-number {
                text-align: center;
                color: #666;
                margin-bottom: 30px;
                font-size: 14px;
            }
            .controls {
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 1px solid #eee;
            }
            .btn {
                display: inline-block;
                padding: 10px 20px;
                margin: 0 5px;
                background-color: #588157;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                border: none;
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
            }
            .btn:hover {
                background-color: #3d5a38;
            }
            .btn-secondary {
                background-color: #666;
            }
            .btn-secondary:hover {
                background-color: #555;
            }
            @media print {
                .controls {
                    display: none;
                }
                body {
                    background-color: white;
                    padding: 0;
                    margin: 0;
                    height: 100%;
                }
                html {
                    height: 100%;
                }
                .invoice-container {
                    box-shadow: none;
                    max-width: 100%;
                    padding: 40px;
                    margin: 0;
                    border-radius: 0;
                }
            }
            @page {
                size: A4;
                margin: 0.5cm 0.5cm 0cm 0.5cm;
            }
            @supports (-webkit-print-color-adjust: exact) {
                @page {
                    margin: 0.5cm 0.5cm 0cm 0.5cm;
                }
            }
            .invoice-content {
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="invoice-container">
            <div class="invoice-title">Фактура</div>
            <div class="invoice-number">
                Номер: <strong><?php echo htmlspecialchars($invoice['invoice_number']); ?></strong>
                <br>
                Дата: <strong><?php echo date('d.m.Y H:i', strtotime($invoice['created_at'])); ?></strong>
            </div>
            
            <div class="controls">
                <button class="btn" onclick="window.print()">🖨️ Отпечатай / Запази като PDF</button>
            </div>
            
            <div class="invoice-content">
                <?php echo $invoice_html; ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    
} catch (Exception $e) {
    http_response_code(404);
    ?>
    <!DOCTYPE html>
    <html lang="bg">
    <head>
        <meta charset="UTF-8">
        <title>Грешка</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                padding: 40px;
                text-align: center;
                background-color: #f5f5f5;
            }
            .error-box {
                background-color: white;
                padding: 40px;
                border-radius: 8px;
                max-width: 500px;
                margin: 0 auto;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            h1 {
                color: #c41e3a;
                margin-bottom: 20px;
            }
            p {
                color: #666;
                margin-bottom: 20px;
            }
            a {
                display: inline-block;
                padding: 10px 20px;
                background-color: #588157;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="error-box">
            <h1>⚠️ Грешка</h1>
            <p><?php echo htmlspecialchars($e->getMessage()); ?></p>
            <a href="javascript:window.history.back()">← Назад</a>
        </div>
    </body>
    </html>
    <?php
}
?>
