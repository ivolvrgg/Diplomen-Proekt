<?php
/**
 * API Endpoint to generate and send invoices
 */

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Handle CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database connection
include '../config/db.php';

// Check if mPDF is installed, if not try to use TCPDF
function generateInvoicePDF($order_id) {
    global $conn;
    
    // Get order details
    $order = $conn->query("SELECT * FROM orders WHERE id = " . intval($order_id))->fetch_assoc();
    if (!$order) {
        return ['success' => false, 'message' => 'Order not found'];
    }
    
    // Get order items
    $items_result = $conn->query("
        SELECT p.name, oi.quantity, oi.unit_price 
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = " . intval($order_id)
    );
    
    $items = [];
    while ($item = $items_result->fetch_assoc()) {
        $items[] = $item;
    }
    
    // Check if mPDF is available
    try {
        if (file_exists('../vendor/autoload.php')) {
            require_once '../vendor/autoload.php';
        }
        
        // Try mPDF
        if (class_exists('Mpdf\Mpdf')) {
            return generateWithMPDF($order, $items);
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'PDF library error: ' . $e->getMessage()];
    }
    
    // Fallback: Generate simple HTML-based invoice
    return generateSimpleHTMLInvoice($order, $items);
}

function generateWithMPDF($order, $items) {
    global $conn;
    
    try {
        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4',
            'margin_left' => 10,
            'margin_right' => 10,
            'margin_top' => 10,
            'margin_bottom' => 10,
            'default_font' => 'Arial'
        ]);
        
        // Generate invoice number
        $invoice_number = 'INV-' . date('Y') . '-' . str_pad($order['id'], 6, '0', STR_PAD_LEFT);
        
        // Build HTML content
        $html = buildInvoiceHTML($order, $items, $invoice_number);
        
        $mpdf->WriteHTML($html);
        
        // Create uploads directory if it doesn't exist
        $invoice_dir = '../uploads/invoices';
        if (!is_dir($invoice_dir)) {
            mkdir($invoice_dir, 0755, true);
        }
        
        $filename = $invoice_dir . '/' . $invoice_number . '.pdf';
        $mpdf->Output($filename, 'F');
        
        // Save invoice record to database
        $stmt = $conn->prepare("
            INSERT INTO invoices (order_id, user_id, invoice_number, file_path, status)
            VALUES (?, ?, ?, ?, 'generated')
        ");
        $stmt->bind_param('iiss', $order['id'], $order['user_id'], $invoice_number, $filename);
        $stmt->execute();
        
        return [
            'success' => true,
            'invoice_number' => $invoice_number,
            'file_path' => $filename
        ];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'mPDF error: ' . $e->getMessage()];
    }
}

function generateSimpleHTMLInvoice($order, $items) {
    // Generate invoice number
    $invoice_number = 'INV-' . date('Y') . '-' . str_pad($order['id'], 6, '0', STR_PAD_LEFT);
    
    // Create HTML file as fallback
    $invoice_dir = '../uploads/invoices';
    if (!is_dir($invoice_dir)) {
        mkdir($invoice_dir, 0755, true);
    }
    
    $filename = $invoice_dir . '/' . $invoice_number . '.html';
    $html_content = buildInvoiceHTML($order, $items, $invoice_number);
    
    file_put_contents($filename, $html_content);
    
    return [
        'success' => true,
        'invoice_number' => $invoice_number,
        'file_path' => $filename,
        'format' => 'html'
    ];
}

function buildInvoiceHTML($order, $items, $invoice_number) {
    // Get delivery method name
    global $conn;
    
    $delivery_query = $conn->query("SELECT name FROM delivery_methods WHERE id = " . intval($order['delivery_method_id']));
    $delivery_method = $delivery_query ? $delivery_query->fetch_assoc() : ['name' => 'Unknown'];
    
    $subtotal = 0;
    $items_html = '';
    
    foreach ($items as $item) {
        $item_total = $item['unit_price'] * $item['quantity'];
        $subtotal += $item_total;
        $items_html .= "
            <tr>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>{$item['name']}</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd; text-align: center;'>{$item['quantity']}</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd; text-align: right;'>€ " . number_format($item['unit_price'], 2) . "</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd; text-align: right;'>€ " . number_format($item_total, 2) . "</td>
            </tr>
        ";
    }
    
    $total_with_delivery = $subtotal + $order['delivery_cost'];
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body {
                font-family: Arial, sans-serif;
                color: #333;
            }
            .invoice-container {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 2px solid #588157;
                padding-bottom: 20px;
            }
            .company-info h1 {
                margin: 0;
                color: #588157;
                font-size: 28px;
            }
            .invoice-info {
                text-align: right;
            }
            .invoice-info h2 {
                margin: 0;
                font-size: 20px;
                color: #588157;
            }
            .invoice-info p {
                margin: 5px 0;
                font-size: 14px;
            }
            .customer-info {
                margin-bottom: 30px;
                display: flex;
                justify-content: space-between;
            }
            .customer-info > div {
                flex: 1;
            }
            .customer-info h3 {
                margin: 0 0 10px 0;
                font-size: 12px;
                color: #666;
                text-transform: uppercase;
            }
            .customer-info p {
                margin: 5px 0;
                font-size: 14px;
            }
            table {
                width: 100%;
                margin-bottom: 20px;
                border-collapse: collapse;
            }
            table th {
                background-color: #588157;
                color: white;
                padding: 12px;
                text-align: left;
                font-weight: bold;
            }
            .totals {
                width: 100%;
                margin-top: 20px;
                text-align: right;
            }
            .total-row {
                display: flex;
                justify-content: flex-end;
                margin: 10px 0;
                font-size: 14px;
            }
            .total-row.total {
                border-top: 2px solid #588157;
                padding-top: 10px;
                font-size: 16px;
                font-weight: bold;
                color: #588157;
            }
            .footer {
                margin-top: 40px;
                border-top: 1px solid #ddd;
                padding-top: 20px;
                text-align: center;
                font-size: 12px;
                color: #666;
            }
        </style>
    </head>
    <body>
        <div class='invoice-container'>
            <div class='header'>
                <div class='invoice-info' style='width: 100%; text-align: center;'>
                    <h2>INVOICE</h2>
                    <p><strong>Invoice #:</strong> {$invoice_number}</p>
                    <p><strong>Date:</strong> " . date('d.m.Y', strtotime($order['created_at'])) . "</p>
                    <p><strong>Order #:</strong> ORD-" . str_pad($order['id'], 6, '0', STR_PAD_LEFT) . "</p>
                </div>
            </div>
            
            <div class='customer-info'>
                <div>
                    <h3>Bill To</h3>
                    <p>" . htmlspecialchars($order['email']) . "</p>
                    <p>Phone: " . htmlspecialchars($order['phone']) . "</p>
                </div>
                <div>
                    <h3>Delivery Method</h3>
                    <p>" . htmlspecialchars($delivery_method['name']) . "</p>
                </div>
                <div>
                    <h3>Order Status</h3>
                    <p>" . ucfirst(htmlspecialchars($order['status'])) . "</p>
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style='text-align: center;'>Quantity</th>
                        <th style='text-align: right;'>Unit Price</th>
                        <th style='text-align: right;'>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {$items_html}
                </tbody>
            </table>
            
            <div class='totals'>
                <div class='total-row'>
                    <span style='width: 100px; text-align: right;'><strong>Subtotal:</strong> €" . number_format($subtotal, 2) . "</span>
                </div>
                <div class='total-row'>
                    <span style='width: 100px; text-align: right;'><strong>Delivery:</strong> €" . number_format($order['delivery_cost'], 2) . "</span>
                </div>
                <div class='total-row total'>
                    <span style='width: 100px; text-align: right;'><strong>TOTAL:</strong> €" . number_format($total_with_delivery, 2) . "</span>
                </div>
            </div>
            
            <div class='footer'>
                <p>Thank you for your purchase!</p>
                <p>Dronche.BG | www.dronche.bg | Contact: support@dronche.bg</p>
                <p style='font-size: 11px; margin-top: 20px;'>Generated on " . date('d.m.Y H:i:s') . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return $html;
}

// Handle different actions
if ($action === 'generate' && $method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $order_id = intval($data['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
        exit;
    }
    
    $result = generateInvoicePDF($order_id);
    echo json_encode($result);
    
} elseif ($action === 'download' && $method === 'GET') {
    $invoice_id = intval($_GET['invoice_id'] ?? 0);
    
    if ($invoice_id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid invoice ID']);
        exit;
    }
    
    // Get invoice from database
    $invoice = $conn->query("SELECT * FROM invoices WHERE id = $invoice_id")->fetch_assoc();
    
    if (!$invoice) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Invoice not found']);
        exit;
    }
    
    if (!file_exists($invoice['file_path'])) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Invoice file not found']);
        exit;
    }
    
    // Update download status
    $conn->query("UPDATE invoices SET downloaded_at = NOW(), status = 'downloaded' WHERE id = $invoice_id");
    
    // Serve file
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . basename($invoice['file_path']) . '.pdf"');
    readfile($invoice['file_path']);
    exit;
    
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
