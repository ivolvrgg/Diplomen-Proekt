<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['old_password']) || empty($data['new_password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Паролите са задължителни']);
    exit;
}

$user_id = $_SESSION['user_id'];
$oldPassword = $data['old_password'];
$newPassword = $data['new_password'];

try {
    // Get user's current password hash using prepared statement
    $pwd_stmt = $conn->prepare("SELECT password_hash FROM users WHERE id = ?");
    $pwd_stmt->bind_param("i", $user_id);
    $pwd_stmt->execute();
    $result = $pwd_stmt->get_result();
    $user = $result->fetch_assoc();
    $pwd_stmt->close();
    
    if (!$user) {
        throw new Exception('Потребителят не е намерен');
    }

    // Verify old password
    if (!password_verify($oldPassword, $user['password_hash'])) {
        throw new Exception('Текущата парола е неправилна');
    }

    // Hash new password
    $newHash = password_hash($newPassword, PASSWORD_BCRYPT);

    // Update password using prepared statement
    $update_pwd = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    $update_pwd->bind_param("si", $newHash, $user_id);
    
    if ($update_pwd->execute()) {
        echo json_encode(['success' => true, 'message' => 'Паролата е променена успешно']);
    } else {
        throw new Exception('Грешка при промяна на паролата');
    }
    $update_pwd->close();
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
