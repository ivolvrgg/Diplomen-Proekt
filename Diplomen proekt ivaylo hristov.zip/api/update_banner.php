<?php
session_start();
header('Content-Type: application/json');
include '../config/db.php';
include '../includes/admin_check.php';

$banner_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$is_active = isset($_POST['is_active']) ? intval($_POST['is_active']) : null;

if (!$banner_id) {
    echo json_encode(['success' => false, 'message' => 'Banner ID required']);
    exit;
}

// Get current banner info
$current = $conn->query("SELECT * FROM banners WHERE id = $banner_id");
if (!$current || $current->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Banner not found']);
    exit;
}
$banner = $current->fetch_assoc();

// Handle file upload if present
$new_image_url = $banner['image_url'];
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = '../uploads/banners/';
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, 0777, true);
    }
    
    $file = $_FILES['image'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($file_ext, $allowed_exts)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type']);
        exit;
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'File too large']);
        exit;
    }

    $filename = 'banner_' . time() . '_' . uniqid() . '.' . $file_ext;
    $file_path = $upload_dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
        exit;
    }

    // Delete old file
    if (!empty($banner['image_url'])) {
        @unlink('../' . $banner['image_url']);
    }
    
    $new_image_url = 'uploads/banners/' . $filename;
}

// Build update query
$updates = array();

// Handle image URL update
if ($new_image_url !== $banner['image_url']) {
    $updates[] = "image_url = '" . $conn->real_escape_string($new_image_url) . "'";
}

// Handle link URL updates
if (isset($_POST['link_type'])) {
    $link_type = $_POST['link_type'];
    $link_value = $_POST['link_value'] ?? '';
    $link_url = '#';
    
    if ($link_type === 'sales') {
        $sale_percent = isset($_POST['sale_percent']) ? intval($_POST['sale_percent']) : 0;
        if ($sale_percent > 0) {
            $link_url = 'category-products.php?sale=1&discount=' . $sale_percent;
        } else {
            $link_url = 'category-products.php?sale=1';
        }
    } elseif ($link_type === 'category') {
        $category_ids = array_map('trim', explode(',', $link_value));
        if (count($category_ids) === 1) {
            $link_url = 'category-products.php?id=' . intval($category_ids[0]);
        } else {
            $ids = implode(',', array_map('intval', $category_ids));
            $link_url = 'category-products.php?ids=' . $ids;
        }
    } elseif ($link_type === 'custom' && !empty($link_value)) {
        $link_url = htmlspecialchars($link_value);
    }
    
    $updates[] = "link_url = '" . $conn->real_escape_string($link_url) . "'";
}

// Handle title and description
if (isset($_POST['title'])) {
    $updates[] = "title = '" . $conn->real_escape_string($_POST['title']) . "'";
}
if (isset($_POST['description'])) {
    $updates[] = "description = '" . $conn->real_escape_string($_POST['description']) . "'";
}

// Handle sort order
if (isset($_POST['sort_order'])) {
    $updates[] = "sort_order = " . intval($_POST['sort_order']);
}

// Handle is_active
if ($is_active !== null) {
    $updates[] = "is_active = " . $is_active;
}

if (empty($updates)) {
    echo json_encode(['success' => false, 'message' => 'No fields to update']);
    exit;
}

$query = "UPDATE banners SET " . implode(", ", $updates) . " WHERE id = $banner_id";

if ($conn->query($query) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Banner updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

$conn->close();
?>
