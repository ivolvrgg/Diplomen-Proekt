<?php
/**
 * ECONT Offices API Endpoint
 * ECONT uses iframe integration - offices are handled by delivery.econt.com
 * This endpoint is for reference only. Real integration uses iframe.
 */

header('Content-Type: application/json; charset=utf-8');

// ECONT Configuration
$shop_id = '8663581';
$delivery_form_url = 'https://delivery.econt.com/'; // or delivery.econt.com/shop_settings_general.php?id_shop=' . $shop_id;

echo json_encode([
    'success' => true,
    'message' => 'ECONT uses iframe integration. Use delivery.econt.com iframe for office selection.',
    'shop_id' => $shop_id,
    'delivery_form_url' => $delivery_form_url,
    'offices' => [] // Offices are selected via ECONT iframe
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
