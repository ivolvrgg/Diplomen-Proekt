<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$user_id = $_SESSION['user_id'];

try {
    // Start transaction to delete user and related data
    $conn->begin_transaction();

    // Delete user's orders and order items using prepared statements
    $orders_stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ?");
    $orders_stmt->bind_param("i", $user_id);
    $orders_stmt->execute();
    $ordersResult = $orders_stmt->get_result();
    
    if ($ordersResult && $ordersResult->num_rows > 0) {
        $delete_items = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
        while ($order = $ordersResult->fetch_assoc()) {
            $delete_items->bind_param("i", $order['id']);
            $delete_items->execute();
        }
        $delete_items->close();
    }
    $orders_stmt->close();
    
    $delete_orders = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
    $delete_orders->bind_param("i", $user_id);
    $delete_orders->execute();
    $delete_orders->close();

    // Delete user's addresses
    $delete_addresses = $conn->prepare("DELETE FROM addresses WHERE user_id = ?");
    $delete_addresses->bind_param("i", $user_id);
    $delete_addresses->execute();
    $delete_addresses->close();

    // Delete user
    $delete_user = $conn->prepare("DELETE FROM users WHERE id = ?");
    $delete_user->bind_param("i", $user_id);
    $delete_user->execute();
    $delete_user->close();

    // Commit transaction
    $conn->commit();

    // Logout the user
    session_destroy();

    echo json_encode(['success' => true, 'message' => 'Профилът е изтрит успешно']);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Грешка при изтриване на профила: ' . $e->getMessage()]);
}

$conn->close();
?>
