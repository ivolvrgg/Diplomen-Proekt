<?php
header('Content-Type: application/json');
require_once '../config/db.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не сте влезли']);
    exit;
}

$user_id = intval($_SESSION['user_id']);

// Fetch user profile data using prepared statement
$stmt = $conn->prepare("SELECT id, fullname, email, phone, city, street, block, entrance, apartment FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Потребителя не е намерен']);
    $stmt->close();
    exit;
}

$user = $result->fetch_assoc();
$stmt->close();

// Try to fetch default address from addresses table
$user['default_address'] = null;
$addr_stmt = $conn->prepare("SELECT id, city, street, block, entrance, apartment FROM addresses WHERE user_id = ? AND is_default = 1 LIMIT 1");
if ($addr_stmt) {
    $addr_stmt->bind_param("i", $user_id);
    $addr_stmt->execute();
    $addr_result = $addr_stmt->get_result();
    
    if ($addr_result && $addr_result->num_rows > 0) {
        $user['default_address'] = $addr_result->fetch_assoc();
    }
    $addr_stmt->close();
}

// Use default address fields if available, otherwise try user table fields
if ($user['default_address']) {
    $user['city'] = $user['default_address']['city'];
    $user['street'] = $user['default_address']['street'];
    $user['block'] = $user['default_address']['block'];
    $user['entrance'] = $user['default_address']['entrance'];
    $user['apartment'] = $user['default_address']['apartment'];
}

echo json_encode([
    'success' => true,
    'user' => $user
]);
?>
