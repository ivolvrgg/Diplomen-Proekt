<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Не си влязъл']);
    exit;
}

header('Content-Type: application/json');
include '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['city']) || empty($data['street'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Град и адрес са задължителни']);
    exit;
}

$user_id = $_SESSION['user_id'];
$city = $data['city'];
$street = $data['street'];
$block = $data['block'] ?? null;
$entrance = $data['entrance'] ?? null;
$apartment = $data['apartment'] ?? null;
$is_default = $data['is_default'] ? 1 : 0;

try {
    // If setting as default, unset other default addresses
    if ($is_default) {
        $stmt = $conn->prepare("UPDATE addresses SET is_default = 0 WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }

    $stmt = $conn->prepare("INSERT INTO addresses (user_id, city, street, block, entrance, apartment, is_default) 
            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssi", $user_id, $city, $street, $block, $entrance, $apartment, $is_default);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Адресът е добавен успешно']);
    } else {
        throw new Exception('Грешка при добавяне на адреса');
    }
    $stmt->close();
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
