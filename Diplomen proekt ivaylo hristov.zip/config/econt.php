<?php
/**
 * ECONT API Configuration
 * Credentials provided by ECONT
 */

// ECONT API Credentials
define('ECONT_USERNAME', 'dronchebg@gmail.com');
define('ECONT_PASSWORD', 'Test1234');
define('ECONT_API_URL', 'https://api.econt.com/v1');

// ECONT Test API (if needed for testing)
define('ECONT_TEST_API_URL', 'https://api-test.econt.com/v1');
