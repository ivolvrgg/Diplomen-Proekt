<?php
// Google OAuth Configuration

define('GOOGLE_CLIENT_ID', '380705372049-r64ikrermrdnf6q4vmac437rpaos2k05.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

// This is the REDIRECT URI (full URL with path)
// In Google Cloud Console, this goes under "Authorized redirect URIs"
define('GOOGLE_REDIRECT_URI', 'http://localhost/Diplomna_rabota/api/google-callback.php');

// For production, use:
// define('GOOGLE_REDIRECT_URI', 'https://yourdomain.com/api/google-callback.php');

// IMPORTANT: In Google Cloud Console, configure TWO different fields:
// 1. Authorized JavaScript origins (without path): http://localhost
// 2. Authorized redirect URIs (with path): http://localhost/api/google-callback.php

