<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/env.php';

// Load Stripe keys from environment variables
$stripe_secret_key = getenv('STRIPE_SECRET_KEY');

// Validate that key is set
if (!$stripe_secret_key || empty($stripe_secret_key)) {
    throw new Exception('STRIPE_SECRET_KEY not found in environment. Please check your .env file.');
}

\Stripe\Stripe::setApiKey($stripe_secret_key);
?>
