    <?php
    // Email configuration - customize these settings for your mail server

    return [
        // Using Gmail SMTP (recommended for development)
        'mailer' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'encryption' => 'tls',  // 'tls' or 'ssl'
        'username' => 'dronchebg@gmail.com',  // Change this to your Gmail
        'password' => 'aumi hium fmmu fudd',      // Use App Password, not regular password
        'from_email' => 'dronchebg@gmail.com',
        'from_name' => 'Dronche.BG',
        
        // Alternative: Use local mail server with PHP mail()
        // 'mailer' => 'mail',
    ];

    // NOTE: For Gmail:
    // 1. Enable 2FA on your Gmail account
    // 2. Create App Password: https://myaccount.google.com/apppasswords
    // 3. Use that App Password in the 'password' field above
    //
    // Other options:
    // - SendGrid: host = smtp.sendgrid.net, port = 587
    // - Mailtrap: host = live.smtp.mailtrap.io, port = 587 (test emails)
    // - Your hosting provider's SMTP
    ?>
