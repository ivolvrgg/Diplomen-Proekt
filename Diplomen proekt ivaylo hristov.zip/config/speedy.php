<?php
/**
 * Speedy Configuration - DEPRECATED
 * Speedy has been removed from the system entirely.
 */
?>
