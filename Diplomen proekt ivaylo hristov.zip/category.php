<?php
$page_title = 'Каталог по категория';
$page_css = 'css/category-products.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <?php
        // Get category ID from URL
        $category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        
        if ($category_id > 0) {
            // Get category details
            $cat_query = "SELECT * FROM categories WHERE id = $category_id";
            $cat_result = $conn->query($cat_query);
            
            if ($cat_result && $cat_result->num_rows > 0) {
                $category = $cat_result->fetch_assoc();
        ?>
        
        <section class="category-header">
            <div class="container">
                <h1 class="category-title"><?php echo htmlspecialchars($category['name']); ?></h1>
                <p class="category-description"><?php echo htmlspecialchars($category['description'] ?? ''); ?></p>
            </div>
        </section>

        <section class="category-products">
            <div class="container">
                <div class="products-grid">
                    <?php
                    // Get all products for this category
                    $products_query = "SELECT * FROM products WHERE category_id = $category_id AND is_active = 1 ORDER BY id DESC";
                    $products_result = $conn->query($products_query);
                    
                    if ($products_result && $products_result->num_rows > 0) {
                        while ($product = $products_result->fetch_assoc()) {
                            $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                    ?>
                    <div class="product-item">
                        <div class="product-card">
                            <a href="itempage.php?id=<?php echo $product['id']; ?>" class="product-link">
                                <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                                <div class="product-overlay">
                                    <span class="view-details">Преглед</span>
                                </div>
                            </a>
                            
                            <div class="product-info">
                                <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">
                                    <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                        <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                        <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                    <?php } else { ?>
                                        <?php echo number_format($product['price'], 2); ?> €
                                    <?php } ?>
                                </p>
                                <p class="product-stock">
                                    <?php echo $product['stock'] > 0 ? 'На склад (' . $product['stock'] . ')' : 'Изчерпан'; ?>
                                </p>
                            </div>
                            
                            <a href="itempage.php?id=<?php echo $product['id']; ?>" class="btn-buy">Купи</a>
                        </div>
                    </div>
                    <?php
                        }
                    } else {
                        echo '<div class="empty-state"><p>Няма продукти в тази категория.</p></div>';
                    }
                    ?>
                </div>
            </div>
        </section>

        <?php
            } else {
                echo '<div class="container"><p>Категорията не е намерена.</p></div>';
            }
        } else {
            echo '<div class="container"><p>Невалидна категория.</p></div>';
        }
        ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
