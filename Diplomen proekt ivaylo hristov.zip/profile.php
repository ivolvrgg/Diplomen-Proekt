<?php
$page_title = 'Моят Профил - Dronche.BG';
$page_css = 'css/profile.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// Debug session info
file_put_contents(__DIR__ . '/logs/profile_session.log', 
    "[" . date('Y-m-d H:i:s') . "] PROFILE ACCESS - Session ID: " . session_id() . 
    ", SESSION user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') .
    ", is_logged_in(): " . (is_logged_in() ? 'TRUE' : 'FALSE') . "\n", FILE_APPEND);

// Check if user is logged in - require_login will redirect if not
require_login();
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

<?php
// Check if user is logged in - require_login will redirect if not
require_login();

// Generate CSRF token for forms
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Get user data from database using prepared statement
$user_id = $_SESSION['user_id'];
file_put_contents(__DIR__ . '/logs/profile.log', "[" . date('Y-m-d H:i:s') . "] Accessing profile - user_id: $user_id (type: " . gettype($user_id) . ")\n", FILE_APPEND);

$stmt = $conn->prepare("SELECT id, fullname, email, phone, city, created_at FROM users WHERE id = ?");
if (!$stmt) {
    file_put_contents(__DIR__ . '/logs/profile.log', "[" . date('Y-m-d H:i:s') . "] Prepare error: " . $conn->error . "\n", FILE_APPEND);
}
// Use 'i' for integer binding (database now uses INT for id)
$user_id_int = intval($user_id);
$stmt->bind_param("i", $user_id_int);
$stmt->execute();
$userResult = $stmt->get_result();
file_put_contents(__DIR__ . '/logs/profile.log', "[" . date('Y-m-d H:i:s') . "] Query rows: " . ($userResult ? $userResult->num_rows : 'null') . "\n", FILE_APPEND);

if (!$userResult || $userResult->num_rows === 0) {
    file_put_contents(__DIR__ . '/logs/profile.log', "[" . date('Y-m-d H:i:s') . "] User not found - redirecting to login\n", FILE_APPEND);
    header('Location: user_login.php');
    exit;
}

$user = $userResult->fetch_assoc();
$stmt->close();
$memberSince = date('d F Y', strtotime($user['created_at']));
?>
    
    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="profile-container">
        <div class="container">
            <h1 class="section-title">Моят Профил</h1>
            
            <div class="profile-content">
                <!-- Sidebar Navigation -->
                <aside class="profile-sidebar">
                    <div class="profile-nav">
                        <button class="nav-btn active" data-section="info">
                            <i class="fas fa-user"></i> Лични данни
                        </button>
                        <button class="nav-btn" data-section="orders">
                            <i class="fas fa-list"></i> Моите поръчки
                        </button>
                        <button class="nav-btn" data-section="addresses">
                            <i class="fas fa-map-marker-alt"></i> Адреси
                        </button>
                        <button class="nav-btn" data-section="settings">
                            <i class="fas fa-cog"></i> Настройки
                        </button>
                        <button class="nav-btn logout-btn">
                            <i class="fas fa-sign-out-alt"></i> Излезте
                        </button>
                    </div>
                </aside>

                <!-- Main Content -->
                <section class="profile-main">
                    
                    <!-- Personal Info Section -->
                    <div class="section active" id="info-section">
                        <div class="section-header">
                            <h2>Лични данни</h2>
                            <button class="edit-btn" id="edit-info-btn">
                                <i class="fas fa-edit"></i> Редактирай
                            </button>
                        </div>
                        
                        <div class="user-profile-card">
                            <div class="profile-avatar">
                                <img id="profile-avatar-img" src="api/get_profile_picture.php?user_id=<?php echo $user_id; ?>" alt="Profile Avatar" onerror="console.log('Image load error'); this.src='https://via.placeholder.com/150';" onload="console.log('Image loaded successfully');">
                                <input type="file" id="avatar-file-input" accept="image/*" style="display: none;">
                                <button class="change-avatar-btn" title="Смени аватар" type="button" onclick="document.getElementById('avatar-file-input').click(); return false;">
                                    <i class="fas fa-camera"></i>
                                </button>
                            </div>
                            
                            <div class="user-info-display">
                                <div class="info-row">
                                    <span class="label">Име:</span>
                                    <span class="value" id="display-name"><?php echo htmlspecialchars($user['fullname']); ?></span>
                                </div>
                                <div class="info-row">
                                    <span class="label">Email:</span>
                                    <span class="value" id="display-email"><?php echo htmlspecialchars($user['email']); ?></span>
                                </div>
                                <div class="info-row">
                                    <span class="label">Телефон:</span>
                                    <span class="value" id="display-phone"><?php echo htmlspecialchars($user['phone'] ?? 'Не е указан'); ?></span>
                                </div>
                                <div class="info-row">
                                    <span class="label">Град:</span>
                                    <span class="value" id="display-city"><?php echo htmlspecialchars($user['city'] ?? 'Не е указан'); ?></span>
                                </div>
                                <div class="info-row">
                                    <span class="label">Членство от:</span>
                                    <span class="value"><?php echo $memberSince; ?></span>
                                </div>
                            </div>
                        </div>

                        <form class="user-info-form hidden" id="info-form">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <div class="form-group">
                                <label for="name">Име</label>
                                <input type="text" id="name" value="<?php echo htmlspecialchars($user['fullname']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Телефон</label>
                                <input type="tel" id="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="city">Град</label>
                                <input type="text" id="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>" required>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn-save">Запази</button>
                                <button type="button" class="btn-cancel">Откажи</button>
                            </div>
                        </form>
                    </div>

                    <!-- Orders Section -->
                    <div class="section" id="orders-section">
                        <div class="section-header">
                            <h2>Моите поръчки</h2>
                        </div>
                        
                        <div class="orders-list">
                            <?php
                                // Ensure arrival date columns exist (auto-migrate if needed)
                                $check_columns = $conn->query("SHOW COLUMNS FROM orders LIKE 'expected_arrival_start'");
                                if (!$check_columns || $check_columns->num_rows === 0) {
                                    // Columns don't exist, create them
                                    @$conn->query("ALTER TABLE orders 
                                                  ADD COLUMN expected_arrival_start DATE DEFAULT NULL AFTER updated_at,
                                                  ADD COLUMN expected_arrival_end DATE DEFAULT NULL AFTER expected_arrival_start");
                                    
                                    // Create index
                                    @$conn->query("CREATE INDEX idx_orders_arrival_dates ON orders (expected_arrival_start, expected_arrival_end)");
                                }
                                
                                // Now fetch user's orders with arrival dates
                                $stmt = $conn->prepare("SELECT id, status, total, created_at, expected_arrival_start, expected_arrival_end FROM orders WHERE user_id = ? ORDER BY created_at DESC");
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $ordersResult = $stmt->get_result();
                                
                                if ($ordersResult && $ordersResult->num_rows > 0) {
                                    // User has orders - display them
                                    while ($order = $ordersResult->fetch_assoc()) {
                                        $orderId = intval($order['id']);
                                        $orderStatus = htmlspecialchars($order['status']);
                                        $orderTotal = number_format($order['total'], 2, ',', ' ');
                                        $orderDate = htmlspecialchars(date('d F Y', strtotime($order['created_at'])));
                                        
                                        // Format expected arrival dates
                                        $arrivalStartFormatted = '';
                                        $arrivalEndFormatted = '';
                                        
                                        // If arrival dates are null, calculate them based on order date (same as item page)
                                        // Match item page calculation: 1-7 days from order date
                                        if (empty($order['expected_arrival_start']) || empty($order['expected_arrival_end'])) {
                                            $orderDateTime = new DateTime($order['created_at']);
                                            $arrival_start = clone $orderDateTime;
                                            $arrival_start->add(new DateInterval('P1D'));
                                            $arrival_end = clone $orderDateTime;
                                            $arrival_end->add(new DateInterval('P7D'));
                                            
                                            $arrivalStartFormatted = $arrival_start->format('d.m.Y');
                                            $arrivalEndFormatted = $arrival_end->format('d.m.Y');
                                        } else {
                                            if (!empty($order['expected_arrival_start'])) {
                                                $arrivalStartFormatted = date('d.m.Y', strtotime($order['expected_arrival_start']));
                                            }
                                            if (!empty($order['expected_arrival_end'])) {
                                                $arrivalEndFormatted = date('d.m.Y', strtotime($order['expected_arrival_end']));
                                            }
                                        }
                                        
                                        // Determine status badge class and text
                                        $statusClass = htmlspecialchars($orderStatus);
                                        $statusText = match($order['status']) {
                                            'pending' => 'Очакваща плащане',
                                            'paid' => 'Платена',
                                            'processing' => 'В обработка',
                                            'shipped' => 'Изпратена',
                                            'delivered' => 'Доставена',
                                            'cancelled' => 'Отменена',
                                            default => ucfirst(htmlspecialchars($order['status']))
                                        };
                                        
                                        // Fetch order items using prepared statement
                                        $itemStmt = $conn->prepare("SELECT p.id, p.name, p.image_1, oi.quantity, oi.unit_price, p.sale_price FROM order_items oi 
                                                          JOIN products p ON oi.product_id = p.id 
                                                          WHERE oi.order_id = ?");
                                        $itemStmt->bind_param("i", $orderId);
                                        $itemStmt->execute();
                                        $itemsResult = $itemStmt->get_result();
                                        $itemsHtml = '';
                                        $calculatedTotal = 0;
                                        
                                        if ($itemsResult && $itemsResult->num_rows > 0) {
                                            while ($item = $itemsResult->fetch_assoc()) {
                                                $itemName = htmlspecialchars($item['name']);
                                                $itemQuantity = intval($item['quantity']);
                                                // Use sale price if available, otherwise use unit price (without VAT)
                                                $display_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['unit_price'];
                                                $itemPrice = number_format($display_price * $itemQuantity, 2, ',', ' ');
                                                $calculatedTotal += $display_price * $itemQuantity;
                                                $imageUrl = get_image_url($item['image_1'], $item['name']);
                                                $productId = intval($item['id']);
                                                $itemsHtml .= "<div style='display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-start;'><a href='itempage.php?id=" . $productId . "' style='text-decoration: none; color: inherit; display: flex; flex-shrink: 0;'><img src='" . htmlspecialchars($imageUrl) . "' alt='" . $itemName . "' style='width: 60px; height: 60px; object-fit: cover; border-radius: 4px; cursor: pointer;'></a><div><p style='margin: 0;'><a href='itempage.php?id=" . $productId . "' style='text-decoration: none; color: inherit;'><strong style='cursor: pointer;'>" . $itemName . "</strong></a> (" . $itemQuantity . " x) - " . $itemPrice . " €</p></div></div>";
                                            }
                                        }
                                        $itemStmt->close();
                                        // Add delivery cost (3.00€) to the calculated total
                                        $deliveryCost = 3.00;
                                        $totalWithDelivery = $calculatedTotal + $deliveryCost;
                                        $orderTotal = number_format($totalWithDelivery, 2, ',', ' ');
                            ?>
                            <div class="order-card">
                                <div class="order-header">
                                    <div class="order-id">
                                        <strong>Поръчка #ORD-<?php echo str_pad($orderId, 6, '0', STR_PAD_LEFT); ?></strong>
                                        <span class="order-date"><?php echo $orderDate; ?></span>
                                    </div>
                                    <span class="order-status <?php echo $statusClass; ?>"><?php echo htmlspecialchars($statusText); ?></span>
                                </div>
                                
                                <?php if ($arrivalStartFormatted && $arrivalEndFormatted) { ?>
                                <div class="order-arrival-dates" style="padding: 10px 0; border-bottom: 1px solid #f0f0f0; margin-bottom: 10px;">
                                    <p style="margin: 0; font-size: 13px; color: #666;">
                                        <strong style="color: #588157;">Очаквано доставяне:</strong> 
                                        <?php echo htmlspecialchars($arrivalStartFormatted); ?> - <?php echo htmlspecialchars($arrivalEndFormatted); ?>
                                    </p>
                                </div>
                                <?php } ?>
                                
                                <div class="order-items">
                                    <?php echo $itemsHtml; ?>
                                </div>
                                <div class="order-footer">
                                    <span class="order-total">Обща сума: <?php echo $orderTotal; ?> €</span>
                                    <div style="display: flex; gap: 10px; align-items: center;">
                                        <?php
                                            // Check if invoice exists for this order
                                            $invoice_check = $conn->query("SELECT id, invoice_number FROM invoices WHERE order_id = " . $orderId);
                                            if ($invoice_check && $invoice_check->num_rows > 0) {
                                                $invoice = $invoice_check->fetch_assoc();
                                                $invoice_id = intval($invoice['id']);
                                                echo '<a href="api/view-invoice.php?invoice_id=' . $invoice_id . '" class="btn-view-invoice" style="padding: 8px 15px; background: #588157; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; font-size: 13px; font-weight: bold;" target="_blank">📄 ' . htmlspecialchars($invoice['invoice_number']) . '</a>';
                                            }
                                        ?>
                                        <button class="btn-view-details">Преглед</button>
                                    </div>
                                </div>
                            </div>
                            <?php
                                    }
                                    $stmt->close();
                                } else {
                                    // User has no orders
                                    echo '<div class="no-orders-message" style="text-align: center; padding: 40px 20px; color: #8b9d88;">';
                                    echo '<p style="font-size: 18px; margin-bottom: 10px;">Нямаш никакви поръчки</p>';
                                    echo '<p style="color: #8b9d88; margin-bottom: 30px;">Като направиш своята първа поръчка, тя ще се появи тук.</p>';
                                    echo '<a href="catalog.php" class="btn-primary" style="display: inline-block; padding: 10px 30px; background: #588157; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">Направи поръчка</a>';
                                    echo '</div>';
                                }
                            ?>
                        </div>
                    </div>

                    <!-- Addresses Section -->
                    <div class="section" id="addresses-section">
                        <div class="section-header">
                            <h2>Моите адреси</h2>
                            <button type="button" class="btn-add-address">
                                <i class="fas fa-plus"></i> Добави адрес
                            </button>
                        </div>
                        
                        <div class="addresses-list">
                            <?php
                                // Fetch user's addresses from database using prepared statement
                                $stmt = $conn->prepare("SELECT id, city, street, block, entrance, apartment, is_default FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id ASC");
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $addressesResult = $stmt->get_result();
                                
                                if ($addressesResult && $addressesResult->num_rows > 0) {
                                    while ($address = $addressesResult->fetch_assoc()) {
                                        $addrId = intval($address['id']);
                                        $city = htmlspecialchars($address['city']);
                                        $street = htmlspecialchars($address['street']);
                                        $block = htmlspecialchars($address['block'] ?? '');
                                        $entrance = htmlspecialchars($address['entrance'] ?? '');
                                        $apartment = htmlspecialchars($address['apartment'] ?? '');
                                        $isDefault = $address['is_default'] ? 'default' : '';
                                        $badgeHtml = $address['is_default'] ? '<span class="default-badge">Основен</span>' : '';
                            ?>
                            <div class="address-card <?php echo $isDefault; ?>" data-address-id="<?php echo $addrId; ?>">
                                <div class="address-header">
                                    <h3><?php echo $street; ?></h3>
                                    <?php echo $badgeHtml; ?>
                                </div>
                                <p><?php echo $city; ?></p>
                                <?php if ($block) echo "<p>Блок: " . $block . "</p>"; ?>
                                <?php if ($entrance) echo "<p>Вход: " . $entrance . "</p>"; ?>
                                <?php if ($apartment) echo "<p>Апартамент: " . $apartment . "</p>"; ?>
                                <div class="address-actions">
                                    <button type="button" class="btn-edit-address" data-address-id="<?php echo $addrId; ?>">Редактирай</button>
                                    <button type="button" class="btn-delete-address" data-address-id="<?php echo $addrId; ?>">Изтрий</button>
                                </div>
                            </div>
                            <?php
                                    }
                                    $stmt->close();
                                } else {
                                    echo '<div style="text-align: center; padding: 40px 20px; color: #8b9d88;">';
                                    echo '<p style="font-size: 16px; margin-bottom: 20px;">Нямаш добавени адреси</p>';
                                    echo '<p style="color: #8b9d88;">Добави адрес за по-лесна доставка на поръчките.</p>';
                                    echo '</div>';
                                }
                            ?>
                        </div>
                        
                        <div id="address-form-container" style="display: none; margin-top: 30px; padding: 20px; background: #faf8f3; border-radius: 8px;">
                            <h3 id="form-title">Добави нов адрес</h3>
                            <form id="address-form">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" id="address-id" value="">
                                <div style="margin-bottom: 15px;">
                                    <label for="addr-city">Град:</label>
                                    <input type="text" id="addr-city" placeholder="Град" required style="width: 100%; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <label for="addr-street">Улица:</label>
                                    <input type="text" id="addr-street" placeholder="Улица" required style="width: 100%; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <label for="addr-block">Блок:</label>
                                    <input type="text" id="addr-block" placeholder="Блок (опционално)" style="width: 100%; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <label for="addr-entrance">Вход:</label>
                                    <input type="text" id="addr-entrance" placeholder="Вход (опционално)" style="width: 100%; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <label for="addr-apartment">Апартамент:</label>
                                    <input type="text" id="addr-apartment" placeholder="Апартамент (опционално)" style="width: 100%; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <label>
                                        <input type="checkbox" id="addr-default"> Задай като основен адрес
                                    </label>
                                </div>
                                <div style="display: flex; gap: 10px;">
                                    <button type="submit" class="btn-save" >Запази</button>
                                     <button type="button" class="btn-cancel" >Откажи</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Settings Section -->
                    <div class="section" id="settings-section">
                        <div class="section-header">
                            <h2>Настройки</h2>
                        </div>
                        
                        <div class="settings-group">
                            <h3>Известия</h3>
                            <div class="setting-item">
                                <div class="setting-text">
                                    <p class="setting-label">Имейл известия за поръчки</p>
                                    <p class="setting-desc">Получавайте уведомления за статуса на поръчката</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" checked>
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">
                                    <p class="setting-label">Маркетингови имейли</p>
                                    <p class="setting-desc">Получавайте ексклузивни предложения и новини</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox">
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>

                        <div class="settings-group">
                            <h3>Сигурност</h3>
                            <button class="btn-change-password" style="background: #588157; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                                <i class="fas fa-lock"></i> Промени паролата
                            </button>
                            <div id="password-form-container" style="display: none; margin-top: 20px; padding: 20px; background: #faf8f3; border-radius: 8px;">
                                <h4>Промяна на парола</h4>
                                <form id="password-form">
                                    <div style="margin-bottom: 15px;">
                                        <label for="old-password">Текуща парола:</label>
                                        <div style="display: flex; gap: 10px; align-items: center;">
                                            <input type="password" id="old-password" placeholder="Текуща парола" required style="flex: 1; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                                <input type="checkbox" class="toggle-password" data-target="old-password">
                                                <span style="font-size: 14px;">👁️</span>
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-bottom: 15px;">
                                        <label for="new-password">Нова парола:</label>
                                        <div style="display: flex; gap: 10px; align-items: center;">
                                            <input type="password" id="new-password" placeholder="Нова парола" required style="flex: 1; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                                <input type="checkbox" class="toggle-password" data-target="new-password">
                                                <span style="font-size: 14px;">👁️</span>
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-bottom: 15px;">
                                        <label for="confirm-password">Потвърди паролата:</label>
                                        <div style="display: flex; gap: 10px; align-items: center;">
                                            <input type="password" id="confirm-password" placeholder="Потвърди паролата" required style="flex: 1; padding: 8px; border: 1px solid #e8e6df; border-radius: 4px; box-sizing: border-box;">
                                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                                <input type="checkbox" class="toggle-password" data-target="confirm-password">
                                                <span style="font-size: 14px;">👁️</span>
                                            </label>
                                        </div>
                                    </div>
                                    <div style="display: flex; gap: 10px;">
                                        <button type="submit" style="background: #588157; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Запази</button>
                                        <button type="button" id="cancel-password-form" style="background: #a3b18a; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Откажи</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="settings-group danger-zone">
                            <h3>Опасна зона</h3>
                            <button class="btn-delete-account">
                                <i class="fas fa-trash"></i> Изтрий профил
                            </button>
                        </div>
                    </div>

                </section>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script>
        // Initialize profile functionality BEFORE include
        function initProfileEvents() {
            console.log('✓ PROFILE SCRIPT RUNNING');
            
            // Handle avatar change
            const changeAvatarBtn = document.querySelector('.change-avatar-btn');
            const avatarFileInput = document.getElementById('avatar-file-input');
            
            console.log('Avatar button found:', !!changeAvatarBtn);
            console.log('File input found:', !!avatarFileInput);
            
            if (changeAvatarBtn && avatarFileInput) {
                changeAvatarBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Avatar button clicked');
                    avatarFileInput.click();
                });
                
                avatarFileInput.addEventListener('change', function(e) {
                    if (this.files && this.files[0]) {
                        const file = this.files[0];
                        console.log('File selected:', file.name, 'Size:', file.size, 'Type:', file.type);
                        
                        // Validate file size (2MB max)
                        if (file.size > 2 * 1024 * 1024) {
                            alert('Файлът е твърде голям (максимум 2MB)');
                            return;
                        }
                        
                        // Validate file type
                        if (!['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(file.type)) {
                            alert('Позволени са само JPEG, PNG, GIF и WebP файлове');
                            return;
                        }
                        
                        // Create FormData for file upload
                        const formData = new FormData();
                        formData.append('profile_picture', file);
                        
                        // Disable button during upload
                        changeAvatarBtn.disabled = true;
                        const originalText = changeAvatarBtn.innerHTML;
                        changeAvatarBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                        
                        console.log('Starting upload...');
                        
                        fetch('api/upload_profile_picture.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(r => r.json())
                        .then(data => {
                            console.log('Upload response:', data);
                            if (data.success) {
                                // Update avatar image with cache busting
                                const avatarImg = document.getElementById('profile-avatar-img');
                                if (avatarImg) {
                                    // Force reload with timestamp
                                    const newSrc = 'api/get_profile_picture.php?user_id=' + <?php echo $user_id; ?> + '&t=' + Date.now();
                                    console.log('Setting image src to:', newSrc);
                                    
                                    // Add load/error handlers
                                    avatarImg.onload = function() {
                                        console.log('✓ Image loaded successfully');
                                    };
                                    
                                    avatarImg.onerror = function() {
                                        console.log('✗ Image failed to load, using placeholder');
                                        this.src = 'https://via.placeholder.com/150';
                                    };
                                    
                                    // Trigger the load
                                    avatarImg.src = newSrc;
                                }
                                alert('Снимката е качена успешно');
                            } else {
                                alert('Грешка: ' + (data.error || 'Неизвестна грешка'));
                            }
                        })
                        .catch(err => {
                            console.error('Upload error:', err);
                            alert('Грешка при качване: ' + err);
                        })
                        .finally(() => {
                            // Re-enable button
                            changeAvatarBtn.disabled = false;
                            changeAvatarBtn.innerHTML = originalText;
                            // Reset file input
                            avatarFileInput.value = '';
                        });
                    }
                });
            }
            
            // Profile section navigation
            const navBtns = document.querySelectorAll('.profile-nav .nav-btn');
            console.log('✓ Found nav buttons:', navBtns.length);
            
            navBtns.forEach((btn, index) => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    console.log('✓✓✓ CLICKED:', this.textContent.trim());
                    
                    if (this.classList.contains('logout-btn')) {
                        window.location.href = 'api/logout.php';
                        return;
                    }
                    
                    // Deactivate all buttons and sections
                    document.querySelectorAll('.profile-nav .nav-btn').forEach(b => b.classList.remove('active'));
                    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
                    
                    // Activate current button and section
                    this.classList.add('active');
                    const targetId = this.dataset.section + '-section';
                    const target = document.getElementById(targetId);
                    if (target) {
                        target.classList.add('active');
                        console.log('✓ Switched to:', targetId);
                    }
                });
            });

            // Check URL parameters for tab switching
            const urlParams = new URLSearchParams(window.location.search);
            const tabParam = urlParams.get('tab');
            if (tabParam) {
                const targetBtn = document.querySelector(`[data-section="${tabParam}"]`);
                if (targetBtn) {
                    targetBtn.click();
                }
            }

            // Edit profile info
            const editBtn = document.getElementById('edit-info-btn');
            const infoDisplay = document.querySelector('.user-info-display');
            const infoForm = document.getElementById('info-form');
            const cancelBtn = document.querySelector('.btn-cancel');

            if (editBtn) {
                editBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    infoDisplay.classList.add('hidden');
                    infoForm.classList.remove('hidden');
                });
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    infoDisplay.classList.remove('hidden');
                    infoForm.classList.add('hidden');
                });
            }

            // Save personal info button
            const saveInfoBtn = document.querySelector('.btn-save');
            if (saveInfoBtn) {
                saveInfoBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const fullname = document.getElementById('name').value.trim();
                    const email = document.getElementById('email').value.trim();
                    const phone = document.getElementById('phone').value.trim();
                    const city = document.getElementById('city').value.trim();
                    const csrfToken = document.querySelector('input[name="csrf_token"]').value;
                    
                    if (!fullname || !email) {
                        alert('Име и Email са задължителни');
                        return;
                    }
                    
                    fetch('api/update_profile.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({fullname, email, phone, city, csrf_token: csrfToken})
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('display-name').textContent = fullname;
                            document.getElementById('display-email').textContent = email;
                            document.getElementById('display-phone').textContent = phone || 'Не е указан';
                            document.getElementById('display-city').textContent = city || 'Не е указан';
                            
                            infoDisplay.classList.remove('hidden');
                            infoForm.classList.add('hidden');
                            alert('Профилът е обновен успешно');
                        } else {
                            alert(data.error || 'Грешка при запазване');
                        }
                    })
                    .catch(err => alert('Грешка: ' + err));
                });
            }

            // View order details
            document.querySelectorAll('.btn-view-details').forEach(btn => {
                btn.addEventListener('click', function() {
                    const orderCard = this.closest('.order-card');
                    const orderHeader = orderCard.querySelector('.order-header');
                    const orderId = orderHeader.querySelector('.order-id strong').textContent;
                    const orderStatus = orderHeader.querySelector('.order-status').textContent;
                    const orderTotal = orderCard.querySelector('.order-total').textContent;
                    const orderItems = orderCard.querySelector('.order-items').innerHTML;
                    
                    const detailsModal = `
                        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;" class="order-details-modal">
                            <div style="background: white; padding: 30px; border-radius: 8px; max-width: 600px; width: 90%; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f0ede8; padding-bottom: 15px;">
                                    <h2 style="margin: 0; color: #344e41;">${orderId}</h2>
                                    <button onclick="this.closest('.order-details-modal').remove();" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #8b9d88;">&times;</button>
                                </div>
                                <div style="margin-bottom: 20px;">
                                    <p style="display: flex; justify-content: space-between; margin: 10px 0;"><strong>Статус:</strong> <span>${orderStatus}</span></p>
                                    <p style="display: flex; justify-content: space-between; margin: 10px 0;"><strong>Обща сума:</strong> <span>${orderTotal}</span></p>
                                </div>
                                <div style="margin-bottom: 20px;">
                                    <h3 style="margin: 0 0 15px 0; color: #344e41;">Артикули:</h3>
                                    <div style="background: #faf8f3; padding: 15px; border-radius: 4px;">${orderItems}</div>
                                </div>
                                <button onclick="this.closest('.order-details-modal').remove();" style="width: 100%; padding: 12px; background: #588157; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px;">Затвори</button>
                            </div>
                        </div>
                    `;
                    
                    document.body.insertAdjacentHTML('beforeend', detailsModal);
                });
            });

            // Address Management
            const addressFormContainer = document.getElementById('address-form-container');
            const addressForm = document.getElementById('address-form');
            const cancelAddressBtn = document.getElementById('cancel-address-form');
            const btnAddAddress = document.querySelector('.btn-add-address');

            if (btnAddAddress) {
                btnAddAddress.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (addressForm) addressForm.reset();
                    document.getElementById('address-id').value = '';
                    document.getElementById('form-title').textContent = 'Добави нов адрес';
                    addressFormContainer.style.display = 'block';
                });
            }

            if (cancelAddressBtn) {
                cancelAddressBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    addressFormContainer.style.display = 'none';
                    if (addressForm) addressForm.reset();
                });
            }

            document.querySelectorAll('.btn-edit-address').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const addressId = this.dataset.addressId;
                    const addressCard = document.querySelector(`[data-address-id="${addressId}"]`);
                    
                    const header = addressCard.querySelector('.address-header h3');
                    const paragraphs = addressCard.querySelectorAll('p');
                    
                    const street = header.textContent.trim();
                    let city = '', block = '', entrance = '', apartment = '';
                    
                    if (paragraphs.length > 0) city = paragraphs[0].textContent.trim();
                    if (paragraphs.length > 1) {
                        for (let i = 1; i < paragraphs.length; i++) {
                            const text = paragraphs[i].textContent.trim();
                            if (text.startsWith('Блок:')) block = text.replace('Блок:', '').trim();
                            if (text.startsWith('Вход:')) entrance = text.replace('Вход:', '').trim();
                            if (text.startsWith('Апартамент:')) apartment = text.replace('Апартамент:', '').trim();
                        }
                    }
                    
                    document.getElementById('address-id').value = addressId;
                    document.getElementById('addr-city').value = city;
                    document.getElementById('addr-street').value = street;
                    document.getElementById('addr-block').value = block;
                    document.getElementById('addr-entrance').value = entrance;
                    document.getElementById('addr-apartment').value = apartment;
                    document.getElementById('addr-default').checked = addressCard.classList.contains('default');
                    
                    document.getElementById('form-title').textContent = 'Редактирай адрес';
                    addressFormContainer.style.display = 'block';
                });
            });

            document.querySelectorAll('.btn-delete-address').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('Сигурен ли сте, че искате да изтриете този адрес?')) {
                        const addressId = this.dataset.addressId;
                        fetch('api/delete_address.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({address_id: addressId})
                        })
                        .then(r => r.json())
                        .then(data => {
                            if (data.success) location.reload();
                            else alert('Грешка при изтриване на адреса');
                        });
                    }
                });
            });

            if (addressForm) {
                addressForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const addressId = document.getElementById('address-id').value;
                    const city = document.getElementById('addr-city').value;
                    const street = document.getElementById('addr-street').value;
                    const block = document.getElementById('addr-block').value;
                    const entrance = document.getElementById('addr-entrance').value;
                    const apartment = document.getElementById('addr-apartment').value;
                    const isDefault = document.getElementById('addr-default').checked;
                    
                    if (!city || !street) {
                        alert('Град и адрес са задължителни полета');
                        return;
                    }
                    
                    const endpoint = addressId ? 'api/update_address.php' : 'api/add_address.php';
                    const payload = { city, street, block, entrance, apartment, is_default: isDefault };
                    if (addressId) payload.address_id = addressId;
                    
                    fetch(endpoint, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(payload)
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) location.reload();
                        else alert(data.error || 'Грешка при запазване на адреса');
                    });
                });
            }

            // Password change
            const passwordFormContainer = document.getElementById('password-form-container');
            const passwordForm = document.getElementById('password-form');
            const btnChangePassword = document.querySelector('.btn-change-password');
            const cancelPasswordBtn = document.getElementById('cancel-password-form');

            if (btnChangePassword) {
                btnChangePassword.addEventListener('click', function(e) {
                    e.preventDefault();
                    passwordFormContainer.style.display = passwordFormContainer.style.display === 'none' ? 'block' : 'none';
                    if (passwordFormContainer.style.display === 'block' && passwordForm) passwordForm.reset();
                });
            }

            if (cancelPasswordBtn) {
                cancelPasswordBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    passwordFormContainer.style.display = 'none';
                    if (passwordForm) passwordForm.reset();
                });
            }

            if (passwordForm) {
                passwordForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const oldPassword = document.getElementById('old-password').value;
                    const newPassword = document.getElementById('new-password').value;
                    const confirmPassword = document.getElementById('confirm-password').value;
                    
                    if (newPassword !== confirmPassword) {
                        alert('Паролите не съвпадат');
                        return;
                    }
                    
                    if (newPassword.length < 6) {
                        alert('Паролата трябва да е поне 6 символа');
                        return;
                    }
                    
                    fetch('api/change_password.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({old_password: oldPassword, new_password: newPassword})
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            alert('Паролата е променена успешно');
                            passwordFormContainer.style.display = 'none';
                            if (passwordForm) passwordForm.reset();
                        } else {
                            alert(data.error || 'Грешка при промяна на паролата');
                        }
                    });
                });
            }

            const btnDeleteAccount = document.querySelector('.btn-delete-account');
            if (btnDeleteAccount) {
                btnDeleteAccount.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('ВНИМАНИЕ: Това действие е необратимо. Сигурен ли сте, че искате да изтриете вашия профил? Всички ваши данни ще бъдат изтрити.')) {
                        if (confirm('Последно потвърждение: Наистина ли искаш да изтриеш профила?')) {
                            fetch('api/delete_account.php', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                body: JSON.stringify({confirm: true})
                            })
                            .then(r => r.json())
                            .then(data => {
                                if (data.success) {
                                    alert('Профилът е изтрит успешно. Ще бъдеш пренасочен към началната страница.');
                                    window.location.href = 'homepage.php';
                                } else {
                                    alert(data.error || 'Грешка при изтриване на профила');
                                }
                            });
                        }
                    }
                });
            }
        }

        // Run when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initProfileEvents);
        } else {
            initProfileEvents();
        }

        // Toggle password visibility
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.toggle-password').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const targetId = this.getAttribute('data-target');
                    const passwordInput = document.getElementById(targetId);
                    if (passwordInput) {
                        passwordInput.type = this.checked ? 'text' : 'password';
                    }
                });
            });
        });
    </script>

    <?php include 'includes/scripts.php'; ?>
