<?php
$page_title = 'Потвърждение на поръчка | Dronche.BG';
$page_css = 'css/order-confirmation.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="confirmation-container">
        <div class="container">
            <?php
            $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
            
            if ($order_id > 0) {
                // Get order details
                $order_query = "SELECT * FROM orders WHERE id = $order_id";
                $order_result = $conn->query($order_query);
                
                if ($order_result && $order_result->num_rows > 0) {
                    $order = $order_result->fetch_assoc();
                    
                    // Get delivery method name
                    $delivery_query = "SELECT name FROM delivery_methods WHERE id = " . intval($order['delivery_method_id']);
                    $delivery_result = $conn->query($delivery_query);
                    $delivery_method = $delivery_result ? $delivery_result->fetch_assoc() : null;
                    
                    // Get order items
                    $items_query = "SELECT p.name, oi.quantity, oi.unit_price FROM order_items oi 
                                   JOIN products p ON oi.product_id = p.id 
                                   WHERE oi.order_id = $order_id";
                    $items_result = $conn->query($items_query);
            ?>
            
            <div class="confirmation-box">
                <div class="confirmation-icon">✓</div>
                <h1>Вашата поръчка е успешно завършена!</h1>
                <p class="order-number">Поръчка №<strong> ORD-<?php echo str_pad($order_id, 6, '0', STR_PAD_LEFT); ?></strong></p>
                
                <div class="order-summary-box">
                    <h2>Информация за поръчката</h2>
                    
                    <div class="info-row">
                        <span class="label">Имейл за потвърждение:</span>
                        <span class="value"><?php echo htmlspecialchars($order['email']); ?></span>
                    </div>
                    
                    <div class="info-row">
                        <span class="label">Дата на поръчката:</span>
                        <span class="value"><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></span>
                    </div>
                    
                    <div class="info-row">
                        <span class="label">Статус:</span>
                        <span class="value status <?php echo htmlspecialchars($order['status']); ?>">
                            <?php
                            $status_text = match($order['status']) {
                                'pending' => 'Очакваща плащане',
                                'paid' => 'Платена',
                                'processing' => 'В обработка',
                                'shipped' => 'Изпратена',
                                'delivered' => 'Доставена',
                                'cancelled' => 'Отменена',
                                default => ucfirst(htmlspecialchars($order['status']))
                            };
                            echo $status_text;
                            ?>
                        </span>
                    </div>
                    
                    <?php 
                    $arrival_start_formatted = '';
                    $arrival_end_formatted = '';
                    if (!empty($order['expected_arrival_start'])) {
                        $arrival_start_formatted = date('d.m.Y', strtotime($order['expected_arrival_start']));
                    }
                    if (!empty($order['expected_arrival_end'])) {
                        $arrival_end_formatted = date('d.m.Y', strtotime($order['expected_arrival_end']));
                    }
                    ?>
                    
                    <?php if ($arrival_start_formatted && $arrival_end_formatted) { ?>
                    <div class="info-row">
                        <span class="label">Очаквано доставяне:</span>
                        <span class="value" style="font-weight: 600; color: #588157;">
                            <?php echo htmlspecialchars($arrival_start_formatted); ?> - <?php echo htmlspecialchars($arrival_end_formatted); ?>
                        </span>
                    </div>
                    <?php } ?>
                    
                    <h3 style="margin-top: 2rem; margin-bottom: 1rem;">Артикули</h3>
                    <div class="items-list">
                        <?php
                        if ($items_result && $items_result->num_rows > 0) {
                            while ($item = $items_result->fetch_assoc()) {
                                $item_total = $item['unit_price'] * $item['quantity'];
                        ?>
                        <div class="item-row">
                            <span class="item-name"><?php echo htmlspecialchars($item['name']); ?></span>
                            <span class="item-quantity"><?php echo intval($item['quantity']); ?> x</span>
                            <span class="item-price"><?php echo number_format($item['unit_price'], 2); ?> €</span>
                            <span class="item-total"><?php echo number_format($item_total, 2); ?> €</span>
                        </div>
                        <?php
                            }
                        }
                        ?>
                    </div>
                    
                    <div class="totals-box">
                        <div class="total-row">
                            <span>Подсума:</span>
                            <span><?php echo number_format($order['subtotal'], 2); ?> €</span>
                        </div>
                        <div class="total-row">
                            <span>Доставка:</span>
                            <span><?php echo number_format($order['delivery_cost'], 2); ?> €</span>
                        </div>
                        <div class="total-row">
                            <span>ДДС (20%):</span>
                            <span><?php echo number_format($order['vat'], 2); ?> €</span>
                        </div>
                        <div class="total-row total-final">
                            <span>ОБЩО:</span>
                            <span><?php echo number_format($order['total'], 2); ?> €</span>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <span class="label">Начин на доставка:</span>
                        <span class="value"><?php echo $delivery_method ? htmlspecialchars($delivery_method['name']) : 'N/A'; ?></span>
                    </div>
                    
                    <div class="info-row">
                        <span class="label">Начин на плащане:</span>
                        <span class="value">
                            <?php
                            echo $order['payment_method'] === 'card' ? 'Плащане с карта' : 'Наложен платеж';
                            ?>
                        </span>
                    </div>
                </div>
                
                <div class="confirmation-actions">
                    <a href="homepage.php" class="btn-continue">Продължете към пазаруването</a>
                    <?php if (is_logged_in()): ?>
                    <a href="profile.php" class="btn-profile">Моя профил</a>
                    <?php endif; ?>
                </div>
                
                <p class="confirmation-message">
                    На имейл адреса <strong><?php echo htmlspecialchars($order['email']); ?></strong> е изпратено потвърждение на вашата поръчка.
                </p>
            </div>
            
            <?php
                } else {
                    echo '<div class="error-message"><h2>Поръчката не е намерена</h2></div>';
                }
            } else {
                echo '<div class="error-message"><h2>Невалидна поръчка</h2></div>';
            }
            ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
</body>
</html>
