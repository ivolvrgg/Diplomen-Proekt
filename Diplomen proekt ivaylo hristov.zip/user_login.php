<?php
$page_title = 'Вход - Dronche.BG';
$page_css = 'css/user_login.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// If user is already logged in, redirect to homepage
if (is_logged_in()) {
    header('Location: homepage.php');
    exit;
}
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Вход</h1>
                <form class="login-form" id="loginForm">
                    <div class="form-group">
                        <label for="email">Email адрес</label>
                        <input type="email" id="email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Паролa</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="password" name="password" required placeholder="Въведи своя пароля" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            Помни ме
                        </label>
                        <a href="password-recovery.php" class="forgot-password-link">Забравена парола?</a>
                    </div>
                    
                    <button type="submit" class="login-btn">Вход</button>
                </form>
                
                <div style="margin: 20px 0; border-top: 1px solid #ddd; padding-top: 20px;">
                    <p style="text-align: center; color: #666; font-size: 14px; margin-bottom: 15px;">или продължи с</p>
                    <a href="<?php include 'includes/google_auth.php'; echo getGoogleAuthUrl(); ?>" class="google-login-btn">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 8px;">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        Вход с Google
                    </a>
                </div>
                
                <div class="signup-link">
                    Нямаш акаунт? <a href="user_register.php">Регистрирай се тук</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        // Handle password visibility toggle
        document.querySelectorAll('.toggle-password').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const targetId = this.dataset.target;
                const targetInput = document.getElementById(targetId);
                if (targetInput) {
                    targetInput.type = this.checked ? 'text' : 'password';
                }
            });
        });

        // Merge guest cart into logged-in user's cart
        function mergeGuestCart() {
            const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            if (guestCart.length === 0) return Promise.resolve();

            return fetch('api/cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ action: 'merge', items: guestCart })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.removeItem('guest_cart');
                    console.log('Guest cart merged successfully');
                }
            })
            .catch(error => {
                console.error('Error merging guest cart:', error);
            });
        }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const rememberMe = document.querySelector('[name="remember"]').checked;
            const btn = document.querySelector('.login-btn');
            
            // Clear previous errors
            const emailErrorEl = document.getElementById('emailError');
            const passwordErrorEl = document.getElementById('passwordError');
            emailErrorEl.textContent = '';
            emailErrorEl.classList.remove('show');
            passwordErrorEl.textContent = '';
            passwordErrorEl.classList.remove('show');
            
            // Set loading state
            btn.disabled = true;
            btn.textContent = 'Моля изчакайте...';
            
            // Submit to server
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('remember', rememberMe ? '1' : '0');
            
            fetch('api/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Merge guest cart before redirect
                    mergeGuestCart().then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    // Re-enable button
                    btn.disabled = false;
                    btn.textContent = 'Вход';
                    
                    // Show error
                    const errorMsg = data.message || 'Възникна грешка';
                    const errorField = data.error_field;
                    
                    if (errorField === 'email') {
                        const emailErrorEl = document.getElementById('emailError');
                        emailErrorEl.textContent = errorMsg;
                        emailErrorEl.classList.add('show');
                    } else if (errorField === 'password') {
                        const passwordErrorEl = document.getElementById('passwordError');
                        passwordErrorEl.textContent = errorMsg;
                        passwordErrorEl.classList.add('show');
                    } else {
                        alert(errorMsg);
                    }
                }
            })
            .catch(err => {
                // Re-enable button on error
                btn.disabled = false;
                btn.textContent = 'Вход';
                alert('Възникна грешка при вход: ' + err.message);
            });
        });

        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.getElementById(targetId);
                passwordInput.type = this.checked ? 'text' : 'password';
            });
        });
    </script>
</body>
</html>
