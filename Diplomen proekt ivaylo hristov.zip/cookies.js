// Cookie Consent Management Script

(function() {
    'use strict';

    const COOKIE_CONSENT_NAME = 'dronche_cookie_consent';
    const COOKIE_EXPIRY_DAYS = 365;

    // Cookie categories and their defaults
    const COOKIE_CATEGORIES = {
        necessary: {
            name: 'Необходимо',
            description: 'Необходимо за функционирането на сайта. Не могат да бъдат Изключени.',
            required: true
        },
        functional: {
            name: 'Функционално',
            description: 'Помага ни да запомним вашите предпочитания и настройки.',
            required: false
        },
        analytics: {
            name: 'Аналитика',
            description: 'Помага ни да разберем как използвате сайта.',
            required: false
        },
        marketing: {
            name: 'Маркетинг',
            description: 'Използва се за персонализирани реклами и маркетингово съдържание.',
            required: false
        }
    };

    // Initialize cookie consent
    function init() {
        // Check if consent has already been given
        const consent = getCookieConsent();
        
        if (!consent) {
            // Show banner to guests
            createAndShowBanner();
        } else {
            // Apply saved preferences
            applyCookieConsent(consent);
        }
    }

    // Create and display the cookie consent banner
    function createAndShowBanner() {
        const body = document.body;
        
        // Create banner HTML
        const bannerHTML = `
            <div class="cookie-consent-banner show" id="cookieConsentBanner">
                <div class="cookie-consent-content">
                    <h3>🍪 Преди всичко - Бисквитки</h3>
                    <p>
                        Ние използваме бисквитки за да подобрим вашето преживяване на нашия сайт. 
                        <a href="privacy-policy.php" target="_blank">Научете повече за нашата политика за лични данни</a>
                    </p>
                </div>
                <div class="cookie-consent-buttons">
                    <button class="cookie-accept-btn" id="cookieAcceptAll">Приемам всички</button>
                    <button class="cookie-reject-btn" id="cookieRejectAll">Отхвърли</button>
                    <button class="cookie-settings-btn" id="cookieSettings">Настройки</button>
                </div>
            </div>
        `;

        // Create settings modal HTML
        const modalHTML = `
            <div class="cookie-settings-modal" id="cookieSettingsModal">
                <div class="cookie-settings-content">
                    <h2>Настройки на бисквутките</h2>
                    <div id="cookieSettingsList"></div>
                    <div class="cookie-settings-buttons">
                        <button class="cookie-close-btn" id="cookieSettingsCancel">Отхвърляне</button>
                        <button class="cookie-save-btn" id="cookieSettingsSave">Запази настройките</button>
                    </div>
                </div>
            </div>
        `;

        // Add to body
        body.insertAdjacentHTML('beforeend', bannerHTML);
        body.insertAdjacentHTML('beforeend', modalHTML);

        // Add CSS link if not already loaded
        if (!document.querySelector('link[href*="cookies.css"]')) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'cookies.css';
            document.head.appendChild(link);
        }

        // Setup event listeners
        setupBannerEvents();
        populateSettingsModal();
    }

    // Setup event listeners for banner buttons
    function setupBannerEvents() {
        const acceptBtn = document.getElementById('cookieAcceptAll');
        const rejectBtn = document.getElementById('cookieRejectAll');
        const settingsBtn = document.getElementById('cookieSettings');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function() {
                const consent = {
                    necessary: true,
                    functional: true,
                    analytics: true,
                    marketing: true,
                    timestamp: Date.now()
                };
                saveCookieConsent(consent);
                applyCookieConsent(consent);
                removeBanner();
            });
        }

        if (rejectBtn) {
            rejectBtn.addEventListener('click', function() {
                const consent = {
                    necessary: true,
                    functional: false,
                    analytics: false,
                    marketing: false,
                    timestamp: Date.now()
                };
                saveCookieConsent(consent);
                applyCookieConsent(consent);
                removeBanner();
            });
        }

        if (settingsBtn) {
            settingsBtn.addEventListener('click', function() {
                showSettingsModal();
            });
        }
    }

    // Populate the settings modal with checkboxes
    function populateSettingsModal() {
        const settingsList = document.getElementById('cookieSettingsList');
        if (!settingsList) return;

        let html = '';
        const currentConsent = getCookieConsent() || {
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false
        };

        for (const [key, category] of Object.entries(COOKIE_CATEGORIES)) {
            const isChecked = currentConsent[key] || false;
            const isDisabled = category.required;

            html += `
                <div class="cookie-setting-item">
                    <h3>${category.name}</h3>
                    <p>${category.description}</p>
                    <div class="cookie-toggle">
                        <input 
                            type="checkbox" 
                            class="cookie-checkbox" 
                            id="cookie_${key}" 
                            value="${key}"
                            ${isChecked ? 'checked' : ''}
                            ${isDisabled ? 'disabled' : ''}
                        >
                        <label for="cookie_${key}" class="cookie-checkbox-label">
                            ${isDisabled ? 'Винаги включено' : 'Включено'}
                        </label>
                    </div>
                </div>
            `;
        }

        settingsList.innerHTML = html;

        // Setup save button
        const saveBtn = document.getElementById('cookieSettingsSave');
        const cancelBtn = document.getElementById('cookieSettingsCancel');

        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                const consent = {
                    necessary: true,
                    timestamp: Date.now()
                };

                for (const key of Object.keys(COOKIE_CATEGORIES)) {
                    if (key === 'necessary') continue;
                    const checkbox = document.getElementById(`cookie_${key}`);
                    if (checkbox) {
                        consent[key] = checkbox.checked;
                    }
                }

                saveCookieConsent(consent);
                applyCookieConsent(consent);
                closeSettingsModal();
                removeBanner();
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', function() {
                closeSettingsModal();
            });
        }
    }

    // Show the settings modal
    function showSettingsModal() {
        const modal = document.getElementById('cookieSettingsModal');
        if (modal) {
            modal.classList.add('show');
        }
    }

    // Close the settings modal
    function closeSettingsModal() {
        const modal = document.getElementById('cookieSettingsModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    // Remove the cookie banner
    function removeBanner() {
        const banner = document.getElementById('cookieConsentBanner');
        if (banner) {
            banner.classList.remove('show');
            setTimeout(() => {
                banner.remove();
            }, 300);
        }
    }

    // Save cookie consent to localStorage
    function saveCookieConsent(consent) {
        localStorage.setItem(COOKIE_CONSENT_NAME, JSON.stringify(consent));
        
        // Also set as HTTP cookie for server-side detection if needed
        document.cookie = COOKIE_CONSENT_NAME + '=accepted; path=/; max-age=' + (COOKIE_EXPIRY_DAYS * 24 * 60 * 60);
    }

    // Get cookie consent from localStorage
    function getCookieConsent() {
        try {
            const stored = localStorage.getItem(COOKIE_CONSENT_NAME);
            return stored ? JSON.parse(stored) : null;
        } catch (e) {
            return null;
        }
    }

    // Apply cookie consent settings
    function applyCookieConsent(consent) {
        // Load analytics only if allowed
        if (consent.analytics) {
            loadAnalytics();
        }

        // Load marketing scripts only if allowed
        if (consent.marketing) {
            loadMarketingScripts();
        }

        // Load functional scripts if allowed
        if (consent.functional) {
            loadFunctionalScripts();
        }

        // Store the consent for other scripts to check
        window.cookieConsent = consent;
    }

    // Load analytics (Google Analytics, etc.)
    function loadAnalytics() {
        // Example: Google Analytics
        // Uncomment and add your tracking ID
        /*
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'YOUR_GOOGLE_ANALYTICS_ID');
        
        const script = document.createElement('script');
        script.src = 'https://www.googletagmanager.com/gtag/js?id=YOUR_GOOGLE_ANALYTICS_ID';
        script.async = true;
        document.head.appendChild(script);
        */
    }

    // Load marketing scripts
    function loadMarketingScripts() {
        // Load Facebook pixel, etc.
        // Example implementation would go here
    }

    // Load functional scripts
    function loadFunctionalScripts() {
        // Load functionality-enhancing scripts
        // Example implementation would go here
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose API for checking consent
    window.hasCookieConsent = function(category) {
        const consent = getCookieConsent();
        if (!consent) return false;
        return consent[category] === true;
    };

    // Expose API for showing consent manager
    window.showCookieSettings = function() {
        if (!document.getElementById('cookieSettingsModal')) {
            createAndShowBanner();
        }
        showSettingsModal();
    };

})();
