<?php
$page_title = 'Нова Парола - Dronche.BG';
$page_css = 'css/user_login.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// If user is already logged in, redirect to homepage
if (is_logged_in()) {
    header('Location: homepage.php');
    exit;
}
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Избери Нова Парола</h1>
                <p style="text-align: center; color: #666; margin-bottom: 20px;">Въведи кода за верификация и своята нова парола</p>
                
                <form class="login-form" id="resetForm">
                    <div class="form-group">
                        <label for="verification-code">Код за Верификация</label>
                        <input type="text" id="verification-code" name="code" required placeholder="Въведи 6-цифрения код">
                        <span class="error-message" id="codeError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="new-password">Нова Парола</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="new-password" name="password" required placeholder="Въведи нова парола" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="new-password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="passwordError"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">Потвърди Парола</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="password" id="confirm-password" name="confirm" required placeholder="Потвърди новата парола" style="flex: 1;">
                            <label style="display: flex; align-items: center; gap: 5px; white-space: nowrap; cursor: pointer;">
                                <input type="checkbox" class="toggle-password" data-target="confirm-password">
                                <span style="font-size: 14px;">👁️</span>
                            </label>
                        </div>
                        <span class="error-message" id="confirmError"></span>
                    </div>
                    
                    <button type="submit" class="login-btn">Промени Парола</button>
                </form>
                
                <div class="signup-link">
                    <a href="user_login.php">← Обратно към Вход</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        // Handle password visibility toggle
        document.querySelectorAll('.toggle-password').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const targetId = this.dataset.target;
                const targetInput = document.getElementById(targetId);
                if (targetInput) {
                    targetInput.type = this.checked ? 'text' : 'password';
                }
            });
        });

        document.getElementById('resetForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const code = document.getElementById('verification-code').value.trim();
            const password = document.getElementById('new-password').value;
            const confirm = document.getElementById('confirm-password').value;
            const email = sessionStorage.getItem('recovery_email');
            
            // Clear errors
            document.getElementById('codeError').textContent = '';
            document.getElementById('passwordError').textContent = '';
            document.getElementById('confirmError').textContent = '';
            
            // Validation
            if (!code) {
                document.getElementById('codeError').textContent = 'Моля, въведи кода за верификация';
                return;
            }
            
            if (!password) {
                document.getElementById('passwordError').textContent = 'Моля, въведи новата парола';
                return;
            }
            
            if (!confirm) {
                document.getElementById('confirmError').textContent = 'Моля, потвърди паролата';
                return;
            }
            
            if (password !== confirm) {
                document.getElementById('confirmError').textContent = 'Паролите не съвпадат';
                return;
            }
            
            if (password.length < 6) {
                document.getElementById('passwordError').textContent = 'Паролата трябва да е минимум 6 символа';
                return;
            }
            
            if (!email) {
                document.getElementById('codeError').textContent = 'Моля, започни отново от възстановяване на парола';
                return;
            }
            
            // Disable button during submission
            const btn = this.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.textContent = 'Обработка...';
            
            fetch('api/password-recovery.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'reset_password',
                    email: email,
                    code: code,
                    password: password
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Паролата ти е успешно променена! Можеш да се логиниш с новата парола.');
                    sessionStorage.removeItem('recovery_email');
                    window.location.href = 'user_login.php';
                } else {
                    // Re-enable button
                    btn.disabled = false;
                    btn.textContent = 'Промени Парола';
                    
                    if (data.field === 'code') {
                        document.getElementById('codeError').textContent = data.message;
                    } else if (data.field === 'email') {
                        document.getElementById('codeError').textContent = data.message;
                    } else if (data.field === 'password') {
                        document.getElementById('passwordError').textContent = data.message;
                    } else {
                        document.getElementById('codeError').textContent = data.message || 'Възникна грешка. Опитай отново.';
                    }
                }
            })
            .catch(error => {
                btn.disabled = false;
                btn.textContent = 'Промени Парола';
                document.getElementById('codeError').textContent = 'Възникна грешка при свързване. Проверете интернет достъпа.';
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
