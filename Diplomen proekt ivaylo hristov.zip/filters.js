// Simple Filter Script - Price and Sort Only
document.addEventListener('DOMContentLoaded', function() {
    const productsGrid = document.getElementById('productsGrid');
    const priceMinInput = document.getElementById('priceMin');
    const priceMaxInput = document.getElementById('priceMax');
    const priceSlider = document.getElementById('priceSlider');
    const sortSelect = document.getElementById('sortSelect');
    const resetButton = document.getElementById('resetFilters');
    const productCards = document.querySelectorAll('.product-card');
    
    if (!productsGrid || productCards.length === 0) {
        return;
    }
    
    // Get min/max prices
    let minPrice = Infinity;
    let maxPrice = 0;
    
    productCards.forEach(card => {
        const price = parseInt(card.dataset.price) || 0;
        if (price > 0) {
            minPrice = Math.min(minPrice, price);
            maxPrice = Math.max(maxPrice, price);
        }
    });
    
    if (minPrice === Infinity) minPrice = 0;
    
    // Set initial values
    if (priceMinInput) priceMinInput.value = minPrice;
    if (priceMaxInput) priceMaxInput.value = maxPrice;
    if (priceSlider) {
        priceSlider.max = maxPrice;
        priceSlider.value = maxPrice;
    }
    
    // Filter and sort function
    function applyFilters() {
        const minVal = priceMinInput ? parseInt(priceMinInput.value) || minPrice : minPrice;
        const maxVal = priceMaxInput ? parseInt(priceMaxInput.value) || maxPrice : maxPrice;
        
        let visibleCount = 0;
        
        // Filter by price
        productCards.forEach(card => {
            const price = parseInt(card.dataset.price) || 0;
            
            if (price < minVal || price > maxVal) {
                card.classList.add('hidden');
            } else {
                card.classList.remove('hidden');
                visibleCount++;
            }
        });
        
        // Sort visible products
        if (sortSelect && sortSelect.value) {
            const visibleCards = Array.from(productCards).filter(c => !c.classList.contains('hidden'));
            
            visibleCards.sort((a, b) => {
                const aName = (a.dataset.name || '').toLowerCase();
                const bName = (b.dataset.name || '').toLowerCase();
                const aPrice = parseInt(a.dataset.price) || 0;
                const bPrice = parseInt(b.dataset.price) || 0;
                
                switch (sortSelect.value) {
                    case 'name-asc':
                        return aName.localeCompare(bName, 'bg');
                    case 'name-desc':
                        return bName.localeCompare(aName, 'bg');
                    case 'price-asc':
                        return aPrice - bPrice;
                    case 'price-desc':
                        return bPrice - aPrice;
                    default:
                        return 0;
                }
            });
            
            visibleCards.forEach(card => {
                productsGrid.appendChild(card);
            });
        }
        
        // Handle empty state
        let emptyState = productsGrid.querySelector('.empty-state');
        if (visibleCount === 0) {
            if (!emptyState) {
                emptyState = document.createElement('div');
                emptyState.className = 'empty-state';
                emptyState.innerHTML = '<p>Няма продукти в този диапазон на цени.</p>';
                productsGrid.appendChild(emptyState);
            }
        } else if (emptyState) {
            emptyState.style.display = 'none';
        }
    }
    
    // Event listeners
    if (priceMinInput) {
        priceMinInput.addEventListener('input', applyFilters);
        priceMinInput.addEventListener('change', applyFilters);
    }
    if (priceMaxInput) {
        priceMaxInput.addEventListener('input', applyFilters);
        priceMaxInput.addEventListener('change', applyFilters);
    }
    if (priceSlider) {
        priceSlider.addEventListener('input', function() {
            if (priceMaxInput) priceMaxInput.value = this.value;
            applyFilters();
        });
    }
    if (sortSelect) {
        sortSelect.addEventListener('change', applyFilters);
    }
    
    // Reset button
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            if (priceMinInput) priceMinInput.value = minPrice;
            if (priceMaxInput) priceMaxInput.value = maxPrice;
            if (priceSlider) priceSlider.value = maxPrice;
            if (sortSelect) sortSelect.value = 'name-asc';
            applyFilters();
        });
    }
    
    // Apply initial filters
    applyFilters();
});
