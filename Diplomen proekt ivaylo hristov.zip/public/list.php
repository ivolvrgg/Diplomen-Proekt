<?php
require_once __DIR__ . '/../config/db.php';

$stmt = $pdo->query("SELECT id, name, email, created_at FROM users ORDER BY id DESC LIMIT 100");
$rows = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>List</title></head>
<body>
<a href="index.php">Add new</a>
<table border="1" cellpadding="6">
	<tr><th>ID</th><th>Name</th><th>Email</th><th>Created</th></tr>
	<?php foreach ($rows as $r): ?>
		<tr>
			<td><?= htmlspecialchars($r['id']) ?></td>
			<td><?= htmlspecialchars($r['name']) ?></td>
			<td><?= htmlspecialchars($r['email']) ?></td>
			<td><?= htmlspecialchars($r['created_at']) ?></td>
		</tr>
	<?php endforeach; ?>
</table>
</body>
</html>
