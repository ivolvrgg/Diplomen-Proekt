<?php
// ...existing code...
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Submit</title></head>
<body>
<form action="submit.php" method="post">
	<label>Name: <input name="name" required></label><br>
	<label>Email: <input name="email" type="email" required></label><br>
	<button type="submit">Send</button>
</form>
</body>
</html>