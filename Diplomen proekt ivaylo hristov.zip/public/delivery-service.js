/**
 * Delivery Service Integration
 * Handles interaction with Speedy, Econt, and Courier delivery APIs
 */

class DeliveryService {
    constructor() {
        this.selectedOffice = {};
        this.deliveryMethod = 'courier';
        this.init();
    }
    
    /**
     * Initialize delivery service
     */
    init() {
        this.attachEventListeners();
        this.setupDeliveryMethodToggle();
    }
    
    /**
     * Attach event listeners to delivery options
     */
    attachEventListeners() {
        // Delivery method radio buttons
        document.querySelectorAll('input[name="delivery-method"]').forEach(radio => {
            radio.addEventListener('change', (e) => this.handleDeliveryMethodChange(e));
        });
        
        // Office search inputs
        document.querySelectorAll('.delivery-search').forEach(search => {
            search.addEventListener('input', (e) => this.handleOfficeSearch(e));
        });
        
        // Office selection
        document.querySelectorAll('.delivery-option-item').forEach(item => {
            item.addEventListener('click', (e) => this.selectOffice(e));
        });
    }
    
    /**
     * Handle delivery method change
     */
    handleDeliveryMethodChange(e) {
        this.deliveryMethod = e.target.value;
        
        // Hide all delivery wrappers
        document.querySelectorAll('.delivery-select-wrapper').forEach(wrapper => {
            wrapper.style.display = 'none';
        });
        
        // Show address fields for courier
        const addressFields = document.querySelector('.address-fields');
        if (this.deliveryMethod === 'courier' && addressFields) {
            addressFields.style.display = 'block';
        } else if (addressFields) {
            addressFields.style.display = 'none';
        }
        
        // Show offices for speedy/econt
        if (this.deliveryMethod === 'speedy') {
            document.getElementById('speedy-offices').style.display = 'block';
            this.loadOffices('speedy');
        } else if (this.deliveryMethod === 'econt') {
            document.getElementById('econt-offices').style.display = 'block';
            this.loadOffices('econt');
        }
        
        this.updateDeliveryPrice();
    }
    
    /**
     * Load offices from API
     */
    async loadOffices(method, city = '') {
        const wrapper = document.querySelector(`#${method}-offices`);
        const dropdown = wrapper.querySelector('.delivery-dropdown');
        
        // Show loading state
        dropdown.innerHTML = '<div class="loading">Зареждане на офисите...</div>';
        
        try {
            const params = new URLSearchParams({ method: method });
            if (city) {
                params.append('city', city);
            }
            
            const response = await fetch(`/api/get_delivery_offices.php?${params}`);
            const data = await response.json();
            
            if (!data.success) {
                dropdown.innerHTML = `<div class="error">Грешка: ${data.message}</div>`;
                return;
            }
            
            // Populate offices
            dropdown.innerHTML = '';
            data.data.offices.forEach(office => {
                const div = document.createElement('div');
                div.className = 'delivery-option-item';
                div.setAttribute('data-office-id', office.id);
                div.setAttribute('data-office-name', office.name);
                div.setAttribute('data-office-city', office.city);
                div.textContent = office.name;
                
                div.addEventListener('click', (e) => this.selectOffice(e));
                dropdown.appendChild(div);
            });
            
            if (data.data.offices.length === 0) {
                dropdown.innerHTML = '<div class="empty">Няма намерени офиси</div>';
            }
            
        } catch (error) {
            console.error('Error loading offices:', error);
            dropdown.innerHTML = '<div class="error">Грешка при зареждане на офисите</div>';
        }
    }
    
    /**
     * Handle office search/filter
     */
    handleOfficeSearch(e) {
        const searchText = e.target.value.toLowerCase();
        const wrapper = e.target.closest('.delivery-select-wrapper');
        const method = wrapper.id.split('-')[0]; // 'speedy' or 'econt'
        const dropdown = wrapper.querySelector('.delivery-dropdown');
        
        if (searchText.length > 2) {
            // Load offices filtered by city
            this.loadOffices(method, searchText);
        }
    }
    
    /**
     * Select delivery office
     */
    selectOffice(e) {
        const item = e.target.closest('.delivery-option-item');
        if (!item) return;
        
        const officeId = item.getAttribute('data-office-id');
        const officeName = item.getAttribute('data-office-name') || item.textContent;
        const wrapper = item.closest('.delivery-select-wrapper');
        const method = wrapper.id.split('-')[0]; // 'speedy' or 'econt'
        
        // Store selected office
        this.selectedOffice[method] = {
            id: officeId,
            name: officeName
        };
        
        // Update hidden inputs
        const idInput = document.getElementById(`delivery-office-id-${method}`);
        const nameInput = document.getElementById(`delivery-office-${method}`);
        
        if (idInput) idInput.value = officeId;
        if (nameInput) nameInput.value = officeName;
        
        // Update UI
        item.closest('.delivery-dropdown').querySelectorAll('.delivery-option-item').forEach(el => {
            el.classList.remove('selected');
        });
        item.classList.add('selected');
        
        // Highlight selected office
        const searchInput = wrapper.querySelector('.delivery-search');
        if (searchInput) {
            searchInput.value = officeName;
        }
        
        console.log(`Selected ${method} office:`, officeId, officeName);
    }
    
    /**
     * Setup delivery method toggle (for address fields vs office selection)
     */
    setupDeliveryMethodToggle() {
        const courierInput = document.querySelector('input[value="courier"]');
        if (courierInput) {
            courierInput.checked = true;
            courierInput.dispatchEvent(new Event('change'));
        }
    }
    
    /**
     * Update delivery price based on method
     */
    updateDeliveryPrice() {
        const priceMap = {
            'courier': '3.00',
            'speedy': '4.99',
            'econt': '3.00'
        };
        
        const priceElements = document.querySelectorAll('.delivery-price');
        priceElements.forEach(el => {
            el.textContent = (priceMap[this.deliveryMethod] || '3.00') + ' €';
        });
        
        // Update total price
        this.updateTotalPrice();
    }
    
    /**
     * Update total price
     */
    updateTotalPrice() {
        const subtotalElement = document.querySelector('.subtotal-price');
        const totalElement = document.querySelector('.total-price');
        
        if (subtotalElement && totalElement) {
            const subtotal = parseFloat(subtotalElement.textContent) || 0;
            const delivery = parseFloat(document.querySelector('.delivery-price').textContent) || 0;
            const total = subtotal + delivery;
            totalElement.textContent = total.toFixed(2) + ' €';
        }
    }
    
    /**
     * Get selected delivery data for form submission
     */
    getDeliveryData() {
        const data = {
            delivery_method: this.deliveryMethod
        };
        
        if (this.deliveryMethod === 'courier') {
            // Get address fields
            data.city = document.getElementById('city-input')?.value || '';
            data.street = document.getElementById('street-input')?.value || '';
            data.block = document.getElementById('block-input')?.value || '';
            data.entrance = document.getElementById('entrance-input')?.value || '';
            data.apartment = document.getElementById('apartment-input')?.value || '';
        } else {
            // Get office selection
            const officeIdInput = document.getElementById(`delivery-office-id-${this.deliveryMethod}`);
            const officeNameInput = document.getElementById(`delivery-office-${this.deliveryMethod}`);
            
            data.delivery_office_id = officeIdInput?.value || '';
            data.delivery_office_name = officeNameInput?.value || '';
        }
        
        return data;
    }
    
    /**
     * Validate delivery data
     */
    validateDeliveryData() {
        if (this.deliveryMethod === 'courier') {
            const requiredFields = ['city', 'street'];
            const data = this.getDeliveryData();
            
            for (const field of requiredFields) {
                if (!data[field]) {
                    alert(`Моля, попълнете ${field === 'city' ? 'град' : 'улица'}`);
                    return false;
                }
            }
        } else {
            const officeId = document.getElementById(`delivery-office-id-${this.deliveryMethod}`)?.value;
            if (!officeId) {
                alert('Моля, изберете офис на доставка');
                return false;
            }
        }
        
        return true;
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.deliveryService = new DeliveryService();
    
    // Hook into form submission
    const paymentForm = document.getElementById('payment-form');
    if (paymentForm) {
        paymentForm.addEventListener('submit', (e) => {
            if (!window.deliveryService.validateDeliveryData()) {
                e.preventDefault();
            }
        });
    }
});
