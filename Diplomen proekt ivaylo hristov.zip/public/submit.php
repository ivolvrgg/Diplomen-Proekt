<?php
require_once __DIR__ . '/../config/db.php';

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');

if ($name === '' || $email === '') {
	http_response_code(400);
	exit('Missing fields');
}

$sql = "INSERT INTO users (name, email, created_at) VALUES (:name, :email, NOW())";
$stmt = $pdo->prepare($sql);
$stmt->execute([':name' => $name, ':email' => $email]);

header('Location: list.php');
exit;
