<?php
$page_title = 'Детайл на продукт - Drone store Dronche.BG';
$page_css = 'css/itempage.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
    
    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="product-container">
        <div class="container">
            <?php
            // Get product ID from URL
            $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            
            if ($product_id > 0) {
                $query = "SELECT p.*, c.name as category_name FROM products p 
                         LEFT JOIN categories c ON p.category_id = c.id 
                         WHERE p.id = $product_id AND p.is_active = 1";
                $result = $conn->query($query);
                
                if ($result && $result->num_rows > 0) {
                    $product = $result->fetch_assoc();
            ?>
            <div class="product-content">
                <div class="product-gallery">
                    <img src="<?php echo htmlspecialchars(get_image_url($product['image_1'], $product['name'])); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="main-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27500%27 height=%27500%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27500%27 height=%27500%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2720%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E'">
                    
                    <div class="image-carousel">
                        <button class="carousel-arrow prev-arrow" aria-label="Previous image">❮</button>
                        <div class="carousel-track">
                            <?php
                            // Display all available images
                            for ($i = 1; $i <= 4; $i++) {
                                $image_field = "image_$i";
                                if (!empty($product[$image_field])) {
                            ?>
                            <img src="<?php echo htmlspecialchars(get_image_url($product[$image_field], $product['name'] . " view " . $i)); ?>" alt="<?php echo htmlspecialchars($product['name']); ?> view <?php echo $i; ?>" class="carousel-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2780%27 height=%2780%27%3E%3Crect fill=%27%23f0f0f0%27 width=%2780%27 height=%2780%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2710%27 fill=%27%23999%27%3ENo Img%3C/text%3E%3C/svg%3E'">
                            <?php
                                }
                            }
                            
                            // Add video if available
                            if (!empty($product['video_url'])) {
                                $video_id = '';
                                if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/', $product['video_url'], $matches)) {
                                    $video_id = $matches[1];
                                } else {
                                    $video_id = basename($product['video_url']);
                                }  
                            ?>
                            <div class="carousel-video-item" data-video-id="<?php echo htmlspecialchars($video_id); ?>">
                                <img src="https://img.youtube.com/vi/<?php echo htmlspecialchars($video_id); ?>/mqdefault.jpg" alt="Product Video" class="carousel-image carousel-video-thumb" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2780%27 height=%2780%27%3E%3Crect fill=%27%236f6f6f%27 width=%2780%27 height=%2780%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%278%27 fill=%27%23fff%27%3E▶%3C/text%3E%3C/svg%3E'">
                            </div>
                            <?php
                            }
                            ?>
                        </div>
                        <button class="carousel-arrow next-arrow" aria-label="Next image">❯</button>
                    </div>
                </div>
                
                <div class="product-info">
                    <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                    
                    <?php if (!empty($product['category_name'])) { ?>
                    <p class="product-category">Категория: <?php echo htmlspecialchars($product['category_name']); ?></p>
                    <?php } ?>
                    
                    <div class="price-container">
                        <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                            <div class="original-price-line">
                                <span class="original-price"><?php echo number_format($product['price'], 2); ?> €</span>
                            </div>
                            <div class="sale-price-container">
                                <span class="sale-price"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                <div class="sale-badge">
                                    <span class="sale-text">SALE</span>
                                    <span class="discount-percent"><?php echo intval($product['discount_percent']); ?>%</span>
                                </div>
                            </div>
                        <?php } else { ?>
                            <div class="price"><?php echo number_format($product['price'], 2); ?> €</div>
                        <?php } ?>
                        <div class="availability">
                            <?php echo $product['stock'] > 0 ? 'На склад' : 'Край на наличност'; ?>
                        </div>
                    </div>
                    
                    <?php
                    // Calculate expected arrival dates (1-7 days from today)
                    $today = new DateTime('NOW');
                    $arrival_start = clone $today;
                    $arrival_start->add(new DateInterval('P1D'));
                    $arrival_end = clone $today;
                    $arrival_end->add(new DateInterval('P7D'));
                    
                    $arrival_start_formatted = $arrival_start->format('d.m.Y');
                    $arrival_end_formatted = $arrival_end->format('d.m.Y');
                    ?>
                    
                    <div class="expected-delivery" style="margin: 15px 0; padding: 12px; background: #f5f5f5; border-left: 4px solid #588157; border-radius: 4px;">
                        <p style="margin: 0; font-size: 14px; color: #666;">
                            <strong style="color: #588157;">Очаквано доставяне:</strong><br>
                            <?php echo htmlspecialchars($arrival_start_formatted); ?> - <?php echo htmlspecialchars($arrival_end_formatted); ?>
                        </p>
                    </div>
                    
                    <div class="product-description">
                        <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'Качествен продукт')); ?></p>
                    </div>
                    
                    <div class="quantity-selector">
                        <label for="quantity">Количество:</label>
                        <button type="button" class="qty-decrement" onclick="decrementQty()">-</button>
                        <input type="number" id="quantity" class="quantity-input" min="1" max="<?php echo max($product['stock'], 10); ?>" value="1" readonly>
                        <button type="button" class="qty-increment" onclick="incrementQty()">+</button>
                    </div>
                    
                    <button class="add-to-cart" onclick="addToCartWithQty(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name'], ENT_QUOTES); ?>', <?php echo $product['price']; ?>)" 
                        <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                        Добави в количка
                    </button>
                </div>
            </div>
            
            <div class="related-products">
                <h2>Свързани продукти</h2>
                <div class="related-grid">
                    <?php
                    // Get related products from same category
                    // Both $product['category_id'] and $product_id are already sanitized (intval)
                    $category_id = intval($product['category_id']);
                    $related_query = "SELECT * FROM products WHERE category_id = $category_id 
                                    AND id != $product_id AND is_active = 1 LIMIT 4";
                    $related_result = $conn->query($related_query);
                    
                    if ($related_result && $related_result->num_rows > 0) {
                        while ($related = $related_result->fetch_assoc()) {
                    ?>
                    <div class="related-item">
                        <a href="itempage.php?id=<?php echo $related['id']; ?>" style="text-decoration: none; color: inherit;">
                            <img src="<?php echo htmlspecialchars(get_image_url($related['image_1'], $related['name'])); ?>" alt="<?php echo htmlspecialchars($related['name']); ?>" class="related-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27200%27 height=%27150%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27200%27 height=%27150%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2712%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E'">
                            <div class="related-info">
                                <div class="related-title"><?php echo htmlspecialchars($related['name']); ?></div>
                                <div class="related-price"><?php echo number_format($related['price'], 2); ?> €</div>
                            </div>
                        </a>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
            
            <?php
                } else {
                    echo '<p>Продуктът не е намерен.</p>';
                }
            } else {
                echo '<p>Невалиден продукт.</p>';
            }
            ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
    
    <script>
        function incrementQty() {
            const input = document.getElementById('quantity');
            const max = parseInt(input.getAttribute('max')) || 999;
            const current = parseInt(input.value) || 1;
            if (current < max) {
                input.value = current + 1;
            }
        }

        function decrementQty() {
            const input = document.getElementById('quantity');
            const current = parseInt(input.value) || 1;
            if (current > 1) {
                input.value = current - 1;
            }
        }

        function addToGuestCart(productId, productName, productPrice, quantity) {
            let cart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
            
            const existing = cart.find(item => item.product_id === productId);
            if (existing) {
                existing.quantity += quantity;
            } else {
                cart.push({ 
                    product_id: productId, 
                    quantity: quantity,
                    name: productName,
                    price: productPrice
                });
            }
            
            localStorage.setItem('guest_cart', JSON.stringify(cart));
            alert('Продукт добавен в количката!');
            document.getElementById('quantity').value = 1;
            // Update cart badge
            if (window.updateCartBadge) {
                window.updateCartBadge();
            }
        }

        function addToCartWithQty(productId, productName, productPrice) {
            const quantity = parseInt(document.getElementById('quantity').value);
            // Use sale price if available, otherwise use original price
            const salePriceEl = document.querySelector('.sale-price');
            const priceToUse = salePriceEl ? parseFloat(salePriceEl.textContent) : parseFloat(productPrice);
            
            fetch('api/cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({ product_id: parseInt(productId), quantity: quantity, action: 'add' })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('HTTP Error: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                if (data.guest) {
                    addToGuestCart(productId, productName, priceToUse, quantity);
                } else if (data.success) {
                    alert('Продукт добавен в количката!');
                    document.getElementById('quantity').value = 1;
                    // Update cart badge
                    if (window.updateCartBadge) {
                        window.updateCartBadge();
                    }
                } else {
                    alert('Грешка: ' + (data.message || 'Не беше възможно да се добави продуктът'));
                }
            })
            .catch(error => {
                alert('Възникна грешка при добавяне на продуктът. Детайли: ' + error.message);
            });
        }
        
        // Product gallery carousel
        const carouselTrack = document.querySelector('.carousel-track');
        const carouselImages = document.querySelectorAll('.carousel-image');
        const prevArrow = document.querySelector('.prev-arrow');
        const nextArrow = document.querySelector('.next-arrow');
        let currentSlide = 0;

        function updateCarousel() {
            carouselImages.forEach((img, index) => {
                img.style.borderColor = index === currentSlide ? '#588157' : 'transparent';
            });
            
            const currentItem = document.querySelectorAll('.carousel-track > *')[currentSlide];
            
            if (currentItem.classList.contains('carousel-video-item')) {
                const videoId = currentItem.getAttribute('data-video-id');
                const mainImage = document.querySelector('.product-gallery > img, .product-gallery > iframe');
                if (mainImage) {
                    mainImage.outerHTML = `<iframe width="100%" height="500" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen></iframe>`;
                }
            } else {
                const mainMedia = document.querySelector('.product-gallery > img, .product-gallery > iframe');
                if (mainMedia && mainMedia.tagName === 'IFRAME') {
                    mainMedia.outerHTML = `<img src="${carouselImages[currentSlide].src}" alt="${carouselImages[currentSlide].alt}" class="main-image">`;
                } else if (mainMedia && mainMedia.tagName === 'IMG') {
                    mainMedia.src = carouselImages[currentSlide].src;
                }
            }
        }

        const allCarouselItems = document.querySelectorAll('.carousel-track > *');
        allCarouselItems.forEach((item, index) => {
            item.addEventListener('click', () => {
                currentSlide = index;
                updateCarousel();
            });
            item.style.cursor = 'pointer';
        });

        prevArrow?.addEventListener('click', () => {
            const totalItems = document.querySelectorAll('.carousel-track > *').length;
            currentSlide = (currentSlide - 1 + totalItems) % totalItems;
            updateCarousel();
        });

        nextArrow?.addEventListener('click', () => {
            const totalItems = document.querySelectorAll('.carousel-track > *').length;
            currentSlide = (currentSlide + 1) % totalItems;
            updateCarousel();
        });
    </script>
</body>
</html>
