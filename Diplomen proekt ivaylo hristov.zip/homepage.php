<?php
$page_title = 'Dronche.BG';
$page_css = 'css/homepage.css';
$include_banner_css = true; // Flag to include banner CSS
?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
<?php include 'includes/auth_check.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>
    
    <main id="main-content">
        <?php
        // Get active banners for carousel
        $has_banners = false;
        $banners = array();
        
        // Check if banners table exists first
        $table_check = $conn->query("SHOW TABLES LIKE 'banners'");
        if ($table_check && $table_check->num_rows > 0) {
            $banners_query = "SELECT * FROM banners WHERE is_active = 1 ORDER BY sort_order ASC";
            $banners_result = $conn->query($banners_query);
            
            if ($banners_result) {
                while ($banner = $banners_result->fetch_assoc()) {
                    $banners[] = $banner;
                }
                $has_banners = count($banners) > 0;
            }
        }
        
        // Build banner navigation URL function
        function getBannerUrl($banner) {
            // Use the link_url directly from the table
            $link_url = $banner['link_url'] ?? '#';
            return htmlspecialchars($link_url);
        }
        ?>
        
        <?php if ($has_banners): ?>
        <section class="banner-carousel-section">
            <div class="banner-carousel-container">
                <div class="banner-carousel-wrapper">
                    <div class="banner-carousel-slides" id="bannerCarousel">
                        <?php foreach ($banners as $banner): 
                            $banner_url = getBannerUrl($banner);
                        ?>
                        <div class="banner-slide" onclick="window.location.href='<?php echo $banner_url; ?>';" style="cursor: pointer;">
                            <img src="<?php echo htmlspecialchars($banner['image_url']); ?>" alt="Banner" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27800%27 height=%27400%27%3E%3Crect fill=%27%23cccccc%27 width=%27800%27 height=%27400%27/%3E%3C/svg%3E'">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($banners) > 1): ?>
                    <button class="banner-carousel-btn prev-btn" onclick="moveBannerCarousel(-1)">❮</button>
                    <button class="banner-carousel-btn next-btn" onclick="moveBannerCarousel(1)">❯</button>
                    
                    <div class="banner-carousel-nav" id="bannerNav">
                        <?php foreach ($banners as $index => $banner): ?>
                        <div class="banner-nav-dot <?php echo ($index === 0) ? 'active' : ''; ?>" onclick="goToBannerSlide(<?php echo $index; ?>)"></div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>
        
        <section class="best-sellers">
            <h2 class="section-title">Бестселъри</h2>
            <div class="bestsellers-container">
                <?php
                // Get best sellers (top products by stock or recent)
                $bestsellers_query = "SELECT * FROM products WHERE is_active = 1 AND stock > 0 ORDER BY id DESC LIMIT 3";
                $bestsellers_result = $conn->query($bestsellers_query);
                
                while ($product = $bestsellers_result->fetch_assoc()) {
                    $image = get_image_url($product['image_1'], $product['name']);
                ?>
                <div class="bestseller-card">
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" style="text-decoration: none; color: inherit;">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="bestseller-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2716%27 fill=%27%23999%27%3ENo Image%3C/text%3E%3C/svg%3E'">
                        <div class="bestseller-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price">
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] > 0) { ?>
                                    <span style="text-decoration: line-through; color: #999; margin-right: 10px;"><?php echo number_format($product['price'], 2); ?> €</span>
                                    <span style="color: #e74c3c; font-weight: bold;"><?php echo number_format($product['sale_price'], 2); ?> €</span>
                                <?php } else { ?>
                                    <?php echo number_format($product['price'], 2); ?> €
                                <?php } ?>
                            </p>
                        </div>
                    </a>
                    <a href="itempage.php?id=<?php echo $product['id']; ?>" class="add-to-cart" style="text-decoration: none;">Купи</a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
        
        <section class="product-categories">
            <h2 class="section-title">Категории</h2>
            <div class="categories-container">
                <?php
                // Get all categories
                $cats_query = "SELECT * FROM categories ORDER BY sort_order ASC";
                $cats_result = $conn->query($cats_query);
                
                while ($cat = $cats_result->fetch_assoc()) {
                    // Get first product image from category for thumbnail
                    $thumb_query = "SELECT image_1 FROM products WHERE category_id = " . intval($cat['id']) . " AND is_active = 1 LIMIT 1";
                    $thumb_result = $conn->query($thumb_query);
                    $thumb_product = $thumb_result->fetch_assoc();
                    $thumb_image = get_image_url($thumb_product['image_1'] ?? '', $cat['name']);
                ?>
                <div class="category-card">
                    <a href="category-products.php?id=<?php echo $cat['id']; ?>" class="category-link">
                        <img src="<?php echo htmlspecialchars($thumb_image); ?>" alt="<?php echo htmlspecialchars($cat['name']); ?>" class="category-image" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27300%27 height=%27300%27%3E%3Crect fill=%27%23f0f0f0%27 width=%27300%27 height=%27300%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 dominant-baseline=%27middle%27 text-anchor=%27middle%27 font-family=%27Arial%27 font-size=%2716%27 fill=%27%23999%27%3E<?php echo htmlspecialchars($cat['name']); ?> %3C/text%3E%3C/svg%3E'">
                        <div class="category-name"><?php echo htmlspecialchars($cat['name']); ?></div>
                    </a>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
