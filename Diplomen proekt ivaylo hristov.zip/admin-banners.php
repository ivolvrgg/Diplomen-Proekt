<?php
session_start();
include 'includes/admin_check.php';
include 'config/db.php';
?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Административен панел - Управление на банери</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #344e41;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-size: 28px;
        }
        .logout-btn, .back-btn {
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .logout-btn {
            background-color: #e74c3c;
        }
        .logout-btn:hover {
            background-color: #c0392b;
        }
        .back-btn {
            background-color: #3498db;
            margin-right: 10px;
        }
        .back-btn:hover {
            background-color: #2980b9;
        }
        .header-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .section {
            background-color: white;
            padding: 25px;
            border-radius: 5px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #e8e6df;
            border-radius: 4px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        textarea {
            min-height: 80px;
            resize: vertical;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        button.delete-btn {
            background-color: #e74c3c;
            padding: 6px 12px;
            font-size: 12px;
            margin: 0;
        }
        button.delete-btn:hover {
            background-color: #c0392b;
        }
        button.edit-btn {
            background-color: #f39c12;
            padding: 6px 12px;
            font-size: 12px;
            margin-right: 5px;
        }
        button.edit-btn:hover {
            background-color: #d68910;
        }
        button.toggle-btn {
            background-color: #27ae60;
            padding: 6px 12px;
            font-size: 12px;
            margin-right: 5px;
        }
        button.toggle-btn:hover {
            background-color: #229954;
        }
        button.cancel-btn {
            background-color: #95a5a6;
        }
        button.cancel-btn:hover {
            background-color: #7f8c8d;
        }
        .message {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .banner-card {
            border: 1px solid #e8e6df;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #faf8f3;
            display: grid;
            grid-template-columns: 100px 1fr;
            gap: 20px;
            align-items: start;
        }
        .banner-preview {
            position: relative;
        }
        .banner-preview img {
            width: 100px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        .banner-info {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }
        .banner-details {
            flex: 1;
        }
        .banner-details h3 {
            margin-bottom: 8px;
            color: #2c3e50;
        }
        .banner-details p {
            margin: 5px 0;
            font-size: 13px;
            color: #666;
        }
        .banner-actions {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        .banners-list {
            margin-top: 30px;
        }
        .no-banners {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-size: 16px;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: #3498db;
        }
        .file-input-label {
            display: inline-block;
            padding: 10px;
            background-color: #3498db;
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .file-input-label:hover {
            background-color: #2980b9;
        }
        input[type="file"] {
            display: none;
        }
        .file-name {
            margin-left: 10px;
            color: #666;
            font-size: 13px;
        }
        .redirect-options {
            background-color: #ecf0f1;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
        }
        .edit-form-container {
            background-color: #ecf0f1;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            border-left: 4px solid #3498db;
        }
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            .banner-card {
                grid-template-columns: 1fr;
            }
            .banner-actions {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Управление на банери</h1>
                <div style="font-size: 14px;">Добре дошли, <?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
            </div>
            <div class="header-buttons">
                <button class="back-btn" onclick="window.location.href='admin.php'">← Към админ панела</button>
                <button class="logout-btn" onclick="logout()">Изход</button>
            </div>
        </div>

        <div id="message-container"></div>

        <!-- Add Banner Form -->
        <div class="section">
            <h2>Добавяне на банер</h2>
            <form id="add-banner-form" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="banner_image">Изображение на банера * (JPG, PNG, GIF, WebP - макс 5MB)</label>
                    <label for="image_input" class="file-input-label">Избор на файл</label>
                    <input type="file" id="image_input" name="image" accept="image/*" required>
                    <span class="file-name" id="file-name">Избран файл: няма</span>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="banner_link_type">Насочи към *</label>
                        <select id="banner_link_type" name="link_type" required onchange="updateLinkOptions()">
                            <option value="">Избор</option>
                            <option value="sales">Продажби (намаления)</option>
                            <option value="category">Категория</option>
                            <option value="custom">Персонализиран URL</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="banner_link_value" id="link-label">Избор *</label>
                        <select id="banner_category_select" name="link_value" style="display: none;">
                            <option value="">Избор на категория</option>
                        </select>
                        <input type="text" id="banner_custom_url" name="link_value" placeholder="https://example.com" style="display: none;">
                    </div>
                </div>

                <div id="sale-percent-group" class="form-group" style="display: none;">
                    <label for="banner_sale_percent">Процент намаление (%)</label>
                    <input type="number" id="banner_sale_percent" name="sale_percent" min="1" max="100" placeholder="Напр: 20">
                    <small style="display: block; margin-top: 5px; color: #666;">Ще показва само продукти с намаление поне до този процент</small>
                </div>

                <button type="submit" style="width: 100%; margin-top: 20px;">Добавяне на банер</button>
            </form>
        </div>

        <!-- Banners List -->
        <div class="section">
            <h2>Съществуващи банери</h2>
            <div id="banners-container" class="banners-list loading">Зареждане на банерите...</div>
        </div>
    </div>

    <script>
        let allCategories = [];

        document.addEventListener('DOMContentLoaded', function() {
            loadBanners();
            loadCategories();
            
            // File input change handler
            document.getElementById('image_input').addEventListener('change', function(e) {
                const fileName = e.target.files[0]?.name || 'няма';
                document.getElementById('file-name').textContent = 'Избран файл: ' + fileName;
            });

            // Form submission
            document.getElementById('add-banner-form').addEventListener('submit', submitAddBanner);
        });

        function loadBanners() {
            fetch('api/get_banners.php')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('banners-container');
                    if (data.success && data.data.length > 0) {
                        container.innerHTML = '';
                        data.data.forEach((banner) => {
                            const linkTypeText = getLinkTypeText(banner.link_type, banner.link_value, banner.sale_percent);
                            const statusText = banner.is_active ? '✓ Активен' : '✗ Неактивен';
                            
                            const bannerCard = document.createElement('div');
                            bannerCard.className = 'banner-card';
                            bannerCard.innerHTML = `
                                <div class="banner-preview">
                                    <img src="uploads/banners/${htmlspecialchars(banner.image_filename)}" alt="Banner" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27200%27 height=%27120%27%3E%3Crect fill=%27%23ccc%27 width=%27200%27 height=%27120%27/%3E%3C/svg%3E'">
                                </div>
                                <div class="banner-info">
                                    <div class="banner-details">
                                        <h3>Банер #${banner.id}</h3>
                                        <p><strong>Статус:</strong> ${statusText}</p>
                                        <p><strong>Насочва към:</strong> ${linkTypeText}</p>
                                        <p><strong>Позиция:</strong> ${banner.position}</p>
                                        <p><strong>Файл:</strong> ${htmlspecialchars(banner.image_filename)}</p>
                                    </div>
                                    <div class="banner-actions">
                                        <button class="toggle-btn" onclick="toggleBannerActive(${banner.id}, ${banner.is_active})">
                                            ${banner.is_active ? 'Деактивиране' : 'Активиране'}
                                        </button>
                                        <button class="delete-btn" onclick="deleteBanner(${banner.id})">Изтриване</button>
                                    </div>
                                </div>
                            `;
                            container.appendChild(bannerCard);
                        });
                    } else {
                        container.innerHTML = '<div class="no-banners">Няма добавени банери. Добавете първи банер горе.</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Грешка при зареждане на банерите', 'error');
                });
        }

        function loadCategories() {
            fetch('api/get_categories.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data) {
                        allCategories = data.data;
                        const select = document.getElementById('banner_category_select');
                        select.innerHTML = '<option value="">Избор на категория</option>';
                        allCategories.forEach(cat => {
                            const option = document.createElement('option');
                            option.value = cat.id;
                            option.textContent = cat.name;
                            select.appendChild(option);
                        });
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function updateLinkOptions() {
            const linkType = document.getElementById('banner_link_type').value;
            const categorySelect = document.getElementById('banner_category_select');
            const customUrl = document.getElementById('banner_custom_url');
            const salePct = document.getElementById('sale-percent-group');
            const linkLabel = document.getElementById('link-label');

            categorySelect.parentElement.style.display = 'none';
            customUrl.parentElement.style.display = 'none';
            salePct.style.display = 'none';
            customUrl.removeAttribute('required');
            categorySelect.removeAttribute('required');

            if (linkType === 'sales') {
                salePct.style.display = 'block';
                linkLabel.textContent = '(Опционално)';
            } else if (linkType === 'category') {
                categorySelect.parentElement.style.display = 'block';
                categorySelect.setAttribute('required', 'required');
                linkLabel.textContent = 'Избор категория *';
            } else if (linkType === 'custom') {
                customUrl.parentElement.style.display = 'block';
                customUrl.setAttribute('required', 'required');
                linkLabel.textContent = 'URL адрес *';
            }
        }

        function submitAddBanner(event) {
            event.preventDefault();
            
            const formData = new FormData();
            const imageFile = document.getElementById('image_input').files[0];
            const linkType = document.getElementById('banner_link_type').value;
            
            if (!imageFile) {
                showMessage('Моля изберете изображение', 'error');
                return;
            }

            let linkValue = '';
            if (linkType === 'sales') {
                linkValue = '';
            } else if (linkType === 'category') {
                linkValue = document.getElementById('banner_category_select').value;
                if (!linkValue) {
                    showMessage('Моля изберете категория', 'error');
                    return;
                }
            } else if (linkType === 'custom') {
                linkValue = document.getElementById('banner_custom_url').value;
                if (!linkValue) {
                    showMessage('Моля въведете URL адрес', 'error');
                    return;
                }
            }

            formData.append('image', imageFile);
            formData.append('link_type', linkType);
            formData.append('link_value', linkValue);
            
            if (linkType === 'sales') {
                const salePercent = document.getElementById('banner_sale_percent').value;
                if (salePercent) {
                    formData.append('sale_percent', salePercent);
                }
            }

            fetch('api/add_banner.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Банер добавен успешно!', 'success');
                    document.getElementById('add-banner-form').reset();
                    document.getElementById('file-name').textContent = 'Избран файл: няма';
                    loadBanners();
                } else {
                    showMessage(data.message || 'Грешка при добавяне на банер', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Грешка при добавяне на банер: ' + error.message, 'error');
            });
        }

        function toggleBannerActive(id, currentActive) {
            const formData = new FormData();
            formData.append('id', id);
            formData.append('is_active', currentActive ? 0 : 1);

            fetch('api/update_banner.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(currentActive ? 'Банер деактивиран' : 'Банер активиран', 'success');
                    loadBanners();
                } else {
                    showMessage(data.message || 'Грешка при обновяване', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Грешка: ' + error.message, 'error');
            });
        }

        function deleteBanner(id) {
            if (confirm('Сигурни ли сте, че искате да изтриете този банер?')) {
                const formData = new FormData();
                formData.append('id', id);

                fetch('api/delete_banner.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('Банер изтрит успешно!', 'success');
                        loadBanners();
                    } else {
                        showMessage(data.message || 'Грешка при изтриване', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Грешка: ' + error.message, 'error');
                });
            }
        }

        function getLinkTypeText(linkType, linkValue, salePercent) {
            if (linkType === 'sales') {
                return `Продажби${salePercent > 0 ? ' (' + salePercent + '%)' : ''}`;
            } else if (linkType === 'category') {
                const cat = allCategories.find(c => c.id == linkValue);
                return cat ? 'Категория: ' + cat.name : 'Категория';
            } else if (linkType === 'custom') {
                return 'URL: ' + linkValue;
            }
            return linkType;
        }

        function showMessage(message, type = 'info') {
            const container = document.getElementById('message-container');
            const messageEl = document.createElement('div');
            messageEl.className = `message ${type}`;
            messageEl.textContent = message;
            container.innerHTML = '';
            container.appendChild(messageEl);
            
            setTimeout(() => {
                messageEl.remove();
            }, 5000);
        }

        function logout() {
            if (confirm('Сигурни ли сте, че искате да се отявите?')) {
                window.location.href = 'api/logout.php';
            }
        }

        function htmlspecialchars(str) {
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }
    </script>
</body>
</html>
