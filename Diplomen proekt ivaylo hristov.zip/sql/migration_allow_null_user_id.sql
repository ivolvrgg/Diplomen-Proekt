-- Migration: Allow NULL user_id for guest orders
-- This allows guest users to place orders without having a user account

-- Drop the existing foreign key constraint
ALTER TABLE orders DROP FOREIGN KEY fk_order_user;

-- Modify user_id column to allow NULL
ALTER TABLE orders 
MODIFY COLUMN user_id INT(11) NULL;

-- Re-add the foreign key constraint with ON DELETE SET NULL
ALTER TABLE orders 
ADD CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL;

-- Also update cart table to support guest carts
ALTER TABLE cart DROP FOREIGN KEY fk_cart_user;

ALTER TABLE cart 
MODIFY COLUMN user_id INT(11) NULL;

ALTER TABLE cart 
ADD CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE;
