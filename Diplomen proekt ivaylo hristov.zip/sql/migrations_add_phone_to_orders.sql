-- Add phone column to orders table
ALTER TABLE orders ADD COLUMN phone VARCHAR(20) DEFAULT NULL;
