-- Add Stripe payment_intent_id column to orders table
ALTER TABLE orders ADD COLUMN payment_intent_id VARCHAR(255) NULL UNIQUE;

-- Add payment status tracking
ALTER TABLE orders ADD COLUMN stripe_payment_status VARCHAR(50) NULL DEFAULT 'pending';

-- Add an index for faster queries
CREATE INDEX idx_payment_intent_id ON orders(payment_intent_id);
CREATE INDEX idx_stripe_payment_status ON orders(stripe_payment_status);
