-- Migration to add profile_picture column to users table
-- Run this SQL in your database to enable profile picture uploads

ALTER TABLE `users` 
ADD COLUMN `profile_picture` VARCHAR(255) DEFAULT NULL AFTER `city`;
