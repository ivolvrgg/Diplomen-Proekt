-- Migration: Add expected arrival dates to orders table
-- This migration adds columns to track expected delivery date range for each order

ALTER TABLE orders 
ADD COLUMN expected_arrival_start DATE DEFAULT NULL AFTER updated_at,
ADD COLUMN expected_arrival_end DATE DEFAULT NULL AFTER expected_arrival_start;

-- Add index for faster queries
CREATE INDEX idx_orders_arrival_dates ON orders (expected_arrival_start, expected_arrival_end);
