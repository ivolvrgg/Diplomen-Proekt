-- Migration to add phone and city columns to users table
-- Run this SQL in your database to add missing columns

ALTER TABLE `users` 
ADD COLUMN `phone` VARCHAR(20) DEFAULT NULL AFTER `password_hash`,
ADD COLUMN `city` VARCHAR(80) DEFAULT NULL AFTER `phone`;
