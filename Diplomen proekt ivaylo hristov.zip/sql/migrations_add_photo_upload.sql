-- Migration to add binary photo storage columns to users table
-- This enables storing actual image data directly in the database
-- Run this SQL in your database to enable photo uploads

ALTER TABLE `users` 
ADD COLUMN `profile_picture_data` LONGBLOB DEFAULT NULL AFTER `profile_picture`,
ADD COLUMN `profile_picture_mime_type` VARCHAR(100) DEFAULT NULL AFTER `profile_picture_data`;

-- Optional: Add indexes for faster queries
ALTER TABLE `users` 
ADD INDEX `idx_user_profile_image` (`id`, `profile_picture_data`(100));
