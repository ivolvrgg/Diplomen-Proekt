-- Add ECONT office code column to orders table
ALTER TABLE orders ADD COLUMN econt_office_code VARCHAR(50) DEFAULT NULL AFTER delivery_office_id;
ALTER TABLE orders ADD COLUMN econt_selected_address VARCHAR(255) DEFAULT NULL AFTER econt_office_code;
