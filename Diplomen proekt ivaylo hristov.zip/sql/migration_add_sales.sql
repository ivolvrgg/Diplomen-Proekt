-- Add sales columns to products table (if they don't exist)
ALTER TABLE `products` ADD COLUMN `sale_price` DECIMAL(10,2) DEFAULT NULL AFTER `price`;
ALTER TABLE `products` ADD COLUMN `discount_percent` INT DEFAULT NULL AFTER `sale_price`;
