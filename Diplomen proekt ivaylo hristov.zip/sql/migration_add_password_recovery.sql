-- Add password recovery columns to users table
ALTER TABLE users ADD COLUMN reset_code VARCHAR(6) DEFAULT NULL AFTER password_hash;
ALTER TABLE users ADD COLUMN reset_code_expires DATETIME DEFAULT NULL AFTER reset_code;

-- Add index for faster lookup
CREATE INDEX idx_reset_code ON users(reset_code);
CREATE INDEX idx_reset_code_expires ON users(reset_code_expires);
