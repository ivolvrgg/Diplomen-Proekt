-- Create invoices table
CREATE TABLE IF NOT EXISTS invoices (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(50) UNIQUE NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('generated', 'sent', 'downloaded') NOT NULL DEFAULT 'generated',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` datetime DEFAULT NULL,
  `downloaded_at` datetime DEFAULT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add invoice_requested column to orders table
ALTER TABLE `orders` ADD COLUMN `invoice_requested` BOOLEAN DEFAULT FALSE;
