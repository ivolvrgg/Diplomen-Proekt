-- Speedy & Econt API Integration Database Setup
-- Run this migration to prepare the database for courier API integration

-- 1. Create/Update delivery_methods table
CREATE TABLE IF NOT EXISTS delivery_methods (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    cost DECIMAL(10, 2),
    min_days INT,
    max_days INT,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ensure the three delivery methods exist
INSERT IGNORE INTO delivery_methods (id, name, cost, min_days, max_days, is_active) VALUES
(1, 'Courier', 3.00, 3, 5, 1),
(2, 'Speedy', 4.99, 2, 4, 1),
(3, 'Econt', 3.00, 2, 3, 1);

-- 2. Create delivery_offices table
CREATE TABLE IF NOT EXISTS delivery_offices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    delivery_method_id INT NOT NULL,
    label VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    street VARCHAR(255),
    phone VARCHAR(20),
    working_hours VARCHAR(100),
    external_id VARCHAR(100),
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (delivery_method_id) REFERENCES delivery_methods(id),
    INDEX idx_method_city (delivery_method_id, city),
    INDEX idx_active (is_active)
);

-- 3. Add required columns to orders table
ALTER TABLE orders ADD COLUMN IF NOT EXISTS external_shipment_id VARCHAR(100);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipment_status VARCHAR(50) DEFAULT 'pending';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipment_created_at TIMESTAMP NULL;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipment_updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP;

-- 4. Create shipment_logs table for tracking
CREATE TABLE IF NOT EXISTS shipment_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    external_shipment_id VARCHAR(100),
    delivery_method VARCHAR(50),
    status VARCHAR(50),
    location VARCHAR(255),
    description TEXT,
    raw_response JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    INDEX idx_order (order_id),
    INDEX idx_shipment (external_shipment_id)
);

-- 5. Create courier_settings table for API credentials
CREATE TABLE IF NOT EXISTS courier_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    courier_type VARCHAR(50),
    setting_key VARCHAR(100),
    setting_value TEXT,
    is_test TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_setting (courier_type, setting_key, is_test)
);

-- Sample configuration entries (UPDATE with your actual credentials)
INSERT IGNORE INTO courier_settings (courier_type, setting_key, setting_value, is_test) VALUES
('speedy', 'username', 'test_user', 1),
('speedy', 'password', 'test_pass', 1),
('speedy', 'customer_code', '9999', 1),
('speedy', 'api_url', 'https://test.speedy.bg/webservices/v2_0/Shipment.asmx', 1),
('econt', 'username', 'test_user', 1),
('econt', 'password', 'test_pass', 1),
('econt', 'client_system_id', 'test_system', 1),
('econt', 'api_url', 'https://api-test.econt.com/v1', 1);
