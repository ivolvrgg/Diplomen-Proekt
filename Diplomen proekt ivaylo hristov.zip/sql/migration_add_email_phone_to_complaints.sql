-- Add email and phone columns to complaints table
ALTER TABLE complaints 
ADD COLUMN email VARCHAR(255) NOT NULL DEFAULT '' AFTER user_id,
ADD COLUMN phone VARCHAR(20) NOT NULL DEFAULT '' AFTER email;
