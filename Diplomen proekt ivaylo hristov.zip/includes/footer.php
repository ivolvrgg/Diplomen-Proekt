    <footer class="footer-section">
        <div class="footer-top">
            <div class="footer-branding">
                <h3>Dronche.BG</h3>
                <div class="footer-social-links">
                    <a href="https://www.facebook.com"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://www.instagram.com"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.youtube.com"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>

        <div class="footer-content">
            <div class="footer-column">
                <h4>За Dronche.BG</h4>
                <ul>
                    <li><a href="homepage.php">Начало</a></li>
                    <li><a href="about.php">За нас</a></li>
                    
                </ul>
            </div>

            <div class="footer-column">
                <h4>Магазин</h4>
                <ul>
                    <li><a href="category-products.php?id=1">Дронове</a></li>
                    <li><a href="category-products.php?id=2">RC Самолети</a></li>
                    <li><a href="category-products.php?id=3">RC Лодки</a></li>
                    <li><a href="category-products.php?id=4">RC Коли</a></li>
                    <li><a href="category-products.php?id=5">Батерии</a></li>
                    <li><a href="category-products.php?id=6">Джойстици</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h4>Помощ и поддръжка</h4>
                <ul>
                    <li><a href="faq.php">Често задавани въпроси</a></li>
                    <li><a href="contact.php">Контакти</a></li>
                    <li><a href="complaints.php">Подай оплакване</a></li>
                    <li><a href="privacy-policy.php">Политика за лични данни</a></li>
                </ul>
            </div>

            <div class="footer-column footer-contact">
                <h4>Контактна информация</h4>
                <p><strong>Адрес:</strong> България, Варна</p>
                <p><strong>Телефон:</strong> +359 884 597 448</p>
                <p><strong>Email:</strong> dronchebg@gmail.com</p>
            </div>
        </div>

        <div class="copyright-area">
            <p>&copy; Dronche.BG | Всички права запазени | <a href="privacy-policy.php">Политика за лични данни</a></p>
        </div>
    </footer>
