<?php
/**
 * Speedy Service - DEPRECATED
 * This file is no longer used. Speedy has been removed from the system.
 * All shipments now use ECONT or courier delivery methods.
 */

class SpeedyService {
    public function __construct() {
        throw new Exception('Speedy service has been disabled. Use ECONT or courier delivery methods instead.');
    }
}
?>
