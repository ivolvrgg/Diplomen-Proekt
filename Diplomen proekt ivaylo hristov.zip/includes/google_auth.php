<?php
// Helper functions for Google OAuth (using native cURL, no dependencies needed)

function getGoogleAuthUrl() {
    include_once __DIR__ . '/../config/google.php';
    
    $params = [
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'response_type' => 'code',
        'scope' => 'openid email profile',
        'access_type' => 'offline'
    ];
    
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
}
