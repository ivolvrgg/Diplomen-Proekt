
    <nav>
        <div class="logo">
            <a href="homepage.php" style="text-decoration: none; color: inherit;">
                <p>DRONCHE.BG</p>
            </a>
        </div>
        
        <div class="search-bar">
            <input type="text" placeholder="Търси продукти..." class="search-input" autocomplete="off">
            <button class="search-btn" aria-label="Търси"><i class="fas fa-search"></i></button>
            <div class="search-dropdown" id="searchDropdown"></div>
        </div>
        
        <button class="mobile-menu-toggle" aria-label="Меню">☰</button>
        
        <ul class="menu">
            <li><a href="homepage.php">НАЧАЛНА СТРАНИЦА</a></li>
            <li class="dropdown">
                <button class="dropdown-btn">КАТАЛОГ <i class="fas fa-chevron-down"></i></button>
                <div class="dropdown-content">
                    <a href="category-products.php?id=1">Дронове</a>
                    <a href="category-products.php?id=2">RC Самолети</a>
                    <a href="category-products.php?id=3">RC Лодки</a>
                    <a href="category-products.php?id=4">RC Коли</a>
                    <a href="category-products.php?id=5">Батерии</a>
                    <a href="category-products.php?id=6">Джойстици</a>
                </div>
            </li>
            <li class="cart-link-container">
                <a href="cart.php">
                    <i class="fas fa-shopping-cart"></i> КОЛИЧКА
                    <span class="cart-badge" id="cart-badge" style="display: none;">0</span>
                </a>
            </li>
            <li><a href="profile.php"><i class="fas fa-user-circle"></i> ПРОФИЛ</a></li>
            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
            <li><a href="admin.php" style="color: #DBF227; font-weight: bold;"><i class="fas fa-cog"></i> АДМИН ПАНЕЛ</a></li>
            <?php endif; ?>
        </ul>
    </nav>
