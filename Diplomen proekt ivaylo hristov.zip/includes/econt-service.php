<?php
/**
 * ECONT Courier Service
 * Simple, clean integration with ECONT API
 * Credentials: dronchebg@gmail.com / Test1234
 */

class EcontService {
    
    private $username;
    private $password;
    private $api_url;
    private $auth_token;
    
    public function __construct() {
        // ECONT API Credentials
        $this->username = 'dronchebg@gmail.com';
        $this->password = 'Test1234';
        $this->api_url = 'https://api.econt.com/v1';
        $this->auth_token = base64_encode($this->username . ':' . $this->password);
    }
    
    /**
     * Get all ECONT offices
     */
    public function getOffices($city = null) {
        try {
            // ECONT API accepts multiple endpoint formats
            // Try GET /locations first (without /v1)
            $endpoint = '/locations';
            $params = [
                'countryCode' => 'BG',
                'pageIndex' => 0,
                'pageSize' => 500
            ];
            
            if ($city) {
                $params['city'] = $city;
            }
            
            $response = $this->makeRequest('GET', $endpoint, ['query' => $params]);
            
            // If endpoint returned nothing, try alternative endpoint
            if (!$response) {
                error_log('First endpoint failed, trying alternative...');
                $endpoint = '/offices/list';
                $response = $this->makeRequest('GET', $endpoint, ['query' => $params]);
            }
            
            if (!$response) {
                throw new Exception('No response from API');
            }
            
            // Parse response - handle different response formats
            $offices = [];
            
            // Try different response formats ECONT might use
            $locationData = $response['locations'] ?? $response['offices'] ?? $response['data'] ?? [];
            
            if (is_array($locationData) && !empty($locationData)) {
                foreach ($locationData as $location) {
                    $offices[] = [
                        'id' => $location['id'] ?? $location['poiId'] ?? null,
                        'name' => $location['name'] ?? 'ECONT Office',
                        'city' => $location['city'] ?? '',
                        'address' => $location['address'] ?? '',
                        'phone' => $location['phone'] ?? '',
                        'working_hours' => $this->getWorkingHours($location),
                        'timezone' => $location['timezone'] ?? 'Europe/Sofia'
                    ];
                }
            }
            
            return [
                'success' => !empty($offices),
                'offices' => $offices,
                'count' => count($offices),
                'raw_response' => $response
            ];
            
        } catch (Exception $e) {
            error_log('ECONT getOffices Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'offices' => []
            ];
        }
    }
    
    /**
     * Get office by ID
     */
    public function getOfficeById($officeId) {
        try {
            $endpoint = '/locations/' . urlencode($officeId);
            $response = $this->makeRequest('GET', $endpoint);
            
            if ($response && isset($response['location'])) {
                $loc = $response['location'];
                return [
                    'success' => true,
                    'office' => [
                        'id' => $loc['id'] ?? $loc['poiId'] ?? null,
                        'name' => $loc['name'] ?? '',
                        'city' => $loc['city'] ?? '',
                        'address' => $loc['address'] ?? '',
                        'phone' => $loc['phone'] ?? '',
                        'working_hours' => $this->getWorkingHours($loc)
                    ]
                ];
            }
            
            throw new Exception('Office not found');
            
        } catch (Exception $e) {
            error_log('ECONT getOfficeById Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Create shipment
     */
    public function createShipment($shipmentData) {
        try {
            $endpoint = '/shipments/create';
            $payload = $this->buildShipmentPayload($shipmentData);
            
            $response = $this->makeRequest('POST', $endpoint, $payload);
            
            if ($response && isset($response['shipmentNumber'])) {
                return [
                    'success' => true,
                    'shipment_number' => $response['shipmentNumber'],
                    'label_number' => $response['shipmentNumber'],
                    'response' => $response
                ];
            }
            
            throw new Exception($response['message'] ?? 'Failed to create shipment');
            
        } catch (Exception $e) {
            error_log('ECONT createShipment Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get shipment status
     */
    public function getShipmentStatus($shipmentNumber) {
        try {
            $endpoint = '/shipments/' . urlencode($shipmentNumber) . '/status';
            $response = $this->makeRequest('GET', $endpoint);
            
            return [
                'success' => true,
                'status' => $response,
                'shipment_number' => $shipmentNumber
            ];
            
        } catch (Exception $e) {
            error_log('ECONT getShipmentStatus Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Make HTTP request to ECONT API
     */
    private function makeRequest($method, $endpoint, $data = null) {
        try {
            // Try without /v1 first (in case API structure changed)
            $url = $this->api_url . $endpoint;
            
            // If URL still has /v1 and we already added it, try without
            if (strpos($url, '/v1/v1') !== false) {
                $url = str_replace('/v1/v1', '/v1', $url);
            }
            
            // Add query parameters if GET request
            if ($method === 'GET' && $data && isset($data['query'])) {
                $url .= '?' . http_build_query($data['query']);
            }
            
            // Debug log
            error_log("ECONT Request: $method $url");
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            
            // Set authentication header
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $this->username . ':' . $this->password);
            
            // Set method and data
            if ($method === 'POST') {
                curl_setopt($ch, CURLOPT_POST, true);
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            } elseif ($method === 'PUT') {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            }
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            // Log detailed info
            $logMsg = "ECONT API Call - URL: $url | HTTP Code: $http_code | cURL Error: " . ($error ?: 'none');
            error_log($logMsg);
            
            if ($error) {
                throw new Exception('cURL Error: ' . $error);
            }
            
            if ($http_code >= 400) {
                throw new Exception("API Error ($http_code): " . substr($response, 0, 500));
            }
            
            $result = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON response: ' . json_last_error_msg());
            }
            
            return $result;
            
        } catch (Exception $e) {
            $errorMsg = 'ECONT API Request Error: ' . $e->getMessage();
            error_log($errorMsg);
            file_put_contents('econt_error.log', date('Y-m-d H:i:s') . ' - ' . $errorMsg . "\n", FILE_APPEND);
            return null;
        }
    }
    
    /**
     * Get working hours from location data
     */
    private function getWorkingHours($location) {
        if (isset($location['workingHours'])) {
            return $location['workingHours'];
        }
        
        // Default working hours
        return [
            'Monday' => '08:00-18:00',
            'Tuesday' => '08:00-18:00',
            'Wednesday' => '08:00-18:00',
            'Thursday' => '08:00-18:00',
            'Friday' => '08:00-18:00',
            'Saturday' => '09:00-14:00',
            'Sunday' => 'Closed'
        ];
    }
    
    /**
     * Build shipment payload for API
     */
    private function buildShipmentPayload($data) {
        return [
            'shipment' => [
                'shipmentNumber' => $data['shipment_number'] ?? '',
                'shipmentType' => 'BOX',
                'weight' => floatval($data['weight'] ?? 0),
                'parcelCount' => intval($data['parcel_count'] ?? 1),
                'shipper' => [
                    'name' => $data['shipper_name'] ?? '',
                    'email' => $data['shipper_email'] ?? '',
                    'phone' => $data['shipper_phone'] ?? '',
                    'address' => $data['shipper_address'] ?? '',
                    'city' => $data['shipper_city'] ?? '',
                    'postalCode' => $data['shipper_postal'] ?? '',
                    'countryCode' => 'BG'
                ],
                'recipient' => [
                    'name' => $data['recipient_name'] ?? '',
                    'email' => $data['recipient_email'] ?? '',
                    'phone' => $data['recipient_phone'] ?? '',
                    'address' => $data['recipient_address'] ?? '',
                    'city' => $data['recipient_city'] ?? '',
                    'postalCode' => $data['recipient_postal'] ?? '',
                    'countryCode' => 'BG'
                ],
                'specialServices' => $data['special_services'] ?? [],
                'content' => $data['content_description'] ?? 'Package'
            ]
        ];
    }
}
