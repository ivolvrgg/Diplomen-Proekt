<?php
// Include auth check
include 'includes/auth_check.php';

// Display appropriate navbar based on login status
if (is_logged_in()) {
    include 'includes/navbar_logged.php';
} else {
    include 'includes/navbar.php';
}
?>
