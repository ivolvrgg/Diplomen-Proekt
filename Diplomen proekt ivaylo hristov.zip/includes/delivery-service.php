<?php
/**
 * Abstract Delivery Service Class
 * Base class for all courier integrations
 */

abstract class DeliveryService {
    
    protected $is_test = true;
    protected $logger = null;
    
    public function __construct() {
        $this->is_test = (getenv('COURIER_ENV') !== 'production');
        $this->logger = $this->getLogger();
    }
    
    /**
     * Get logger for courier requests
     */
    protected function getLogger() {
        $log_dir = __DIR__ . '/../logs';
        if (!is_dir($log_dir)) {
            mkdir($log_dir, 0755, true);
        }
        return $log_dir;
    }
    
    /**
     * Log API request/response
     */
    protected function log($action, $data, $response = null) {
        $log_file = $this->logger . '/courier_' . date('Y-m-d') . '.log';
        $timestamp = date('Y-m-d H:i:s');
        
        $log_content = "[$timestamp] {$action}\n";
        $log_content .= "Request: " . json_encode($data) . "\n";
        if ($response !== null) {
            $log_content .= "Response: " . json_encode($response) . "\n";
        }
        $log_content .= str_repeat("-", 80) . "\n";
        
        file_put_contents($log_file, $log_content, FILE_APPEND);
    }
    
    /**
     * Validate required fields
     */
    protected function validateFields($data, $required_fields) {
        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }
    }
    
    /**
     * Format response
     */
    protected function response($success, $message, $data = null) {
        return [
            'success' => $success,
            'message' => $message,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Abstract methods that must be implemented
     */
    abstract public function getOffices($city = null);
    abstract public function createShipment($shipment_data);
    abstract public function getTracking($shipment_id);
    abstract public function calculateDelivery($from_city, $to_city, $weight = 1);
}

/**
 * Factory to get correct courier service
 */
class DeliveryServiceFactory {
    
    public static function getService($courier_type) {
        switch (strtolower($courier_type)) {
            case 'speedy':
                return new SpeedyService();
            case 'econt':
                return new EcontService();
            case 'courier':
                return new CourierService();
            default:
                throw new Exception('Unknown courier type: ' . $courier_type);
        }
    }
}

/**
 * Local Courier (Home Delivery) Service
 */
class CourierService extends DeliveryService {
    
    public function __construct() {
        parent::__construct();
    }
    
    public function getOffices($city = null) {
        return $this->response(true, 'Home delivery available', [
            'offices' => [
                [
                    'id' => 1,
                    'name' => 'Home Delivery',
                    'city' => $city ?: 'Bulgaria',
                    'phone' => '+359 1 123 45 67',
                    'hours' => '08:00 - 18:00'
                ]
            ]
        ]);
    }
    
    public function createShipment($shipment_data) {
        // For home delivery, just validate address
        $required = ['recipient_name', 'recipient_phone', 'city', 'street'];
        $this->validateFields($shipment_data, $required);
        
        $this->log('CREATE_SHIPMENT', $shipment_data);
        
        return $this->response(true, 'Shipment created for home delivery', [
            'shipment_id' => 'HOME_' . time(),
            'method' => 'courier',
            'status' => 'pending'
        ]);
    }
    
    public function getTracking($shipment_id) {
        return $this->response(true, 'Tracking info', [
            'shipment_id' => $shipment_id,
            'status' => 'in_transit',
            'location' => 'Sofia Regional Center',
            'last_update' => date('Y-m-d H:i:s')
        ]);
    }
    
    public function calculateDelivery($from_city, $to_city, $weight = 1) {
        return [
            'cost' => 3.00,
            'min_days' => 1,
            'max_days' => 5
        ];
    }
}
