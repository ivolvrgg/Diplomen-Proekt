<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        $logged_in = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
        if (!$logged_in && strpos($_SERVER['REQUEST_URI'] ?? '', 'profile.php') !== false) {
            file_put_contents(__DIR__ . '/../logs/session_debug.log', "[" . date('Y-m-d H:i:s') . "] is_logged_in() = false. Session user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') . "\n", FILE_APPEND);
        }
        return $logged_in;
    }
}

// Get current user ID
if (!function_exists('get_user_id')) {
    function get_user_id() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
    }
}

// Get current user name
if (!function_exists('get_user_name')) {
    function get_user_name() {
        return isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
    }
}

// Get current user email
if (!function_exists('get_user_email')) {
    function get_user_email() {
        return isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
    }
}

// Require login - redirect if not logged in
if (!function_exists('require_login')) {
    function require_login() {
        $logged_in = is_logged_in();
        file_put_contents(__DIR__ . '/../logs/require_login.log', 
            "[" . date('Y-m-d H:i:s') . "] require_login() called. is_logged_in() = " . ($logged_in ? 'TRUE' : 'FALSE') . 
            ", user_id = " . ($_SESSION['user_id'] ?? 'NOT SET') . "\n", FILE_APPEND);
        
        if (!$logged_in) {
            file_put_contents(__DIR__ . '/../logs/require_login.log', "[" . date('Y-m-d H:i:s') . "] NOT LOGGED IN - redirecting to user_login.php\n", FILE_APPEND);
            header('Location: user_login.php');
            exit;
        }
        file_put_contents(__DIR__ . '/../logs/require_login.log', "[" . date('Y-m-d H:i:s') . "] LOGGED IN - continuing\n", FILE_APPEND);
    }
}

// Redirect if already logged in
if (!function_exists('require_logout')) {
    function require_logout() {
        if (is_logged_in()) {
            header('Location: homepage.php');
            exit;
        }
    }
}
