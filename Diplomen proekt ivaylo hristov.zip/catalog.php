<?php
$page_title = 'Dronche.BG - Каталог';
$page_css = 'css/catalog.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <?php
        // Check if this is a sales filter request
        $show_sales_only = isset($_GET['sale']) && $_GET['sale'] == 1;
        $discount_filter = isset($_GET['discount']) ? intval($_GET['discount']) : 0;
        ?>
        
        <section class="catalog-header">
            <div class="container">
                <h1><?php echo $show_sales_only ? 'Продукти на Намаление' : 'Каталог'; ?></h1>
                <p><?php echo $show_sales_only ? 'Вижте всички продукти на намаление' : 'Избирете категория, за да видите всички продукти'; ?></p>
            </div>
        </section>
        
        <?php if ($show_sales_only && $discount_filter > 0): ?>
        <!-- Sales Products View -->
        <section class="category-products">
            <div class="container">
                <div class="products-wrapper">
                    <!-- Filter Sidebar -->
                    <aside class="filters-sidebar">
                        <div class="filter-header">
                            <h3>Филтри</h3>
                            <button class="filter-toggle-mobile" id="filterToggleMobile">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>

                        <!-- Price Range Filter -->
                        <div class="filter-group">
                            <h4>Цена</h4>
                            <div class="price-filter">
                                <input type="range" min="0" max="5000" value="5000" class="price-slider" id="priceSlider">
                                <div class="price-display">
                                    <span>0 €</span> - <span id="priceValue">5000</span> €
                                </div>
                            </div>
                        </div>

                        <!-- Stock Filter -->
                        <div class="filter-group">
                            <h4>Наличност</h4>
                            <label class="filter-checkbox">
                                <input type="checkbox" value="inStock" class="stock-filter">
                                <span>Само на склад</span>
                            </label>
                        </div>

                        <!-- Sort Filter -->
                        <div class="filter-group">
                            <h4>Сортиране</h4>
                            <select id="sortSelect" class="sort-select">
                                <option value="name-asc">Име (А-Я)</option>
                                <option value="name-desc">Име (Я-А)</option>
                                <option value="price-asc">Цена (ниска-висока)</option>
                                <option value="price-desc">Цена (висока-ниска)</option>
                            </select>
                        </div>

                        <button class="filter-reset" id="resetFilters">Изчисти филтрите</button>
                    </aside>

                    <!-- Products Grid -->
                    <div class="products-section">
                        <div class="products-grid">
                            <?php
                            // Debug: Show parameters
                            error_log("Sales Filter Debug - sale: " . $_GET['sale'] . ", discount: " . $_GET['discount']);
                            
                            // Get products on sale with discount <= the specified percent
                            // Changed to use >= instead of <= because we want products with UP TO X% discount
                            $query = "SELECT id, name, price, sale_price, image_1, stock FROM products 
                                     WHERE is_active = 1 
                                     AND sale_price > 0
                                     AND sale_price < price
                                     ORDER BY name ASC";
                            
                            $result = $conn->query($query);
                            
                            if ($result && $result->num_rows > 0) {
                                $filtered_products = array();
                                
                                // Filter on PHP side to get discount percentage
                                while ($product = $result->fetch_assoc()) {
                                    $discount_percent = round(((($product['price'] - $product['sale_price']) / $product['price']) * 100));
                                    
                                    // Only include products with discount <= the filter
                                    if ($discount_percent <= $discount_filter) {
                                        $product['discount_percent'] = $discount_percent;
                                        $filtered_products[] = $product;
                                    }
                                }
                                
                                if (count($filtered_products) > 0) {
                                    echo "<p style='margin-bottom: 20px; grid-column: 1/-1;'>Продукти на намаление до <strong>" . $discount_filter . "%</strong> - Намерени <strong>" . count($filtered_products) . "</strong> продукт(и)</p>";
                                    
                                    foreach ($filtered_products as $product) {
                                        $image = $product['image_1'] ?: 'https://via.placeholder.com/300x300?text=No+Image';
                            ?>
                                <div class="product-card" data-price="<?php echo $product['sale_price']; ?>" data-stock="<?php echo $product['stock']; ?>" data-name="<?php echo htmlspecialchars($product['name']); ?>">
                                    <div class="product-image-wrapper">
                                        <div class="product-discount-badge"><?php echo $product['discount_percent']; ?>%</div>
                                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                                        <div class="product-overlay">
                                            <a href="itempage.php?id=<?php echo $product['id']; ?>" class="view-details-btn">Детайли</a>
                                        </div>
                                    </div>
                                    
                                    <div class="product-info">
                                        <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                                        <div class="product-price">
                                            <span class="original-price">€<?php echo number_format($product['price'], 2); ?></span>
                                            <span class="sale-price">€<?php echo number_format($product['sale_price'], 2); ?></span>
                                        </div>
                                        <button class="add-to-cart-btn" onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>')">
                                            <i class="fas fa-shopping-cart"></i> В количката
                                        </button>
                                    </div>
                                </div>
                            <?php
                                    }
                                } else {
                                    echo "<p style='grid-column: 1/-1; text-align: center; padding: 40px 20px;'>Няма продукти на намаление до " . htmlspecialchars($discount_filter) . "%</p>";
                                }
                            } else {
                                echo "<p style='grid-column: 1/-1; text-align: center; padding: 40px 20px;'>Няма продукти на намаление</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php else: ?>
        <!-- Categories View -->
        <section class="categories-showcase">
            <div class="container">
                <div class="categories-grid">
                    <?php
                    // Get all categories
                    $categories_query = "SELECT c.*, COUNT(p.id) as product_count FROM categories c 
                                       LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
                                       GROUP BY c.id
                                       ORDER BY c.sort_order ASC";
                    $categories_result = $conn->query($categories_query);
                    
                    if ($categories_result && $categories_result->num_rows > 0) {
                        while ($category = $categories_result->fetch_assoc()) {
                            // Get first product image from category for thumbnail using prepared statement
                            $thumb_query = "SELECT image_1 FROM products WHERE category_id = ? AND is_active = 1 LIMIT 1";
                            $thumb_stmt = $conn->prepare($thumb_query);
                            
                            if ($thumb_stmt) {
                                $thumb_stmt->bind_param("i", $category['id']);
                                $thumb_stmt->execute();
                                $thumb_result = $thumb_stmt->get_result();
                                $thumb_product = $thumb_result->fetch_assoc();
                                $thumb_image = $thumb_product['image_1'] ?? 'https://via.placeholder.com/400x300?text=' . urlencode($category['name']);
                                $thumb_stmt->close();
                            } else {
                                $thumb_image = 'https://via.placeholder.com/400x300?text=' . urlencode($category['name']);
                            }
                    ?>
                    <div class="category-card">
                        <a href="category-products.php?id=<?php echo $category['id']; ?>" class="category-link">
                            <img src="<?php echo htmlspecialchars($thumb_image); ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" class="category-image">
                            <div class="category-name"><?php echo htmlspecialchars($category['name']); ?></div>
                        </a>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>
