<?php
$page_title = 'Плащане | Dronche.BG';
$page_css = 'css/payment.css';
?>
<?php include 'includes/auth_check.php'; ?>
<?php include 'includes/head.php'; ?>
<?php include 'config/db.php'; ?>
<?php include 'config/stripe.php'; ?>
<?php
// Get Stripe publishable key from environment or use live key
$stripe_publishable_key = getenv('STRIPE_PUBLISHABLE_KEY');
if (!$stripe_publishable_key) {
    $stripe_publishable_key = 'pk_live_51T4KmZDXo0KK7clOQJfbBlILcdtjXTUpa5EBo9E8K0uEAfuhY2L8U9jbCuYRGMtcrTdD1xGf8BnRuor82AYhU4BM00cRGX2fNG';
}
?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content" class="payment-container">
        <div class="container">
            <h1 class="section-title">Плащане</h1>
            
            <div class="payment-content">
                <div class="order-summary">
                    <h2>Вашата поръчка</h2>
                    <div class="order-items" id="order-items">
                        <?php
                        $subtotal = 0;
                        $user_id = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                        
                        if ($user_id === 0) {
                            // Guest user - cart will be loaded from localStorage via JavaScript
                            if (!isset($_SESSION['guest_id'])) {
                                $_SESSION['guest_id'] = 'guest_' . substr(md5(session_id() . time()), 0, 16);
                            }
                            echo '<p><em>Зареждане на количката...</em></p>';
                        } else {
                            // Logged-in user - fetch from database using prepared statement
                            $db_user_id = $user_id;
                            
                            $cart_stmt = $conn->prepare("SELECT c.product_id, c.quantity, p.name, p.price, p.sale_price, p.discount_percent 
                                                         FROM cart c 
                                                         JOIN products p ON c.product_id = p.id 
                                                         WHERE c.user_id = ?");
                            $cart_stmt->bind_param("i", $db_user_id);
                            $cart_stmt->execute();
                            $cart_result = $cart_stmt->get_result();
                            $cart_stmt->close();
                            
                            if (!$cart_result) {
                                echo '<p style="color: red;">Възникна грешка при зареждане на количката. Грешка: ' . htmlspecialchars($conn->error) . '</p>';
                            } else if ($cart_result && $cart_result->num_rows > 0) {
                                while ($item = $cart_result->fetch_assoc()) {
                                    // Use sale price if available, otherwise use regular price
                                    $display_price = (!empty($item['sale_price']) && $item['sale_price'] > 0) ? $item['sale_price'] : $item['price'];
                                    $item_total = $display_price * $item['quantity'];
                                    $subtotal += $item_total;
                            ?>
                            <div class="order-item">
                                <span class="item-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                <span class="item-price"><?php echo number_format($display_price * $item['quantity'], 2); ?> €</span>
                            </div>
                            <?php
                                }
                            } else {
                                echo '<p>Вашата количка е празна. <a href="cart.php">Назад към количката</a></p>';
                            }
                        }
                        ?>
                    </div>
                    <div class="order-total">
                        <span>Подсума:</span>
                        <span class="subtotal-price"><?php echo number_format($subtotal, 2); ?> €</span>
                    </div>
                    <div class="order-total" style="margin-top: 0.5rem;">
                        <span>Доставка:</span>
                        <span class="delivery-price">3.00 €</span>
                    </div>
                    
                    <div class="order-total" style="margin-top: 1rem; border-top: 2px solid #588157; padding-top: 1rem;">
                        <span><strong>ОБЩО:</strong></span>
                        <span class="total-price"><strong><?php echo number_format(($subtotal) + 3, 2); ?> €</strong></span>
                    </div>
                </div>

                <form class="payment-form" id="payment-form">
                    <h2>Метод на плащане</h2>
                    
                    <div class="payment-methods">
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="card" checked>
                            <span class="payment-label">Плащане с карта</span>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment-method" value="cod">
                            <span class="payment-label">Наложен платеж</span>
                        </label>
                    </div>

                    <h2 style="margin-top: 2rem;">Начин на доставка</h2>
                    
                    <div class="delivery-methods">
                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="courier" class="delivery-radio" checked>
                                <span class="delivery-label">До адрес</span>
                            </label>
                            <div class="address-fields" style="display: block;">
                                <div class="address-field">
                                    <label for="city-input">Град</label>
                                    <input type="text" id="city-input" name="city" class="address-input" placeholder="Град">
                                </div>

                                <div class="address-field">
                                    <label for="street-input">Улица</label>
                                    <input type="text" id="street-input" name="street" class="address-input" placeholder="Улица">
                                </div>

                                <div class="address-field">
                                    <label for="block-input">Блок</label>
                                    <input type="text" id="block-input" name="block" class="address-input" placeholder="Номер на блок">
                                </div>

                                <div class="address-field">
                                    <label for="entrance-input">Вход</label>
                                    <input type="text" id="entrance-input" name="entrance" class="address-input" placeholder="Вход (А, Б, В и т.н.)">
                                </div>

                                <div class="address-field">
                                    <label for="apartment-input">Апартамент</label>
                                    <input type="text" id="apartment-input" name="apartment" class="address-input" placeholder="Номер на апартамент">
                                </div>
                            </div>
                        </div>
                        

                        <div class="delivery-option">
                            <label>
                                <input type="radio" name="delivery-method" value="econt" class="delivery-radio">
                                <span class="delivery-label">econt</span>
                            </label>
                            <div id="econt-delivery" class="delivery-select-wrapper" style="display: none;">
                                <div style="padding: 15px; background: #f0f8ff; border: 1px solid #0099cc; border-radius: 4px; margin-bottom: 15px;">
                                    <p style="margin: 0 0 10px 0; font-weight: bold; color: #0099cc;">ECONT Office Selection</p>
                                    <p style="margin: 0 0 15px 0; color: #333; font-size: 0.9em;">
                                        Select an office from the form below, or enter the office code manually.
                                    </p>
                                </div>
                                
                                <!-- ECONT Iframe for office selection -->
                                <iframe id="econt-iframe" src="" style="width: 100%; height: 600px; border: 1px solid #ddd; border-radius: 4px; background: white; margin-bottom: 15px;"></iframe>
                                
                                <input type="hidden" name="customerInfo[id]" id="customerInfo_id">
                                <input type="hidden" name="econt_office_code" id="econt_office_code">
                                <input type="hidden" name="econt_selected_address" id="econt_selected_address">
                                
                                <div id="econt-selected-info" style="margin-top: 10px; padding: 10px; background: #f5f5f5; border-radius: 5px; display: none;">
                                    <strong>✓ Selected office:</strong> <span id="econt-office-display"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                     
                    <h2 style="margin-top: 2rem;">Контактни данни</h2>
                    
                    <div class="form-group">
                        <label for="phone">Телефонен номер *</label>
                        <input type="tel" id="phone" name="phone" placeholder="+359 123 456 789" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Имейл за потвърждение <?php echo !is_logged_in() ? '*' : ''; ?></label>
                        <?php if (!is_logged_in()): ?>
                        <input type="email" id="email" name="email" placeholder="вашият@имейл.com" required>
                        <?php else: ?>
                        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>" disabled style="background-color: #f0f0f0; cursor: not-allowed;">
                        <?php endif; ?>
                    </div>

                    <h2 style="margin-top: 2rem;">Допълнителни опции</h2>
                    
                    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" id="invoice-checkbox" name="invoice_requested" value="1">
                        <label for="invoice-checkbox" style="margin: 0;">Искам да получа фактура по имейл</label>
                    </div>
                    
                    <button type="submit" class="btn-pay" id="submit-btn">Завърши поръчка</button>
                    <div id="form-message" style="margin-top: 1rem; display: none;"></div>
                </form>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    <script>
        // ECONT Configuration
        const ECONT_SHOP_ID = '8663581';
        const ECONT_DELIVERY_URL = 'https://delivery.econt.com/customer_info.php';
        
        // Load user's default address from database
        async function loadUserAddresses() {
            try {
                const response = await fetch('api/get_user_addresses.php');
                const data = await response.json();
                
                if (data.success && data.addresses && data.addresses.length > 0) {
                    // Find the default address or use the first one
                    const defaultAddress = data.addresses.find(addr => addr.is_default) || data.addresses[0];
                    
                    // Populate the address fields
                    document.getElementById('city-input').value = defaultAddress.city || '';
                    document.getElementById('street-input').value = defaultAddress.street || '';
                    document.getElementById('block-input').value = defaultAddress.block || '';
                    document.getElementById('entrance-input').value = defaultAddress.entrance || '';
                    document.getElementById('apartment-input').value = defaultAddress.apartment || '';
                    
                    console.log('✓ User address loaded:', defaultAddress);
                }
            } catch (error) {
                console.error('Error loading user address:', error);
            }
        }
        
        // Load guest cart items from localStorage and display them
        function loadGuestCartItems() {
            const orderItemsDiv = document.getElementById('order-items');
            if (!orderItemsDiv) return;

            // Check if this is for a guest user
            const isGuestContent = orderItemsDiv.textContent.includes('Зареждане на количката');
            if (!isGuestContent) return; // User is logged in, items already displayed

            // Get guest cart from localStorage
            const guestCartStr = localStorage.getItem('guest_cart');
            if (!guestCartStr) {
                orderItemsDiv.innerHTML = '<p>Вашата количка е празна. <a href="catalog.php">Назад към каталога</a></p>';
                return;
            }

            let guestCart = [];
            try {
                guestCart = JSON.parse(guestCartStr);
            } catch (e) {
                orderItemsDiv.innerHTML = '<p style="color: red;">Грешка при зареждане на количката</p>';
                return;
            }

            if (!Array.isArray(guestCart) || guestCart.length === 0) {
                orderItemsDiv.innerHTML = '<p>Вашата количка е празна. <a href="catalog.php">Назад към каталога</a></p>';
                return;
            }

            // Render cart items
            let html = '';
            let subtotal = 0;

            for (let item of guestCart) {
                const productId = item.product_id;
                const quantity = item.quantity || 1;
                const name = item.name || 'Product #' + productId;
                const price = parseFloat(item.price) || 0;
                const itemTotal = price * quantity;

                html += '<div class="order-item">';
                html += '  <span class="item-name">' + name + '</span>';
                html += '  <span class="item-price">' + itemTotal.toFixed(2) + ' €</span>';
                html += '</div>';

                subtotal += itemTotal;
            }

            orderItemsDiv.innerHTML = html;

            // Update subtotal and total
            const subtotalPriceEl = document.querySelector('.subtotal-price');
            const totalPriceEl = document.querySelector('.total-price');
            const deliveryPrice = 3.00;

            if (subtotalPriceEl) {
                subtotalPriceEl.textContent = subtotal.toFixed(2) + ' €';
                console.log('✓ Guest cart subtotal: ' + subtotal.toFixed(2));
            }

            if (totalPriceEl) {
                const total = subtotal + deliveryPrice;
                totalPriceEl.textContent = total.toFixed(2) + ' €';
                console.log('✓ Guest cart total: ' + total.toFixed(2));
            }

            console.log('✓ Guest cart items loaded:', guestCart.length, ', Subtotal: €' + subtotal.toFixed(2));
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Load guest cart items FIRST
            loadGuestCartItems();

            // Initialize form state - ensure ECONT section is hidden on load
            document.getElementById('econt-delivery').style.display = 'none';

            // Load user's default address if logged in
            <?php if (is_logged_in()): ?>
            loadUserAddresses();
            <?php endif; ?>

            // Delivery method toggle
            document.querySelectorAll('input[name="delivery-method"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    document.querySelectorAll('.delivery-select-wrapper, .address-fields')
                        .forEach(el => el.style.display = 'none');
                    
                    const opt = this.closest('.delivery-option');
                    if (opt) {
                        const section = opt.querySelector('.delivery-select-wrapper, .address-fields');
                        if (section) section.style.display = 'block';
                    }
                    
                    // Load ECONT iframe when selected
                    if (this.value === 'econt') {
                        loadEcontIframe();
                    }
                });
            });

            // Payment method toggle
            document.querySelectorAll('input[name="payment-method"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    const cardSection = document.getElementById('card-payment-section');
                    if (cardSection) cardSection.style.display = this.value === 'card' ? 'block' : 'none';
                });
            });
            
            // Listen for ECONT iframe messagesa
            window.addEventListener('message', handleEcontMessage, false);
            
            // Also log ALL messages to debug
            window.addEventListener('message', function(event) {
                console.log(' [ALL MESSAGES]', {
                    origin: event.origin,
                    data: event.data,
                    source: event.source === window.parent ? 'parent' : 'iframe'
                });
            }, false);

            // Form submission
            const form = document.getElementById('payment-form');
            const submitBtn = document.getElementById('submit-btn');
            const messageDiv = document.getElementById('form-message');

            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                console.log('Form submission started');
                
                // DEBUG: Log all radio button states
                console.log('Radio button states:');
                document.querySelectorAll('input[name="delivery-method"]').forEach(radio => {
                    console.log('  - ' + radio.value + ': ' + (radio.checked ? 'CHECKED ✓' : 'unchecked'));
                });

                const paymentMethod = document.querySelector('input[name="payment-method"]:checked')?.value;
                const deliveryMethod = document.querySelector('input[name="delivery-method"]:checked')?.value;
                const phone = document.getElementById('phone').value.trim();
                const emailInput = document.querySelector('input[name="email"]');
                const email = emailInput?.value.trim() || '<?php echo addslashes($_SESSION["user_email"] ?? ""); ?>';

                console.log('Form validation:');
                console.log('  Payment method:', paymentMethod);
                console.log('  Delivery method:', deliveryMethod);
                console.log('  Phone:', phone);
                console.log('  Email:', email);

                // Validation
                if (!phone || phone.replace(/\D/g, '').length < 10) {
                    showMessage('Моля, въведете валиден телефонен номер', 'error'); return;
                }
                if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    showMessage('Моля, въведете валиден имейл адрес', 'error'); return;
                }
                if (!deliveryMethod) {
                    showMessage('Моля, изберете начин на доставка', 'error'); return;
                }

                // Delivery-specific validation
                if (deliveryMethod === 'courier') {
                    const city = document.getElementById('city-input').value.trim();
                    const street = document.getElementById('street-input').value.trim();
                    if (!city || !street) {
                        showMessage('Моля, попълнете адреса за доставка', 'error'); return;
                    }
                } else if (deliveryMethod === 'econt') {
                    // Get office code from iframe
                    const officeCode = document.getElementById('econt_office_code').value.trim();
                    
                        console.log('ECONT validation:');
                        console.log('  Office code element:', document.getElementById('econt_office_code'));
                        console.log('  Office code value:', officeCode);
                        
                }

                // Build payload
                const formData = {
                    payment_method: paymentMethod,
                    delivery_method: deliveryMethod,
                    email: email,
                    phone: phone,
                    invoice_requested: document.getElementById('invoice-checkbox').checked ? 1 : 0
                };

                console.log('✓ formData built with delivery_method:', formData.delivery_method);

                if (deliveryMethod === 'courier') {
                    formData.city       = document.getElementById('city-input').value.trim();
                    formData.street     = document.getElementById('street-input').value.trim();
                    formData.block      = document.getElementById('block-input').value.trim();
                    formData.entrance   = document.getElementById('entrance-input').value.trim();
                    formData.apartment  = document.getElementById('apartment-input').value.trim();
                } else if (deliveryMethod === 'econt') {
                    formData.delivery_office_id      = document.getElementById('econt_office_code').value;
                    formData.econt_selected_address  = document.getElementById('econt_selected_address').value;
                    formData.econt_customer_id       = document.getElementById('customerInfo_id').value;
                    
                    console.log('ECONT formData constructed:');
                    console.log('  delivery_office_id:', formData.delivery_office_id);
                    console.log('  econt_selected_address:', formData.econt_selected_address);
                    console.log('  delivery_method:', formData.delivery_method);
                }

                // Guest cart
                const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
                if (!isLoggedIn) {
                    const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
                    if (guestCart.length === 0) {
                        showMessage('Вашата количка е празна', 'error'); 
                        return;
                    }
                    formData.cart = guestCart;
                    console.log('✓ Guest cart loaded:', guestCart);
                }

                submitBtn.disabled = true;
                submitBtn.textContent = 'Обработка...';
                console.log(' Form data to submit:', {
                    ...formData,
                    email: formData.email.substring(0, 5) + '***', // Show first 5 chars
                    phone: formData.phone.substring(0, 4) + '***'
                });
                
                // Validate required fields
                if (!formData.email) { showMessage('Имейл е задължителен', 'error'); submitBtn.disabled = false; submitBtn.textContent = 'Завърши поръчка'; return; }
                if (!formData.phone) { showMessage('Телефон е задължителен', 'error'); submitBtn.disabled = false; submitBtn.textContent = 'Завърши поръчка'; return; }
                if (deliveryMethod === 'econt' && !document.getElementById('econt_office_code').value) { 
                    showMessage('Моля, изберете ECONT офис', 'error'); 
                    submitBtn.disabled = false; 
                    submitBtn.textContent = 'Завърши поръчка'; 
                    return; 
                }

                try {
                    if (paymentMethod === 'card') {
                        const intentResponse = await fetch('api/create-payment-intent.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(formData)
                        });
                        const intentResult = await intentResponse.json();
                        console.log('Payment intent response:', intentResult);

                        if (!intentResult.success) {
                            showMessage('Грешка при плащане: ' + intentResult.message, 'error');
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Завърши поръчка';
                            return;
                        }
                        window.location.href = intentResult.checkout_url;

                    } else {
                        // Cash on delivery
                        console.log(' Sending COD order to api/orders.php...');
                        const orderResponse = await fetch('api/orders.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(formData)
                        });
                        
                        console.log('Response status:', orderResponse.status);
                        const responseText = await orderResponse.text();
                        console.log('Raw response:', responseText);
                        
                        let orderResult;
                        try {
                            orderResult = JSON.parse(responseText);
                        } catch (e) {
                            console.error('Failed to parse JSON:', e);
                            showMessage('Грешка при обработката на поръчката: Invalid response from server', 'error');
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Завърши поръчка';
                            return;
                        }
                        
                        console.log('✓ Order response:', orderResult);

                        if (!orderResult.success) {
                            showMessage(orderResult.message || 'Грешка при обработката на поръчката', 'error');
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Завърши поръчка';
                            return;
                        }

                        showMessage('Поръчката е успешно създадена! Ще получите потвърждение по имейл.', 'success');
                        localStorage.removeItem('guest_cart');
                        setTimeout(() => { window.location.href = orderResult.redirect_url; }, 1500);
                    }
                } catch (error) {
                    console.error(' Form submission error:', error);
                    console.error('Error stack:', error.stack);
                    showMessage('Грешка при свързване със сървъра: ' + error.message, 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Завърши поръчка';
                }
            });
        });

        // Load ECONT iframe with shop details
        function loadEcontIframe() {
            const iframeEl = document.getElementById('econt-iframe');
            if (!iframeEl) {
                console.error('iframe element not found');
                return;
            }
            
            console.log('Loading ECONT iframe...');
            
            // Get order data
            const totalText = document.querySelector('.total-price')?.textContent || '0 €';
            const totalValue = parseFloat(totalText.replace(/[^\d.]/g, '')) || 0;
            
            // Get current page's base URL for return/callback
            const returnUrl = window.location.origin + window.location.pathname;
            
            // Build iframe URL with required parameters
            const params = new URLSearchParams({
                id_shop: ECONT_SHOP_ID,
                order_total: totalValue.toFixed(2),
                order_currency: 'euro',
                order_weight: 1,
                customer_country: 'euro',
                return_url: returnUrl  // Tell ECONT where to send data back
            });
            
            const iframeUrl = ECONT_DELIVERY_URL + '?' + params.toString();
            console.log('📋 Loading from:', iframeUrl);
            iframeEl.src = iframeUrl;
            
            iframeEl.onload = () => console.log('✓ ECONT iframe loaded');
            iframeEl.onerror = () => console.error(' ECONT iframe failed to load');
        }

        // Handle messages from ECONT iframe when user selects office
        function handleEcontMessage(event) {
            console.log('==== MESSAGE RECEIVED ====');
            console.log('Full data object:', event.data);
            console.log('Data keys:', Object.keys(event.data));
            
            const data = event.data;
            if (!data || typeof data !== 'object') {
                console.log(' No valid data');
                return;
            }
            
            console.log('Processing ECONT data...');
            console.log('Raw data dump:');
            console.log('- address:', data.address);
            console.log('- street:', data.street);
            console.log('- office_address:', data.office_address);
            console.log('- street_name:', data.street_name);
            console.log('- office_street:', data.office_street);
            console.log('- city_name:', data.city_name);
            console.log('- post_code:', data.post_code);
            console.log('- officeCode:', data.officeCode);
            
            // ECONT sends city data, we'll generate office code from it
            let officeCode = data.officeCode || data.office_code;
            
            // If no office code, generate from city
            if (!officeCode && data.city_name) {
                const cityName = data.city_name.trim();
                const cityMap = {
                    'София': 'VN1',
                    'Варна': 'VA1',
                    'Плевен': 'PL1',
                    'Пловдив': 'PD1',
                    'Бургас': 'BU1',
                    'Рuse': 'RU1',
                    'Стара Загора': 'SZ1'
                };
                
                officeCode = cityMap[cityName] || cityName.substring(0, 2).toUpperCase() + '1';
                console.log('Generated office code from city:', officeCode);
            }
            
            if (!officeCode) {
                console.warn(' No office code available');
                return;
            }
            
            // Set the office code
            document.getElementById('econt_office_code').value = officeCode;
            console.log(' Set econt_office_code:', officeCode);
            
            // Set customer ID if available
            if (data.id) {
                document.getElementById('customerInfo_id').value = data.id;
                console.log('✓ Set customerInfo_id:', data.id);
            }
            
            // Build full address using office_name from ECONT
            const addressParts = [];
            
            // Use the office_name which includes the office code and location
            if (data.office_name) {
                addressParts.push(data.office_name);
            }
            
            // Add city if not already in office_name
            if (data.city_name && !data.office_name.includes(data.city_name)) {
                addressParts.push(data.city_name);
            }
            
            // Add postal code
            if (data.post_code) {
                addressParts.push(data.post_code);
            }
            
            const fullAddress = addressParts.join(', ');
            document.getElementById('econt_selected_address').value = fullAddress;
            console.log('✓ Set address:', fullAddress);
            console.log('Full ECONT data received:', data);
            
            // Show confirmation
            const displayEl = document.getElementById('econt-office-display');
            if (displayEl) {
                displayEl.textContent = fullAddress;
                document.getElementById('econt-selected-info').style.display = 'block';
            }
            
            console.log('✓ ECONT selection processed successfully');
            console.log('==== MESSAGE PROCESSED ====');
        }

        // Show message helper function
        function showMessage(message, type) {
            const messageDiv = document.getElementById('form-message');
            messageDiv.textContent = message;
            messageDiv.style.display = 'block';
            messageDiv.style.padding = '1rem';
            messageDiv.style.borderRadius = '4px';

            const styles = {
                error:   { color: '#d32f2f', background: '#ffebee', border: '1px solid #ef5350' },
                success: { color: '#388e3c', background: '#e8f5e9', border: '1px solid #66bb6a' },
                info:    { color: '#0277bd', background: '#e1f5fe', border: '1px solid #4fc3f7' }
            };
            const s = styles[type] || styles.info;
            messageDiv.style.color = s.color;
            messageDiv.style.backgroundColor = s.background;
            messageDiv.style.border = s.border;

            if (type === 'error') window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>
</html>
