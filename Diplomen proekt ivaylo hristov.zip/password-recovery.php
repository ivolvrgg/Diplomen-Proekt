<?php
$page_title = 'Възстановяване на парола - Dronche.BG';
$page_css = 'css/user_login.css';
?>
<?php include 'includes/auth_check.php'; ?>

<?php
// If user is already logged in, redirect to homepage
if (is_logged_in()) {
    header('Location: homepage.php');
    exit;
}
?>
<?php include 'includes/head.php'; ?>

    <?php include 'includes/navbar_selector.php'; ?>

    <main id="main-content">
        <div class="login-container">
            <div class="login-box">
                <h1 class="login-title">Възстановяване на Парола</h1>
                <p style="text-align: center; color: #666; margin-bottom: 20px;">Въведи своя email адрес и ще ти изпратим код за верификация</p>
                
                <form class="login-form" id="recoveryForm">
                    <div class="form-group">
                        <label for="recovery-email">Email адрес</label>
                        <input type="email" id="recovery-email" name="email" required placeholder="Въведи своя email">
                        <span class="error-message" id="emailError"></span>
                    </div>
                    
                    <button type="submit" class="login-btn">Изпрати Код</button>
                </form>
                
                <div class="signup-link">
                    <a href="user_login.php">← Обратно към Вход</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <?php include 'includes/scripts.php'; ?>
    <script>
        document.getElementById('recoveryForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('recovery-email').value;
            const emailError = document.getElementById('emailError');
            emailError.textContent = '';
            
            fetch('api/password-recovery.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'send_code', email: email })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Store email in session to use in reset page
                    sessionStorage.setItem('recovery_email', email);
                    // Redirect to reset page
                    window.location.href = 'password-reset.php';
                } else {
                    emailError.textContent = data.message || 'Възникна грешка. Опитай отново.';
                }
            })
            .catch(error => {
                emailError.textContent = 'Възникна грешка. Опитай отново.';
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
